<?php
/**
 * TCC page trail: the small "Home > Sermons > In Christ" line above a page's title.
 *
 * Why it exists:
 *   Ordinary pages get this line from Divi's own Breadcrumbs layer (a little house, then
 *   Home > Ministries > Men's Ministry). Divi's layer cannot work out the right trail on the
 *   Sermons page, a sermon series page, a sermon page or the search page, so each of those had its
 *   own hand-made line and they drifted apart. This feature prints one trail for all of them, made
 *   to look exactly like the Divi one on the rest of the site: same house icon, same teal links,
 *   same size, same spacing.
 *
 * How to use it:
 *   Put the short code [tcc_trail] alone in a Divi Text layer, above the page title. It works out
 *   the trail from the page being shown:
 *     the Sermons page        Home > Sermons
 *     a sermon series page    Home > Sermons > In Christ
 *     a sermon page           Home > Sermons > In Christ > Built Together
 *     the search page         Home > Search
 *     any other page          Home > (parent pages) > the page's title
 *   The older short code [tcc_sermon_crumbs] on the sermon page prints this same trail.
 *
 * Spacing is set in Divi, not here, so volunteers can see it: on the Text layer that holds the
 * trail, Spacing > Margin > Bottom is 10px (the gap before the title), the same as other pages.
 *
 * To change how the trail looks, change tcc_trail_css() below; every page that uses it follows.
 *
 * Part of the TCC Website Features plugin (added in 0.4.2, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_trail_shortcode' ) ) {

	/** A plain piece of text, safe to print (titles can hold HTML or codes like &amp;). */
	function tcc_trail_text( $text ) {
		return esc_html( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' ) );
	}

	/** The address and name of the Sermons page (the page WordPress lists posts on). */
	function tcc_trail_sermons() {
		$page_id = (int) get_option( 'page_for_posts' );
		$url     = $page_id ? (string) get_permalink( $page_id ) : '';
		$name    = $page_id ? (string) get_the_title( $page_id ) : '';
		return array(
			'' !== $url ? $url : home_url( '/sermons/' ),
			'' !== trim( $name ) ? $name : 'Sermons',
		);
	}

	/**
	 * The steps of the trail for the page being shown, after "Home".
	 * Each step is array( name, address ); the last step is the page itself and is not a link.
	 * A step with 'long' => true (a sermon's own title) is left off on phones, where it would wrap.
	 */
	function tcc_trail_steps() {
		$steps = array();

		if ( is_search() ) {
			$steps[] = array( 'Search', '' );
			return $steps;
		}

		list( $sermons_url, $sermons_name ) = tcc_trail_sermons();

		if ( is_home() ) {
			$steps[] = array( $sermons_name, '' );
			return $steps;
		}

		if ( is_category() ) {
			$term    = get_queried_object();
			$steps[] = array( $sermons_name, $sermons_url );
			if ( $term instanceof WP_Term ) {
				$steps[] = array( $term->name, '' );
			}
			return $steps;
		}

		if ( is_singular( 'post' ) ) {
			$id      = (int) get_queried_object_id();
			$steps[] = array( $sermons_name, $sermons_url );
			// The series comes from the "Sermon page" feature when it is switched on.
			if ( function_exists( 'tcc_sermon_page_series' ) ) {
				$series = tcc_sermon_page_series( $id );
				if ( is_array( $series ) && ! empty( $series['name'] ) ) {
					$steps[] = array( $series['name'], isset( $series['url'] ) ? (string) $series['url'] : '' );
				}
			}
			$title = function_exists( 'tcc_sermon_page_title' ) ? html_entity_decode( tcc_sermon_page_title( $id ), ENT_QUOTES, 'UTF-8' ) : get_the_title( $id );
			if ( '' !== trim( wp_strip_all_tags( (string) $title ) ) ) {
				$steps[] = array(
					$title,
					'',
					'long' => true,
				);
			}
			return $steps;
		}

		if ( is_singular() ) {
			$id = (int) get_queried_object_id();
			foreach ( array_reverse( get_post_ancestors( $id ) ) as $parent_id ) {
				$steps[] = array( get_the_title( $parent_id ), (string) get_permalink( $parent_id ) );
			}
			$steps[] = array( get_the_title( $id ), '' );
		}

		return $steps;
	}

	/** [tcc_trail]: the house icon, Home, and the steps to this page. */
	function tcc_trail_shortcode() {
		try {
			$steps = tcc_trail_steps();
			$sep   = '<span class="tcc-trail-sep" aria-hidden="true">&rsaquo;</span>';
			// The house is the same Divi icon the Breadcrumbs layer on other pages uses.
			$html  = '<span class="tcc-trail-home" aria-hidden="true">&#xe074;</span>';
			$html .= '<a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
			$last  = count( $steps ) - 1;
			foreach ( $steps as $at => $step ) {
				$name = tcc_trail_text( $step[0] );
				if ( '' === $name ) {
					continue;
				}
				if ( $at === $last || '' === (string) $step[1] ) {
					$piece = '<span class="tcc-trail-here"' . ( $at === $last ? ' aria-current="page"' : '' ) . '>' . $name . '</span>';
				} else {
					$piece = '<a href="' . esc_url( $step[1] ) . '">' . $name . '</a>';
				}
				$html .= '<span class="tcc-trail-step' . ( ! empty( $step['long'] ) ? ' tcc-trail-long' : '' ) . '">' . $sep . $piece . '</span>';
			}
			return '<nav class="tcc-trail" aria-label="Breadcrumb">' . $html . '</nav>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_trail', 'tcc_trail_shortcode' );

	/**
	 * How the trail looks. The numbers are measured from the Divi Breadcrumbs layer on ordinary
	 * pages (for example Men's Ministry), so the two cannot be told apart:
	 *   words 15px on a 26px line, links teal #00A4CF, the page itself dark grey #404041,
	 *   a 16px house 10px before "Home", and an 18px ">" with 14px either side.
	 * Links get an invisible 9px above and below so they are easy to press, without moving anything.
	 */
	function tcc_trail_css() {
		$css = 'Q{display:flex;flex-wrap:wrap;align-items:center;margin:0;padding:0;font:400 15px/26px "CMG Sans SemiBold",Helvetica,Arial,Lucida,sans-serif;letter-spacing:0;text-transform:none;color:#404041}'
			. 'Q .tcc-trail-home{flex:none;margin-right:10px;font:400 16px/16px ETmodules;color:#00A4CF}'
			. 'Q .tcc-trail-step{display:inline-flex;align-items:center}'
			. 'Q a{display:inline-block;margin:-9px 0;padding:9px 0;color:#00A4CF;text-decoration:none}'
			. 'Q a:hover{text-decoration:underline}'
			. 'Q a:focus-visible{outline:3px solid rgba(0,164,207,.45);outline-offset:2px}'
			. 'Q .tcc-trail-sep{margin:0 14px;font-size:18px;color:#404041}'
			. 'Q .tcc-trail-here{color:#404041}'
			// Phones: a sermon's own title is left off the trail (it is the page title just below).
			. '@media (max-width:767px){Q .tcc-trail-long{display:none}}';
		// A capital Q stands for the trail itself. It is written twice so the rules win over Divi's
		// own text styles whichever way Divi wraps the page.
		$out = '';
		foreach ( array( 'body nav.tcc-trail', '#page-container #et-boc nav.tcc-trail' ) as $start ) {
			$out .= preg_replace( '/(^|[},{])Q(?=[ {])/', '$1' . $start, $css );
		}
		return $out;
	}

	/** The styles go in the head of the page, so the trail never shows unstyled. */
	add_action(
		'wp_head',
		function () {
			if ( is_admin() ) {
				return;
			}
			echo '<style id="tcc-trail-css">' . tcc_trail_css() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed text written above.
		},
		30
	);
}
