<?php
/**
 * TCC page trail: the small back link above a page's title, an arrow and one name: "<- Events".
 *
 * What it shows:
 *   One link, back to the page above this one. A top-level page points back to Home. Nothing
 *   else: no "Home > Ministries > Men's Ministry" line any more (changed in 0.8.0, November 2026,
 *   at the owner's request, to keep the top of the page simple).
 *   Ordinary pages go one level up (to their Parent page). Sermons and Trinity Talk always go
 *   to the top of their part of the site, whatever series or book they are in (0.8.1).
 *     an event                       <- Events
 *     the Events page                <- Home
 *     a community group              <- Community Groups
 *     the Community Groups page      <- Home
 *     Men's Ministry                 <- Ministries
 *     a page two levels down         <- the page above it (The Blessed Life -> Core Classes Archive)
 *     a sermon, a series, a speaker  <- Sermons
 *     the Sermons page               <- Home
 *     a Trinity Talk piece or book   <- Trinity Talk
 *     the search page, anything else <- Home
 *
 * How to use it:
 *   Put the short code [tcc_trail] alone in a Divi Text layer, above the page title. It works out
 *   the link from the page being shown; nothing is typed in. The older short code
 *   [tcc_sermon_crumbs] on the sermon page prints this same link.
 *
 * Spacing is set in Divi, not here, so volunteers can see it: on the Text layer that holds the
 * link, Spacing > Margin > Bottom is 10px (the gap before the title).
 *
 * To change where a kind of page points back to, change tcc_trail_back() below.
 * To change how the link looks, change tcc_trail_css() below; every page that uses it follows.
 *
 * Part of the TCC Website Features plugin (added in 0.4.2, made a single back link in 0.8.0, pages one level up in 0.8.1, kept safe from WP Rocket in 0.8.2).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_trail_shortcode' ) ) {

	/** A plain piece of text, safe to print (titles can hold HTML or codes like &amp;). */
	function tcc_trail_text( $text ) {
		return esc_html( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' ) );
	}

	/** The address and name of the Sermons page (the page WordPress lists posts on). */
	function tcc_trail_sermons() {
		$page_id = (int) get_option( 'page_for_posts' );
		$url     = $page_id ? (string) get_permalink( $page_id ) : '';
		$name    = $page_id ? (string) get_the_title( $page_id ) : '';
		return array(
			'' !== $url ? $url : home_url( '/sermons/' ),
			'' !== trim( $name ) ? $name : 'Sermons',
		);
	}

	/**
	 * Where the page being shown sits: the steps from "Home" down to it.
	 * Each step is array( name, address ); the last step is the page itself.
	 * Only the first step is shown (see tcc_trail_back() below); the rest are worked out so that
	 * a page two or three levels down still finds its top-level page.
	 */
	function tcc_trail_steps() {
		$steps = array();

		// Trinity Talk pages: the "Trinity Talk pages" feature knows the book and the short title.
		if ( function_exists( 'tcc_talk_trail_steps' ) ) {
			$talk = tcc_talk_trail_steps();
			if ( is_array( $talk ) ) {
				return $talk;
			}
		}

		if ( is_search() ) {
			$steps[] = array( 'Search', '' );
			return $steps;
		}

		list( $sermons_url, $sermons_name ) = tcc_trail_sermons();

		if ( is_home() ) {
			$steps[] = array( $sermons_name, '' );
			return $steps;
		}

		if ( is_category() ) {
			$term    = get_queried_object();
			$steps[] = array( $sermons_name, $sermons_url );
			if ( $term instanceof WP_Term ) {
				$steps[] = array( $term->name, '' );
			}
			return $steps;
		}

		if ( is_singular( 'post' ) ) {
			$id      = (int) get_queried_object_id();
			$steps[] = array( $sermons_name, $sermons_url );
			// The series comes from the "Sermon page" feature when it is switched on.
			if ( function_exists( 'tcc_sermon_page_series' ) ) {
				$series = tcc_sermon_page_series( $id );
				if ( is_array( $series ) && ! empty( $series['name'] ) ) {
					$steps[] = array( $series['name'], isset( $series['url'] ) ? (string) $series['url'] : '' );
				}
			}
			$title = function_exists( 'tcc_sermon_page_title' ) ? html_entity_decode( tcc_sermon_page_title( $id ), ENT_QUOTES, 'UTF-8' ) : get_the_title( $id );
			if ( '' !== trim( wp_strip_all_tags( (string) $title ) ) ) {
				$steps[] = array(
					$title,
					'',
					'long' => true,
				);
			}
			return $steps;
		}

		if ( is_singular() ) {
			$id = (int) get_queried_object_id();
			foreach ( array_reverse( get_post_ancestors( $id ) ) as $parent_id ) {
				$steps[] = array( get_the_title( $parent_id ), (string) get_permalink( $parent_id ) );
			}
			$steps[] = array( get_the_title( $id ), '' );
		}

		return $steps;
	}

	/** A page of the site found by its address (for example "community-groups"): array( name, address ). */
	function tcc_trail_page( $path, $name ) {
		$page = get_page_by_path( $path );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			$title = trim( wp_strip_all_tags( (string) get_the_title( $page ) ) );
			return array( '' !== $title ? $title : $name, (string) get_permalink( $page ) );
		}
		return array( $name, home_url( '/' . trim( $path, '/' ) . '/' ) );
	}

	/**
	 * Where the back link points for the page being shown: array( name, address ).
	 * The rule: an ordinary page points to the page above it (its Parent in WordPress); events,
	 * community groups, sermons and Trinity Talk point to the top of their part of the site;
	 * a top-level page points to Home.
	 */
	function tcc_trail_back() {
		$home = array( 'Home', home_url( '/' ) );

		// Events (The Events Calendar): an event, or a list of one kind of event, goes back to Events.
		if ( is_singular( 'tribe_events' ) || is_tax( 'tribe_events_cat' ) ) {
			$url = function_exists( 'tribe_get_events_link' ) ? (string) tribe_get_events_link() : '';
			return array( 'Events', '' !== $url ? $url : home_url( '/events/' ) );
		}
		if ( is_post_type_archive( 'tribe_events' ) ) {
			return $home;
		}

		// A community group (WordPress calls these "Projects") goes back to the Community Groups page.
		if ( is_singular( 'project' ) ) {
			return tcc_trail_page( 'community-groups', 'Community Groups' );
		}

		// An ordinary page goes one level up, to its Parent page (set under Pages > Quick Edit).
		// The Blessed Life goes to Core Classes Archive, which goes to Resources, which goes to Home.
		if ( is_page() ) {
			$parent_id = (int) wp_get_post_parent_id( (int) get_queried_object_id() );
			if ( $parent_id && 'publish' === get_post_status( $parent_id ) ) {
				return array( get_the_title( $parent_id ), (string) get_permalink( $parent_id ) );
			}
			return $home;
		}

		// Everything else (sermons, series, Trinity Talk): the first step after Home, so a sermon
		// goes to Sermons and not to its series.
		$steps = tcc_trail_steps();
		if ( count( $steps ) > 1 && '' !== (string) $steps[0][1] && '' !== tcc_trail_text( $steps[0][0] ) ) {
			return array( $steps[0][0], (string) $steps[0][1] );
		}
		return $home;
	}

	/** [tcc_trail]: an arrow and the name of the page to go back to, as one link. */
	function tcc_trail_shortcode() {
		try {
			$back = tcc_trail_back();
			$name = tcc_trail_text( $back[0] );
			if ( '' === $name || '' === (string) $back[1] ) {
				$name = 'Home';
				$back = array( 'Home', home_url( '/' ) );
			}
			// The arrow is Divi's own left-arrow icon (the same icon set as the rest of the site).
			// "Back to" is read out by screen readers and not shown.
			return '<nav class="tcc-trail" aria-label="Back">'
				. '<a href="' . esc_url( $back[1] ) . '">'
				. '<span class="tcc-trail-arrow" aria-hidden="true">&#x23;</span>'
				. '<span class="tcc-trail-sr">Back to </span>'
				. '<span class="tcc-trail-name">' . $name . '</span>'
				. '</a></nav>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_trail', 'tcc_trail_shortcode' );

	/**
	 * How the back link looks. It sits exactly where the old trail's house and "Home" sat, so
	 * nothing below it moved:
	 *   a 16px teal arrow, 10px, then the name in CMG Sans SemiBold 15px on a 26px line, teal #00A4CF.
	 * The link has an invisible 9px above and below and 12px to its right, so it is easy to press
	 * without moving anything. Pointing at it underlines the name and nudges the arrow to the left
	 * (the nudge is left out for visitors who have asked their device for less motion).
	 */
	function tcc_trail_css() {
		$css = 'Q{display:flex;align-items:center;margin:0;padding:0;font:400 15px/26px "CMG Sans SemiBold",Helvetica,Arial,Lucida,sans-serif;letter-spacing:0;text-transform:none;color:#00A4CF}'
			. 'Q a{display:inline-flex;align-items:center;margin:-9px -12px -9px 0;padding:9px 12px 9px 0;color:#00A4CF;text-decoration:none}'
			. 'Q .tcc-trail-arrow{flex:none;margin-right:10px;font:400 16px/16px ETmodules;color:#00A4CF;transition:transform .15s ease}'
			. 'Q a:hover .tcc-trail-name{text-decoration:underline}'
			. 'Q a:hover .tcc-trail-arrow{transform:translateX(-3px)}'
			. 'Q a:focus-visible{outline:3px solid rgba(0,164,207,.45);outline-offset:2px}'
			. 'Q .tcc-trail-sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}'
			. '@media (prefers-reduced-motion:reduce){Q .tcc-trail-arrow{transition:none}Q a:hover .tcc-trail-arrow{transform:none}}';
		// A capital Q stands for the link's line itself. It is written twice so the rules win over
		// Divi's own text styles whichever way Divi wraps the page.
		$out = '';
		foreach ( array( 'body nav.tcc-trail', '#page-container #et-boc nav.tcc-trail' ) as $start ) {
			$out .= preg_replace( '/(^|[},{])Q(?=[ {])/', '$1' . $start, $css );
		}
		return $out;
	}

	/**
	 * Keep WP Rocket from throwing the link's styles away.
	 *
	 * WP Rocket's "Remove Unused CSS" setting keeps its own trimmed copy of each page's styles and
	 * empties style blocks like ours. When its copy was made from an older version of the page, the
	 * back link showed with no styling at all (a "#" where the arrow should be). The plugin's main
	 * file keeps every block whose id starts "tcc-" (this one is tcc-trail-css); this also keeps it
	 * by what it holds. It does nothing if WP Rocket is not installed.
	 */
	function tcc_trail_keep_styles_by_content( $keep ) {
		$keep   = is_array( $keep ) ? $keep : array();
		$keep[] = 'nav.tcc-trail'; // matches the rules inside our block
		return $keep;
	}
	add_filter( 'rocket_rucss_inline_content_exclusions', 'tcc_trail_keep_styles_by_content' );

	/** The styles go in the head of the page, so the link never shows unstyled. */
	add_action(
		'wp_head',
		function () {
			if ( is_admin() ) {
				return;
			}
			echo '<style id="tcc-trail-css">' . tcc_trail_css() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed text written above.
		},
		30
	);
}
