/*
 * The filter bar: its script (TCC Website Features plugin).
 *
 * One script for both filter bars:
 *   the Events page            [tcc_events_filter]  (events-filter.php)
 *   the Community Groups page  [tcc_group_filter]   (group-filter.php)
 * A change here changes both pages.
 *
 * What it does, in the visitor's browser only (it asks the website for nothing):
 *   - finds the list of cards under the bar (the CSS ID in data-target) and fills in the number
 *     beside the page heading;
 *   - shows twelve cards, with "Show 12 more" and "Showing 12 of 20" under them;
 *   - hides and shows the cards as the visitor uses the menus and the search box, shows every
 *     match while a filter is in use, and says "Showing 3 of 8 ..." with "Clear filters".
 *
 * How it knows what to do: each feature's PHP prints these settings on the bar itself.
 *   data-target                    the CSS ID of the list of cards (set in Divi)
 *   data-cards                     what one card is, e.g. ".tcc-event-card"
 *   data-card-data                 the hidden tag inside each card with its facts, e.g. ".tcc-event-data"
 *   data-count-into                where the number of cards goes, e.g. ".tcc-events-count"
 *   data-status-text               the status line, with {shown} and {total} filled in
 *   data-min-cards                 with fewer cards than this the bar stays hidden (Community Groups: 2)
 *   data-hide-unused-choices       a menu keeps only the choices some card has; a menu with fewer
 *                                  than two choices left is hidden (Community Groups)
 *   data-buttons                   this menu shows as press-buttons instead (Community Groups: "who")
 *   data-hide-status-when-none     no status line when nothing matches (Community Groups)
 *   data-focus-search-after-clear  "Clear filters" puts the cursor in the search box (Community Groups)
 *   data-remember-in-address       the filters are kept in the page address, so a filtered page can be
 *                                  shared; the value starts each name, e.g. "events_" (Events)
 *   data-animate                   the cards fade out and in (Events)
 *   data-removable-tags            the status line has a tag per filter in use; pressing one removes
 *                                  that filter (Events)
 * And on each menu and the search box:
 *   data-f                         its name (cat, month, who, day, often; q is the search box)
 *   data-from                      the fact on the card's hidden tag it is matched against: the menu
 *                                  "day" with data-from="days" reads data-days="tue thu"
 *   data-name                      (Events) the word on its removable tag, e.g. "Category"
 * And on a menu choice:
 *   data-none                      the "no match" sentence to use while that choice is chosen
 *   data-label                     (Events) the name on its removable tag, when not the choice's text
 *
 * The search box looks at all the words on a card, and at the hidden words in data-words
 * (Community Groups: the group's description and organizer).
 * Written the plain, older way (no newer JavaScript), so it also works on older phones and tablets.
 * Comments use the slash-star form only, never two slashes, so the script still works if its lines
 * are ever run together.
 */
(function () {
	var STEP = 12; /* how many cards "Show 12 more" adds (and how many show at first) */
	var reduceMotion = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

	function setUp(bar) {
		if (bar.__tcc) {
			return; /* already set up */
		}
		var target = document.getElementById(bar.getAttribute("data-target"));
		var cardSel = bar.getAttribute("data-cards");
		if (!target || !cardSel) {
			return;
		}
		var has = function (name) { return bar.hasAttribute(name); };
		var cardData = bar.getAttribute("data-card-data") || "";
		var cards = [].slice.call(target.querySelectorAll(cardSel));

		/* The number beside the page heading. */
		var countInto = bar.getAttribute("data-count-into");
		if (countInto) {
			[].forEach.call(document.querySelectorAll(countInto), function (el) {
				el.textContent = cards.length ? String(cards.length) : "";
			});
		}
		if (cards.length < (parseInt(bar.getAttribute("data-min-cards"), 10) || 0)) {
			return; /* too few cards to be worth filtering: the bar stays hidden */
		}
		bar.__tcc = 1;

		var animate = has("data-animate");
		var tags = has("data-removable-tags");
		var remember = bar.getAttribute("data-remember-in-address") || "";
		var status = bar.querySelector(".tcc-fb-status");
		var countEl = bar.querySelector(".tcc-fb-count") || status;
		var none = bar.querySelector(".tcc-fb-none");
		var noneText = none.textContent;
		var clearBtn = bar.querySelector(".tcc-fb-clear");
		var chips = {};

		/* The menus and the search box, in the order they are on the page. */
		var keys = [], ctl = {};
		[].forEach.call(bar.querySelectorAll("[data-f]"), function (el) {
			var k = el.getAttribute("data-f");
			keys.push(k);
			ctl[k] = el;
		});

		/* What each card holds, read once: its facts as lists, and its words for the search box. */
		var facts = cards.map(function (card) {
			var d = cardData ? card.querySelector(cardData) : null;
			var f = { text: (card.textContent + " " + (d ? d.getAttribute("data-words") || "" : "")).toLowerCase() };
			keys.forEach(function (k) {
				var from = ctl[k].getAttribute("data-from");
				if (from) {
					f[k] = d ? (d.getAttribute("data-" + from) || "").split(" ") : [];
				}
			});
			return f;
		});
		function matches(f, k, value) {
			return !value || (f[k] || []).indexOf(value) > -1;
		}

		/* A menu only keeps the choices that at least one card has; a menu with nothing to choose is hidden. */
		if (has("data-hide-unused-choices")) {
			keys.forEach(function (k) {
				var sel = ctl[k], left = 0;
				if (!sel.getAttribute("data-from")) {
					return;
				}
				[].slice.call(sel.options).forEach(function (o) {
					if (!o.value) {
						return;
					}
					if (facts.some(function (f) { return matches(f, k, o.value); })) {
						left++;
					} else {
						sel.removeChild(o);
					}
				});
				if (left < 2) {
					sel.hidden = true;
					sel.style.display = "none";
				}
			});
		}

		/* A short menu reads better as press-buttons. The menu stays (hidden) and holds the choice. */
		var seg = null, segSel = ctl[bar.getAttribute("data-buttons") || ""];
		if (segSel && !segSel.hidden) {
			seg = document.createElement("div");
			seg.className = "tcc-fb-seg";
			seg.setAttribute("role", "group");
			seg.setAttribute("aria-label", segSel.getAttribute("aria-label") || "");
			[].slice.call(segSel.options).forEach(function (o) {
				var b = document.createElement("button");
				b.type = "button";
				b.textContent = o.textContent;
				b.setAttribute("data-v", o.value);
				b.addEventListener("click", function () {
					segSel.value = o.value;
					apply(true, false);
				});
				seg.appendChild(b);
			});
			segSel.parentNode.insertBefore(seg, segSel);
			segSel.style.display = "none";
		}

		/* The words for a filter in use: the search words in quotes, or the chosen menu choice. */
		function label(k) {
			var el = ctl[k];
			if (el.tagName !== "SELECT") {
				return "“" + el.value.trim() + "”";
			}
			var o = el.options[el.selectedIndex];
			return o.getAttribute("data-label") || o.text;
		}

		/* Show or hide one card; with data-animate it fades. */
		function setCard(card, ok, instant) {
			if (!animate) {
				card.style.display = ok ? "" : "none";
				return;
			}
			if (card.__ok === ok) {
				return;
			}
			card.__ok = ok;
			clearTimeout(card.__t);
			if (ok) {
				card.style.display = "";
				if (instant || reduceMotion) {
					card.classList.remove("tcc-fb-out");
					return;
				}
				card.classList.add("tcc-fb-out");
				void card.offsetWidth; /* let the browser see the faded state, so it fades in from it */
				card.classList.remove("tcc-fb-out");
			} else {
				card.classList.add("tcc-fb-out");
				if (instant || reduceMotion) {
					card.style.display = "none";
					return;
				}
				card.__t = setTimeout(function () { card.style.display = "none"; }, 220);
			}
		}
		if (animate) {
			cards.forEach(function (c) { c.classList.add("tcc-fb-anim"); });
		}

		/* The removable tag of one filter: made, updated, or faded out and removed. */
		function chip(k, on) {
			var c = chips[k];
			if (on) {
				var text = ctl[k].getAttribute("data-name") + ": " + label(k);
				if (!c) {
					c = document.createElement("button");
					c.type = "button";
					c.className = "tcc-fb-chip";
					c.setAttribute("data-clear", k);
					var t = document.createElement("span");
					t.className = "tcc-fb-chip-t";
					var x = document.createElement("span");
					x.className = "tcc-fb-x";
					x.setAttribute("aria-hidden", "true");
					x.textContent = "×";
					c.appendChild(t);
					c.appendChild(x);
					status.appendChild(c);
					chips[k] = c;
				}
				c.firstChild.textContent = text;
				c.setAttribute("aria-label", "Remove filter: " + text);
			} else if (c) {
				chips[k] = null;
				var gone = function () { if (c.parentNode) { c.parentNode.removeChild(c); } };
				if (reduceMotion) {
					gone();
				} else {
					c.classList.add("is-leaving");
					setTimeout(gone, 180);
				}
			}
		}

		/* "Show 12 more" and "Showing 12 of 20", under the list of cards. */
		var max = STEP;
		var more = document.createElement("div");
		more.className = "tcc-fb-more";
		more.hidden = true;
		var moreBtn = document.createElement("button");
		moreBtn.type = "button";
		var moreNote = document.createElement("span");
		more.appendChild(moreBtn);
		more.appendChild(moreNote);
		target.parentNode.insertBefore(more, target.nextSibling);
		moreBtn.addEventListener("click", function () {
			var first = cards[max];
			max += STEP;
			apply(false, false);
			if (first) { /* move the keyboard to the first new card */
				first.setAttribute("tabindex", "-1");
				try { first.focus(); } catch (e) {}
			}
		});

		/* Look at the menus and the search box, then show the matching cards and say how many.
		   push: also write the filters into the page address. instant: no fading (the first time). */
		function apply(push, instant) {
			var term = ctl.q ? ctl.q.value.trim().toLowerCase() : "";
			var shown = 0, active = 0;
			keys.forEach(function (k) {
				if (ctl[k].value.trim()) {
					active++;
				}
			});
			if (seg) {
				[].forEach.call(seg.children, function (b) {
					b.setAttribute("aria-pressed", b.getAttribute("data-v") === segSel.value ? "true" : "false");
				});
			}
			cards.forEach(function (card, i) {
				var f = facts[i];
				var ok = !term || f.text.indexOf(term) > -1;
				keys.forEach(function (k) {
					if (ok && ctl[k].getAttribute("data-from")) {
						ok = matches(f, k, ctl[k].value);
					}
				});
				/* With no filter in use only the first twelve (or more after "Show 12 more") show. */
				setCard(card, ok && (active > 0 || i < max), instant);
				if (ok) {
					shown++;
				}
			});

			var left = cards.length - max;
			more.hidden = active > 0 || left <= 0;
			moreBtn.textContent = "Show " + Math.min(STEP, left) + " more";
			moreNote.textContent = "Showing " + Math.min(max, cards.length) + " of " + cards.length;

			keys.forEach(function (k) {
				var on = !!ctl[k].value.trim();
				ctl[k].classList.toggle("is-active", on);
				if (tags) {
					chip(k, on);
				}
			});
			bar.classList.toggle("is-filtering", active > 0);
			clearBtn.hidden = !active;
			status.hidden = !active || (shown === 0 && bar.hasAttribute("data-hide-status-when-none"));
			countEl.textContent = (bar.getAttribute("data-status-text") || "")
				.replace("{shown}", shown)
				.replace("{total}", cards.length);

			/* Nothing matches: say so. A chosen choice can carry its own sentence (data-none). */
			var empty = active > 0 && shown === 0;
			if (empty) {
				var text = noneText;
				keys.forEach(function (k) {
					var el = ctl[k];
					var o = el.tagName === "SELECT" && el.value ? el.options[el.selectedIndex] : null;
					if (o && o.getAttribute("data-none")) {
						text = o.getAttribute("data-none");
					}
				});
				none.textContent = text;
			}
			none.hidden = !empty;

			if (push && remember && window.history && history.replaceState) {
				try {
					var u = new URL(window.location.href);
					keys.forEach(function (k) {
						var v = ctl[k].value.trim();
						if (v) {
							u.searchParams.set(remember + k, v);
						} else {
							u.searchParams.delete(remember + k);
						}
					});
					history.replaceState(null, "", u.toString());
				} catch (e) {}
			}
		}

		/* "Clear filters" (data-clear="all") and the removable tags (data-clear="cat" and so on). */
		function clear(k) {
			if (k === "all") {
				keys.forEach(function (key) { ctl[key].value = ""; });
			} else if (ctl[k]) {
				ctl[k].value = "";
			}
			apply(true, false);
			if (k === "all" && ctl.q && bar.hasAttribute("data-focus-search-after-clear")) {
				ctl.q.focus();
			}
		}
		keys.forEach(function (k) {
			ctl[k].addEventListener(ctl[k].tagName === "SELECT" ? "change" : "input", function () {
				apply(true, false);
			});
		});
		bar.addEventListener("click", function (e) {
			var b = e.target.closest ? e.target.closest("[data-clear]") : null;
			if (b) {
				e.preventDefault();
				clear(b.getAttribute("data-clear"));
			}
		});

		/* Filters kept in the page address (a shared filtered link) are put back. */
		if (remember) {
			try {
				var p = new URL(window.location.href).searchParams;
				keys.forEach(function (k) {
					var v = p.get(remember + k);
					if (v) {
						ctl[k].value = v;
					}
				});
			} catch (e) {}
		}

		bar.hidden = false;
		apply(false, true);
	}

	function boot() {
		[].forEach.call(document.querySelectorAll(".tcc-filter-bar"), setUp);
	}
	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", boot);
	} else {
		boot();
	}
	window.addEventListener("load", boot); /* again once everything has loaded, in case the cards came late */
})();
