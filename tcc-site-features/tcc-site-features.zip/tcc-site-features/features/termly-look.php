<?php
/**
 * TCC Termly look: the cookie banner and its Preferences window in the church's look.
 *
 * What it is:
 *   The cookie banner at the foot of the page on a first visit, and the Preferences window that
 *   opens from it or from "Consent Preferences" in the footer, come from Termly (the church's
 *   cookie service). Termly draws them with its own small type (12px) and square buttons.
 *
 * What this does:
 *   It adds a short list of styles so both look like the rest of the website: Open Sans at 15px in
 *   charcoal, teal links, the website's own 48px buttons with 10px corners, and 15px corners on the
 *   Preferences window with its title in CMG Sans. "Decline" and "Accept" are both the teal main
 *   button, so neither choice is pushed; "Preferences" is the quiet white button.
 *   Since 0.14.5 the banner is a very small card in the bottom-left corner (13px words, a 32px
 *   Accept button) with one short line ("By using this site, you consent to cookies. The digital
 *   kind.") and a "Learn more" link to the Cookie Policy, in place of Termly's 60-word paragraph.
 *   Termly offers no way to change that paragraph, so the styles shrink it to nothing and write the
 *   short line in front of it; the words are on the "content:" lines in termly-look.css.
 *   Nothing about what the banner does, or what it remembers, is changed. Which buttons it shows
 *   (Accept only, in Tennessee) is set in Termly, per region: Consent Management > Consent Banner >
 *   Consent Settings.
 *   Since 0.14.7 "Learn more" opens the website's own Cookie Policy page (/cookie-policy/) rather
 *   than Termly's small window over the page; a short script, features/termly-look.js, does that.
 *   The styles are in a file of their own beside this one: features/termly-look.css.
 *
 * What it cannot do:
 *   The policy pages (Privacy Policy, Terms & Conditions, Cookie Policy) show Termly's text inside
 *   a frame served from termly.io. A website cannot style the inside of another site's frame, so
 *   those words keep Termly's look. That is set in Termly itself.
 *
 * If Termly changes:
 *   The styles find Termly's parts by the names Termly gives them (t-consentPrompt,
 *   t-preference-modal, and the start of its style names, such as "termly-styles-button"). If
 *   Termly renames them, the banner simply goes back to Termly's own look; nothing breaks.
 *
 * Part of the TCC Website Features plugin (added in 0.9.8, November 2026).
 * Switch it off under TCC Website > Features to go back to Termly's own look.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_termly_look_css' ) ) {

	/**
	 * The styles. They are in termly-look.css, beside this file, every rule starting with "body" (so
	 * they win over Termly's own without fighting the theme). This hands back that file's text.
	 */
	function tcc_termly_look_css() {
		return tcc_site_asset( 'features/termly-look.css' ); // tcc_site_asset() is in the plugin's main file.
	}

	/** Printed in the head of every page a visitor sees (the banner can open on any page). */
	add_action(
		'wp_head',
		function () {
			if ( is_admin() ) {
				return;
			}
			echo '<style id="tcc-termly-look">' . tcc_termly_look_css() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own styles file.
		},
		30
	);

	/**
	 * Keep WP Rocket from throwing these styles away. Its "Remove Unused CSS" setting drops rules
	 * for things that are not in the page when it looks, and Termly adds the banner later, in the
	 * visitor's browser. The plugin's main file keeps every block whose id starts "tcc-"
	 * (this one is tcc-termly-look); this also keeps it by what it holds. It does nothing if WP Rocket
	 * is not installed.
	 */
	function tcc_termly_look_keep_by_content( $keep ) {
		$keep   = is_array( $keep ) ? $keep : array();
		$keep[] = '.t-consentPrompt';
		return $keep;
	}
	add_filter( 'rocket_rucss_inline_content_exclusions', 'tcc_termly_look_keep_by_content' );

	/**
	 * The address of the website's own Cookie Policy page (the published page whose address ends
	 * /cookie-policy/), or '' if there is no such page. "Learn more" on the banner goes there.
	 */
	function tcc_termly_look_cookie_page() {
		static $url = null;
		if ( null === $url ) {
			$page = get_page_by_path( 'cookie-policy' );
			$url  = ( $page && 'publish' === $page->post_status ) ? (string) get_permalink( $page ) : '';
		}
		return $url;
	}

	/**
	 * "Learn more" opens the Cookie Policy page itself, not Termly's small window over the page.
	 * The script is in termly-look.js, beside this file; this prints it at the foot of every page a
	 * visitor sees, with the page's address on the tag. If the page cannot be found, nothing is
	 * printed and "Learn more" opens Termly's window as before. "nowprocket" keeps WP Rocket from
	 * holding the script back until the visitor first moves the mouse.
	 */
	function tcc_termly_look_learn_more_script() {
		if ( is_admin() || isset( $_GET['et_fb'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only checks whether the Divi editor is open.
			return;
		}
		$page = tcc_termly_look_cookie_page();
		if ( '' === $page ) {
			return;
		}
		echo '<script id="tcc-termly-look-js" data-page="' . esc_url( $page ) . '" nowprocket data-nowprocket>' . "\n"
			. tcc_site_asset( 'features/termly-look.js' ) . "\n" // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file.
			. '</script>' . "\n";
	}
	add_action( 'wp_footer', 'tcc_termly_look_learn_more_script', 99 );
}
