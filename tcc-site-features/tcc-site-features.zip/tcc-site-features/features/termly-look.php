<?php
/**
 * TCC Termly look: the cookie banner and its Preferences window in the church's look.
 *
 * What it is:
 *   The cookie banner at the foot of the page on a first visit, and the Preferences window that
 *   opens from it or from "Consent Preferences" in the footer, come from Termly (the church's
 *   cookie service). Termly draws them with its own small type (12px) and square buttons.
 *
 * What this does:
 *   It adds a short list of styles so both look like the rest of the website: Open Sans at 15px in
 *   charcoal, teal links, the website's own 48px buttons with 10px corners, and 15px corners on the
 *   Preferences window with its title in CMG Sans. "Decline" and "Accept" are both the teal main
 *   button, so neither choice is pushed; "Preferences" is the quiet white button.
 *   Nothing about what the banner does, or what it remembers, is changed.
 *
 * What it cannot do:
 *   The policy pages (Privacy Policy, Terms & Conditions, Cookie Policy) show Termly's text inside
 *   a frame served from termly.io. A website cannot style the inside of another site's frame, so
 *   those words keep Termly's look. That is set in Termly itself.
 *
 * If Termly changes:
 *   The styles find Termly's parts by the names Termly gives them (t-consentPrompt,
 *   t-preference-modal, and the start of its style names, such as "termly-styles-button"). If
 *   Termly renames them, the banner simply goes back to Termly's own look; nothing breaks.
 *
 * Part of the TCC Website Features plugin (added in 0.9.8, November 2026).
 * Switch it off under TCC Website > Features to go back to Termly's own look.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_termly_look_css' ) ) {

	/** The styles. "B" stands for "body" (so they win over Termly's own without fighting the theme). */
	function tcc_termly_look_css() {
		$font = '"Open Sans",Arial,sans-serif';
		$head = '"CMG Sans SemiBold","Montserrat",sans-serif';
		// "button" is named because Termly's row of buttons also has "termly-styles-button" in its name.
		$btn   = 'B [class*="termly-styles-root"] button[class*="termly-styles-button"][class*="termly-styles-button"]';
		$solid = 'B [class*="termly-styles-root"] button[class*="termly-styles-button"][class*="termly-styles-module-solid"]';
		$quiet = 'B [class*="termly-styles-root"] button[class*="termly-styles-button"][class*="termly-styles-module-outline"]';
		$css  = ''
			// The banner on a first visit.
			. 'B .t-consentPrompt{font-family:' . $font . '!important;color:#404041!important;border-radius:15px!important}'
			. 'B .t-consentPrompt div,B .t-consentPrompt p,B .t-consentPrompt span{font-family:' . $font . '!important;font-size:15px!important;line-height:1.5!important;color:#404041!important}'
			// The Preferences window.
			. 'B [class*="termly-styles-modal"]{border-radius:15px!important;font-family:' . $font . '!important;color:#404041!important}'
			. 'B .t-preference-modal{font-family:' . $font . '!important;color:#404041!important}'
			. 'B .t-preference-modal p,B .t-preference-modal span,B .t-preference-modal label,B .t-preference-modal li,B .t-preference-modal div{font-family:' . $font . '!important;font-size:15px!important;line-height:1.5!important;color:#404041!important}'
			. 'B [class*="termly-styles-preferenceTitle"]{font-family:' . $head . '!important;font-weight:500!important;font-size:26px!important;line-height:1.2!important;color:#404041!important}'
			. 'B .t-preference-modal input[type=checkbox]{accent-color:#00A4CF}'
			// Links in both.
			. 'B .t-consentPrompt a,B .t-consentPrompt a span,B .t-preference-modal a,B .t-preference-modal a span{color:#00A4CF!important}'
			. 'B .t-consentPrompt a:hover,B .t-preference-modal a:hover{color:#1962A8!important}'
			// Buttons: the website's own. Solid ones are the teal main button, outlined ones the quiet white button.
			// Termly tells its buttons to take their font and colour from the banner, with strong rules of its
			// own, so these name the button twice and sit inside Termly's root to be stronger still.
			. $btn . '{font-family:' . $head . '!important;font-weight:500!important;font-size:16px!important;line-height:1.2!important;letter-spacing:0!important;text-transform:none!important;min-height:48px!important;padding:0 22px!important;border-radius:10px!important;box-shadow:none!important;transition:background-color .2s,border-color .2s,color .2s}'
			. $solid . '{background:#00A4CF!important;border:2px solid #00A4CF!important;color:#fff!important}'
			. $solid . ':hover,' . $solid . ':focus-visible{background:#1962A8!important;border-color:#1962A8!important;color:#fff!important}'
			. $quiet . '{background:#fff!important;border:2px solid #e3e7ea!important;color:#00A4CF!important}'
			. $quiet . ':hover,' . $quiet . ':focus-visible{background:#fff!important;border-color:#00A4CF!important;color:#00A4CF!important}'
			// Words inside a button keep the button's colour and size.
			. 'B [class*="termly-styles-root"] button[class*="termly-styles-button"] *{color:inherit!important;font-size:inherit!important;font-family:inherit!important}'
			. $btn . ':focus-visible{outline:3px solid rgba(0,164,207,.45)!important;outline-offset:2px}'
			. '@media (prefers-reduced-motion:reduce){' . $btn . '{transition:none!important}}';
		return str_replace( 'B ', 'body ', $css );
	}

	/** Printed in the head of every page a visitor sees (the banner can open on any page). */
	add_action(
		'wp_head',
		function () {
			if ( is_admin() ) {
				return;
			}
			echo '<style id="tcc-termly-look">' . tcc_termly_look_css() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed text written above.
		},
		30
	);

	/**
	 * Keep WP Rocket from throwing these styles away. Its "Remove Unused CSS" setting drops rules
	 * for things that are not in the page when it looks, and Termly adds the banner later, in the
	 * visitor's browser. These lines tell WP Rocket to leave this one block alone. They do nothing
	 * if WP Rocket is not installed.
	 */
	function tcc_termly_look_keep( $keep ) {
		$keep   = is_array( $keep ) ? $keep : array();
		$keep[] = 'tcc-termly-look';
		return $keep;
	}
	function tcc_termly_look_keep_by_content( $keep ) {
		$keep   = is_array( $keep ) ? $keep : array();
		$keep[] = '.t-consentPrompt';
		return $keep;
	}
	add_filter( 'rocket_rucss_inline_atts_exclusions', 'tcc_termly_look_keep' );
	add_filter( 'rocket_rucss_inline_content_exclusions', 'tcc_termly_look_keep_by_content' );
}
