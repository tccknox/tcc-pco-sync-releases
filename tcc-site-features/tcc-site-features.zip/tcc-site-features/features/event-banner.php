<?php
/**
 * TCC event banner shortcodes, for the "banner" layout of the individual event page.
 *
 * [tcc_event_facts]        The short list beside the event graphic: a small teal icon and the
 *                          day, the time, and the name of the place. All-day events show no time.
 *                          Events with no place show no place line.
 * [tcc_event_directions]   A "Get directions" link that opens Google Maps for the event's address.
 *                          Prints nothing when the event has no address.
 *                          Optional: label="Get directions"
 *
 * Both follow the "what shows" switches of the Planning Center events feature (location, end time)
 * when that plugin is active, and work without it.
 *
 * It also prints a few lines of CSS on event pages only, for things Divi cannot do itself:
 *   1. lay out the icon list above;
 *   2. stack the banner (graphic on top) on screens between tablet and 1280 wide, where the panel
 *      would otherwise be taller than the graphic;
 *   3. hide the Location card when an event has nothing to put in it;
 *   4. give the event description slightly looser line spacing, whatever it was written with;
 *   5. when an event has no graphic, drop the empty space where it would be;
 *   6. keep an unusually shaped graphic sensible: a square or tall graphic is never taller than 600px
 *      (it is made smaller, never cropped, and sits in the middle), and a very wide one sits in the
 *      middle of the banner instead of leaving a gap underneath;
 *   7. stop wide things typed into a description (a table, a long web address, a big picture) from
 *      running off the side of a phone screen.
 *
 * The CSS looks for these class names, which are set on layers of the event page template
 * (Divi > Theme Builder > the event template > Advanced > Attributes on each layer):
 *   tcc-event-banner   the banner (graphic + panel)
 *   tcc-event-place    the Location card
 *   tcc-event-about    the column that holds the description
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 25, "TCC event banner shortcodes".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_banner_event_id' ) ) {
	/** The event being viewed, or 0 when there is none (such as inside the page builder). */
	function tcc_banner_event_id() {
		$id = get_the_ID();
		if ( ! $id || 'tribe_events' !== get_post_type( $id ) ) {
			$id = is_singular( 'tribe_events' ) ? get_queried_object_id() : 0;
		}
		return ( $id && 'tribe_events' === get_post_type( $id ) ) ? (int) $id : 0;
	}
}

if ( ! function_exists( 'tcc_banner_shows' ) ) {
	/** Is this piece switched on for this event? Always yes when the Planning Center events feature is off. */
	function tcc_banner_shows( $id, $key ) {
		return function_exists( 'tcc_pco_shows' ) ? (bool) tcc_pco_shows( $id, $key ) : true;
	}
}

if ( ! function_exists( 'tcc_banner_address' ) ) {
	/** The event's street address on one line, or '' when it has none. */
	function tcc_banner_address( $id ) {
		$parts = array();
		foreach ( array( 'tribe_get_address', 'tribe_get_city', 'tribe_get_stateprovince', 'tribe_get_zip' ) as $getter ) {
			if ( function_exists( $getter ) ) {
				$value = trim( (string) call_user_func( $getter, $id ) );
				if ( '' !== $value ) {
					$parts[] = $value;
				}
			}
		}
		return implode( ', ', $parts );
	}
}

if ( ! function_exists( 'tcc_event_facts_shortcode' ) ) {
	function tcc_event_facts_shortcode() {
		try {
			$id = tcc_banner_event_id();
			if ( ! $id || ! function_exists( 'tribe_get_start_date' ) || ! function_exists( 'tribe_get_end_date' ) ) {
				// Editors see this while editing the template. Visitors never do.
				return ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) ? 'Event day, time and place (filled in automatically)' : '';
			}

			$start_day = (string) tribe_get_start_date( $id, false, 'F j, Y' );
			$end_day   = (string) tribe_get_end_date( $id, false, 'F j, Y' );
			if ( '' === $start_day ) {
				return '';
			}

			// One day: "Sunday, November 22, 2026". Several days: "June 23, 2026 - June 25, 2026".
			$several = ( '' !== $end_day && $end_day !== $start_day );
			$day     = $several ? $start_day . ' - ' . $end_day : (string) tribe_get_start_date( $id, false, 'l, F j, Y' );

			// All-day events show no time. With the end time switched off, only the start time shows.
			$time    = '';
			$all_day = function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $id );
			if ( ! $all_day ) {
				$start_time = (string) tribe_get_start_date( $id, false, 'g:i A' );
				$end_time   = (string) tribe_get_end_date( $id, false, 'g:i A' );
				$time       = $start_time;
				if ( tcc_banner_shows( $id, 'end_time' ) && '' !== $end_time && $end_time !== $start_time ) {
					$time .= ' - ' . $end_time;
				}
			}

			$place = '';
			if ( tcc_banner_shows( $id, 'location' ) && function_exists( 'tribe_get_venue' ) ) {
				$place = trim( (string) tribe_get_venue( $id ) );
			}

			$icons = array(
				'day'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2h2v2h6V2h2v2h2a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2V2zm12 8H5v9h14v-9z"/></svg>',
				'time'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 5v4.6l3.2 3.2-1.4 1.4L11 12.4V7h2z"/></svg>',
				'place' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>',
			);

			$rows = '';
			foreach ( array( 'day' => $day, 'time' => $time, 'place' => $place ) as $key => $text ) {
				if ( '' !== $text ) {
					$rows .= '<span class="tcc-event-fact">' . $icons[ $key ] . '<span>' . esc_html( $text ) . '</span></span>';
				}
			}

			return '<span class="tcc-event-facts">' . $rows . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_facts', 'tcc_event_facts_shortcode' );
}

if ( ! function_exists( 'tcc_event_directions_shortcode' ) ) {
	function tcc_event_directions_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'Get directions' ), $atts, 'tcc_event_directions' );
		try {
			$id = tcc_banner_event_id();
			if ( ! $id || ! tcc_banner_shows( $id, 'location' ) ) {
				return '';
			}
			$address = tcc_banner_address( $id );
			if ( '' === $address ) {
				return '';
			}
			$name = function_exists( 'tribe_get_venue' ) ? trim( (string) tribe_get_venue( $id ) ) : '';
			$url  = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( ( '' !== $name ? $name . ', ' : '' ) . $address );
			return '<a class="tcc-event-directions" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $atts['label'] ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_directions', 'tcc_event_directions_shortcode' );
}

if ( ! function_exists( 'tcc_banner_has_rooms' ) ) {
	/**
	 * Does this event have at least one room that is set to show? Uses the Planning Center events feature's
	 * own rules. (The rooms shortcode itself is not run here: it prints its styling only the first time
	 * it runs on a page, so running it early would leave the rooms on the page unstyled.)
	 */
	function tcc_banner_has_rooms( $id ) {
		if ( ! function_exists( 'tcc_pco_shows' ) || ! function_exists( 'tcc_pco_room_visible' ) || ! function_exists( 'tcc_pco_settings' ) ) {
			return false;
		}
		$rooms = get_post_meta( $id, '_tcc_pco_rooms', true );
		if ( ! is_array( $rooms ) || ! $rooms || ! tcc_pco_shows( $id, 'rooms' ) ) {
			return false;
		}
		$settings = tcc_pco_settings();
		$event_id = (string) get_post_meta( $id, '_tcc_pco_event_id', true );
		foreach ( $rooms as $room_id => $name ) {
			if ( tcc_pco_room_visible( $settings, $event_id, (string) $room_id ) ) {
				return true;
			}
		}
		return false;
	}
}

if ( ! function_exists( 'tcc_banner_body_class' ) ) {
	/**
 * Marks event pages that have no place and no rooms to show (so the empty Location card can be hidden)
 * and event pages that have no graphic (so the banner does not leave an empty space for it).
 */
	function tcc_banner_body_class( $classes ) {
		try {
			if ( is_singular( 'tribe_events' ) ) {
				$id = tcc_banner_event_id();
				if ( $id ) {
					$place = ( tcc_banner_shows( $id, 'location' ) && function_exists( 'tribe_get_venue' ) ) ? trim( (string) tribe_get_venue( $id ) ) : '';
					if ( '' === $place && ! tcc_banner_has_rooms( $id ) ) {
						$classes[] = 'tcc-event-no-place';
					}
					if ( ! has_post_thumbnail( $id ) ) {
						$classes[] = 'tcc-event-no-graphic';
					}
				}
			}
		} catch ( \Throwable $e ) {
			// Leave the classes as they were.
		}
		return $classes;
	}
	add_filter( 'body_class', 'tcc_banner_body_class' );
}

if ( ! function_exists( 'tcc_banner_head_css' ) ) {
	function tcc_banner_head_css() {
		if ( ! is_singular( 'tribe_events' ) ) {
			return;
		}
		echo '<style id="tcc-event-banner-css">'
			// 1. The icon list beside the graphic.
			. '.tcc-event-facts{display:flex;flex-direction:column;gap:14px}'
			. '.tcc-event-fact{display:flex;align-items:center;gap:14px;font-size:20px;line-height:1.3}'
			. '.tcc-event-fact svg{flex:0 0 auto;width:24px;height:24px;fill:#00a4cf}'
			. '.tcc-event-directions{display:inline-block;font-weight:600;padding:4px 0}'
			// The Register button sits beside Add To Calendar, and takes no room when there is none.
			. '.tcc-event-banner .tcc-event-register-wrap{display:inline-block!important;margin:0 12px 12px 0!important}'
			// 2. Between tablet and 1280 wide: graphic on top, panel underneath, like the event cards.
			. '@media (min-width:981px) and (max-width:1279px){'
			. '.tcc-event-banner{flex-direction:column!important}'
			. '.tcc-event-banner>.et_pb_module,.et-db #et-boc .et-l .tcc-event-banner>.et_pb_module.et_pb_module{width:100%!important;max-width:100%!important}'
			. '}'
			// 3. Nothing to show in the Location card: hide the card.
			. '.tcc-event-no-place .tcc-event-place{display:none!important}'
			// 5. No graphic: the panel takes the whole banner.
			. '.tcc-event-no-graphic .tcc-event-banner>.et_pb_image{display:none!important}'
			. '.tcc-event-no-graphic .tcc-event-banner>.et_pb_group,.tcc-event-no-graphic #et-boc .et-l .tcc-event-banner>.et_pb_group.et_pb_module{width:100%!important}'
			// 6. Unusually shaped graphics: whole, centred, never taller than 600px.
			. '.tcc-event-banner>.et_pb_image{align-self:center;text-align:center}'
			. '.tcc-event-banner>.et_pb_image img{max-height:600px;width:auto;max-width:100%}'
			// 7. Wide content in the description stays inside the page.
			. '.tcc-event-about{overflow-wrap:break-word}'
			. '.tcc-event-about table{display:block;max-width:100%;overflow-x:auto}'
			. '.tcc-event-about img,.tcc-event-about video,.tcc-event-about iframe{max-width:100%}'
			. '.tcc-event-about img{height:auto}'
			// 4. Easier reading: looser line spacing in the description.
			. '.tcc-event-about .et_pb_post_content p,.tcc-event-about .et_pb_post_content li,.tcc-event-about .tcc-pco-description,.tcc-event-about .tcc-pco-description p,.tcc-event-about .tcc-pco-description div,.tcc-event-about .tcc-pco-description li{line-height:1.45em!important}'
			. '</style>';
	}
	add_action( 'wp_head', 'tcc_banner_head_css' );
}
