<?php
/**
 * TCC events: titles and descriptions for search engines.
 *
 * What a search engine (and a shared link) shows for a page is its title and a one or two
 * sentence description. Yoast SEO writes both for the rest of the website. Two gaps were left:
 *
 *  1. The Events page and the pages for one event category. The Events Calendar writes its own
 *     title there ("Events from November 22 - January 6, 2027") and Yoast prints no description.
 *     This feature gives those pages the title and description that are typed in Yoast:
 *       Yoast SEO > Settings > Events (the "archive" part)  -> the Events page
 *       Yoast SEO > Settings > Event Categories             -> each category page
 *     If nothing is typed there, the plain wording further down this file is used.
 *     A page for one month or one day keeps The Events Calendar's own dated title.
 *
 *  2. An event with no description of its own. Events that arrive from Planning Center have
 *     nothing typed in Yoast's description box. For those, this feature uses the event's
 *     Planning Center summary (or the start of its description) cut to about 155 characters.
 *     A description typed in Yoast on the event always wins.
 *
 * Server load: nothing is looked up from outside and nothing extra is stored. It reads settings
 * WordPress has already loaded and, on an event page, that one event's own fields.
 *
 * Part of the TCC Website Features plugin. Added 2026-11-21.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_event_search_text_view' ) ) {

	/**
	 * Says which Events page is being shown, if any.
	 * Returns array( 'kind' => 'main' or 'category', 'term' => the category or null ), or null
	 * when this is not the Events page or a category page in its ordinary, undated form.
	 */
	function tcc_event_search_text_view() {
		static $found = false;
		if ( ! did_action( 'wp' ) ) {
			return null; // Too early: WordPress has not worked out which page this is yet.
		}
		if ( false !== $found ) {
			return $found;
		}
		$found = null;
		try {
			if ( is_admin() || is_feed() || is_singular() || is_search() ) {
				return $found;
			}
			$term = null;
			if ( is_tax( 'tribe_events_cat' ) ) {
				$object = get_queried_object();
				if ( $object instanceof WP_Term ) {
					$term = $object;
				}
			}
			$is_events = $term || is_post_type_archive( 'tribe_events' ) || ( function_exists( 'tribe_is_event_query' ) && tribe_is_event_query() );
			if ( ! $is_events ) {
				return $found;
			}
			if ( ! $term ) {
				$slug = (string) get_query_var( 'tribe_events_cat' );
				if ( '' !== $slug ) {
					$by_slug = get_term_by( 'slug', $slug, 'tribe_events_cat' );
					if ( $by_slug instanceof WP_Term ) {
						$term = $by_slug;
					}
				}
			}

			// Only the ordinary page (and its "list" form), not a page for one month, day or page 2.
			$link = $term ? get_term_link( $term ) : get_post_type_archive_link( 'tribe_events' );
			if ( ! is_string( $link ) || '' === $link ) {
				return $found;
			}
			$base    = trailingslashit( (string) wp_parse_url( $link, PHP_URL_PATH ) );
			$request = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared, never printed.
			$path    = trailingslashit( (string) strtok( $request, '?' ) );
			if ( $path !== $base && $path !== $base . 'list/' ) {
				return $found;
			}

			$found = array(
				'kind' => $term ? 'category' : 'main',
				'term' => $term,
			);
		} catch ( \Throwable $e ) {
			$found = null;
		}
		return $found;
	}

	/**
	 * The wording for the page: the text typed in Yoast if there is any, otherwise the plain default.
	 * $what is 'title' or 'desc'.
	 */
	function tcc_event_search_text_for( $view, $what ) {
		$site = wp_strip_all_tags( get_bloginfo( 'name' ) );
		$name = $view['term'] ? wp_strip_all_tags( $view['term']->name ) : '';

		if ( 'category' === $view['kind'] ) {
			$key     = 'title' === $what ? 'title-tax-tribe_events_cat' : 'metadesc-tax-tribe_events_cat';
			$default = 'title' === $what
				? '%%term_title%% Events %%sep%% %%sitename%%'
				: 'Upcoming %%term_title%% events at Trinity Community Church in Knoxville, TN. See dates, times and how to take part.';
		} else {
			$key     = 'title' === $what ? 'title-ptarchive-tribe_events' : 'metadesc-ptarchive-tribe_events';
			$default = 'title' === $what
				? 'Upcoming Events %%sep%% %%sitename%%'
				: 'See what is coming up at Trinity Community Church in Knoxville, TN: classes, Bible studies, community dinners, prayer meetings and events for all ages.';
		}

		$saved = get_option( 'wpseo_titles' );
		$text  = ( is_array( $saved ) && isset( $saved[ $key ] ) && is_string( $saved[ $key ] ) ) ? trim( $saved[ $key ] ) : '';
		if ( '' === $text ) {
			$text = $default;
		}

		// Fill in the blanks Yoast uses. Anything else in %%double percent signs%% is dropped.
		$text = str_replace(
			array( '%%term_title%%', '%%sitename%%', '%%sep%%', '%%page%%' ),
			array( $name, $site, '-', '' ),
			$text
		);
		$text = (string) preg_replace( '/%%[a-z0-9_-]+%%/i', '', $text );
		$text = trim( (string) preg_replace( '/\s+/', ' ', $text ) );
		return $text;
	}

	/** Cuts a long piece of text to about 155 characters, ending on a whole word. */
	function tcc_event_search_text_short( $html ) {
		$text = wp_strip_all_tags( strip_shortcodes( (string) $html ) );
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
		if ( '' === $text ) {
			return '';
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
		if ( $length <= 158 ) {
			return $text;
		}
		$cut   = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 155 ) : substr( $text, 0, 155 );
		$space = function_exists( 'mb_strrpos' ) ? mb_strrpos( $cut, ' ' ) : strrpos( $cut, ' ' );
		if ( false !== $space && $space > 80 ) {
			$cut = function_exists( 'mb_substr' ) ? mb_substr( $cut, 0, $space ) : substr( $cut, 0, $space );
		}
		return rtrim( $cut, " ,;:-\t" ) . '...';
	}

	/** The description for one event that has none typed in Yoast. */
	function tcc_event_search_text_event( $post_id ) {
		// A description typed in Yoast's box comes first, in case Yoast has it saved but did not hand it over.
		$typed = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_yoast_wpseo_metadesc', true ) ) );
		if ( '' !== $typed && false === strpos( $typed, '%%' ) ) {
			return $typed;
		}
		foreach ( array( '_tcc_pco_summary', '_tcc_pco_description' ) as $meta_key ) {
			$short = tcc_event_search_text_short( get_post_meta( $post_id, $meta_key, true ) );
			if ( '' !== $short ) {
				return $short;
			}
		}
		$post = get_post( $post_id );
		if ( $post instanceof WP_Post ) {
			$short = tcc_event_search_text_short( '' !== trim( (string) $post->post_excerpt ) ? $post->post_excerpt : $post->post_content );
			if ( '' !== $short ) {
				return $short;
			}
		}
		return '';
	}

	/** The title in the browser tab and in search results. Runs after The Events Calendar and Yoast. */
	function tcc_event_search_text_title( $title ) {
		try {
			$view = tcc_event_search_text_view();
			if ( $view ) {
				$mine = tcc_event_search_text_for( $view, 'title' );
				if ( '' !== $mine ) {
					return $mine;
				}
			}
		} catch ( \Throwable $e ) {
			return $title;
		}
		return $title;
	}
	add_filter( 'pre_get_document_title', 'tcc_event_search_text_title', 9999 );
	add_filter( 'wpseo_title', 'tcc_event_search_text_title', 9999 );
	add_filter( 'wpseo_opengraph_title', 'tcc_event_search_text_title', 9999 );

	/** The description. Only fills a gap: anything Yoast already has is left alone. */
	function tcc_event_search_text_desc( $desc ) {
		try {
			if ( is_string( $desc ) && '' !== trim( $desc ) ) {
				return $desc;
			}
			if ( is_singular( 'tribe_events' ) ) {
				$mine = tcc_event_search_text_event( (int) get_queried_object_id() );
				return '' !== $mine ? $mine : $desc;
			}
			$view = tcc_event_search_text_view();
			if ( $view ) {
				$mine = tcc_event_search_text_for( $view, 'desc' );
				return '' !== $mine ? $mine : $desc;
			}
		} catch ( \Throwable $e ) {
			return $desc;
		}
		return $desc;
	}
	add_filter( 'wpseo_metadesc', 'tcc_event_search_text_desc', 9999 );
	add_filter( 'wpseo_opengraph_desc', 'tcc_event_search_text_desc', 9999 );
}
