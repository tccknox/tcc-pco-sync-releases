<?php
/**
 * TCC Trinity Talk pages: the short codes.
 *
 * Part: the short codes
 *
 * Every Trinity Talk short code except [tcc_talk_title] (that one is in features/trinity-talk.php),
 * with the small helpers they share: "Chapter 5 of 28", the chapter buttons, the writers of a list of
 * pieces, and the books in their usual order. The list of what each short code prints is at the top
 * of features/trinity-talk.php. Each one prints nothing on a page it does not belong to, and nothing
 * at all if something goes wrong, so a page never breaks because of one.
 *
 * Part of the "Trinity Talk pages" feature (features/trinity-talk.php loads it last; it reads the
 * index in books-and-chapters.php and the page facts in pages.php, in this folder).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_talk_chapter_words' ) ) {

	/** "Chapter 5 of 28" for a piece, or '' when it has no chapter number. */
	function tcc_talk_chapter_words( $post_id ) {
		$fact = tcc_talk_fact( $post_id );
		$book = tcc_talk_book_of( $post_id );
		if ( ! $fact || ! $book || ! $fact['n'] ) {
			return '';
		}
		return 'Chapter ' . (int) $fact['n'] . ( $book['max'] > 1 ? ' of ' . (int) $book['max'] : '' );
	}

	/** "Matthew - Chapter 5 of 28 - By Mark Medley - 3 minute read", under the title. */
	function tcc_talk_facts_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$dot  = '<span class="tcc-tt-dot" aria-hidden="true">&middot;</span>';
			$html = '';
			$book = tcc_talk_book_of( $id );
			if ( $book ) {
				$where   = '' !== $book['url'] ? '<a href="' . esc_url( $book['url'] ) . '">' . esc_html( $book['name'] ) . '</a>' : esc_html( $book['name'] );
				$chapter = tcc_talk_chapter_words( $id );
				$html   .= '<span class="tcc-tt-where">' . $where . ( '' !== $chapter ? ' &middot; ' . esc_html( $chapter ) : '' ) . '</span>' . $dot;
			}
			if ( '' !== $fact['a'] ) {
				$html .= 'By <b>' . esc_html( $fact['a'] ) . '</b>' . $dot;
			}
			return $html . (int) $fact['m'] . ' minute read';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_facts', 'tcc_talk_facts_shortcode' );

	/** One button for every chapter of a book. $here is the piece being read (0 for none). */
	function tcc_talk_chips( $book, $here ) {
		$index = tcc_talk_index();
		$html  = '<ul class="tcc-tt-chips">';
		foreach ( $book['ids'] as $id ) {
			$fact = $index['posts'][ $id ];
			$now  = (int) $id === (int) $here;
			$html .= '<li><a class="tcc-tt-chip' . ( $now ? ' is-here' : '' ) . '" href="' . esc_url( get_permalink( $id ) ) . '"'
				. ' aria-label="' . esc_attr( $book['name'] . ( $fact['n'] ? ' ' . $fact['n'] : '' ) . ': ' . $fact['t'] ) . '"'
				. ( $now ? ' aria-current="page"' : '' ) . '>' . ( $fact['n'] ? (int) $fact['n'] : '&bull;' ) . '</a></li>';
		}
		return $html . '</ul>';
	}

	/** True when a book's pieces carry chapter numbers and there is more than one. */
	function tcc_talk_has_chapters( $book ) {
		return is_array( $book ) && count( $book['ids'] ) > 1 && $book['max'] > 1;
	}

	/** The grey panel beside the words of a piece: Written by, a button for every chapter, Go further. */
	function tcc_talk_panel_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$book = tcc_talk_book_of( $id );
			$html = '';
			if ( '' !== $fact['a'] ) {
				$html .= '<h3>Written by</h3><p class="tcc-tt-who">' . esc_html( $fact['a'] ) . '</p>';
			}
			if ( tcc_talk_has_chapters( $book ) ) {
				$html .= '<h3>Chapters in ' . esc_html( $book['name'] ) . '</h3>' . tcc_talk_chips( $book, $id );
			}
			$html .= '<h3>Go further</h3>';
			if ( $book && $fact['n'] ) {
				// Opens the chapter itself on Bible Gateway, in a new tab, in the English Standard Version
				// (the owner's choice, 2026-11-21). To use another translation, change ESV below.
				$passage = $book['name'] . ( $book['max'] > 1 ? ' ' . (int) $fact['n'] : '' );
				$bible   = add_query_arg(
					array(
						'search'  => rawurlencode( $passage ),
						'version' => 'ESV',
					),
					'https://www.biblegateway.com/passage/'
				);
				$html   .= '<a class="tcc-tt-btn" href="' . esc_url( $bible ) . '" target="_blank" rel="noopener">Read ' . esc_html( $passage ) . ' in the Bible<span class="screen-reader-text"> (ESV, opens in a new tab)</span></a>';
			}
			$html .= '<a class="tcc-tt-btn" href="' . esc_url( tcc_talk_home_url() ) . '">Other books in Trinity Talk</a>';
			return '<div class="tcc-tt-panel">' . $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_panel', 'tcc_talk_panel_shortcode' );

	/** "Keep reading in Matthew" and "Chapter 5 of 28", for the heading above the previous and next rows. */
	function tcc_talk_steps_title_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book ) {
				return '';
			}
			$chapter = tcc_talk_chapter_words( $id );
			return 'Keep reading in ' . esc_html( $book['name'] ) . ( '' !== $chapter ? ' <span class="tcc-tt-count">' . esc_html( $chapter ) . '</span>' : '' );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_steps_title', 'tcc_talk_steps_title_shortcode' );

	/** The "See all 28 chapters" link. */
	function tcc_talk_book_link_shortcode() {
		try {
			$book = tcc_talk_book_of( tcc_talk_post_id() );
			if ( ! $book || '' === $book['url'] ) {
				return '';
			}
			$label = $book['max'] > 1 ? 'See all ' . (int) $book['max'] . ' chapters' : 'See all of ' . $book['name'];
			return '<a class="tcc-tt-link" href="' . esc_url( $book['url'] ) . '">' . esc_html( $label ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_link', 'tcc_talk_book_link_shortcode' );

	/** Inside a previous or next row: "Previous chapter" or "Next chapter". */
	function tcc_talk_step_shortcode() {
		try {
			$row_id = (int) get_the_ID();
			$steps  = tcc_talk_steps( tcc_talk_post_id() );
			// The small arrows only show when the two rows are stacked (tablets and phones).
			if ( $row_id && $row_id === $steps['prev'] ) {
				return '<b aria-hidden="true">&lsaquo; </b>Previous chapter';
			}
			if ( $row_id && $row_id === $steps['next'] ) {
				return 'Next chapter<b aria-hidden="true"> &rsaquo;</b>';
			}
			return '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_step', 'tcc_talk_step_shortcode' );

	/** The note shown where a row would be, on the first or the last chapter of a book. */
	function tcc_talk_end_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'which' => 'first' ), $atts, 'tcc_talk_end' );
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book || count( $book['ids'] ) < 2 ) {
				return '';
			}
			$steps = tcc_talk_steps( $id );
			if ( 'last' === $atts['which'] ) {
				return $steps['next'] ? '' : '<span class="tcc-tt-end">This is the last chapter of ' . esc_html( $book['name'] ) . '.</span>';
			}
			return $steps['prev'] ? '' : '<span class="tcc-tt-end">This is the first chapter of ' . esc_html( $book['name'] ) . '.</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_end', 'tcc_talk_end_shortcode' );

	/** "More from Matthew", or "More writing" for a piece in no book. */
	function tcc_talk_more_title_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book ) {
				return 'More writing';
			}
			// A book too short to have more chapters shows the start of other books instead.
			$more  = tcc_talk_more( $id );
			$first = $more ? tcc_talk_fact( $more[0] ) : null;
			if ( $first && (int) $first['book'] !== (int) $book['id'] ) {
				return 'More from Trinity Talk';
			}
			return 'More from ' . esc_html( $book['name'] );
		} catch ( \Throwable $e ) {
			return 'More writing';
		}
	}
	add_shortcode( 'tcc_talk_more_title', 'tcc_talk_more_title_shortcode' );

	/** The "Back to Trinity Talk" link. */
	function tcc_talk_home_link_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'Back to Trinity Talk' ), $atts, 'tcc_talk_home_link' );
		return '<a class="tcc-tt-link" href="' . esc_url( tcc_talk_home_url() ) . '">' . esc_html( $atts['label'] ) . '</a>';
	}
	add_shortcode( 'tcc_talk_home_link', 'tcc_talk_home_link_shortcode' );

	/** Inside a row or card: the small white tile, "MATTHEW 4" or (label="Chapter") "CHAPTER 4". */
	function tcc_talk_tile_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => '' ), $atts, 'tcc_talk_tile' );
		try {
			$id   = tcc_talk_item_id();
			$fact = tcc_talk_fact( $id );
			$book = tcc_talk_book_of( $id );
			if ( ! $fact || ! $book || ! $fact['n'] ) {
				return '';
			}
			$label = '' !== trim( (string) $atts['label'] ) ? (string) $atts['label'] : $book['name'];
			return '<span class="tcc-tt-tile-in"><small>' . esc_html( $label ) . '</small><b>' . (int) $fact['n'] . '</b></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_tile', 'tcc_talk_tile_shortcode' );

	/** Inside a card: "Matthew 7 - Mark Medley" (or the piece's group and writer). */
	function tcc_talk_card_meta_shortcode() {
		try {
			$id   = tcc_talk_item_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$book = tcc_talk_book_of( $id );
			$lead = $book ? $book['name'] . ( $fact['n'] && $book['max'] > 1 ? ' ' . (int) $fact['n'] : '' ) : $fact['g'];
			return esc_html( $lead ) . ( '' !== $lead && '' !== $fact['a'] ? ' &middot; ' : '' ) . esc_html( $fact['a'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_card_meta', 'tcc_talk_card_meta_shortcode' );

	/** Inside a row on a book's page: "Mark Medley - 3 minute read". */
	function tcc_talk_row_meta_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			if ( ! $fact ) {
				return '';
			}
			return esc_html( $fact['a'] ) . '<i>' . ( '' !== $fact['a'] ? ' &middot; ' : '' ) . (int) $fact['m'] . ' minute read</i>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_row_meta', 'tcc_talk_row_meta_shortcode' );

	/** Inside a row or card: the first sentence or two of the piece. */
	function tcc_talk_summary_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			return $fact ? esc_html( $fact['x'] ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_summary', 'tcc_talk_summary_shortcode' );

	/** The writers of a list of pieces, most pieces first: name => how many. */
	function tcc_talk_writers( $ids ) {
		$index = tcc_talk_index();
		$names = array();
		foreach ( (array) $ids as $id ) {
			$name = isset( $index['posts'][ $id ] ) ? (string) $index['posts'][ $id ]['a'] : '';
			if ( '' !== $name ) {
				$names[ $name ] = isset( $names[ $name ] ) ? $names[ $name ] + 1 : 1;
			}
		}
		return $names;
	}

	/** The sentence under a book's name. */
	function tcc_talk_book_lead_shortcode() {
		try {
			$term_id = tcc_talk_term_id();
			$ids     = tcc_talk_term_ids( $term_id );
			$count   = count( $ids );
			if ( ! $count ) {
				return '';
			}
			$index   = tcc_talk_index();
			$book    = isset( $index['books'][ $term_id ] ) ? $index['books'][ $term_id ] : null;
			$writers = array_keys( tcc_talk_writers( $ids ) );
			if ( 1 === count( $writers ) ) {
				$by = ', written by ' . $writers[0];
			} elseif ( $writers ) {
				$by = ', written by ' . count( $writers ) . ' of Trinity&rsquo;s pastors and partners';
			} else {
				$by = '';
			}
			if ( $book && $count > 1 && $count === (int) $book['max'] ) {
				return $count . ' chapters, each with a short reading' . ( 1 === count( $writers ) ? esc_html( $by ) : $by ) . '. Read them in order or pick a chapter.';
			}
			$lead = 1 === $count ? 'One short reading' : $count . ' short readings';
			return $lead . ( 1 === count( $writers ) ? esc_html( $by ) : $by ) . '.';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_lead', 'tcc_talk_book_lead_shortcode' );

	/** The "Start with chapter 1" button on a book's page. It follows the website's own button style. */
	function tcc_talk_start_shortcode() {
		try {
			$ids = tcc_talk_term_ids( tcc_talk_term_id() );
			if ( count( $ids ) < 2 ) {
				return '';
			}
			$fact  = tcc_talk_fact( $ids[0] );
			$label = ( $fact && 1 === (int) $fact['n'] ) ? 'Start with chapter 1' : 'Start reading';
			return '<a class="et_pb_button tcc-tt-start" href="' . esc_url( get_permalink( $ids[0] ) ) . '">' . esc_html( $label ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_start', 'tcc_talk_start_shortcode' );

	/** The grey panel on a book's page: Jump to a chapter, Written by, More. */
	function tcc_talk_book_panel_shortcode() {
		try {
			$term_id = tcc_talk_term_id();
			$ids     = tcc_talk_term_ids( $term_id );
			if ( ! $ids ) {
				return '';
			}
			$index = tcc_talk_index();
			$book  = isset( $index['books'][ $term_id ] ) ? $index['books'][ $term_id ] : null;
			$html  = '';
			$chips = tcc_talk_has_chapters( $book );
			if ( $chips ) {
				$html .= '<h3>Jump to a chapter</h3>' . tcc_talk_chips( $book, 0 );
			}
			$writers = array_keys( tcc_talk_writers( $ids ) );
			if ( $writers ) {
				$html .= '<h3 class="tcc-tt-opt">Written by</h3><p class="tcc-tt-names tcc-tt-opt">' . esc_html( implode( ', ', $writers ) ) . '</p>';
			}
			$html .= '<h3 class="tcc-tt-opt">More</h3><a class="tcc-tt-btn tcc-tt-opt" href="' . esc_url( tcc_talk_home_url() ) . '">Other books in Trinity Talk</a>';
			return '<div class="tcc-tt-panel' . ( $chips ? '' : ' tcc-tt-panel-plain' ) . '">' . $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_panel', 'tcc_talk_book_panel_shortcode' );

	/** The books in their usual order: array of category ids. Books not in the usual list go last, by name. */
	function tcc_talk_books_in_order( $group = '' ) {
		$index   = tcc_talk_index();
		$by_key  = array();
		foreach ( $index['books'] as $id => $book ) {
			if ( $book['ids'] ) {
				$by_key[ tcc_talk_key( $book['name'] ) ] = (int) $id;
			}
		}
		$out     = array();
		$shelves = tcc_talk_shelves();
		foreach ( $shelves as $name => $books ) {
			foreach ( $books as $book_name ) {
				$key = tcc_talk_key( $book_name );
				if ( isset( $by_key[ $key ] ) ) {
					if ( '' === $group || $group === $name ) {
						$out[] = $by_key[ $key ];
					}
					unset( $by_key[ $key ] );
				}
			}
		}
		if ( '' === $group || 'other' === $group ) {
			ksort( $by_key );
			$out = array_merge( $out, array_values( $by_key ) );
		}
		return $out;
	}

	/** A button for every book, with how many pieces it has. The book being viewed is filled in. */
	function tcc_talk_books_shortcode() {
		try {
			$index = tcc_talk_index();
			$here  = tcc_talk_term_id();
			$html  = '';
			foreach ( tcc_talk_books_in_order() as $id ) {
				$book  = $index['books'][ $id ];
				$now   = (int) $id === (int) $here;
				$html .= '<li><a class="tcc-tt-book' . ( $now ? ' is-here' : '' ) . '" href="' . esc_url( $book['url'] ) . '"' . ( $now ? ' aria-current="page"' : '' ) . '>' . esc_html( $book['name'] ) . ' <b>' . count( $book['ids'] ) . '</b></a></li>';
			}
			return '' === $html ? '' : '<ul class="tcc-tt-books">' . $html . '</ul>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_books', 'tcc_talk_books_shortcode' );

	/** The home page: one group's book cards. group="gospels", "paul" or "other". */
	function tcc_talk_shelf_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'group' => 'gospels' ), $atts, 'tcc_talk_shelf' );
		try {
			$index = tcc_talk_index();
			$html  = '';
			foreach ( tcc_talk_books_in_order( sanitize_key( $atts['group'] ) ) as $id ) {
				$book  = $index['books'][ $id ];
				$count = count( $book['ids'] );
				$html .= '<li><a class="tcc-tt-shelf-card" href="' . esc_url( $book['url'] ) . '"><span class="tcc-tt-shelf-txt"><span class="tcc-tt-shelf-name">' . esc_html( $book['name'] ) . '</span>'
					. '<span class="tcc-tt-shelf-count">' . $count . ( 1 === $count ? ' reading' : ' readings' ) . '</span></span></a></li>';
			}
			return '' === $html ? '' : '<ul class="tcc-tt-shelf">' . $html . '</ul>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_shelf', 'tcc_talk_shelf_shortcode' );

	/** How many pieces are in no book. */
	function tcc_talk_loose_count_shortcode() {
		try {
			$index = tcc_talk_index();
			return (string) count( $index['loose'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_loose_count', 'tcc_talk_loose_count_shortcode' );

	/**
	 * The "Show 12 more" button under the "More writing" cards, with "Showing 12 of 37" beside it.
	 * The page shows the first twelve cards and each press adds twelve (the same as the Sermons,
	 * Events and Community Groups pages). With JavaScript off every card simply shows.
	 */
	function tcc_talk_show_all_shortcode() {
		try {
			$index = tcc_talk_index();
			$count = count( $index['loose'] );
			if ( $count <= 12 ) {
				return '';
			}
			return '<div class="tcc-tt-more-row" hidden><button type="button" class="tcc-tt-btn tcc-tt-show-all">Show 12 more</button><span class="tcc-tt-more-note"></span></div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_show_all', 'tcc_talk_show_all_shortcode' );
}
