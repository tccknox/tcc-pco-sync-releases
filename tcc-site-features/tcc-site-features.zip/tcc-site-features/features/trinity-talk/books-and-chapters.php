<?php
/**
 * TCC Trinity Talk pages: the index of books and chapters.
 *
 * Part: the index of books and chapters
 *
 * What is in this part:
 *  - the WordPress names the feature reads (the post type "article" and the category "trinity-talk"),
 *    the names of the five lists Divi can loop over, and the books of the Bible in their usual order;
 *  - tcc_talk_index(): every book and every piece, worked out once. The chapter number is read from
 *    the start of each title ("Matthew 5 | ...", "1 Corinthians 13 | ...") and chapters are put in
 *    order by it. It also keeps the writer, how long a piece takes to read and a short summary.
 *    Remembered for 12 hours, and worked out again as soon as a piece or a Trinity Talk category is
 *    saved (tcc_talk_forget);
 *  - looking things up in it: one piece's facts, its book, its previous and next chapter, and the
 *    cards at the foot of a piece.
 *
 * Part of the "Trinity Talk pages" feature (features/trinity-talk.php loads it first). The other parts,
 * pages.php and short-codes.php in this folder, use what it works out.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_talk_index' ) ) {

	/** The WordPress names this feature reads. */
	function tcc_talk_post_type() {
		return 'article';
	}
	function tcc_talk_taxonomy() {
		return 'trinity-talk';
	}

	/** The five lists Divi can loop over: name => label shown in Divi's loop settings. */
	function tcc_talk_sources() {
		return array(
			'tcc_talk_prev'  => 'Trinity Talk: previous chapter (automatic)',
			'tcc_talk_next'  => 'Trinity Talk: next chapter (automatic)',
			'tcc_talk_more'  => 'Trinity Talk: more from this book (automatic)',
			'tcc_talk_list'  => 'Trinity Talk: every chapter of this book (automatic)',
			'tcc_talk_loose' => 'Trinity Talk: pieces in no book (automatic)',
		);
	}

	/** The books of the Bible in their usual order, in the three groups the home page shows. */
	function tcc_talk_shelves() {
		return array(
			'gospels' => array( 'Matthew', 'Mark', 'Luke', 'John', 'Acts' ),
			'paul'    => array( 'Romans', '1 Corinthians', '2 Corinthians', 'Galatians', 'Ephesians', 'Philippians', 'Colossians', '1 Thessalonians', '2 Thessalonians', '1 Timothy', '2 Timothy', 'Titus', 'Philemon' ),
			'other'   => array( 'Hebrews', 'James', '1 Peter', '2 Peter', '1 John', '2 John', '3 John', 'Jude', 'Revelation' ),
		);
	}

	/** Letters and digits only, lower case: used to compare "1 Corinthians" with "1corinthians". */
	function tcc_talk_key( $text ) {
		return preg_replace( '/[^a-z0-9]+/', '', strtolower( (string) $text ) );
	}

	/**
	 * The first sentence or two of a piece, for rows and cards: about 100 to 200 letters, ending at
	 * the end of a sentence where it can.
	 */
	function tcc_talk_make_summary( $content ) {
		$text = html_entity_decode( wp_strip_all_tags( strip_shortcodes( (string) $content ) ), ENT_QUOTES, 'UTF-8' );
		$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
		if ( '' === $text ) {
			return '';
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
		if ( $length <= 200 ) {
			return $text;
		}
		$out   = '';
		$parts = preg_split( '/(?<=[.!?])\s+/u', $text );
		foreach ( (array) $parts as $sentence ) {
			$try     = '' === $out ? $sentence : $out . ' ' . $sentence;
			$try_len = function_exists( 'mb_strlen' ) ? mb_strlen( $try ) : strlen( $try );
			if ( $try_len > 200 ) {
				break;
			}
			$out = $try;
			if ( $try_len >= 100 ) {
				break;
			}
		}
		if ( '' !== $out ) {
			return $out;
		}
		// The first sentence alone is too long: stop at a whole word and show that more follows.
		$cut   = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 180 ) : substr( $text, 0, 180 );
		$space = strrpos( $cut, ' ' );
		if ( false !== $space && $space > 80 ) {
			$cut = substr( $cut, 0, $space );
		}
		return rtrim( $cut, ' ,;:-' ) . '...';
	}

	/**
	 * Everything this feature knows, worked out once and remembered for 12 hours (and worked out
	 * again as soon as a piece or a Trinity Talk category is saved):
	 *   'posts' => piece id => array( t (short title), full, book (category id or 0), n (chapter or 0),
	 *                                 a (writer), m (minutes to read), x (summary), g (group, for pieces in no book) )
	 *   'books' => category id => array( name, slug, url, ids (in chapter order), max (highest chapter) )
	 *   'loose' => ids of the pieces in no book
	 *   'heads' => ids of the heading categories (New Testament, Old Testament)
	 */
	function tcc_talk_index() {
		static $index = null;
		if ( null !== $index ) {
			return $index;
		}
		// The "2" is the shape of what is remembered. Raise it when this function changes what it works
		// out, so an older remembered copy is not used.
		$key    = 'tcc_talk_index_2_' . tcc_site_gen( 'talk' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['posts'], $cached['books'], $cached['loose'], $cached['heads'] ) ) {
			$index = $cached;
			return $index;
		}
		$index = array(
			'posts' => array(),
			'books' => array(),
			'loose' => array(),
			'heads' => array(),
		);
		try {
			$terms = get_terms(
				array(
					'taxonomy'   => tcc_talk_taxonomy(),
					'hide_empty' => false,
				)
			);
			if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
				return $index;
			}
			// "New Testament" and "Old Testament" are headings; a book is a category filed under one of them.
			$heads = array();
			$names = array();
			foreach ( $terms as $term ) {
				$names[ (int) $term->term_id ] = (string) $term->name;
				if ( in_array( $term->slug, array( 'new-testament', 'old-testament' ), true ) ) {
					$heads[] = (int) $term->term_id;
				}
			}
			$index['heads'] = $heads;
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( in_array( $id, $heads, true ) || ! in_array( (int) $term->parent, $heads, true ) ) {
					continue;
				}
				$link                  = get_term_link( $term );
				$index['books'][ $id ] = array(
					'name' => html_entity_decode( (string) $term->name, ENT_QUOTES, 'UTF-8' ),
					'slug' => (string) $term->slug,
					'url'  => is_wp_error( $link ) ? '' : (string) $link,
					'ids'  => array(),
					'max'  => 0,
				);
			}

			$posts = get_posts(
				array(
					'post_type'        => tcc_talk_post_type(),
					'post_status'      => 'publish',
					'has_password'     => false, // A password-protected piece is never listed or summarised.
					'numberposts'      => -1,
					'orderby'          => 'date',
					'order'            => 'ASC',
					'suppress_filters' => true,
				)
			);
			$sort  = array();
			$loose = array();
			foreach ( (array) $posts as $post ) {
				if ( ! ( $post instanceof WP_Post ) ) {
					continue;
				}
				$id       = (int) $post->ID;
				$full     = trim( html_entity_decode( wp_strip_all_tags( (string) $post->post_title ), ENT_QUOTES, 'UTF-8' ) );
				// get_posts above fetched every piece's books in one go, so this asks the database nothing more.
				$terms    = get_the_terms( $id, tcc_talk_taxonomy() );
				$term_ids = ( ! $terms || is_wp_error( $terms ) ) ? array() : array_map( 'intval', wp_list_pluck( $terms, 'term_id' ) );
				$book     = 0;
				foreach ( $term_ids as $term_id ) {
					if ( isset( $index['books'][ $term_id ] ) ) {
						$book = $term_id;
						break;
					}
				}
				// "Matthew 5 | Choosing to Walk The Hard Path": the part before the bar names the book and chapter.
				$short   = $full;
				$chapter = 0;
				$bar     = strpos( $full, '|' );
				if ( $book && false !== $bar ) {
					$left  = trim( substr( $full, 0, $bar ) );
					$right = trim( substr( $full, $bar + 1 ) );
					// The book's name with any spacing ("1 Corinthians", "1Corinthians"), then the first number
					// after it. "John 2 & 3" is chapter 2.
					$words = array_map( 'preg_quote', preg_split( '/\s+/', trim( $index['books'][ $book ]['name'] ) ) );
					if ( '' !== $right && $words && preg_match( '/^' . implode( '\s*', $words ) . '(?![a-z])\s*(.*)$/iu', $left, $found ) ) {
						$short = $right;
						$rest  = trim( $found[1] );
						if ( preg_match( '/^(\d+)/', $rest, $number ) ) {
							$chapter = (int) $number[1];
						} elseif ( '' === $rest ) {
							$chapter = 1; // A book with one chapter (Jude, Philemon).
						}
					}
				}
				$typed = trim( (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ) );
				$words = str_word_count( wp_strip_all_tags( (string) $post->post_content ) );
				$group = '';
				if ( ! $book ) {
					foreach ( $term_ids as $term_id ) {
						if ( isset( $names[ $term_id ] ) && ( '' === $group || ! in_array( $term_id, $heads, true ) ) ) {
							$group = $names[ $term_id ];
						}
					}
					$loose[ $id ] = $post->post_date;
				}
				$index['posts'][ $id ] = array(
					't'    => $short,
					'full' => $full,
					'book' => $book,
					'n'    => $chapter,
					'a'    => (string) get_the_author_meta( 'display_name', (int) $post->post_author ),
					'm'    => max( 1, (int) round( $words / 220 ) ),
					'x'    => '' !== $typed ? $typed : tcc_talk_make_summary( $post->post_content ),
					'g'    => html_entity_decode( $group, ENT_QUOTES, 'UTF-8' ),
				);
				if ( $book ) {
					$sort[ $book ][ $id ] = sprintf( '%05d %s', $chapter ? $chapter : 99999, $post->post_date );
				}
			}
			foreach ( $sort as $book => $rows ) {
				asort( $rows, SORT_STRING );
				$index['books'][ $book ]['ids'] = array_map( 'intval', array_keys( $rows ) );
				foreach ( array_keys( $rows ) as $id ) {
					$index['books'][ $book ]['max'] = max( $index['books'][ $book ]['max'], $index['posts'][ $id ]['n'] );
				}
			}
			arsort( $loose, SORT_STRING ); // Newest first.
			$index['loose'] = array_map( 'intval', array_keys( $loose ) );
			set_transient( $key, $index, 12 * HOUR_IN_SECONDS );
		} catch ( \Throwable $e ) {
			return $index;
		}
		return $index;
	}

	/** Forget what was worked out, so the next page view works it out again. */
	function tcc_talk_forget() {
		tcc_site_new_gen( 'talk' );
	}
	add_action( 'save_post_article', 'tcc_talk_forget' );
	add_action(
		'deleted_post',
		function ( $post_id, $post = null ) {
			if ( $post instanceof WP_Post && tcc_talk_post_type() === $post->post_type ) {
				tcc_talk_forget();
			}
		},
		10,
		2
	);
	add_action(
		'set_object_terms',
		function ( $object_id, $terms, $tt_ids, $taxonomy ) {
			if ( tcc_talk_taxonomy() === $taxonomy ) {
				tcc_talk_forget();
			}
		},
		10,
		4
	);
	foreach ( array( 'created_trinity-talk', 'edited_trinity-talk', 'delete_trinity-talk' ) as $tcc_talk_hook ) {
		add_action( $tcc_talk_hook, 'tcc_talk_forget' );
	}
	unset( $tcc_talk_hook );

	/* ------------------------------------------------------------------------------------------
	 * Looking things up in the index.
	 * ---------------------------------------------------------------------------------------- */

	/** One piece's facts from the index, or null. */
	function tcc_talk_fact( $post_id ) {
		$index = tcc_talk_index();
		return isset( $index['posts'][ (int) $post_id ] ) ? $index['posts'][ (int) $post_id ] : null;
	}

	/** The book a piece belongs to (with 'id' and the piece's place 'at', from 0), or null. */
	function tcc_talk_book_of( $post_id ) {
		$fact  = tcc_talk_fact( $post_id );
		$index = tcc_talk_index();
		if ( ! $fact || ! $fact['book'] || ! isset( $index['books'][ $fact['book'] ] ) ) {
			return null;
		}
		$book       = $index['books'][ $fact['book'] ];
		$at         = array_search( (int) $post_id, $book['ids'], true );
		$book['id'] = (int) $fact['book'];
		$book['at'] = false === $at ? 0 : (int) $at;
		return $book;
	}

	/** The address of the Trinity Talk home page. */
	function tcc_talk_home_url() {
		$url = (string) get_post_type_archive_link( tcc_talk_post_type() );
		return '' !== $url ? $url : home_url( '/articles/' );
	}

	/** The pieces listed on a category's page, in order: a book's chapters, or a group's pieces. */
	function tcc_talk_term_ids( $term_id ) {
		$term_id = (int) $term_id;
		$index   = tcc_talk_index();
		if ( isset( $index['books'][ $term_id ] ) ) {
			return $index['books'][ $term_id ]['ids'];
		}
		if ( $term_id < 1 ) {
			return array();
		}
		static $memo = array();
		if ( ! isset( $memo[ $term_id ] ) ) {
			$ids              = get_posts(
				array(
					'post_type'        => tcc_talk_post_type(),
					'post_status'      => 'publish',
					'numberposts'      => 200,
					'fields'           => 'ids',
					'orderby'          => 'date',
					'order'            => 'DESC',
					'suppress_filters' => true,
					'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'taxonomy'         => tcc_talk_taxonomy(),
							'terms'            => array( $term_id ),
							'include_children' => false,
						),
					),
				)
			);
			$memo[ $term_id ] = array_map( 'intval', (array) $ids );
		}
		return $memo[ $term_id ];
	}

	/** The previous and next chapter of a piece: array( 'prev' => id or 0, 'next' => id or 0 ). */
	function tcc_talk_steps( $post_id ) {
		$book = tcc_talk_book_of( $post_id );
		// tcc_site_neighbours() is in the plugin's main file.
		return $book ? tcc_site_neighbours( $book['ids'], $book['at'] ) : tcc_site_neighbours( array(), 0 );
	}

	/**
	 * The cards at the foot of a piece: up to four.
	 * In a book: the chapters after the next one (going round to the start at the end of the book).
	 * In no book: other pieces that are in no book.
	 */
	function tcc_talk_more( $post_id ) {
		$post_id = (int) $post_id;
		$out     = array();
		$book    = tcc_talk_book_of( $post_id );
		$index   = tcc_talk_index();
		if ( $book ) {
			$ids   = $book['ids'];
			$count = count( $ids );
			$steps = tcc_talk_steps( $post_id );
			for ( $k = 2; $k < $count + 2 && count( $out ) < 4; $k++ ) {
				$id = (int) $ids[ ( $book['at'] + $k ) % $count ];
				if ( $id !== $post_id && $id !== $steps['prev'] && $id !== $steps['next'] && ! in_array( $id, $out, true ) ) {
					$out[] = $id;
				}
			}
			if ( ! $out ) {
				// A book with one or two pieces (Jude, Philemon) has no other chapters to offer:
				// show where the books that follow it begin (tcc_talk_books_in_order() is in short-codes.php).
				$order = tcc_talk_books_in_order();
				$place = array_search( (int) $book['id'], $order, true );
				$total = count( $order );
				for ( $k = 1; false !== $place && $k < $total && count( $out ) < 4; $k++ ) {
					$next = $index['books'][ $order[ ( $place + $k ) % $total ] ];
					if ( $next['ids'] ) {
						$out[] = (int) $next['ids'][0];
					}
				}
			}
			return $out;
		}
		$ids   = $index['loose'];
		$count = count( $ids );
		$at    = array_search( $post_id, $ids, true );
		$at    = false === $at ? -1 : (int) $at;
		for ( $k = 1; $k <= $count && count( $out ) < 4; $k++ ) {
			$id = (int) $ids[ ( $at + $k ) % $count ];
			if ( $id !== $post_id && ! in_array( $id, $out, true ) ) {
				$out[] = $id;
			}
		}
		return $out;
	}
}
