<?php
/**
 * TCC Trinity Talk pages: which page this is, and showing the three new layouts.
 *
 * Part: which page this is, the page swap and the lists Divi loops over
 *
 * What is in this part:
 *  - which page a visitor is on (one piece, a book's page or the home page) and, in the Divi editor,
 *    which real piece or book to show as an example;
 *  - finding the three Theme Builder layouts by the short code each one holds, and showing the right
 *    one on Trinity Talk pages whatever the Theme Builder has assigned to them (tcc_talk_swap_layout);
 *  - the steps for the back link above the title, which the "Page trail" feature asks for;
 *  - the five lists Divi loops over (previous chapter, next chapter, more from this book, every
 *    chapter of this book, pieces in no book).
 *
 * Part of the "Trinity Talk pages" feature (features/trinity-talk.php loads it, after
 * books-and-chapters.php in this folder, whose index it reads).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_talk_page_kind' ) ) {

	/* ------------------------------------------------------------------------------------------
	 * Which page is this?
	 * ---------------------------------------------------------------------------------------- */

	/** Is a visitor looking at one Trinity Talk piece? */
	function tcc_talk_is_single() {
		return did_action( 'wp' ) && ! is_admin() && is_singular( tcc_talk_post_type() );
	}

	/** Is a visitor looking at the page of a Trinity Talk category (a book)? */
	function tcc_talk_is_term() {
		return did_action( 'wp' ) && ! is_admin() && is_tax( tcc_talk_taxonomy() );
	}

	/** Is a visitor looking at the Trinity Talk home page (the list of all pieces)? */
	function tcc_talk_is_archive() {
		return did_action( 'wp' ) && ! is_admin() && is_post_type_archive( tcc_talk_post_type() );
	}

	/**
	 * Which of the three new pages this page view should show: 'single', 'book', 'home' or ''.
	 * The heading categories (New Testament) have no chapters of their own, so they show the home page.
	 */
	function tcc_talk_page_kind() {
		if ( tcc_talk_is_single() ) {
			return 'single';
		}
		if ( tcc_talk_is_archive() ) {
			return 'home';
		}
		if ( tcc_talk_is_term() ) {
			$index = tcc_talk_index();
			return in_array( (int) get_queried_object_id(), $index['heads'], true ) ? 'home' : 'book';
		}
		return '';
	}

	/** True in the Divi editor, where there is no piece or book being viewed. */
	function tcc_talk_editing() {
		return tcc_site_divi_drawing(); // In the plugin's main file.
	}

	/** A real book to show in the Divi editor: the one with the most chapters. */
	function tcc_talk_example_book() {
		$index = tcc_talk_index();
		$best  = 0;
		$most  = 0;
		foreach ( $index['books'] as $id => $book ) {
			if ( count( $book['ids'] ) > $most ) {
				$most = count( $book['ids'] );
				$best = (int) $id;
			}
		}
		return $best;
	}

	/** The piece these parts are about: the one being viewed, or, in the Divi editor, an example. */
	function tcc_talk_post_id() {
		if ( tcc_talk_is_single() ) {
			return (int) get_queried_object_id();
		}
		if ( ! tcc_talk_editing() ) {
			return 0;
		}
		$index = tcc_talk_index();
		$book  = tcc_talk_example_book();
		if ( $book && $index['books'][ $book ]['ids'] ) {
			$ids = $index['books'][ $book ]['ids'];
			return (int) $ids[ (int) floor( count( $ids ) / 2 ) ];
		}
		return 0;
	}

	/** The category whose page is being viewed (a book, or a group such as Christian Living), or an example. */
	function tcc_talk_term_id() {
		if ( tcc_talk_is_term() ) {
			return (int) get_queried_object_id();
		}
		return tcc_talk_editing() ? tcc_talk_example_book() : 0;
	}

	/** The piece a short code inside a row or card is about; outside one, the piece being viewed. */
	function tcc_talk_item_id() {
		$id    = (int) get_the_ID();
		$index = tcc_talk_index();
		if ( $id && isset( $index['posts'][ $id ] ) ) {
			return $id;
		}
		return tcc_talk_post_id();
	}

	/* ------------------------------------------------------------------------------------------
	 * Showing the three new layouts.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The Theme Builder body layouts that hold the three pages: array( 'single' => id, 'book' => id, 'home' => id ),
	 * 0 for one that does not exist. Found by the short code each holds, not by name or number, so
	 * renaming a template does not break anything.
	 */
	function tcc_talk_layouts() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		return tcc_site_body_layouts(
			array(
				'single' => '[tcc_talk_panel]',
				'book'   => '[tcc_talk_book_panel]',
				'home'   => '[tcc_talk_shelf',
			)
		);
	}

	/** The new layout this page view shows ('single', 'book' or 'home'), or '' when it keeps the older page. */
	function tcc_talk_showing() {
		static $showing = null;
		if ( null !== $showing ) {
			return $showing;
		}
		if ( ! did_action( 'wp' ) ) {
			return '';
		}
		$showing = '';
		try {
			$kind = tcc_talk_page_kind();
			if ( '' === $kind ) {
				return $showing;
			}
			$layouts = tcc_talk_layouts();
			if ( ! empty( $layouts[ $kind ] ) ) {
				$showing = $kind;
			}
		} catch ( \Throwable $e ) {
			$showing = '';
		}
		return $showing;
	}

	/** Shows the new layout on Trinity Talk pages, whatever is assigned to them in the Theme Builder. */
	function tcc_talk_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) ) {
				return $layouts;
			}
			$kind = tcc_talk_showing();
			if ( '' === $kind ) {
				return $layouts;
			}
			$ids = tcc_talk_layouts();
			return tcc_site_use_body_layout( $layouts, $ids[ $kind ] );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_talk_swap_layout', 20 );

	/** Used by the "Page trail" feature: the steps after Home on a Trinity Talk page, or null elsewhere. */
	function tcc_talk_trail_steps() {
		try {
			$kind = tcc_talk_page_kind();
			if ( '' === $kind ) {
				return null;
			}
			$steps = array();
			$home  = tcc_talk_home_url();
			if ( tcc_talk_is_archive() ) {
				$steps[] = array( 'Trinity Talk', '' );
				return $steps;
			}
			$steps[] = array( 'Trinity Talk', $home );
			if ( tcc_talk_is_term() ) {
				$term = get_queried_object();
				if ( $term instanceof WP_Term ) {
					// 'long' leaves this step off on phones, where the page title just below says the same.
					$steps[] = array(
						$term->name,
						'',
						'long' => true,
					);
				}
				return $steps;
			}
			$id   = (int) get_queried_object_id();
			$book = tcc_talk_book_of( $id );
			$fact = tcc_talk_fact( $id );
			if ( $book ) {
				$steps[] = array( $book['name'], $book['url'] );
			}
			$steps[] = array(
				$fact ? $fact['t'] : get_the_title( $id ),
				'',
				'long' => true,
			);
			return $steps;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/* ------------------------------------------------------------------------------------------
	 * The five lists Divi loops over.
	 * ---------------------------------------------------------------------------------------- */

	// Automatic lists for Divi loops (tcc_site_loop_source() is in the plugin's main file).
	add_action(
		'init',
		function () {
			foreach ( tcc_talk_sources() as $name => $label ) {
				tcc_site_loop_source( $name, $label, 'tcc_talk_answer', array( 'title' ) );
			}
		},
		30
	);

	/** The pieces a Divi loop gets for one of the five lists (cut to the loop's "posts per page"). */
	function tcc_talk_answer( $name, $query ) {
		if ( 'tcc_talk_loose' === $name ) {
			$index = tcc_talk_index();
			return $index['loose'];
		}
		if ( 'tcc_talk_list' === $name ) {
			return tcc_talk_term_ids( tcc_talk_term_id() );
		}
		$current = tcc_talk_post_id();
		if ( ! $current ) {
			return array();
		}
		if ( 'tcc_talk_more' === $name ) {
			return tcc_talk_more( $current );
		}
		$steps = tcc_talk_steps( $current );
		$one   = 'tcc_talk_prev' === $name ? $steps['prev'] : $steps['next'];
		return $one ? array( $one ) : array();
	}
}
