<?php
/**
 * Feature: "Sermons" instead of "Posts" in the admin.
 *
 * The church keeps its sermons as ordinary WordPress posts. This renames them where volunteers
 * see them in the admin:
 *
 *  1. The left-hand admin menu: "Posts" becomes "Sermons", and under it "All Posts" becomes
 *     "Sermons" and "Add New Post" becomes "Add New Sermon".
 *  2. The black bar along the top: "+ New" > "Post" becomes "+ New" > "Sermon".
 *
 * Visitors never see any of this. Nothing about the sermons themselves is changed: they stay posts,
 * with the same addresses, categories and fields. Switching it off brings back WordPress's own words.
 *
 * Part of the TCC Website plugin since 0.13.2. Until 2026-11-24 this was Code Snippets snippet 7,
 * 'Change "Posts" to "Sermons'. The menu and top-bar renaming is a straight copy of what that snippet
 * did, with two small safety changes:
 *  - the functions have their own names (tcc_sermon_labels_...), so this file and the old snippet
 *    can both be switched on for a moment while changing over without an error (they then just
 *    rename the same words twice);
 *  - the top-bar renaming first checks that the "+ New > Post" item is there. For someone who may not
 *    add posts it is missing, and the old snippet would then stop with an error.
 * The old snippet also held a function that would have renamed the words on the post screens
 * themselves ("Edit Post", "Search Posts" and so on), but it was never hooked up, so it never ran.
 * It was not copied.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermon_labels_menu' ) ) {

	/** 1. The left-hand admin menu. Posts is item 5 in WordPress's menu; its sub-items are 5 (All), 10 (Add New) and 16 (Tags). */
	function tcc_sermon_labels_menu() {
		global $menu, $submenu;
		if ( isset( $menu[5][0] ) ) {
			$menu[5][0] = 'Sermons'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- renaming a menu item is the point.
		}
		if ( isset( $submenu['edit.php'][5][0] ) ) {
			$submenu['edit.php'][5][0] = 'Sermons'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		if ( isset( $submenu['edit.php'][10][0] ) ) {
			$submenu['edit.php'][10][0] = 'Add New Sermon'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		if ( isset( $submenu['edit.php'][16][0] ) ) {
			$submenu['edit.php'][16][0] = 'Tags'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
	}
	add_action( 'admin_menu', 'tcc_sermon_labels_menu' );

	/** 2. The top bar's "+ New" menu. */
	function tcc_sermon_labels_admin_bar( $wp_admin_bar ) {
		$node = $wp_admin_bar->get_node( 'new-post' );
		if ( ! $node ) {
			return;
		}
		$node->title = 'Sermon';
		$wp_admin_bar->add_node( $node );
	}
	add_action( 'admin_bar_menu', 'tcc_sermon_labels_admin_bar', 80 );
}
