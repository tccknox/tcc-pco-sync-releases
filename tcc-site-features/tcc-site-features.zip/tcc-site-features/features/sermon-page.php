<?php
/**
 * TCC sermon page: the pieces of the page for one sermon.
 *
 * The page for one sermon is an ordinary Divi layout (Divi > Theme Builder > "Individual sermon
 * page - NEW"). Divi draws the player, the title, the short and long descriptions and the cards.
 * This file adds only the pieces Divi cannot work out by itself:
 *
 *  1. Short lines of text: the trail at the top (Sermons > series > this sermon), the series name
 *     and "Part 6 of 27", and the speaker and date.
 *  2. Three lists Divi can loop over, so the rows and cards stay ordinary Divi layers:
 *       "Sermon page: previous part of the series (automatic)"   none or one sermon
 *       "Sermon page: next part of the series (automatic)"       none or one sermon
 *       "Sermon page: more sermons (automatic)"                  up to four sermons: the newest other
 *                                                                parts of the series, or, for a sermon
 *                                                                in no series, the newest other sermons
 *  3. The "Find more like this" buttons (speaker, series, books of the Bible, topics). Each one
 *     opens the Sermons page already filtered.
 *  4. The "Read the full summary" button, which keeps a long write-up short until it is asked for.
 *  5. A few styles: the hover on rows and cards, the small arrows, and the Video / Audio switch.
 *  6. On the Audio side of the switch, the soft grey panel around the player with its heading and
 *     the line about the podcast (only on the new layout; the old one is left exactly as it was).
 *
 * Nothing is typed in twice. Series, speaker, book and topic all come from the sermon's categories,
 * worked out by the feature "Sermons page: search, filters and series", which this one needs.
 *
 * The styles (item 5 above) and the script (item 4, and pressing the words Video / Audio) are in
 * files of their own beside this one, printed inside the page: features/sermon-page.css and
 * features/sermon-page.js.
 *
 * Short codes:
 *   [tcc_sermon_crumbs]         the trail at the top: Home > Sermons > In Christ > How Do I Pray...
 *                               (the same trail as [tcc_trail] from the "Page trail" feature)
 *   [tcc_sermon_eyebrow]        "In Christ - Part 6 of 27" (the series name is a link), or "Sermon"
 *   [tcc_sermon_byline]         "Mark Medley - October 12, 2025" (the name opens that speaker's sermons)
 *   [tcc_sermon_series_title]   "In Christ" and "Part 6 of 27", for the heading above previous / next
 *   [tcc_sermon_series_link]    the "See the whole series" link
 *   [tcc_sermon_step]           inside a previous or next row: "Previous - Part 5" or "Next - Part 7"
 *   [tcc_sermon_end]            which="first" or "last": the note shown in place of a missing row
 *   [tcc_sermon_tags]           the "Find more like this" buttons
 *   [tcc_sermon_read_more]      the "Read the full summary" button (the long text needs the CSS ID
 *                               tcc-sermon-long)
 *   [tcc_sermon_more_title]     "More from this series" or "Recent sermons"
 *   [tcc_sermon_part]           inside a "more sermons" card: "Part 27 - May 31, 2026", or the
 *                               speaker and date
 *
 * In the Divi editor there is no sermon being viewed, so every piece shows a real sermon from the
 * newest series as an example.
 *
 * Part of the TCC Website Features plugin (added in 0.4.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermon_page_id' ) ) {

	/** The three lists Divi can loop over: name => label shown in Divi's loop settings. */
	function tcc_sermon_page_sources() {
		return array(
			'tcc_sermon_prev' => 'Sermon page: previous part of the series (automatic)',
			'tcc_sermon_next' => 'Sermon page: next part of the series (automatic)',
			'tcc_sermon_more' => 'Sermon page: more sermons (automatic)',
		);
	}

	/** True when the feature this one leans on ("Sermons page: search, filters and series") is running. */
	function tcc_sermon_page_ready() {
		return function_exists( 'tcc_sermons_index' ) && function_exists( 'tcc_sermons_speaker' );
	}

	/** Is a visitor looking at the page of one sermon? */
	function tcc_sermon_page_is_live() {
		return did_action( 'wp' ) && ! is_admin() && is_singular( 'post' );
	}

	/** A real sermon to show in the Divi editor: one from the middle of the newest series. */
	function tcc_sermon_page_example() {
		static $example = null;
		if ( null !== $example ) {
			return $example;
		}
		$example = 0;
		if ( ! tcc_sermon_page_ready() ) {
			return $example;
		}
		$index = tcc_sermons_index();
		foreach ( $index['series'] as $series_id => $row ) {
			$ids = tcc_sermons_series_post_ids( $series_id );
			if ( count( $ids ) >= 3 ) {
				$example = (int) $ids[ (int) floor( count( $ids ) / 2 ) ];
				break;
			}
		}
		if ( ! $example && $index['posts'] ) {
			$all     = array_keys( $index['posts'] );
			$example = (int) end( $all );
		}
		return $example;
	}

	/**
	 * The sermon these pieces are about: the one being viewed, or, in the Divi editor, the example.
	 * 0 anywhere else, so the short codes print nothing if they are put on some other page.
	 */
	function tcc_sermon_page_id() {
		if ( tcc_sermon_page_is_live() ) {
			return (int) get_queried_object_id();
		}
		// tcc_site_divi_drawing() (in the plugin's main file): the admin, the Divi editor, or a Theme Builder layout on its own.
		return tcc_site_divi_drawing() ? tcc_sermon_page_example() : 0;
	}

	/**
	 * The series a sermon belongs to, or null when it is in none.
	 * array( id, name, slug, url, ids (every part, oldest first), at (this sermon's place, from 0), count )
	 */
	function tcc_sermon_page_series( $post_id ) {
		static $memo = array();
		$post_id = (int) $post_id;
		if ( array_key_exists( $post_id, $memo ) ) {
			return $memo[ $post_id ];
		}
		$memo[ $post_id ] = null;
		if ( ! $post_id || ! tcc_sermon_page_ready() ) {
			return null;
		}
		$index     = tcc_sermons_index();
		$series_id = isset( $index['posts'][ $post_id ] ) ? (int) $index['posts'][ $post_id ] : 0;
		if ( ! $series_id || ! isset( $index['series'][ $series_id ] ) ) {
			return null;
		}
		$ids = tcc_sermons_series_post_ids( $series_id );
		$at  = array_search( $post_id, $ids, true );
		if ( false === $at ) {
			return null;
		}
		$row              = $index['series'][ $series_id ];
		$memo[ $post_id ] = array(
			'id'    => $series_id,
			'name'  => (string) $row['name'],
			'slug'  => (string) $row['slug'],
			'url'   => (string) $row['url'],
			'ids'   => $ids,
			'at'    => (int) $at,
			'count' => count( $ids ),
		);
		return $memo[ $post_id ];
	}

	/** The address of the Sermons page, with a filter already chosen when one is given. */
	function tcc_sermon_page_list_url( $filter = '', $value = '' ) {
		$url = (string) get_post_type_archive_link( 'post' );
		if ( '' === $url ) {
			$url = home_url( '/sermons/' );
		}
		return ( '' !== $filter && '' !== (string) $value ) ? add_query_arg( 'sermon_' . $filter, rawurlencode( (string) $value ), $url ) : $url;
	}

	/** The previous and next part of a sermon's series: array( 'prev' => id or 0, 'next' => id or 0 ). */
	function tcc_sermon_page_steps( $post_id ) {
		$series = tcc_sermon_page_series( $post_id );
		// tcc_site_neighbours() is in the plugin's main file.
		return $series ? tcc_site_neighbours( $series['ids'], $series['at'] ) : tcc_site_neighbours( array(), 0 );
	}

	/**
	 * The cards at the foot of the page: array( 'mode' => 'series' or 'recent', 'ids' => up to four sermons ).
	 * In a series: its newest other parts. In no series (or alone in one): the newest other sermons.
	 */
	function tcc_sermon_page_more( $post_id ) {
		$post_id = (int) $post_id;
		$out     = array(
			'mode' => 'recent',
			'ids'  => array(),
		);
		if ( ! $post_id || ! tcc_sermon_page_ready() ) {
			return $out;
		}
		$series = tcc_sermon_page_series( $post_id );
		if ( $series && $series['count'] >= 2 ) {
			$out['mode'] = 'series';
			$pool        = array_reverse( $series['ids'] );
		} else {
			$index = tcc_sermons_index();
			$pool  = array_reverse( array_keys( $index['posts'] ) );
		}
		foreach ( $pool as $id ) {
			if ( (int) $id !== $post_id ) {
				$out['ids'][] = (int) $id;
			}
			if ( count( $out['ids'] ) >= 4 ) {
				break;
			}
		}
		return $out;
	}

	/* ------------------------------------------------------------------------------------------
	 * The three lists Divi loops over.
	 * ---------------------------------------------------------------------------------------- */

	// Automatic lists for Divi loops (tcc_site_loop_source() is in the plugin's main file).
	add_action(
		'init',
		function () {
			foreach ( tcc_sermon_page_sources() as $name => $label ) {
				tcc_site_loop_source( $name, $label, 'tcc_sermon_page_answer' );
			}
		},
		30
	);

	/** The sermons a Divi loop gets for one of the three lists (cut to the loop's "posts per page"). */
	function tcc_sermon_page_answer( $name, $query ) {
		$current = tcc_sermon_page_id();
		if ( ! $current ) {
			return array();
		}
		if ( 'tcc_sermon_more' === $name ) {
			$more = tcc_sermon_page_more( $current );
			return $more['ids'];
		}
		$steps = tcc_sermon_page_steps( $current );
		$one   = 'tcc_sermon_prev' === $name ? $steps['prev'] : $steps['next'];
		return $one ? array( $one ) : array();
	}

	/**
	 * On a sermon page, a row or card for another sermon that has no graphic of its own borrows its
	 * series graphic, or the church's default graphic. The sermon being viewed is left alone.
	 */
	function tcc_sermon_page_borrowed_graphic( $value, $post_id, $meta_key ) {
		if ( '_thumbnail_id' !== $meta_key || ! empty( $GLOBALS['tcc_sermons_building'] ) || ! function_exists( 'tcc_sermons_stand_in_graphic' ) ) {
			return $value;
		}
		if ( ! tcc_sermon_page_is_live() || (int) $post_id === (int) get_queried_object_id() ) {
			return $value;
		}
		static $busy = false;
		if ( $busy || 'post' !== get_post_type( $post_id ) ) {
			return $value;
		}
		$busy = true;
		$own  = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		$busy = false;
		if ( $own ) {
			return $value;
		}
		$stand_in = (int) tcc_sermons_stand_in_graphic( $post_id );
		return $stand_in ? array( $stand_in ) : $value;
	}
	add_filter( 'get_post_metadata', 'tcc_sermon_page_borrowed_graphic', 10, 3 );
}

/* ----------------------------------------------------------------------------------------------
 * Short codes.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_crumbs_shortcode' ) ) {

	/** The plain title of a sermon, safe to print. */
	function tcc_sermon_page_title( $post_id ) {
		return esc_html( html_entity_decode( wp_strip_all_tags( get_the_title( $post_id ) ), ENT_QUOTES, 'UTF-8' ) );
	}

	/**
	 * Home > Sermons > In Christ > How Do I Pray for My People?
	 * When the "Page trail" feature is on, this prints that feature's trail, so the sermon page
	 * matches every other page. The plainer trail below is only the fallback for when it is off.
	 */
	function tcc_sermon_crumbs_shortcode() {
		try {
			if ( function_exists( 'tcc_trail_shortcode' ) && tcc_sermon_page_id() ) {
				return tcc_trail_shortcode();
			}
			$id = tcc_sermon_page_id();
			if ( ! $id ) {
				return '';
			}
			$sep    = '<span class="tcc-sp-sep" aria-hidden="true">&rsaquo;</span>';
			$html   = '<a href="' . esc_url( tcc_sermon_page_list_url() ) . '">Sermons</a>';
			$series = tcc_sermon_page_series( $id );
			if ( $series && '' !== $series['url'] ) {
				$html .= $sep . '<a href="' . esc_url( $series['url'] ) . '">' . esc_html( $series['name'] ) . '</a>';
			}
			$html .= '<span class="tcc-sp-here">' . $sep . '<em>' . tcc_sermon_page_title( $id ) . '</em></span>';
			return '<nav class="tcc-sp-crumbs" aria-label="You are here">' . $html . '</nav>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_crumbs', 'tcc_sermon_crumbs_shortcode' );

	/** "In Christ - Part 6 of 27", or "Sermon" for a sermon in no series. */
	function tcc_sermon_eyebrow_shortcode() {
		try {
			$id = tcc_sermon_page_id();
			if ( ! $id ) {
				return '';
			}
			$series = tcc_sermon_page_series( $id );
			if ( ! $series ) {
				return 'Sermon';
			}
			$name = '' !== $series['url'] ? '<a href="' . esc_url( $series['url'] ) . '">' . esc_html( $series['name'] ) . '</a>' : esc_html( $series['name'] );
			if ( $series['count'] < 2 ) {
				return $name;
			}
			return $name . ' &middot; Part ' . ( (int) $series['at'] + 1 ) . ' of ' . (int) $series['count'];
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_eyebrow', 'tcc_sermon_eyebrow_shortcode' );

	/** "Mark Medley - October 12, 2025". Each name opens the Sermons page filtered to that speaker. */
	function tcc_sermon_byline_shortcode() {
		try {
			$id = tcc_sermon_page_id();
			if ( ! $id || ! tcc_sermon_page_ready() ) {
				return '';
			}
			$speaker = (string) tcc_sermons_speaker( $id );
			$names   = function_exists( 'tcc_sermons_speaker_people' ) ? tcc_sermons_speaker_people( $id ) : array();
			$links   = array();
			foreach ( $names as $key => $name ) {
				$links[] = '<a href="' . esc_url( tcc_sermon_page_list_url( 'speaker', $key ) ) . '">' . esc_html( $name ) . '</a>';
			}
			// "Tyler Lynde & Amy Lynde", or "A, B & C" (each name a link).
			$who  = $links ? tcc_sermons_join_names( $links, ' &amp; ' ) : esc_html( $speaker );
			$date = esc_html( (string) get_the_date( 'F j, Y', $id ) );
			return $who . ( '' !== $who && '' !== $date ? '<span class="tcc-sp-dot" aria-hidden="true">&middot;</span>' : '' ) . $date;
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_byline', 'tcc_sermon_byline_shortcode' );

	/** "In Christ" and "Part 6 of 27", for the heading above the previous and next rows. */
	function tcc_sermon_series_title_shortcode() {
		try {
			$series = tcc_sermon_page_series( tcc_sermon_page_id() );
			if ( ! $series ) {
				return '';
			}
			return esc_html( $series['name'] ) . ' <span class="tcc-sp-count">Part ' . ( (int) $series['at'] + 1 ) . ' of ' . (int) $series['count'] . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_series_title', 'tcc_sermon_series_title_shortcode' );

	/** The "See the whole series" link. */
	function tcc_sermon_series_link_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'See the whole series' ), $atts, 'tcc_sermon_series_link' );
		try {
			$series = tcc_sermon_page_series( tcc_sermon_page_id() );
			if ( ! $series || '' === $series['url'] ) {
				return '';
			}
			return '<a class="tcc-sp-link" href="' . esc_url( $series['url'] ) . '">' . esc_html( $atts['label'] ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_series_link', 'tcc_sermon_series_link_shortcode' );

	/** Inside a previous or next row: "Previous - Part 5" or "Next - Part 7". */
	function tcc_sermon_step_shortcode() {
		try {
			$row_id = (int) get_the_ID();
			$series = tcc_sermon_page_series( tcc_sermon_page_id() );
			if ( ! $row_id || ! $series ) {
				return '';
			}
			$at = array_search( $row_id, $series['ids'], true );
			if ( false === $at || (int) $at === $series['at'] ) {
				return '';
			}
			$part = 'Part ' . ( (int) $at + 1 );
			// The small arrows only show when the two rows are stacked (tablets and phones).
			if ( (int) $at < $series['at'] ) {
				return '<b aria-hidden="true">&lsaquo; </b>Previous &middot; ' . $part;
			}
			return 'Next &middot; ' . $part . '<b aria-hidden="true"> &rsaquo;</b>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_step', 'tcc_sermon_step_shortcode' );

	/** The note shown where a row would be, on the first or the latest part of a series. */
	function tcc_sermon_end_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'which' => 'first' ), $atts, 'tcc_sermon_end' );
		try {
			$id     = tcc_sermon_page_id();
			$series = tcc_sermon_page_series( $id );
			if ( ! $series || $series['count'] < 2 ) {
				return '';
			}
			$steps = tcc_sermon_page_steps( $id );
			if ( 'last' === $atts['which'] ) {
				return $steps['next'] ? '' : '<span class="tcc-sp-end">This is the latest part of the series.</span>';
			}
			return $steps['prev'] ? '' : '<span class="tcc-sp-end">This is the first part of the series.</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_end', 'tcc_sermon_end_shortcode' );

	/** One group of "Find more like this" buttons. $items is key => name. */
	function tcc_sermon_page_tag_group( $label, $items, $filter ) {
		if ( ! $items ) {
			return '';
		}
		$html = '<h3>' . esc_html( $label ) . '</h3><ul class="tcc-sp-tags">';
		foreach ( $items as $key => $name ) {
			$html .= '<li><a class="tcc-sp-tag" href="' . esc_url( tcc_sermon_page_list_url( $filter, $key ) ) . '">' . esc_html( $name ) . '</a></li>';
		}
		return $html . '</ul>';
	}

	/** The "Find more like this" buttons: speaker, series, books of the Bible, topics. */
	function tcc_sermon_tags_shortcode() {
		try {
			$id = tcc_sermon_page_id();
			if ( ! $id || ! tcc_sermon_page_ready() ) {
				return '';
			}
			$facts   = tcc_sermons_facts( $id );
			$speaker = function_exists( 'tcc_sermons_speaker_people' ) ? tcc_sermons_speaker_people( $id ) : array();
			$books   = $facts['book'];
			$topics  = $facts['topic'];
			natcasesort( $books );
			natcasesort( $topics );
			$html  = tcc_sermon_page_tag_group( 'Speaker', $speaker, 'speaker' );
			$html .= tcc_sermon_page_tag_group( 'Series', $facts['series'], 'series' );
			$html .= tcc_sermon_page_tag_group( 'Scripture', $books, 'book' );
			$html .= tcc_sermon_page_tag_group( 'Topics', $topics, 'topic' );
			return '' === $html ? '' : '<div class="tcc-sp-find">' . $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_tags', 'tcc_sermon_tags_shortcode' );

	/**
	 * The "Read the full summary" button. It starts hidden; the page's script shows it only when the
	 * long text (the layer with the CSS ID tcc-sermon-long) is tall enough to be worth shortening.
	 */
	function tcc_sermon_read_more_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'more' => 'Read the full summary',
				'less' => 'Show less',
			),
			$atts,
			'tcc_sermon_read_more'
		);
		return '<button type="button" class="tcc-sp-more" hidden aria-expanded="false" aria-controls="tcc-sermon-long" data-more="' . esc_attr( $atts['more'] ) . '" data-less="' . esc_attr( $atts['less'] ) . '">' . esc_html( $atts['more'] ) . '</button>';
	}
	add_shortcode( 'tcc_sermon_read_more', 'tcc_sermon_read_more_shortcode' );

	/** "More from this series" or "Recent sermons". */
	function tcc_sermon_more_title_shortcode() {
		try {
			$more = tcc_sermon_page_more( tcc_sermon_page_id() );
			return 'series' === $more['mode'] ? 'More from this series' : 'Recent sermons';
		} catch ( \Throwable $e ) {
			return 'Recent sermons';
		}
	}
	add_shortcode( 'tcc_sermon_more_title', 'tcc_sermon_more_title_shortcode' );

	/** Inside a "more sermons" card: "Part 27 - May 31, 2026", or "Speaker - May 31, 2026". */
	function tcc_sermon_part_shortcode() {
		try {
			$card_id = (int) get_the_ID();
			if ( ! $card_id || 'post' !== get_post_type( $card_id ) || ! tcc_sermon_page_ready() ) {
				return '';
			}
			$date   = (string) get_the_date( 'M j, Y', $card_id );
			$lead   = '';
			$series = tcc_sermon_page_series( tcc_sermon_page_id() );
			if ( $series && $series['count'] >= 2 ) {
				$at = array_search( $card_id, $series['ids'], true );
				if ( false !== $at ) {
					$lead = 'Part ' . ( (int) $at + 1 );
				}
			}
			if ( '' === $lead ) {
				$lead = (string) tcc_sermons_speaker( $card_id );
			}
			return esc_html( $lead ) . ( '' !== $lead && '' !== $date ? ' &middot; ' : '' ) . esc_html( $date );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_part', 'tcc_sermon_part_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * The Audio side of the player.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_page_uses_new_layout' ) ) {

	/**
	 * Is this sermon being shown with the new layout (the one that holds [tcc_sermon_crumbs])?
	 * While the old layout is kept for rollback, its pages must stay exactly as they were.
	 */
	function tcc_sermon_page_uses_new_layout() {
		static $answer = null;
		if ( null !== $answer ) {
			return $answer;
		}
		if ( ! tcc_sermon_page_is_live() ) {
			return false;
		}
		$answer = false;
		try {
			if ( function_exists( 'et_theme_builder_get_template_layouts' ) ) {
				$layouts = et_theme_builder_get_template_layouts();
				$body_id = ( is_array( $layouts ) && isset( $layouts['et_body_layout']['id'] ) ) ? (int) $layouts['et_body_layout']['id'] : 0;
				$body    = $body_id ? get_post( $body_id ) : null;
				$answer  = ( $body instanceof WP_Post ) && false !== strpos( (string) $body->post_content, 'tcc_sermon_crumbs' );
			}
		} catch ( \Throwable $e ) {
			$answer = false;
		}
		return $answer;
	}

	/**
	 * On the new layout the audio player sits in a soft grey panel with a heading above it and a
	 * line about the podcast below, as in the approved design. The player itself still comes from
	 * [tcc_sermon_audio] (the feature "Sermon audio player"), inside the Divi Library layout
	 * "Sermon Podcast" that the Video / Audio switch shows.
	 */
	function tcc_sermon_page_audio_panel( $output, $tag ) {
		if ( 'tcc_sermon_audio' !== $tag || '' === trim( (string) $output ) ) {
			return $output;
		}
		try {
			if ( ! tcc_sermon_page_uses_new_layout() ) {
				return $output;
			}
		} catch ( \Throwable $e ) {
			return $output;
		}
		return '<div class="tcc-sp-audio"><p class="tcc-sp-audio-title">Listen to this sermon</p><div class="tcc-sp-audio-box">' . $output . '</div><p class="tcc-sp-audio-note">Also on the Trinity podcast, in every podcast app.</p></div>';
	}
	add_filter( 'do_shortcode_tag', 'tcc_sermon_page_audio_panel', 10, 2 );
}

/* ----------------------------------------------------------------------------------------------
 * Looks, and the "Read the full summary" button.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_page_css' ) ) {

	/**
	 * Tells the styles what kind of sermon this is:
	 *   tcc-sermon-page       every sermon page
	 *   tcc-sermon-no-steps   a sermon with no previous or next part (the "tcc-sp-series" section hides)
	 */
	add_filter(
		'body_class',
		function ( $classes ) {
			try {
				if ( tcc_sermon_page_is_live() ) {
					$classes[] = 'tcc-sermon-page';
					$series    = tcc_sermon_page_series( (int) get_queried_object_id() );
					if ( ! $series || $series['count'] < 2 ) {
						$classes[] = 'tcc-sermon-no-steps';
					}
				}
			} catch ( \Throwable $e ) {
				return $classes;
			}
			return $classes;
		}
	);

	/**
	 * The styles for the sermon page. Colours, corner size and fonts match the Sermons page.
	 * The teal here is the one Trinity teal (#00A4CF) throughout, as the owner asked on 2026-11-21.
	 */
	function tcc_sermon_page_css() {
		// The rules themselves are in features/sermon-page.css. Two notes on them:
		// - A previous or next row with no sermon in it is hidden (Divi prints "No Results Found" there).
		// - ":not(#tcc-keep)" only makes one rule strong enough to win over the Events feature's rule
		//   that hides the whole box around an empty list. Here that box also holds the "This is the
		//   first part of the series" note, so on computers it has to stay. No layer has that ID.
		return tcc_site_asset( 'features/sermon-page.css' ); // tcc_site_asset() is in the plugin's main file.
	}

	/** The styles go in the head of every sermon page, so nothing flashes unstyled. */
	add_action(
		'wp_head',
		function () {
			if ( tcc_sermon_page_is_live() ) {
				echo '<style id="tcc-sermon-page-css">' . tcc_sermon_page_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		},
		30
	);

	/**
	 * Shortens a long write-up and makes the "Read the full summary" button open and close it.
	 * A short write-up is left alone and the button stays hidden. With JavaScript off the whole
	 * write-up simply shows. It also lets a press on the words "Video" and "Audio" work the switch.
	 * The script itself is in features/sermon-page.js; the "\n" after it is the line break the file's
	 * last line had.
	 */
	add_action(
		'wp_footer',
		function () {
			if ( ! tcc_sermon_page_is_live() ) {
				return;
			}
			?>
<script id="tcc-sermon-page-js">
<?php echo tcc_site_asset( 'features/sermon-page.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
			<?php
		},
		51
	);
}
