(function () {
	try {
		var bar = document.querySelector('header.et-l--header, .et-l--header');
		var fixed = bar && bar.querySelector('.et_pb_sticky, [class*="sticky"]');
		var h = fixed ? fixed.getBoundingClientRect().height : 0;
		if (h > 0 && h < 300) { document.documentElement.style.setProperty('--tcc-tt-top', Math.round(h + 40) + 'px'); }
	} catch (e) {}
	var list = document.querySelector('.tcc-tt-loose');
	var btn = document.querySelector('.tcc-tt-show-all');
	if (!list || !btn) { return; }
	var row = btn.parentNode, note = row.querySelector('.tcc-tt-more-note');
	var cards = [].slice.call(list.querySelectorAll('.tcc-tt-card')), STEP = 12, max = STEP;
	function paint() {
		cards.forEach(function (c, i) { c.classList.toggle('is-later', i >= max); });
		var left = cards.length - max;
		row.hidden = left <= 0;
		btn.textContent = 'Show ' + Math.min(STEP, left) + ' more';
		if (note) { note.textContent = 'Showing ' + Math.min(max, cards.length) + ' of ' + cards.length; }
	}
	paint();
	btn.addEventListener('click', function () {
		var next = cards[max];
		max += STEP;
		paint();
		if (next) { next.setAttribute('tabindex', '-1'); try { next.focus(); } catch (e) {} }
	});
})();
