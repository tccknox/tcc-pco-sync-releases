/* TCC Website Features: "Learn more" on the cookie banner opens the website's own Cookie Policy page
   (since 0.14.7). termly-look.php prints this at the foot of every page a visitor sees, with the
   page's address on the script tag (data-page).
   Termly's own link (the words are changed to "Learn more" in termly-look.css) opens the policy in a
   small window over the page. This catches the press (a click, or Enter or Space for keyboard users)
   just before Termly does, and goes to the page instead. Ctrl- or Cmd-click opens it in a new tab.
   If Termly changes its banner and the link is not found, nothing here happens and Termly's window
   opens as before. Nothing about what the banner does or remembers is changed. */
(function () {
	var me = document.getElementById('tcc-termly-look-js');
	var page = me && me.getAttribute('data-page');
	if (!page || !document.addEventListener) {
		return;
	}
	var LINK = '.t-consentPrompt [data-testid="cookie-policy-link"]';

	function findLink(e) {
		var t = e.target;
		return t && t.closest ? t.closest(LINK) : null;
	}

	// Screen readers: Termly calls it a button that opens a window; it is now a link to a page.
	function tidy(e) {
		var link = findLink(e);
		if (link && link.getAttribute('role') !== 'link') {
			link.setAttribute('role', 'link');
			link.removeAttribute('aria-haspopup');
		}
	}

	function go(e) {
		if (!findLink(e)) {
			return;
		}
		if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') {
			return;
		}
		e.preventDefault();
		e.stopImmediatePropagation();
		if (e.type === 'click' && (e.ctrlKey || e.metaKey)) {
			window.open(page, '_blank', 'noopener');
		} else if (window.location.href.split('#')[0] === page) {
			window.scrollTo(0, 0); // Already on the Cookie Policy page.
		} else {
			window.location.href = page;
		}
	}

	// "true" = in the capturing phase, which runs before Termly's own handler.
	window.addEventListener('click', go, true);
	window.addEventListener('keydown', go, true);
	window.addEventListener('focusin', tidy, true);
	window.addEventListener('pointerover', tidy, true);
})();
