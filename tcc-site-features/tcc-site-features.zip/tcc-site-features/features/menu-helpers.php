<?php
/**
 * TCC main menu helpers.
 *
 * Five small jobs for the main menu header (the Global Header in Divi > Theme Builder). Divi cannot do
 * them by itself. The menu's words, links, pictures and looks are all in the Divi header.
 *
 * 1. The red "Watch Online" button (the layer with the CSS class tccm-watch) is hidden all
 *    week and shows on Sunday from 8:30am to 12 noon, Knoxville time. The times are on the
 *    LIVE line below; the button's words and link are in the Divi layer. To see the button
 *    on any day, add ?navlive=1 to a page address.
 * 2. It makes every drop-down panel the same height as the tallest one, so the menu does
 *    not change size as you move from one menu button to the next.
 * 3. When the Search button (the magnifying glass) is clicked, it puts the typing cursor in
 *    the search box, so a visitor can type straight away.
 * 4. On a window between 981 and about 995 pixels wide that has a scroll bar, Divi's phone-menu
 *    switch hides the menu buttons although the page is still in its computer layout, which
 *    would leave no menu at all. This puts them back.
 * 5. If a window is made narrower (or a tablet is turned upright) and so changes from the
 *    computer layout to the phone layout, it closes the phone menu, which would otherwise
 *    open by itself and cover the page.
 *
 * It does nothing on a page whose header has no tccm-... layers (for example the old header).
 * To switch it off, use TCC Website > Features: Watch Online then never shows and the panels
 * keep their own heights.
 *
 * Part of the TCC Website plugin since 0.13.2. Until 2026-11-24 this was Code Snippets
 * snippet 31, "TCC main menu helpers". The code is a straight copy of that snippet.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_main_menu_helpers' ) ) {
	function tcc_main_menu_helpers() {
		if ( is_admin() || isset( $_GET['et_fb'] ) ) {
			return;
		}
		?>
<script id="tcc-main-menu-helpers" nowprocket data-nowprocket>
(function () {
	// Sunday, 8:30am (510 minutes after midnight) to 12 noon (720), Knoxville time.
	var LIVE = { day: 'Sun', from: 510, to: 720, zone: 'America/New_York' };

	function each(list, fn) { Array.prototype.forEach.call(list, fn); }

	function isLive() {
		if (location.search.indexOf('navlive=1') > -1) { return true; }
		try {
			var o = {};
			new Intl.DateTimeFormat('en-US', { timeZone: LIVE.zone, weekday: 'short', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(new Date()).forEach(function (p) { o[p.type] = p.value; });
			var m = (parseInt(o.hour, 10) % 24) * 60 + parseInt(o.minute, 10);
			return o.weekday === LIVE.day && m >= LIVE.from && m < LIVE.to;
		} catch (err) { return false; }
	}

	// 1. Watch Online. The class "tccm-live-on" on the white bar is what shows the red button (see the menu stylesheet).
	function setButton() {
		var live = isLive();
		each(document.querySelectorAll('.tccm-bar'), function (bar) { bar.classList.toggle('tccm-live-on', live); });
	}

	// 2. Same height for every drop-down panel (computer-size screens only).
	function evenPanels() {
		var rows = document.querySelectorAll('.tccm-panel:not(.tccm-panel-search) .tccm-row'), tallest = 0;
		each(rows, function (r) { r.style.removeProperty('min-height'); });
		if (!rows.length || !window.matchMedia('(min-width:981px)').matches) { return; }
		each(rows, function (r) {
			var panel = r.closest('.tccm-panel'), hidden = panel.classList.contains('et_pb_dropdown_hidden');
			if (hidden) { panel.classList.remove('et_pb_dropdown_hidden'); }
			tallest = Math.max(tallest, r.offsetHeight);
			if (hidden) { panel.classList.add('et_pb_dropdown_hidden'); }
		});
		if (tallest) { each(rows, function (r) { r.style.setProperty('min-height', tallest + 'px', 'important'); }); }
	}

	// 3. Clicking the magnifying glass puts the cursor in the search box (computer-size screens only).
	document.addEventListener('click', function (e) {
		if (!e.target.closest || !e.target.closest('.tccm-search') || !window.matchMedia('(min-width:981px)').matches) { return; }
		setTimeout(function () {
			var panel = document.querySelector('.tccm-panel-search'), box = panel ? panel.querySelector('input.et_pb_s') : null;
			if (box && !panel.classList.contains('et_pb_dropdown_hidden')) { box.focus(); }
		}, 120);
	});

	// 4. Keep the menu buttons showing whenever the page is in its computer layout.
	function keepMenu() {
		if (!window.matchMedia('(min-width:981px)').matches) { return; }
		each(document.querySelectorAll('.tccm-items'), function (m) {
			if (m.style.display === 'none') { m.style.removeProperty('display'); }
		});
	}
	function watchMenu() {
		keepMenu();
		if (!window.MutationObserver) { return; }
		each(document.querySelectorAll('.tccm-items'), function (m) {
			new MutationObserver(keepMenu).observe(m, { attributes: true, attributeFilter: ['style'] });
		});
	}

	// 5. Changing from the computer layout to the phone layout: start with the phone menu closed.
	var wide = window.matchMedia('(min-width:981px)');
	function onLayoutChange() {
		if (wide.matches) { keepMenu(); return; }
		each(document.querySelectorAll('.tccm-items, .tccm-close-btn'), function (el) { el.style.setProperty('display', 'none', 'important'); });
		each(document.querySelectorAll('.tccm-menu-btn'), function (el) { el.style.removeProperty('display'); });
	}
	if (wide.addEventListener) { wide.addEventListener('change', onLayoutChange); } else if (wide.addListener) { wide.addListener(onLayoutChange); }

	var timer = 0;
	function start() { setButton(); watchMenu(); evenPanels(); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', start); } else { start(); }
	window.addEventListener('load', evenPanels);
	window.addEventListener('resize', function () { clearTimeout(timer); timer = setTimeout(function () { keepMenu(); evenPanels(); }, 150); });
	setInterval(setButton, 30000);
})();
</script>
		<?php
	}
	add_action( 'wp_footer', 'tcc_main_menu_helpers', 99 );
}
