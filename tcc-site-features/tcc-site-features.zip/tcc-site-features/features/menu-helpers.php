<?php
/**
 * TCC main menu helpers.
 *
 * Five small jobs for the main menu header (the Global Header in Divi > Theme Builder). Divi cannot do
 * them by itself. The menu's words, links, pictures and looks are all in the Divi header.
 *
 * 1. The red "Watch Online" button (the layer with the CSS class tccm-watch) is hidden all
 *    week and shows on Sunday from 8:30am to 12 noon, Knoxville time. The times are on the
 *    LIVE line at the top of menu-helpers.js; the button's words and link are in the Divi
 *    layer. To see the button on any day, add ?navlive=1 to a page address.
 * 2. It makes every drop-down panel the same height as the tallest one, so the menu does
 *    not change size as you move from one menu button to the next.
 * 3. When the Search button (the magnifying glass) is clicked, it puts the typing cursor in
 *    the search box, so a visitor can type straight away.
 * 4. On a window between 981 and about 995 pixels wide that has a scroll bar, Divi's phone-menu
 *    switch hides the menu buttons although the page is still in its computer layout, which
 *    would leave no menu at all. This puts them back.
 * 5. If a window is made narrower (or a tablet is turned upright) and so changes from the
 *    computer layout to the phone layout, it closes the phone menu, which would otherwise
 *    open by itself and cover the page.
 *
 * It does nothing on a page whose header has no tccm-... layers (for example the old header).
 * To switch it off, use TCC Website > Features: Watch Online then never shows and the panels
 * keep their own heights.
 *
 * The script itself is in menu-helpers.js, beside this file; this file only prints it in the
 * page footer.
 *
 * Part of the TCC Website plugin since 0.13.2. Until 2026-11-24 this was Code Snippets
 * snippet 31, "TCC main menu helpers". The script in menu-helpers.js is that snippet's script,
 * unchanged; only its place moved (out of this file and into its own).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_main_menu_helpers' ) ) {
	function tcc_main_menu_helpers() {
		if ( is_admin() || isset( $_GET['et_fb'] ) ) {
			return;
		}
		// The script itself is in menu-helpers.js (beside this file). Only the <script> tag is written here.
		?>
<script id="tcc-main-menu-helpers" nowprocket data-nowprocket>
<?php echo tcc_site_asset( 'features/menu-helpers.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
		<?php
	}
	add_action( 'wp_footer', 'tcc_main_menu_helpers', 99 );
}
