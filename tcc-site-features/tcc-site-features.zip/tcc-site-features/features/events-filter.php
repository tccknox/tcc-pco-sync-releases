<?php
/**
 * TCC events filter bar.
 *
 * [tcc_events_filter]  prints a filter bar (category, month, search) for the Events page.
 * [tcc_event_data]     goes inside each event card; it prints a hidden tag with that
 *                      event's categories and month so the bar knows what to show.
 *
 * Filtering happens in the visitor's browser on the cards already on the page, so it is
 * instant and adds no extra page loads. Every category that has ever had an event is
 * listed, even when it has nothing upcoming. The bar highlights every filter that is in use,
 * shows "Showing 3 of 8 events" with a removable tag for each filter, and offers
 * "Clear filters".
 *
 * Needs the "Event feeds" feature to be switched on. To remove the bar, switch this
 * feature off on TCC Website > Features: the Events page simply shows all events again.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 11, "TCC events filter bar".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_event_real_id' ) ) {
	// Recurring events use a stand-in id per date; categories live on the real event.
	function tcc_event_real_id( $id ) {
		try {
			$class = '\TEC\Events\Custom_Tables\V1\Models\Occurrence';
			if ( class_exists( $class ) && method_exists( $class, 'normalize_id' ) ) {
				return (int) $class::normalize_id( (int) $id );
			}
		} catch ( \Throwable $e ) {
			return (int) $id;
		}
		return (int) $id;
	}

	function tcc_event_cat_terms( $id ) {
		$terms = get_the_terms( tcc_event_real_id( $id ), 'tribe_events_cat' );
		return is_array( $terms ) ? $terms : array();
	}
}

if ( ! function_exists( 'tcc_event_data_shortcode' ) ) {
	function tcc_event_data_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) ) {
				return '';
			}
			$slugs = array();
			foreach ( tcc_event_cat_terms( $id ) as $term ) {
				$slugs[] = $term->slug;
			}
			$month = (string) tribe_get_start_date( $id, false, 'Y-m' );
			return '<span class="tcc-event-data" style="display:none" data-cats="' . esc_attr( implode( ' ', $slugs ) ) . '" data-month="' . esc_attr( $month ) . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_data', 'tcc_event_data_shortcode' );
}

if ( ! function_exists( 'tcc_events_filter_shortcode' ) ) {
	function tcc_events_filter_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'target' => 'tcc-events' ), $atts, 'tcc_events_filter' );
		try {
			if ( ! function_exists( 'tcc_upcoming_ids_for' ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			$ids = tcc_upcoming_ids_for( '6mo', 0 );
			if ( count( $ids ) < 2 ) {
				return '';
			}
			$cats   = array();
			$counts = array();
			$months = array();
			// Every category that has ever had an event is listed, even with nothing upcoming.
			$all = get_terms(
				array(
					'taxonomy'   => 'tribe_events_cat',
					'hide_empty' => true,
				)
			);
			if ( is_array( $all ) ) {
				foreach ( $all as $term ) {
					$cats[ $term->slug ]   = wp_specialchars_decode( $term->name, ENT_QUOTES );
					$counts[ $term->slug ] = 0;
				}
			}
			foreach ( $ids as $id ) {
				foreach ( tcc_event_cat_terms( $id ) as $term ) {
					$cats[ $term->slug ]   = wp_specialchars_decode( $term->name, ENT_QUOTES );
					$counts[ $term->slug ] = isset( $counts[ $term->slug ] ) ? $counts[ $term->slug ] + 1 : 1;
				}
				$key = (string) tribe_get_start_date( $id, false, 'Y-m' );
				if ( '' !== $key ) {
					$months[ $key ] = (string) tribe_get_start_date( $id, false, 'F Y' );
				}
			}
			asort( $cats );

			$out  = '<div class="tcc-events-filter" data-target="' . esc_attr( $atts['target'] ) . '" role="search" aria-label="Filter events">';
			$out .= '<span class="tcc-ef-label">Filter events</span>';
			$out .= '<select data-f="cat" data-name="Category" aria-label="Category"><option value="">All categories</option>';
			foreach ( $cats as $slug => $name ) {
				$out .= '<option value="' . esc_attr( $slug ) . '" data-label="' . esc_attr( $name ) . '" data-count="' . (int) $counts[ $slug ] . '">' . esc_html( $name ) . '</option>';
			}
			$out .= '</select>';
			$out .= '<select data-f="month" data-name="Month" aria-label="Month"><option value="">Any month</option>';
			foreach ( $months as $key => $name ) {
				$out .= '<option value="' . esc_attr( $key ) . '">' . esc_html( $name ) . '</option>';
			}
			$out .= '</select>';
			$out .= '<input type="search" data-f="q" data-name="Search" aria-label="Search events" placeholder="Search events" />';
			$out .= '<button type="button" class="tcc-ef-clear" data-clear="all" hidden>Clear filters</button>';
			$out .= '<div class="tcc-ef-status" aria-live="polite" hidden><strong>Filter on:</strong> <span class="tcc-ef-count"></span></div>';
			$out .= '<div class="tcc-ef-none" hidden>No events match those filters. Try removing one, or clear the filters to see everything.</div>';
			$out .= '</div>';

			static $printed = false;
			if ( ! $printed ) {
				$printed = true;
				$out    .= '<style>'
					. '.tcc-events-filter{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin:0 0 6px;padding:16px 18px;background:#f4f4f4;border-radius:15px;border:2px solid #f4f4f4;transition:border-color .25s ease}'
					. '.tcc-events-filter.is-filtering{border-color:#00A4CF}'
					. '.tcc-ef-label{font:600 18px/1.2 "CMG Sans SemiBold",Helvetica,Arial,sans-serif;color:#404041;margin-right:4px}'
					. '.tcc-events-filter select,.tcc-events-filter input[type=search]{font:400 17px/1.2 "Open Sans",Helvetica,Arial,sans-serif;color:#404041;background-color:#fff;border:2px solid #d9d9da;border-radius:12px;padding:10px 14px;height:48px;box-sizing:border-box;max-width:100%;margin:0;outline:0;box-shadow:none;transition:border-color .2s ease,box-shadow .2s ease,color .2s ease}'
					. '.tcc-events-filter select{-webkit-appearance:none;appearance:none;cursor:pointer;padding-right:42px;background-image:url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 12 8%27%3E%3Cpath d=%27M1 1.5l5 5 5-5%27 fill=%27none%27 stroke=%27%23404041%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 15px center;background-size:13px auto}'
					. '.tcc-events-filter input[type=search]{flex:1 1 220px;min-width:0}'
					. '.tcc-events-filter select:hover,.tcc-events-filter input[type=search]:hover{border-color:#b5b5b6}'
					. '.tcc-events-filter select.is-active,.tcc-events-filter input[type=search].is-active{border-color:#00A4CF;color:#00637d;font-weight:600}'
					. '.tcc-events-filter select:focus,.tcc-events-filter input[type=search]:focus{border-color:#00A4CF!important;box-shadow:0 0 0 3px rgba(0,164,207,.25)!important;outline:0!important}'
					. '.tcc-events-filter button:focus-visible{outline:3px solid #00A4CF;outline-offset:2px}'
					. '.tcc-ef-clear{font:600 17px/1.2 "CMG Sans SemiBold",Helvetica,Arial,sans-serif;color:#fff;background:#404041;border:0;border-radius:12px;padding:0 18px;height:48px;cursor:pointer;transition:background-color .2s ease}'
					. '.tcc-ef-clear:hover{background:#00A4CF}'
					. '.tcc-ef-clear[hidden],.tcc-ef-none[hidden],.tcc-ef-status[hidden]{display:none}'
					. '.tcc-ef-status{flex:1 1 100%;display:flex;flex-wrap:wrap;gap:8px;align-items:center;font:400 17px/1.3 "Open Sans",Helvetica,Arial,sans-serif;color:#404041}'
					. '.tcc-ef-status strong{font-weight:700}'
					. '.tcc-ef-count{margin-right:4px}'
					. '.tcc-ef-chip{display:inline-flex;align-items:center;gap:8px;font:600 16px/1.2 "CMG Sans SemiBold",Helvetica,Arial,sans-serif;color:#fff;background:#00A4CF;border:0;border-radius:999px;padding:8px 14px;min-height:38px;cursor:pointer;transition:background-color .2s ease,opacity .18s ease,transform .18s ease}'
					. '.tcc-ef-chip:hover{background:#1962A8}'
					. '.tcc-ef-chip.is-leaving{opacity:0;transform:scale(.9)}'
					. '.tcc-ef-x{font-size:18px;line-height:1}'
					. '.tcc-ef-none{flex:1 1 100%;font:400 18px/1.4 "Open Sans",Helvetica,Arial,sans-serif;color:#404041;background:#fff;border-radius:12px;padding:16px 18px}'
					. '@keyframes tccEfIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}'
					. '.tcc-ef-status:not([hidden]),.tcc-ef-chip,.tcc-ef-clear:not([hidden]),.tcc-ef-none:not([hidden]){animation:tccEfIn .25s ease both}'
					. '.tcc-event-card.tcc-ef-anim{transition:opacity .22s ease,transform .22s ease,background-color .2s ease}'
					. '.tcc-event-card.tcc-ef-out{opacity:0;transform:scale(.97)}'
					. '@media (prefers-reduced-motion:reduce){.tcc-events-filter *,.tcc-event-card.tcc-ef-anim{animation:none!important;transition:none!important}}'
					. '@media (max-width:767px){.tcc-ef-label{flex:1 1 100%}.tcc-events-filter select,.tcc-events-filter input[type=search],.tcc-ef-clear{flex:1 1 100%;width:100%}}'
					. '</style>';
				$out    .= '<script>(function(){'
					. 'var RM=!!(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches);'
					. 'function init(bar){if(bar.__tcc){return;}var target=document.getElementById(bar.getAttribute("data-target"));if(!target){return;}bar.__tcc=1;'
					. 'var cards=[].slice.call(target.querySelectorAll(".tcc-event-card"));cards.forEach(function(c){c.classList.add("tcc-ef-anim");});'
					. 'var ctl={cat:bar.querySelector("[data-f=cat]"),month:bar.querySelector("[data-f=month]"),q:bar.querySelector("[data-f=q]")};'
					. 'var status=bar.querySelector(".tcc-ef-status"),countEl=bar.querySelector(".tcc-ef-count"),none=bar.querySelector(".tcc-ef-none"),clearBtn=bar.querySelector(".tcc-ef-clear"),chips={};'
					. 'function label(k){var el=ctl[k];if(k==="q"){return "“"+el.value.trim()+"”";}var o=el.options[el.selectedIndex];return o.getAttribute("data-label")||o.text;}'
					. 'function setCard(card,ok,instant){if(card.__ok===ok){return;}card.__ok=ok;clearTimeout(card.__t);'
					. 'if(ok){card.style.display="";if(instant||RM){card.classList.remove("tcc-ef-out");return;}card.classList.add("tcc-ef-out");void card.offsetWidth;card.classList.remove("tcc-ef-out");}'
					. 'else{card.classList.add("tcc-ef-out");if(instant||RM){card.style.display="none";return;}card.__t=setTimeout(function(){card.style.display="none";},220);}}'
					. 'function chip(k,on){var c=chips[k];if(on){var text=ctl[k].getAttribute("data-name")+": "+label(k);'
					. 'if(!c){c=document.createElement("button");c.type="button";c.className="tcc-ef-chip";c.setAttribute("data-clear",k);c.innerHTML="<span class=\"tcc-ef-chip-t\"></span><span class=\"tcc-ef-x\" aria-hidden=\"true\">×</span>";status.appendChild(c);chips[k]=c;}'
					. 'c.firstChild.textContent=text;c.setAttribute("aria-label","Remove filter: "+text);}'
					. 'else if(c){chips[k]=null;if(RM){if(c.parentNode){c.parentNode.removeChild(c);}}else{c.classList.add("is-leaving");setTimeout(function(){if(c.parentNode){c.parentNode.removeChild(c);}},180);}}}'
					. 'function apply(push,instant){var term=ctl.q.value.trim().toLowerCase(),shown=0,active=0;'
					. 'cards.forEach(function(card){var d=card.querySelector(".tcc-event-data");var cats=d?(d.getAttribute("data-cats")||"").split(" "):[];var m=d?d.getAttribute("data-month"):"";'
					. 'var ok=(!ctl.cat.value||cats.indexOf(ctl.cat.value)>-1)&&(!ctl.month.value||m===ctl.month.value)&&(!term||card.textContent.toLowerCase().indexOf(term)>-1);'
					. 'setCard(card,ok,instant);if(ok){shown++;}});'
					. '["cat","month","q"].forEach(function(k){var on=!!ctl[k].value.trim();ctl[k].classList.toggle("is-active",on);chip(k,on);if(on){active++;}});'
					. 'bar.classList.toggle("is-filtering",active>0);clearBtn.hidden=!active;status.hidden=!active;countEl.textContent="showing "+shown+" of "+cards.length+" events";'
					. 'var empty=active>0&&shown===0;if(empty){var o=ctl.cat.options[ctl.cat.selectedIndex];none.textContent=(ctl.cat.value&&o.getAttribute("data-count")==="0")?"There are no upcoming "+label("cat")+" events in the next six months. Choose another category or clear the filters.":"No events match those filters. Try removing one, or clear the filters to see everything.";}none.hidden=!empty;'
					. 'if(push&&window.history&&history.replaceState){try{var u=new URL(window.location.href);["cat","month","q"].forEach(function(k){var v=ctl[k].value.trim();if(v){u.searchParams.set("events_"+k,v);}else{u.searchParams.delete("events_"+k);}});history.replaceState(null,"",u.toString());}catch(e){}}}'
					. 'function clear(k){if(k==="all"){ctl.cat.value="";ctl.month.value="";ctl.q.value="";}else if(ctl[k]){ctl[k].value="";}apply(true,false);}'
					. 'ctl.cat.addEventListener("change",function(){apply(true,false);});ctl.month.addEventListener("change",function(){apply(true,false);});ctl.q.addEventListener("input",function(){apply(true,false);});'
					. 'bar.addEventListener("click",function(e){var b=e.target.closest?e.target.closest("[data-clear]"):null;if(b){e.preventDefault();clear(b.getAttribute("data-clear"));}});'
					. 'try{var p=new URL(window.location.href).searchParams;["cat","month","q"].forEach(function(k){var v=p.get("events_"+k);if(v){ctl[k].value=v;}});}catch(e){}'
					. 'apply(false,true);}'
					. 'function boot(){[].forEach.call(document.querySelectorAll(".tcc-events-filter"),init);}'
					. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",boot);}else{boot();}window.addEventListener("load",boot);'
					. '})();</script>';
			}
			return $out;
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_events_filter', 'tcc_events_filter_shortcode' );
}
