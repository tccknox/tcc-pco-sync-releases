<?php
/**
 * TCC events filter bar.
 *
 * [tcc_events_filter]  prints a filter bar (category, month, search) for the Events page.
 * [tcc_event_data]     goes inside each event card; it prints a hidden tag with that
 *                      event's categories and month so the bar knows what to show.
 *                      A recurring event is one card, so its tag lists every month it
 *                      happens in (of the dates the website knows about).
 *
 * Filtering happens in the visitor's browser on the cards already on the page, so it is
 * instant and adds no extra page loads. Every category that has ever had an event is
 * listed, even when it has nothing upcoming. The bar highlights every filter that is in use,
 * shows "Showing 3 of 8 events" with a removable tag for each filter, and offers
 * "Clear filters". Twelve cards show at first, with "Show 12 more" under them. The filters
 * are kept in the page address (?events_cat=...), so a filtered page can be shared.
 *
 * The look and the script are shared with the Community Groups filter bar: they are in
 * features/filter-bar.css and features/filter-bar.js (a change there changes both pages).
 * This file prints the bar's parts and, on the bar, the settings that make it the Events
 * bar (data-..., explained at the top of filter-bar.js). The bar has the classes
 * tcc-filter-bar and tcc-events-filter; its parts have tcc-fb-... and their older tcc-ef-... names.
 *
 * What the page needs: the list of cards keeps the CSS ID tcc-events, each card keeps the CSS
 * class tcc-event-card and holds [tcc_event_data]. A <span> with the class tcc-events-count
 * anywhere on the page (the "Upcoming Events" heading has one) is filled with the number of events.
 *
 * Needs the "Event feeds" feature to be switched on. To remove the bar, switch this
 * feature off on TCC Website > Features: the Events page simply shows all events again.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 11, "TCC events filter bar".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_event_real_id' ) ) {
	// Recurring events use a stand-in id per date; categories live on the real event.
	function tcc_event_real_id( $id ) {
		try {
			$class = '\TEC\Events\Custom_Tables\V1\Models\Occurrence';
			if ( class_exists( $class ) && method_exists( $class, 'normalize_id' ) ) {
				return (int) $class::normalize_id( (int) $id );
			}
		} catch ( \Throwable $e ) {
			return (int) $id;
		}
		return (int) $id;
	}

	function tcc_event_cat_terms( $id ) {
		$terms = get_the_terms( tcc_event_real_id( $id ), 'tribe_events_cat' );
		return is_array( $terms ) ? $terms : array();
	}
}

if ( ! function_exists( 'tcc_event_data_shortcode' ) ) {
	function tcc_event_data_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) ) {
				return '';
			}
			$slugs = array();
			foreach ( tcc_event_cat_terms( $id ) as $term ) {
				$slugs[] = $term->slug;
			}
			// One month for a one-off event; every known month for a recurring event (it is shown once).
			$month = function_exists( 'tcc_upcoming_months_for' )
				? implode( ' ', array_keys( tcc_upcoming_months_for( $id ) ) )
				: (string) tribe_get_start_date( $id, false, 'Y-m' );
			return '<span class="tcc-event-data" style="display:none" data-cats="' . esc_attr( implode( ' ', $slugs ) ) . '" data-month="' . esc_attr( $month ) . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_data', 'tcc_event_data_shortcode' );
}

if ( ! function_exists( 'tcc_filter_bar_assets' ) ) {
	/**
	 * The filter bar's shared look and script (features/filter-bar.css and features/filter-bar.js),
	 * printed inside the page straight after the first filter bar, once per page.
	 * The same small function is in group-filter.php, so it is there whichever feature is switched on.
	 * (Tests can set $GLOBALS['tcc_filter_bar_printed'] back to false to print it again.)
	 */
	function tcc_filter_bar_assets() {
		if ( ! empty( $GLOBALS['tcc_filter_bar_printed'] ) ) {
			return '';
		}
		$GLOBALS['tcc_filter_bar_printed'] = true;
		$file = function ( $ext ) {
			if ( function_exists( 'tcc_site_asset' ) ) {
				return tcc_site_asset( 'features/filter-bar.' . $ext ); // An administrator's saved edit, if any.
			}
			$text = is_readable( __DIR__ . '/filter-bar.' . $ext ) ? (string) file_get_contents( __DIR__ . '/filter-bar.' . $ext ) : '';
			return (string) preg_replace( '/\n\z/', '', $text );
		};
		// Empty lines are left out: WordPress's paragraph tool could otherwise break the style or script apart.
		$css = (string) preg_replace( '/\n\s*\n/', "\n", $file( 'css' ) );
		$js  = (string) preg_replace( '/\n\s*\n/', "\n", $file( 'js' ) );
		return '<style id="tcc-filter-bar-css">' . $css . '</style><script>' . $js . '</script>';
	}
}

if ( ! function_exists( 'tcc_events_filter_none_sentence' ) ) {
	/**
	 * What the Events page says when a category has nothing coming up, for example
	 * "There are no upcoming Men's events in the next six months. ..." A category whose name already
	 * ends in "Events" or "Event" (Men's Events, Women's Event) loses that word, so it is not said twice.
	 */
	function tcc_events_filter_none_sentence( $name ) {
		$base = trim( (string) preg_replace( '/\s+events?$/i', '', trim( (string) $name ) ) );
		$base = '' !== $base ? $base : trim( (string) $name );
		return 'There are no upcoming ' . $base . ' events in the next six months. Choose another category or clear the filters.';
	}
}

if ( ! function_exists( 'tcc_events_filter_bar_html' ) ) {
	/**
	 * The bar itself, from the choices the short code found:
	 * $cats   category slug => name, $counts  slug => upcoming events in it, $months  'Y-m' => 'F Y'.
	 * The settings on the bar (data-...) tell the shared script what to do; see filter-bar.js.
	 */
	function tcc_events_filter_bar_html( $cats, $counts, $months, $target ) {
		$out  = '<div class="tcc-filter-bar tcc-events-filter" data-target="' . esc_attr( $target ) . '"'
			. ' data-cards=".tcc-event-card" data-card-data=".tcc-event-data" data-count-into=".tcc-events-count"'
			. ' data-status-text="showing {shown} of {total} events"'
			. ' data-remember-in-address="events_" data-animate data-removable-tags'
			. ' role="search" aria-label="Filter events">';
		$out .= '<span class="tcc-fb-label tcc-ef-label">Filter events</span>';
		$out .= '<select data-f="cat" data-from="cats" data-name="Category" aria-label="Category"><option value="">All categories</option>';
		foreach ( $cats as $slug => $name ) {
			$count = isset( $counts[ $slug ] ) ? (int) $counts[ $slug ] : 0;
			// A category with nothing upcoming has its own "no match" sentence. A category already named
			// "... Events" or "... Event" is not followed by a second "events" ("no upcoming Men's events").
			$none  = 0 === $count ? ' data-none="' . esc_attr( tcc_events_filter_none_sentence( $name ) ) . '"' : '';
			$out  .= '<option value="' . esc_attr( $slug ) . '" data-label="' . esc_attr( $name ) . '" data-count="' . $count . '"' . $none . '>' . esc_html( $name ) . '</option>';
		}
		$out .= '</select>';
		$out .= '<select data-f="month" data-from="month" data-name="Month" aria-label="Month"><option value="">Any month</option>';
		foreach ( $months as $key => $name ) {
			$out .= '<option value="' . esc_attr( $key ) . '">' . esc_html( $name ) . '</option>';
		}
		$out .= '</select>';
		$out .= '<input type="search" data-f="q" data-name="Search" aria-label="Search events" placeholder="Search events" />';
		$out .= '<button type="button" class="tcc-fb-clear tcc-ef-clear" data-clear="all" hidden>Clear filters</button>';
		$out .= '<div class="tcc-fb-status tcc-ef-status" aria-live="polite" hidden><strong>Filter on:</strong> <span class="tcc-fb-count tcc-ef-count"></span></div>';
		$out .= '<div class="tcc-fb-none tcc-ef-none" hidden>No events match those filters. Try removing one, or clear the filters to see everything.</div>';
		$out .= '</div>';
		return $out . tcc_filter_bar_assets();
	}
}

if ( ! function_exists( 'tcc_events_filter_shortcode' ) ) {
	function tcc_events_filter_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'target' => 'tcc-events' ), $atts, 'tcc_events_filter' );
		try {
			if ( ! function_exists( 'tcc_upcoming_ids_for' ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			$ids = tcc_upcoming_ids_for( '6mo', 0 );
			if ( count( $ids ) < 2 ) {
				return '';
			}
			$cats   = array();
			$counts = array();
			$months = array();
			// Every category that has ever had an event is listed, even with nothing upcoming.
			$all = get_terms(
				array(
					'taxonomy'   => 'tribe_events_cat',
					'hide_empty' => true,
				)
			);
			if ( is_array( $all ) ) {
				foreach ( $all as $term ) {
					$cats[ $term->slug ]   = wp_specialchars_decode( $term->name, ENT_QUOTES );
					$counts[ $term->slug ] = 0;
				}
			}
			foreach ( $ids as $id ) {
				foreach ( tcc_event_cat_terms( $id ) as $term ) {
					$cats[ $term->slug ]   = wp_specialchars_decode( $term->name, ENT_QUOTES );
					$counts[ $term->slug ] = isset( $counts[ $term->slug ] ) ? $counts[ $term->slug ] + 1 : 1;
				}
				if ( function_exists( 'tcc_upcoming_months_for' ) ) {
					$months = $months + tcc_upcoming_months_for( $id );
				} else {
					$key = (string) tribe_get_start_date( $id, false, 'Y-m' );
					if ( '' !== $key ) {
						$months[ $key ] = (string) tribe_get_start_date( $id, false, 'F Y' );
					}
				}
			}
			ksort( $months );
			asort( $cats );
			return tcc_events_filter_bar_html( $cats, $counts, $months, $atts['target'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_events_filter', 'tcc_events_filter_shortcode' );
}
