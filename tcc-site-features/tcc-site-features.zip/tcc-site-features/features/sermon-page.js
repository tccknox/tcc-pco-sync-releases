/* The Video / Audio switch: pressing the word "Video" or "Audio" works the switch too. */
(function () {
	var wrap = document.querySelector('.tcc-sp-player');
	var sw = wrap && wrap.querySelector('.dipi-content-toggle__switch');
	if (!sw) { return; }
	sw.setAttribute('aria-label', 'Listen to the audio instead of watching the video');
	function choose(audio) { if (sw.checked !== audio) { sw.click(); } }
	var first = wrap.querySelector('.dipi-content-toggle__first-text');
	var second = wrap.querySelector('.dipi-content-toggle_second-text');
	if (first) { first.addEventListener('click', function () { choose(false); }); }
	if (second) { second.addEventListener('click', function () { choose(true); }); }
})();
(function () {
	var box = document.getElementById('tcc-sermon-long');
	var btn = document.querySelector('.tcc-sp-more');
	if (!box || !btn) { return; }
	box.classList.add('tcc-sp-long');
	/* Only shorten a write-up that is clearly longer than the shortened height. */
	if (box.scrollHeight < 560) { return; }
	function set(open) {
		box.classList.toggle('is-closed', !open);
		btn.setAttribute('aria-expanded', open ? 'true' : 'false');
		btn.textContent = btn.getAttribute(open ? 'data-less' : 'data-more');
	}
	btn.hidden = false;
	set(false);
	btn.addEventListener('click', function () {
		var open = btn.getAttribute('aria-expanded') !== 'true';
		set(open);
		if (!open) { try { box.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
	});
})();
