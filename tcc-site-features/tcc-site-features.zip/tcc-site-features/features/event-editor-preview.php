<?php
/**
 * Event pages in the Divi editor: real details, and clear labels.
 *
 * When someone opens an event in the Divi editor (the visual builder), two things help them:
 *
 *  1. Real details instead of "(filled in automatically)".
 *     The event page template draws the day, time, place, description, rooms and Register button with
 *     short codes ([tcc_event_facts], [tcc_pco_description] and others). On the real page those short
 *     codes know which event they are on. Inside the editor, Divi draws each short code in a separate
 *     background request (a hidden preview of the home page, /?et_pb_preview=true, sent with the open
 *     event's id as post_id), and in that request WordPress does not treat the open event as "the current
 *     post", so every short code printed its "(filled in automatically)" stand-in. This file tells those
 *     short codes which event is open, so the editor shows that event's real details.
 *     How it finds the event, in order: the post id the editor sends with the request (when that post is
 *     an event); otherwise the address of the editor page the request came from (/event/the-event-name/).
 *     It only does this for signed-in editors, only inside the editor, and only for the short codes
 *     listed in tcc_editor_preview_codes(). Visitors and the real pages are not touched.
 *
 *  2. Labels, shown only inside the editor (visitors never see them):
 *     - the event's own box under "About this event" gets a teal dashed edge and the words
 *       "This event only: add buttons, pictures or text here". Anything put in that box shows on this
 *       event and no other.
 *     - everything else on the page (the title, the banner, the Location card) is the shared event
 *       template, and Divi lets anyone change it with one click: there is no separate "edit the template"
 *       step. So whenever the settings of a layer outside the event's own box are open (including a layer
 *       that has just been added there), a dark notice just under the menu says that changes there
 *       show on every event, and the "This event only" caption turns grey.
 *     The labels look for Divi's own names: #theme-builder-area--post_content (the event's own box),
 *     #theme-builder-area--body (the shared template), and the class et-vb-module--is-edited, which Divi
 *     puts on the layer whose settings are open. They need a browser that understands :has() (current
 *     Chrome, Safari, Edge and Firefox do); an older one simply shows no notice.
 *
 * Part of the TCC Website Features plugin (added in 0.9.9). Switch it off under TCC Website > Features
 * and the editor goes back to the "(filled in automatically)" stand-ins and no labels; the website itself
 * is the same either way.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_editor_preview_codes' ) ) {
	/** The event short codes that are told which event is open while the editor draws them. */
	function tcc_editor_preview_codes() {
		return array(
			'tcc_event_facts',      // Day, time and place in the banner (Event page banner feature).
			'tcc_event_directions', // "Get directions" (Event page banner feature).
			'tcc_event_date',       // Older event layout (Event date and venue feature).
			'tcc_event_venue',      // Place and address in the Location card.
			'tcc_pco_description',  // Planning Center description (Planning Center events).
			'tcc_event_register',   // Register button (Planning Center events).
			'tcc_event_rooms',      // Room labels (Planning Center events).
		);
	}
}

if ( ! function_exists( 'tcc_editor_preview_is_event' ) ) {
	/** Is this post id an event (including one date of a repeating event)? */
	function tcc_editor_preview_is_event( $id ) {
		$id = (int) $id;
		// Only an event this person may edit: an Author previewing their own page must not be able
		// to show another event's details (a draft, a private or a password-protected one).
		return $id > 0 && 'tribe_events' === get_post_type( $id ) && current_user_can( 'edit_post', $id );
	}
}

if ( ! function_exists( 'tcc_editor_preview_find_post_id' ) ) {
	/** Looks through what the editor sent for a post id ("postId", "post_id", "et_post_id", or currentPage[id]). */
	function tcc_editor_preview_find_post_id( $data, $depth = 0 ) {
		if ( ! is_array( $data ) || $depth > 4 ) {
			return 0;
		}
		foreach ( array( 'postId', 'post_id', 'et_post_id' ) as $key ) {
			if ( isset( $data[ $key ] ) && is_scalar( $data[ $key ] ) && tcc_editor_preview_is_event( $data[ $key ] ) ) {
				return (int) $data[ $key ];
			}
		}
		if ( isset( $data['currentPage']['id'] ) && is_scalar( $data['currentPage']['id'] ) && tcc_editor_preview_is_event( $data['currentPage']['id'] ) ) {
			return (int) $data['currentPage']['id'];
		}
		foreach ( $data as $value ) {
			if ( is_string( $value ) && '' !== $value && ( '{' === $value[0] || '[' === $value[0] ) ) {
				$value = json_decode( $value, true ); // The editor sometimes sends its data as one JSON string.
			}
			$found = tcc_editor_preview_find_post_id( $value, $depth + 1 );
			if ( $found ) {
				return $found;
			}
		}
		return 0;
	}
}

if ( ! function_exists( 'tcc_editor_preview_event_from_referer' ) ) {
	/** The event whose editor page sent this request, read from its address (/event/the-event-name/...). */
	function tcc_editor_preview_event_from_referer() {
		$ref = wp_get_referer();
		if ( ! $ref || 0 !== strpos( $ref, home_url() ) ) {
			return 0;
		}
		$path = trim( (string) wp_parse_url( $ref, PHP_URL_PATH ), '/' );
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $path, $home . '/' ) ) {
			$path = substr( $path, strlen( $home ) + 1 );
		}
		$parts = explode( '/', $path );
		// The Events Calendar's address for one event is /event/name/ (a repeating event adds /date/).
		if ( count( $parts ) < 2 || 'event' !== $parts[0] || '' === $parts[1] ) {
			return 0;
		}
		$post = get_page_by_path( sanitize_title( $parts[1] ), OBJECT, 'tribe_events' );
		return $post ? (int) $post->ID : 0;
	}
}

if ( ! function_exists( 'tcc_editor_preview_in_editor' ) ) {
	/**
	 * Is this request the Divi editor drawing something, for someone who can edit?
	 *
	 * Divi 5 draws a short code in a template layer by posting it to a hidden preview of the home page:
	 * /?et_pb_preview=true&et_pb_preview_nonce=...  with  shortcode=..., post_id=<the open event>,
	 * is_fb_preview=1. Divi checks its own preview key on that request; this only reads it. The main
	 * file's tcc_site_in_divi_editor() covers the editor page itself and Divi's /wp-json/divi/ requests.
	 */
	function tcc_editor_preview_in_editor() {
		if ( function_exists( 'tcc_site_in_divi_editor' ) && tcc_site_in_divi_editor() ) {
			return true;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- Divi verifies et_pb_preview_nonce; nothing is changed here.
		return is_user_logged_in() && current_user_can( 'edit_posts' )
			&& isset( $_GET['et_pb_preview'] ) && ! empty( $_POST['is_fb_preview'] );
		// phpcs:enable WordPress.Security.NonceVerification
	}
}

if ( ! function_exists( 'tcc_editor_preview_event_id' ) ) {
	/** The event open in the Divi editor, or 0. Worked out once per request. */
	function tcc_editor_preview_event_id() {
		static $id = null;
		if ( null !== $id ) {
			return $id;
		}
		$id = 0;
		if ( ! tcc_editor_preview_in_editor() ) {
			return $id;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only reads which post is open; Divi checks its own nonce.
		$id = tcc_editor_preview_find_post_id( wp_unslash( $_REQUEST ) );
		if ( ! $id && ! empty( $GLOBALS['tcc_editor_preview_rest_params'] ) ) {
			$id = tcc_editor_preview_find_post_id( $GLOBALS['tcc_editor_preview_rest_params'] );
		}
		if ( ! $id ) {
			$id = tcc_editor_preview_event_from_referer();
		}
		return $id;
	}
}

if ( ! function_exists( 'tcc_editor_preview_keep_rest_params' ) ) {
	/** Keeps what the editor sent to one of Divi's own requests (it can come as JSON, which $_REQUEST does not hold). */
	function tcc_editor_preview_keep_rest_params( $result, $server, $request ) {
		if ( 0 === strpos( (string) $request->get_route(), '/divi/' ) ) {
			$GLOBALS['tcc_editor_preview_rest_params'] = (array) $request->get_params();
		}
		return $result;
	}
	add_filter( 'rest_pre_dispatch', 'tcc_editor_preview_keep_rest_params', 1, 3 );
}

if ( ! function_exists( 'tcc_editor_preview_set_event' ) ) {
	/**
	 * Just before one of the event short codes runs inside the editor, make the open event the current
	 * post, so the short code prints that event's details. Put back straight after (see below).
	 * Runs first (priority 1), before the Planning Center plugin's own check on the same short codes.
	 */
	function tcc_editor_preview_set_event( $out, $tag ) {
		if ( false !== $out || ! in_array( $tag, tcc_editor_preview_codes(), true ) ) {
			return $out;
		}
		$current = get_the_ID();
		if ( $current && 'tribe_events' === get_post_type( $current ) ) {
			return $out; // Already on an event (the real page): nothing to do.
		}
		$id = tcc_editor_preview_event_id();
		// However the event was found (what the editor sent, or the page address), it is only shown
		// to someone who may edit that event.
		if ( ! $id || ! tcc_editor_preview_is_event( $id ) ) {
			return $out;
		}
		$GLOBALS['tcc_editor_preview_saved'][] = array(
			'tag'  => $tag,
			'post' => isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null,
		);
		$GLOBALS['post'] = get_post( $id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- put back after the short code.
		setup_postdata( $GLOBALS['post'] );
		return $out;
	}
	add_filter( 'pre_do_shortcode_tag', 'tcc_editor_preview_set_event', 1, 2 );
}

if ( ! function_exists( 'tcc_editor_preview_put_back' ) ) {
	/** Puts back whatever was the current post before the short code ran. */
	function tcc_editor_preview_put_back( $output, $tag ) {
		$saved = isset( $GLOBALS['tcc_editor_preview_saved'] ) ? $GLOBALS['tcc_editor_preview_saved'] : array();
		$last  = $saved ? end( $saved ) : null;
		if ( $last && $last['tag'] === $tag ) { // Only undo what was done for this same short code.
			array_pop( $GLOBALS['tcc_editor_preview_saved'] );
			$GLOBALS['post'] = $last['post']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			if ( $GLOBALS['post'] instanceof WP_Post ) {
				setup_postdata( $GLOBALS['post'] );
			} else {
				wp_reset_postdata();
			}
		}
		return $output;
	}
	add_filter( 'do_shortcode_tag', 'tcc_editor_preview_put_back', 999, 2 );

	/**
	 * When another check answers for the short code without running it (the Planning Center plugin does this
	 * when a piece is switched off for an event), WordPress skips the step above, so put back here instead.
	 */
	function tcc_editor_preview_put_back_early( $out, $tag ) {
		return false === $out ? $out : tcc_editor_preview_put_back( $out, $tag );
	}
	add_filter( 'pre_do_shortcode_tag', 'tcc_editor_preview_put_back_early', PHP_INT_MAX, 2 );
}

if ( ! function_exists( 'tcc_editor_preview_labels' ) ) {
	/** The two labels, printed only on an event page that is open in the Divi editor. */
	function tcc_editor_preview_labels() {
		if ( ! is_singular( 'tribe_events' ) || ! function_exists( 'tcc_site_in_divi_editor' ) || ! tcc_site_in_divi_editor() ) {
			return;
		}
		?>
<style id="tcc-event-editor-labels">
/* TCC Website Features: event editor labels (editor only, visitors never see this). */

/* 1. The event's own box under "About this event": a teal dashed edge and a caption above it. */
.single-tribe_events #theme-builder-area--post_content {
	position: relative;
	margin-top: 36px;
	min-height: 64px;
	outline: 2px dashed #00A4CF;
	outline-offset: 6px;
	border-radius: 4px;
}
.single-tribe_events #theme-builder-area--post_content::before {
	content: "This event only: add buttons, pictures or text here";
	position: absolute;
	left: -8px;
	bottom: calc(100% + 10px);
	padding: 3px 10px;
	border-radius: 4px;
	background: #00A4CF;
	color: #fff;
	font: 600 14px/1.4 "Open Sans", Arial, sans-serif;
	white-space: nowrap;
	pointer-events: none;
	z-index: 5;
}

/* While a layer of the shared template is open, Divi marks the event's own box inactive: grey its caption. */
.single-tribe_events #theme-builder-area--post_content.theme-builder-area--inactive::before {
	background: #8a8a8b;
}

/* 2. A layer of the shared template has its settings open: a dark notice just under the menu.
      The editor's own styles give this area's ::before a height, so every size is set here.
      It sits 110px down because the site's floating menu is drawn above everything in this area. */
.single-tribe_events #theme-builder-area--body:has(.et-vb-module--is-edited:not(#theme-builder-area--post_content *))::before {
	content: "You are changing the shared event template. This change will show on every event. To change only this event, close this and use the teal box under \"About this event\".";
	position: fixed;
	top: 110px;
	bottom: auto;
	left: 50%;
	right: auto;
	width: min(92%, 820px);
	height: auto;
	min-height: 0;
	transform: translateX(-50%);
	z-index: 100000;
	padding: 12px 20px;
	border-radius: 10px;
	box-shadow: 0 6px 24px rgba(0, 0, 0, .25);
	background: #404041;
	color: #fff;
	font: 600 16px/1.45 "Open Sans", Arial, sans-serif;
	text-align: center;
	pointer-events: none;
}
</style>
		<?php
	}
	add_action( 'wp_head', 'tcc_editor_preview_labels', 99 );
}
