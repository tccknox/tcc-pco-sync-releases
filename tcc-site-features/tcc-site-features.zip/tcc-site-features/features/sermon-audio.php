<?php
/**
 * TCC sermon audio player.
 *
 * [tcc_sermon_audio] prints the Buzzsprout audio player for the current sermon,
 * using the embed code saved in the sermon's "sermon_podcast" field.
 *
 * Why this exists: Divi 5 removes <script> tags from custom fields shown through
 * Dynamic Content, which left the Audio side of the sermon player empty.
 * This shortcode reads the same field and prints only a genuine Buzzsprout player.
 * It prints nothing if the field is empty or is not a Buzzsprout embed.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 12, "TCC sermon audio player".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermon_audio_shortcode' ) ) {
	function tcc_sermon_audio_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id && is_singular() ) {
				$id = get_queried_object_id();
			}
			if ( ! $id ) {
				return '';
			}
			$raw = (string) get_post_meta( $id, 'sermon_podcast', true );
			if ( '' === $raw && is_singular() ) {
				$raw = (string) get_post_meta( get_queried_object_id(), 'sermon_podcast', true );
			}
			if ( '' === $raw ) {
				return '';
			}
			// Only accept a real Buzzsprout episode script. Buzzsprout has given out two forms of the
			// address, and both still work:
			//   since late 2024:  buzzsprout.com/1987066/episodes/20089961-title.js?...
			//   before that:      buzzsprout.com/1987066/15791851-title.js?...   (no "episodes/")
			// Until 0.5.3 only the first form was accepted, so sermons from June 2023 to
			// September 2024 showed no audio player.
			// Only the church's own show (Buzzsprout show 1987066, used by every sermon), so an
			// account that can edit a sermon cannot put another podcast's player on the website.
			// If the church ever moves to a new Buzzsprout show, change the number here.
			$show = '1987066';
			if ( ! preg_match( '#https://www\.buzzsprout\.com/' . $show . '/(?:episodes/)?[A-Za-z0-9._-]+\.js\?[^"\'\s<>]+#', $raw, $m ) ) {
				return '';
			}
			$src = html_entity_decode( $m[0], ENT_QUOTES );
			if ( ! preg_match( '#container_id=(buzzsprout-player-[0-9]+)#', $src, $c ) ) {
				return '';
			}
			return '<div id="' . esc_attr( $c[1] ) . '"></div><script src="' . esc_url( $src ) . '" type="text/javascript" charset="utf-8"></script>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_audio', 'tcc_sermon_audio_shortcode' );
}
