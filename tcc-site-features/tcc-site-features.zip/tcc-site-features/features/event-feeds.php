<?php
/**
 * TCC "Upcoming Events (automatic)" sources for Divi loops.
 *
 * Lets a normal Divi loop show upcoming events from The Events Calendar.
 * In the loop settings choose one of these as the post type:
 *
 *   Upcoming Events (automatic)               next events, one card per recurring event
 *   Upcoming Events - every date (automatic)  upcoming dates (up to 3 per recurring event), for the Events page
 *   Upcoming Events - next 6 months (automatic) events starting in the next six months (next two dates of a recurring event)
 *   Upcoming Events: <Category> (automatic)   one per event category, e.g. Men's Events
 *
 * Events come soonest first. The loop's "posts per page" sets how many.
 * The lists are remembered for 10 minutes and refresh whenever an event is saved.
 *
 * Shortcodes for use inside a loop card:
 *   [tcc_event_day format="F d, Y"]   start date, e.g. "November 22, 2026"
 *   [tcc_event_time]                  "4:30 PM - 6:00 PM" or "All Day"
 *
 * Shortcode for use under a loop:
 *   [tcc_no_upcoming category="mens-events" message="There are no upcoming men's events."]
 *   prints the message only when that list is empty (leave category out for all events).
 *
 * If The Events Calendar is switched off the loops are simply empty.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 9, "TCC upcoming events source for Divi loops".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_upcoming_sources' ) ) {
	/**
	 * slug => array( label, mode, term_id ).
	 */
	function tcc_upcoming_sources() {
		static $sources = null;
		if ( null !== $sources ) {
			return $sources;
		}
		$sources = array(
			'tcc_upcoming_event' => array( 'Upcoming Events (automatic)', 'series', 0 ),
			'tcc_upcoming_all'   => array( 'Upcoming Events - every date (automatic)', 'all', 0 ),
			'tcc_upcoming_6mo'   => array( 'Upcoming Events - next 6 months (automatic)', '6mo', 0 ),
		);
		if ( taxonomy_exists( 'tribe_events_cat' ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'tribe_events_cat',
					'hide_empty' => false,
				)
			);
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$sources[ 'tcc_upcat_' . (int) $term->term_id ] = array(
						'Upcoming Events: ' . wp_specialchars_decode( $term->name, ENT_QUOTES ) . ' (automatic)',
						'series',
						(int) $term->term_id,
					);
				}
			}
		}
		return $sources;
	}

	function tcc_upcoming_register_sources() {
		foreach ( tcc_upcoming_sources() as $slug => $source ) {
			register_post_type(
				$slug,
				array(
					'labels'              => array(
						'name'          => $source[0],
						'singular_name' => $source[0],
					),
					'public'              => true,
					// Must be true or the Divi editor's loop preview ignores the source and shows unrelated content.
					'publicly_queryable'  => true,
					'exclude_from_search' => true,
					'show_ui'             => false,
					'show_in_menu'        => false,
					'show_in_nav_menus'   => false,
					'show_in_admin_bar'   => false,
					'show_in_rest'        => false,
					'has_archive'         => false,
					'rewrite'             => false,
					'query_var'           => false,
					'supports'            => array( 'title', 'thumbnail' ),
				)
			);
		}
	}
	add_action( 'init', 'tcc_upcoming_register_sources', 30 );

	// Keep the placeholder types out of Yoast's sitemap.
	add_filter(
		'wpseo_sitemap_exclude_post_type',
		function ( $excluded, $post_type ) {
			return ( 0 === strpos( (string) $post_type, 'tcc_upcoming_' ) || 0 === strpos( (string) $post_type, 'tcc_upcat_' ) ) ? true : $excluded;
		},
		10,
		2
	);
}

if ( ! function_exists( 'tcc_upcoming_ids_for' ) ) {
	/**
	 * Upcoming event ids, soonest first.
	 *
	 * @param string $mode    'series' = one per recurring event, 'all' = every date.
	 * @param int    $term_id Event category id, or 0 for all.
	 */
	function tcc_upcoming_ids_for( $mode = 'series', $term_id = 0 ) {
		$mode    = in_array( $mode, array( 'all', '6mo' ), true ) ? $mode : 'series';
		$term_id = (int) $term_id;
		$key     = 'tcc_up3_' . (int) get_option( 'tcc_upcoming_gen', 1 ) . '_' . $mode . '_' . $term_id;
		$cached  = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$ids = array();
		if ( function_exists( 'tribe_get_events' ) ) {
			$args = array(
				'posts_per_page' => 150,
				'ends_after'     => 'now',
				'post_status'    => 'publish',
			);
			if ( '6mo' === $mode ) {
				// Only events that start within the next six months.
				$args['starts_before'] = '+6 months';
			}
			if ( $term_id > 0 ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'tribe_events_cat',
						'field'    => 'term_id',
						'terms'    => array( $term_id ),
					),
				);
			}
			$events = tribe_get_events( $args );
			$seen   = array();
			$limit  = ( 'series' === $mode ) ? 24 : 120;
			foreach ( (array) $events as $event ) {
				if ( ! ( $event instanceof WP_Post ) ) {
					continue;
				}
				if ( 'yes' === get_post_meta( $event->ID, '_EventHideFromUpcoming', true ) ) {
					continue;
				}
				// Dates of one recurring event share an address apart from the date on the end.
				// 'series' lists show one date per recurring event, the 6-month list the next two, the every-date list up to three.
				$series = preg_replace( '#/\d{4}-\d{2}-\d{2}/?$#', '/', (string) get_permalink( $event->ID ) );
				// Lets other code (the Planning Center sync) say which dates belong to the same repeating event.
				$series = (string) apply_filters( 'tcc_upcoming_series_key', $series, $event->ID );
				$shown  = isset( $seen[ $series ] ) ? (int) $seen[ $series ] : 0;
				if ( $shown >= ( ( 'series' === $mode ) ? 1 : ( ( '6mo' === $mode ) ? 2 : 3 ) ) ) {
					continue;
				}
				$seen[ $series ] = $shown + 1;
				$ids[] = (int) $event->ID;
				if ( count( $ids ) >= $limit ) {
					break;
				}
			}
		}

		set_transient( $key, $ids, 10 * MINUTE_IN_SECONDS );
		return $ids;
	}

	function tcc_upcoming_flush_all() {
		update_option( 'tcc_upcoming_gen', (int) get_option( 'tcc_upcoming_gen', 1 ) + 1, false );
		delete_transient( 'tcc_upcoming_event_ids_v1' );
	}
	add_action( 'save_post_tribe_events', 'tcc_upcoming_flush_all' );
	add_action( 'trashed_post', 'tcc_upcoming_flush_all' );
	add_action( 'edited_tribe_events_cat', 'tcc_upcoming_flush_all' );
}

if ( ! function_exists( 'tcc_upcoming_sources_pre_query' ) ) {
	function tcc_upcoming_sources_pre_query( $posts, $query ) {
		try {
			if ( ! ( $query instanceof WP_Query ) ) {
				return $posts;
			}
			$type  = $query->get( 'post_type' );
			$types = is_array( $type ) ? array_values( $type ) : array( $type );
			if ( 1 !== count( $types ) || ! is_string( $types[0] ) ) {
				return $posts;
			}
			if ( 0 !== strpos( $types[0], 'tcc_upcoming_' ) && 0 !== strpos( $types[0], 'tcc_upcat_' ) ) {
				return $posts;
			}
			$sources = tcc_upcoming_sources();
			if ( ! isset( $sources[ $types[0] ] ) ) {
				return array();
			}
			$source = $sources[ $types[0] ];

			$count = (int) $query->get( 'posts_per_page' );
			if ( $count < 1 || $count > 48 ) {
				$count = 4;
			}
			$offset = (int) $query->get( 'offset' );
			if ( $offset < 1 ) {
				$page = max( 1, (int) $query->get( 'paged' ) );
				// The Events page list is paged with ?tcc_page=2 (see [tcc_events_paging]).
				if ( 'all' === $source[1] && isset( $_GET['tcc_page'] ) ) {
					$page = max( 1, (int) $_GET['tcc_page'] );
				}
				$offset = ( $page - 1 ) * $count;
			}
			$all = tcc_upcoming_ids_for( $source[1], $source[2] );
			$ids = array_slice( $all, $offset, $count );

			$query->found_posts   = count( $all );
			$query->max_num_pages = (int) ceil( count( $all ) / $count );

			if ( 'ids' === $query->get( 'fields' ) ) {
				return $ids;
			}

			$out = array();
			foreach ( $ids as $id ) {
				$post = get_post( $id );
				if ( $post instanceof WP_Post ) {
					$out[] = $post;
				}
			}
			return $out;
		} catch ( \Throwable $e ) {
			return array();
		}
	}
	add_filter( 'posts_pre_query', 'tcc_upcoming_sources_pre_query', 10, 2 );
}

if ( ! function_exists( 'tcc_event_day_shortcode' ) ) {
	function tcc_event_day_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'format' => 'F j' ), $atts, 'tcc_event_day' );
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			$format = preg_replace( '/[^A-Za-z ,.\-\/]/', '', (string) $atts['format'] );
			if ( '' === $format ) {
				$format = 'F j';
			}
			return esc_html( (string) tribe_get_start_date( $id, false, $format ) );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_day', 'tcc_event_day_shortcode' );
}

if ( ! function_exists( 'tcc_event_time_shortcode' ) ) {
	function tcc_event_time_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			if ( function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $id ) ) {
				return 'All Day';
			}
			$start = (string) tribe_get_start_date( $id, false, 'g:i A' );
			$end   = (string) tribe_get_end_date( $id, false, 'g:i A' );
			return esc_html( ( '' !== $end && $end !== $start ) ? $start . ' - ' . $end : $start );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_time', 'tcc_event_time_shortcode' );
}

if ( ! function_exists( 'tcc_no_upcoming_shortcode' ) ) {
	function tcc_no_upcoming_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'message'  => 'There are no upcoming events scheduled.',
			),
			$atts,
			'tcc_no_upcoming'
		);
		try {
			$term_id = 0;
			if ( '' !== $atts['category'] ) {
				$term = is_numeric( $atts['category'] )
					? get_term( (int) $atts['category'], 'tribe_events_cat' )
					: get_term_by( 'slug', sanitize_title( $atts['category'] ), 'tribe_events_cat' );
				if ( ! ( $term instanceof WP_Term ) ) {
					return '';
				}
				$term_id = (int) $term->term_id;
			}
			if ( count( tcc_upcoming_ids_for( 'series', $term_id ) ) > 0 ) {
				return '';
			}
			return '<span class="tcc-no-upcoming">' . esc_html( $atts['message'] ) . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_no_upcoming', 'tcc_no_upcoming_shortcode' );
}

if ( ! function_exists( 'tcc_upcoming_empty_css' ) ) {
	/**
	 * When one of these loops has no events, Divi prints its stock "No Results Found" text.
	 * Hide that (and the empty card area) so only our own message shows.
	 */
	function tcc_upcoming_empty_css() {
		echo '<style id="tcc-upcoming-empty">'
			. '.et_pb_group[data-loop-source^="loop-tcc"]>.entry{display:none!important}'
			. '.et_pb_group[data-loop-source^="loop-tcc"]:has(>.entry>.not-found-title){display:none!important}'
			. '.et_pb_group:has(>.et_pb_group[data-loop-source^="loop-tcc"]>.entry>.not-found-title){display:none!important}'
			// Event cards (class "tcc-event-card" on the card, "tcc-event-title" on its title):
			// a blue circle-chevron (same family as the site's blue plus-circle icons) fades and slides in beside the title on hover.
			. '.tcc-event-card{position:relative}'
			. '.tcc-event-card .tcc-event-title{position:relative}'
			. '.tcc-event-card .tcc-event-title:after{content:"\f138";font-family:FontAwesome;font-weight:900;position:absolute;right:20px;top:21px;font-size:25px;line-height:1;color:#00A4CF;opacity:0;transform:translateX(16px);transition:opacity .25s ease,transform .25s ease;pointer-events:none}'
			. '.tcc-event-card:hover .tcc-event-title:after,.tcc-event-card:focus-within .tcc-event-title:after{opacity:1;transform:none}'
			. '.tcc-event-card.tcc-event-card-small .tcc-event-title:after{font-size:19px;right:12px;top:13px}'
			// Phone list in the Events menu: let the text fill the row so the arrows line up on the right.
			. '.tcc-event-card.tcc-event-card-small>.et_pb_group:last-child{flex:1 1 auto;min-width:0}'
			. '.tcc-event-card.tcc-event-card-small>.et_pb_group:last-child .tcc-event-title:after{right:2px;top:2px}'
			. '@media (hover:none){.tcc-event-card .tcc-event-title:after{opacity:1;transform:none}}'
			. '@media (prefers-reduced-motion:reduce){.tcc-event-card .tcc-event-title:after{transition:none}}'
			. '</style>';
	}
	add_action( 'wp_head', 'tcc_upcoming_empty_css', 99 );
}

if ( ! function_exists( 'tcc_events_paging_shortcode' ) ) {
	/**
	 * [tcc_events_paging per_page="8"] prints "Previous Events" / "Next Events" links
	 * for a loop that uses "Upcoming Events - every date (automatic)".
	 * per_page must match the loop's "posts per page".
	 */
	function tcc_events_paging_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'per_page' => 8 ), $atts, 'tcc_events_paging' );
		try {
			$per   = max( 1, min( 48, (int) $atts['per_page'] ) );
			$total = count( tcc_upcoming_ids_for( 'all', 0 ) );
			$pages = (int) ceil( $total / $per );
			if ( $pages < 2 ) {
				return '';
			}
			$page = isset( $_GET['tcc_page'] ) ? max( 1, min( $pages, (int) $_GET['tcc_page'] ) ) : 1;
			$prev = '';
			$next = '';
			if ( $page > 1 ) {
				$url  = ( 2 === $page ) ? remove_query_arg( 'tcc_page' ) : add_query_arg( 'tcc_page', $page - 1 );
				$prev = '<a class="tcc-events-prev" style="color:inherit" href="' . esc_url( $url ) . '#tcc-events">&laquo; Previous Events</a>';
			}
			if ( $page < $pages ) {
				$next = '<a class="tcc-events-next" style="color:inherit;margin-left:auto" href="' . esc_url( add_query_arg( 'tcc_page', $page + 1 ) ) . '#tcc-events">Next Events &raquo;</a>';
			}
			return '<span class="tcc-events-paging" style="display:flex;justify-content:space-between;gap:20px">' . $prev . $next . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_events_paging', 'tcc_events_paging_shortcode' );
}

/**
 * Keep the automatic event sources out of the Theme Builder's "Template Settings" list.
 * They exist only so Divi loops can pick them; nobody assigns a template to them.
 */
if ( ! function_exists( 'tcc_upcoming_hide_from_theme_builder' ) ) {
	function tcc_upcoming_hide_from_theme_builder( $options ) {
		if ( ! is_array( $options ) ) {
			return $options;
		}
		foreach ( array_keys( $options ) as $key ) {
			if ( is_string( $key ) && 0 === strpos( $key, 'tcc_up' ) ) {
				unset( $options[ $key ] );
			}
		}
		return $options;
	}
	add_filter( 'et_theme_builder_template_settings_options', 'tcc_upcoming_hide_from_theme_builder', 99 );
}
