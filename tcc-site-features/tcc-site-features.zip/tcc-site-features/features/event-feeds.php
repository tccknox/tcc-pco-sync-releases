<?php
/**
 * TCC "Upcoming Events (automatic)" sources for Divi loops.
 *
 * Lets a normal Divi loop show upcoming events from The Events Calendar.
 * In the loop settings choose one of these as the post type:
 *
 *   Upcoming Events (automatic)               next events, one card per recurring event
 *   Upcoming Events - every date (automatic)  upcoming dates (up to 3 per recurring event), for the Events page
 *   Upcoming Events - next 6 months (automatic) events starting in the next six months, one card per recurring event (the Events page)
 *   Upcoming Events: <Category> (automatic)   one per event category, e.g. Men's Events
 *
 * Events come soonest first. The loop's "posts per page" sets how many.
 * The lists are remembered until the first of their events is over (at most 6 hours; an empty list
 * 10 minutes), and refresh straight away whenever an event is saved, trashed or given other
 * categories. (Until 0.14.1 they were remembered for only 10 minutes, so the Events menu on every
 * page rebuilt them six times an hour.)
 *
 * Shortcodes for use inside a loop card:
 *   [tcc_event_day format="F d, Y"]   start date, e.g. "November 22, 2026"
 *   [tcc_event_time]                  "4:30 PM - 6:00 PM" or "All Day"
 *   [tcc_event_repeats]               for an event that repeats: a teal line such as "Every Wednesday", then the
 *                                     word "Next:". Put it straight in front of [tcc_event_day]. Prints nothing for
 *                                     a one-off event. next="" leaves the word out; next="Next date:" changes it.
 *
 * Where "Every Wednesday" comes from: Planning Center's own wording for a synced event, or the
 * "Repeats" box on the event's edit screen (which wins when both are filled in).
 *
 * Shortcode for use under a loop:
 *   [tcc_no_upcoming category="mens-events" message="There are no upcoming men's events."]
 *   prints the message only when that list is empty (leave category out for all events).
 *
 * If The Events Calendar is switched off the loops are simply empty.
 *
 * The styles (hiding Divi's "No Results Found" text, and the event cards' look) are in a file of
 * their own beside this one: features/event-feeds.css. tcc_upcoming_empty_css() below prints it.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 9, "TCC upcoming events source for Divi loops".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_upcoming_sources' ) ) {
	/**
	 * slug => array( label, mode, term_id ).
	 */
	function tcc_upcoming_sources() {
		static $sources = null;
		if ( null !== $sources ) {
			return $sources;
		}
		$sources = array(
			'tcc_upcoming_event' => array( 'Upcoming Events (automatic)', 'series', 0 ),
			'tcc_upcoming_all'   => array( 'Upcoming Events - every date (automatic)', 'all', 0 ),
			'tcc_upcoming_6mo'   => array( 'Upcoming Events - next 6 months (automatic)', '6mo', 0 ),
		);
		if ( taxonomy_exists( 'tribe_events_cat' ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'tribe_events_cat',
					'hide_empty' => false,
				)
			);
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$sources[ 'tcc_upcat_' . (int) $term->term_id ] = array(
						'Upcoming Events: ' . wp_specialchars_decode( $term->name, ENT_QUOTES ) . ' (automatic)',
						'series',
						(int) $term->term_id,
					);
				}
			}
		}
		return $sources;
	}

	/**
	 * Sets up every list as an automatic list for Divi loops (tcc_site_loop_source() in the plugin's
	 * main file does the setting up, and keeps the lists out of the sitemap and the Theme Builder).
	 */
	function tcc_upcoming_register_sources() {
		foreach ( tcc_upcoming_sources() as $slug => $source ) {
			tcc_site_loop_source( $slug, $source[0], 'tcc_upcoming_answer' );
		}
	}
	add_action( 'init', 'tcc_upcoming_register_sources', 30 );

	/**
	 * The events a Divi loop gets for one of the lists, one page of them. The loop's "posts per page"
	 * sets how many (4 if it gives none, 48 at most). The Events page list is paged with ?tcc_page=2
	 * (see [tcc_events_paging]).
	 */
	function tcc_upcoming_answer( $slug, $query ) {
		$sources = tcc_upcoming_sources();
		if ( ! isset( $sources[ $slug ] ) ) {
			return array();
		}
		$source = $sources[ $slug ];
		$count  = (int) $query->get( 'posts_per_page' );
		if ( $count < 1 || $count > 48 ) {
			$count = 4;
		}
		$offset = (int) $query->get( 'offset' );
		if ( $offset < 1 ) {
			$page = max( 1, (int) $query->get( 'paged' ) );
			if ( 'all' === $source[1] && isset( $_GET['tcc_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only chooses a page of the list.
				$page = max( 1, (int) $_GET['tcc_page'] );
			}
			$offset = ( $page - 1 ) * $count;
		}
		$all = tcc_upcoming_ids_for( $source[1], $source[2] );
		return array(
			'ids'   => array_slice( $all, $offset, $count ),
			'found' => count( $all ),
			'pages' => (int) ceil( count( $all ) / $count ),
		);
	}
}

if ( ! function_exists( 'tcc_upcoming_ids_for' ) ) {
	/**
	 * Upcoming event ids, soonest first.
	 *
	 * @param string $mode    'series' = one per recurring event, 'all' = every date.
	 * @param int    $term_id Event category id, or 0 for all.
	 */
	function tcc_upcoming_ids_for( $mode = 'series', $term_id = 0 ) {
		$mode    = in_array( $mode, array( 'all', '6mo' ), true ) ? $mode : 'series';
		$term_id = (int) $term_id;
		$key     = 'tcc_up4_' . tcc_site_gen( 'upcoming' ) . '_' . $mode . '_' . $term_id;
		$cached  = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$ids = array();
		if ( function_exists( 'tribe_get_events' ) ) {
			$args = array(
				'posts_per_page' => 150,
				'ends_after'     => 'now',
				'post_status'    => 'publish',
			);
			if ( '6mo' === $mode ) {
				// Only events that start within the next six months.
				$args['starts_before'] = '+6 months';
			}
			if ( $term_id > 0 ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'tribe_events_cat',
						'field'    => 'term_id',
						'terms'    => array( $term_id ),
					),
				);
			}
			$events = tribe_get_events( $args );
			$seen   = array();
			$first  = array(); // series => id of the card that stands for it
			$months = array(); // that id => array( '2026-12' => 'December 2026', ... )
			$limit  = ( 'series' === $mode ) ? 24 : 120;
			foreach ( (array) $events as $event ) {
				if ( ! ( $event instanceof WP_Post ) ) {
					continue;
				}
				if ( 'yes' === get_post_meta( $event->ID, '_EventHideFromUpcoming', true ) ) {
					continue;
				}
				// Dates of one recurring event share an address apart from the date on the end.
				// A recurring event gets one card (its next date); only the every-date list shows up to three.
				// The card says that it repeats: see [tcc_event_repeats] below.
				$series = preg_replace( '#/\d{4}-\d{2}-\d{2}/?$#', '/', (string) get_permalink( $event->ID ) );
				// Lets other code (Planning Center events) say which dates belong to the same repeating event.
				$series = (string) apply_filters( 'tcc_upcoming_series_key', $series, $event->ID );
				$shown  = isset( $seen[ $series ] ) ? (int) $seen[ $series ] : 0;
				if ( '6mo' === $mode && 0 === $term_id && function_exists( 'tribe_get_start_date' ) ) {
					// Remember every month this event happens in, so the Events page's Month filter
					// still finds a recurring event that is shown once (see tcc_upcoming_months_for).
					if ( ! isset( $first[ $series ] ) ) {
						$first[ $series ] = (int) $event->ID;
					}
					$month_key = (string) tribe_get_start_date( $event->ID, false, 'Y-m' );
					if ( '' !== $month_key ) {
						$months[ $first[ $series ] ][ $month_key ] = (string) tribe_get_start_date( $event->ID, false, 'F Y' );
					}
				}
				if ( $shown >= ( ( 'all' === $mode ) ? 3 : 1 ) ) {
					continue;
				}
				$seen[ $series ] = $shown + 1;
				$ids[] = (int) $event->ID;
				if ( count( $ids ) >= $limit ) {
					break;
				}
			}
		}

		$keep = tcc_upcoming_keep_for( isset( $events ) ? $events : array() );
		set_transient( $key, $ids, $keep );
		if ( '6mo' === $mode && 0 === $term_id ) {
			set_transient( $key . '_m', isset( $months ) ? $months : array(), $keep );
		}
		return $ids;
	}

	/**
	 * The months (within the next six) in which an event on the Events page happens:
	 * array( '2026-12' => 'December 2026', ... ). A one-off event has one month; a recurring
	 * event has the month of every date the website knows about.
	 */
	function tcc_upcoming_months_for( $event_id ) {
		$event_id = (int) $event_id;
		tcc_upcoming_ids_for( '6mo', 0 ); // Makes sure the list (and the months with it) has been worked out.
		$all = get_transient( 'tcc_up4_' . tcc_site_gen( 'upcoming' ) . '_6mo_0_m' );
		if ( is_array( $all ) && isset( $all[ $event_id ] ) && is_array( $all[ $event_id ] ) && $all[ $event_id ] ) {
			return $all[ $event_id ];
		}
		$out = array();
		if ( function_exists( 'tribe_get_start_date' ) ) {
			$month_key = (string) tribe_get_start_date( $event_id, false, 'Y-m' );
			if ( '' !== $month_key ) {
				$out[ $month_key ] = (string) tribe_get_start_date( $event_id, false, 'F Y' );
			}
		}
		return $out;
	}

	function tcc_upcoming_flush_all() {
		tcc_site_new_gen( 'upcoming' );
	}
	add_action( 'save_post_tribe_events', 'tcc_upcoming_flush_all' );
	add_action( 'trashed_post', 'tcc_upcoming_flush_all' );
	add_action( 'edited_tribe_events_cat', 'tcc_upcoming_flush_all' );
}

/*
 * How long the lists are remembered (since 0.14.1). A block of its own, so it is there even when
 * another copy of the lists above is running (an old snippet, or the tests' stand-in).
 */
if ( ! function_exists( 'tcc_upcoming_keep_for' ) ) {
	/**
	 * How long a list can be remembered, in seconds: until the first of its events is over, because
	 * that is when the list changes by itself (an event that is over drops off and the next one moves
	 * up). Everything else that changes a list (an event saved, trashed or given other categories)
	 * starts afresh at once.
	 *
	 * Never less than a minute, and never more than 6 hours, so an event that comes into the "next
	 * 6 months" window, or a change made in a way that does not tell WordPress, shows the same day.
	 * An empty list is kept for 10 minutes only.
	 */
	function tcc_upcoming_keep_for( $events ) {
		if ( ! $events ) {
			// No events at all: perhaps there are none, perhaps The Events Calendar was switched off for a
			// moment (during an update). Ask again in 10 minutes, as before 0.14.1.
			return 10 * MINUTE_IN_SECONDS;
		}
		$now  = time();
		$soon = $now + 6 * HOUR_IN_SECONDS;
		foreach ( (array) $events as $event ) {
			$id  = $event instanceof WP_Post ? (int) $event->ID : (int) $event;
			$utc = (string) get_post_meta( $id, '_EventEndDateUTC', true );
			$end = '' !== $utc ? strtotime( $utc . ' UTC' ) : false;
			if ( false === $end ) {
				// Older events without the UTC copy: the local end time, in the website's time zone.
				$local = date_create( (string) get_post_meta( $id, '_EventEndDate', true ), wp_timezone() );
				$end   = $local ? $local->getTimestamp() : false;
			}
			if ( false !== $end && $end > $now && $end < $soon ) {
				$soon = $end;
			}
		}
		return max( MINUTE_IN_SECONDS, $soon - $now + 5 ); // A few seconds over, so the event really is over.
	}

	/**
	 * An event given other categories without being saved (Planning Center events does this when a tag
	 * changes in Planning Center) changes the category lists, so start afresh then too.
	 */
	function tcc_upcoming_flush_on_categories( $object_id, $terms, $tt_ids, $taxonomy, $append = false, $old_tt_ids = array() ) {
		if ( 'tribe_events_cat' !== $taxonomy ) {
			return;
		}
		$new = array_map( 'intval', (array) $tt_ids );
		$old = array_map( 'intval', (array) $old_tt_ids );
		sort( $new );
		sort( $old );
		if ( $new !== $old ) {
			tcc_site_new_gen( 'upcoming' ); // The same as tcc_upcoming_flush_all().
		}
	}
	add_action( 'set_object_terms', 'tcc_upcoming_flush_on_categories', 10, 6 );
}

if ( ! function_exists( 'tcc_event_day_shortcode' ) ) {
	function tcc_event_day_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'format' => 'F j' ), $atts, 'tcc_event_day' );
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			$format = preg_replace( '/[^A-Za-z ,.\-\/]/', '', (string) $atts['format'] );
			if ( '' === $format ) {
				$format = 'F j';
			}
			return esc_html( (string) tribe_get_start_date( $id, false, $format ) );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_day', 'tcc_event_day_shortcode' );
}

if ( ! function_exists( 'tcc_event_time_shortcode' ) ) {
	function tcc_event_time_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) || ! function_exists( 'tribe_get_start_date' ) ) {
				return '';
			}
			if ( function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $id ) ) {
				return 'All Day';
			}
			$start = (string) tribe_get_start_date( $id, false, 'g:i A' );
			$end   = (string) tribe_get_end_date( $id, false, 'g:i A' );
			return esc_html( ( '' !== $end && $end !== $start ) ? $start . ' - ' . $end : $start );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_time', 'tcc_event_time_shortcode' );
}

if ( ! function_exists( 'tcc_event_repeats_text' ) ) {
	/**
	 * The words that say how often an event repeats, e.g. "Every Wednesday". Empty for a one-off event.
	 * 1. The "Repeats" box on the event's edit screen, if someone typed in it ("none" there hides the line).
	 * 2. Otherwise whatever another plugin supplies through the filter "tcc_event_repeats_text"
	 *    (Planning Center events passes on Planning Center's own wording).
	 */
	function tcc_event_repeats_text( $id ) {
		$id = (int) $id;
		// A recurring event made on the website has a stand-in id per date; the box is saved on the real event.
		$real  = $id;
		$class = '\TEC\Events\Custom_Tables\V1\Models\Occurrence';
		if ( class_exists( $class ) && method_exists( $class, 'normalize_id' ) ) {
			try {
				$real = (int) $class::normalize_id( $id );
			} catch ( \Throwable $e ) {
				$real = $id;
			}
		}
		$own = trim( (string) get_post_meta( $real ? $real : $id, '_tcc_repeats', true ) );
		if ( '' !== $own ) {
			return 'none' === strtolower( $own ) ? '' : $own;
		}
		return trim( (string) apply_filters( 'tcc_event_repeats_text', '', $real ? $real : $id ) );
	}

	/**
	 * [tcc_event_repeats] goes straight in front of [tcc_event_day] on an event card.
	 * For an event that repeats it prints a teal line ("Every Wednesday") and then "Next:",
	 * so the card reads "Every Wednesday / Next: Wednesday, December 2". Nothing for a one-off event.
	 */
	function tcc_event_repeats_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'next' => 'Next:' ), $atts, 'tcc_event_repeats' );
		try {
			$id = get_the_ID();
			if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) ) {
				return '';
			}
			$text = tcc_event_repeats_text( $id );
			if ( '' === $text ) {
				return '';
			}
			// The "repeat" arrows are from Font Awesome Free (the icon set the site already uses), CC BY 4.0.
			$icon = '<svg viewBox="0 0 512 512" aria-hidden="true" focusable="false"><path d="M0 224c0 17.7 14.3 32 32 32s32-14.3 32-32c0-53 43-96 96-96H320v32c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l64-64c12.5-12.5 12.5-32.8 0-45.3l-64-64c-9.2-9.2-22.9-11.9-34.9-6.9S320 19.1 320 32V64H160C71.6 64 0 135.6 0 224zm512 64c0-17.7-14.3-32-32-32s-32 14.3-32 32c0 53-43 96-96 96H192V352c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9l-64 64c-12.5 12.5-12.5 32.8 0 45.3l64 64c9.2 9.2 22.9 11.9 34.9 6.9s19.8-16.6 19.8-29.6V448H352c88.4 0 160-71.6 160-160z"/></svg>';
			$next = trim( (string) $atts['next'] );
			return '<span class="tcc-event-repeats">' . $icon . '<span>' . esc_html( $text ) . '</span></span>'
				. ( '' !== $next ? '<span class="tcc-event-next">' . esc_html( $next ) . '</span> ' : '' );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_repeats', 'tcc_event_repeats_shortcode' );

	/**
	 * The "Repeats" box on an event's edit screen.
	 */
	function tcc_event_repeats_box() {
		add_meta_box( 'tcc-event-repeats', 'Repeats (shown on event cards)', 'tcc_event_repeats_box_html', 'tribe_events', 'side', 'default' );
	}
	add_action( 'add_meta_boxes', 'tcc_event_repeats_box' );

	function tcc_event_repeats_box_html( $post ) {
		$own  = (string) get_post_meta( $post->ID, '_tcc_repeats', true );
		$auto = trim( (string) apply_filters( 'tcc_event_repeats_text', '', (int) $post->ID ) );
		wp_nonce_field( 'tcc_event_repeats', 'tcc_event_repeats_nonce' );
		echo '<p><label for="tcc-event-repeats-field">How often this event repeats</label></p>';
		echo '<input type="text" id="tcc-event-repeats-field" name="tcc_event_repeats" value="' . esc_attr( $own ) . '" maxlength="80" style="width:100%" placeholder="' . esc_attr( '' !== $auto ? $auto : 'Every Wednesday' ) . '" />';
		if ( '' !== $auto ) {
			echo '<p class="description">Planning Center says: <strong>' . esc_html( $auto ) . '</strong>. That is used while this box is empty. Type here to use your own words, or type <code>none</code> to hide the line.</p>';
		} else {
			echo '<p class="description">Leave empty for a one-off event. For an event that repeats, type it the way you would say it, for example <em>Every Wednesday</em> or <em>The first Sunday of every month</em>.</p>';
		}
		echo '<p class="description">Event lists show a repeating event once, with this line and its next date.</p>';
	}

	function tcc_event_repeats_save( $post_id ) {
		if ( ! isset( $_POST['tcc_event_repeats_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['tcc_event_repeats_nonce'] ) ), 'tcc_event_repeats' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$text = isset( $_POST['tcc_event_repeats'] ) ? sanitize_text_field( wp_unslash( $_POST['tcc_event_repeats'] ) ) : '';
		$text = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 80 ) : substr( $text, 0, 80 );
		if ( '' === $text ) {
			delete_post_meta( $post_id, '_tcc_repeats' );
		} else {
			update_post_meta( $post_id, '_tcc_repeats', $text );
		}
	}
	// Priority 5: before the lists are refreshed (tcc_upcoming_flush_all runs at 10 on the same action).
	add_action( 'save_post_tribe_events', 'tcc_event_repeats_save', 5 );
}

if ( ! function_exists( 'tcc_no_upcoming_shortcode' ) ) {
	function tcc_no_upcoming_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'message'  => 'There are no upcoming events scheduled.',
			),
			$atts,
			'tcc_no_upcoming'
		);
		try {
			$term_id = 0;
			if ( '' !== $atts['category'] ) {
				$term = is_numeric( $atts['category'] )
					? get_term( (int) $atts['category'], 'tribe_events_cat' )
					: get_term_by( 'slug', sanitize_title( $atts['category'] ), 'tribe_events_cat' );
				if ( ! ( $term instanceof WP_Term ) ) {
					return '';
				}
				$term_id = (int) $term->term_id;
			}
			if ( count( tcc_upcoming_ids_for( 'series', $term_id ) ) > 0 ) {
				return '';
			}
			return '<span class="tcc-no-upcoming">' . esc_html( $atts['message'] ) . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_no_upcoming', 'tcc_no_upcoming_shortcode' );
}

if ( ! function_exists( 'tcc_upcoming_empty_css' ) ) {
	/**
	 * When one of these loops has no events, Divi prints its stock "No Results Found" text.
	 * Hide that (and the empty card area) so only our own message shows. The same block also holds
	 * the look of the event cards (the arrow beside the title on hover, the "repeats" line).
	 * The rules are in event-feeds.css, beside this file.
	 */
	function tcc_upcoming_empty_css() {
		echo '<style id="tcc-upcoming-empty">' . tcc_site_asset( 'features/event-feeds.css' ) . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own styles file.
	}
	add_action( 'wp_head', 'tcc_upcoming_empty_css', 99 );
}

if ( ! function_exists( 'tcc_events_paging_shortcode' ) ) {
	/**
	 * [tcc_events_paging per_page="8"] prints "Previous Events" / "Next Events" links
	 * for a loop that uses "Upcoming Events - every date (automatic)".
	 * per_page must match the loop's "posts per page".
	 */
	function tcc_events_paging_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'per_page' => 8 ), $atts, 'tcc_events_paging' );
		try {
			$per   = max( 1, min( 48, (int) $atts['per_page'] ) );
			$total = count( tcc_upcoming_ids_for( 'all', 0 ) );
			$pages = (int) ceil( $total / $per );
			if ( $pages < 2 ) {
				return '';
			}
			$page = isset( $_GET['tcc_page'] ) ? max( 1, min( $pages, (int) $_GET['tcc_page'] ) ) : 1;
			$prev = '';
			$next = '';
			if ( $page > 1 ) {
				$url  = ( 2 === $page ) ? remove_query_arg( 'tcc_page' ) : add_query_arg( 'tcc_page', $page - 1 );
				$prev = '<a class="tcc-events-prev" style="color:inherit" href="' . esc_url( $url ) . '#tcc-events">&laquo; Previous Events</a>';
			}
			if ( $page < $pages ) {
				$next = '<a class="tcc-events-next" style="color:inherit;margin-left:auto" href="' . esc_url( add_query_arg( 'tcc_page', $page + 1 ) ) . '#tcc-events">Next Events &raquo;</a>';
			}
			return '<span class="tcc-events-paging" style="display:flex;justify-content:space-between;gap:20px">' . $prev . $next . '</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_events_paging', 'tcc_events_paging_shortcode' );
}
