(function () {
	/* The Speakers box: "Main speaker" beside each ticked name, the search line, and Add a new speaker. */
	var box = document.getElementById('tcc-speakers-box');
	if (!box) { return; }
	var list = box.querySelector('.tcc-spk-list');
	if (!list) { return; }
	/* Always sit straight under the Categories box, in whichever column that is (on the church's
	   site Categories is in the wide column), so speakers are picked next to the other categories. */
	var cats = document.getElementById('categorydiv');
	if (cats && cats.parentNode) { cats.parentNode.insertBefore(box, cats.nextSibling); }
	if (cats) {
		var inside = cats.querySelector('.inside');
		if (inside) {
			var note = document.createElement('p');
			note.className = 'description';
			note.textContent = 'Speakers are picked in the Speakers box.';
			inside.appendChild(note);
		}
	}
	function rows() { return Array.prototype.slice.call(list.querySelectorAll('.tcc-spk-row')); }
	function tick(row) { return row.querySelector('input[type=checkbox]'); }
	function radio(row) { return row.querySelector('input[type=radio]'); }
	/* Shows "Main speaker" beside each ticked name, and makes sure one of them is chosen (the first A to Z). */
	function sync() {
		var on = rows().filter(function (r) { return tick(r).checked; });
		rows().forEach(function (r) {
			r.classList.toggle('is-on', tick(r).checked);
			if (!tick(r).checked) { radio(r).checked = false; }
		});
		if (on.length && !on.some(function (r) { return radio(r).checked; })) { radio(on[0]).checked = true; }
	}
	var touched = document.getElementById('tcc-spk-touched');
	function touch() { if (touched) { touched.value = '1'; } }
	list.addEventListener('change', function () { touch(); sync(); });
	/* "Use these speakers": accepts what the box pre-ticked, so it is saved with the next Update. */
	var use = document.getElementById('tcc-spk-use');
	if (use) {
		use.addEventListener('click', function () {
			touch();
			var s = document.getElementById('tcc-spk-use-status');
			if (s) { s.textContent = 'These speakers will be saved when you press Update.'; }
			use.disabled = true;
		});
	}
	function norm(t) { return t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim(); }

	var search = box.querySelector('.tcc-spk-search');
	if (search) {
		search.addEventListener('input', function () {
			var q = search.value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
			rows().forEach(function (r) {
				r.hidden = q !== '' && r.getAttribute('data-name').indexOf(q) === -1 && !tick(r).checked;
			});
		});
		search.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); } });
	}

	var input = document.getElementById('tcc-spk-new');
	var button = document.getElementById('tcc-spk-add-btn');
	var status = box.querySelector('.tcc-spk-status');
	function add() {
		var name = input.value.replace(/\s+/g, ' ').trim();
		if (!name) { status.textContent = 'Type the speaker’s name first.'; input.focus(); return; }
		button.disabled = true;
		status.textContent = 'Adding…';
		var body = new URLSearchParams({ action: 'tcc_add_speaker', name: name, _ajax_nonce: button.getAttribute('data-nonce') });
		fetch(window.ajaxurl, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (r) { return r.json(); })
			.then(function (res) {
				button.disabled = false;
				if (!res || !res.success) {
					status.textContent = (res && res.data && res.data.message) || 'The speaker could not be added. Reload the page and try again.';
					return;
				}
				var d = res.data;
				var found = list.querySelector('input[type=checkbox][value="' + d.id + '"]');
				var row;
				if (found) {
					row = found.closest('.tcc-spk-row');
				} else {
					var holder = document.createElement('ul');
					holder.innerHTML = d.row;
					row = holder.firstElementChild;
					var before = rows().filter(function (r) { return r.getAttribute('data-name') > row.getAttribute('data-name'); })[0];
					list.insertBefore(row, before || null);
				}
				tick(row).checked = true;
				row.hidden = false;
				/* The first typed name was not a speaker yet: make them the main speaker once added. */
				if (touched && touched.getAttribute('data-first') && norm(d.name) === touched.getAttribute('data-first')) { radio(row).checked = true; }
				touch();
				sync();
				var empty = box.querySelector('.tcc-spk-empty');
				if (empty) { empty.remove(); }
				input.value = '';
				input.focus();
				status.textContent = d.existed ? d.name + ' was already in the list and is now ticked.' : d.name + ' was added and ticked.';
				row.scrollIntoView({ block: 'nearest' });
			})
			.catch(function () {
				button.disabled = false;
				status.textContent = 'The speaker could not be added. Check the internet connection and try again.';
			});
	}
	if (button) {
		button.addEventListener('click', add);
		input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); add(); } });
	}
	sync();
})();
