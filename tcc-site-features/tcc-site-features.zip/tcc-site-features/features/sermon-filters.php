<?php
/**
 * TCC Sermons page: search, filters and sermon series.
 *
 * The Sermons page and the series pages are ordinary Divi layouts (Theme Builder). Divi draws the
 * cards with its own loops. This feature adds only the pieces Divi cannot do by itself:
 *
 *  1. The search and filter bar above the sermon cards. Divi draws the newest cards; the bar's script
 *     copies that card for every older sermon and shows or hides cards in the visitor's browser, so
 *     nothing is asked of the server while someone searches and the page stays quick to build.
 *  2. A list Divi can loop over: "Sermon series - newest first (automatic)". It is the categories
 *     filed under "Series" that have at least one sermon, newest series first.
 *  3. A few lines of text for the cards and the series page (speaker and date, series name,
 *     "27 sermons - 2025 to 2026", the "Start with part 1" button).
 *  4. A second list for Divi: "Sermons in this series - oldest first (automatic)", so a series page
 *     reads as part 1, 2, 3. And it shows the "Sermon series page" layout on every series page, so
 *     nobody has to assign that layout to each new series.
 *  5. A sermon with no graphic of its own borrows its series graphic, or failing that the church's
 *     default graphic, on these pages only. A sermon with no title shows as "Sermon from <date>".
 *
 * Where the facts come from (nothing is typed in twice):
 *   Series, speaker, book of the Bible, topic   the sermon's categories (Posts > Categories)
 *   Speaker name                                the speakers ticked in the Speakers box (main speaker
 *                                               first; needs the "Sermon speakers" feature to tick them),
 *                                               else the "Speaker Name" field, else the Speaker category,
 *                                               else the sermon's author
 *   Series description                          the Description box of that series category
 *   Series graphic                              the "Series graphic" field on that category;
 *                                               until one is added, the series' first sermon graphic
 *
 * Short codes:
 *   [tcc_sermon_filter]        the search and filter bar (put it above the list of cards)
 *   [tcc_sermon_meta]          inside a sermon card: "Speaker name - Nov 1, 2026" (also carries the
 *                              hidden marker the filter bar reads, so every card needs it)
 *   [tcc_sermon_series]        inside a sermon card: the name of its series
 *   [tcc_sermon_count]         how many sermons there are; what="series" for how many series
 *   [tcc_series_toggle]        the "See all 19 series" button
 *   [tcc_series_graphic]       on a series page: the series graphic
 *   [tcc_series_facts]         on a series page: "27 sermons - September 7, 2025 to May 31, 2026"
 *   [tcc_series_start]         on a series page: the "Start with part 1" button
 *
 * Everything is worked out once and remembered for 12 hours; it is worked out again whenever a
 * sermon or a category is saved.
 *
 * The looks and the script are in files of their own beside this one, printed inside the page:
 *   features/sermon-filters.css   the filter bar, the cards' hover, the series cards and the series page rows
 *   features/sermon-filters.js    the filter bar's script (copies the cards, searches, filters)
 * The script for the "See all series" button is short and stays at the end of this file.
 *
 * Where the code is. This file is short on purpose: it loads the three parts in the folder
 * sermon-filters/ beside it. Each part can be seen and edited on its own on TCC Website > Features
 * (the folded list "Parts of the larger features" at the bottom of that tab):
 *   sermon-filters/facts.php       the facts about every sermon: its series, speakers, book and topic
 *                                  (from its categories), and the speaker line shown on cards
 *   sermon-filters/series.php      the two lists Divi loops over, the series pictures (and the stand-in
 *                                  picture for a sermon with none), the series page layout and the
 *                                  short codes at the top of a series page
 *   sermon-filters/filter-bar.php  the rows the filter bar's script copies cards from, the short codes
 *                                  inside the cards, and the pieces the filter bar is built from
 * This file itself keeps the [tcc_sermon_filter] short code (the Features tab looks for it to say the
 * feature is working) and, at the end, the looks and the "See all series" script.
 *
 * Part of the TCC Website Features plugin (added in 0.3.0, November 2026; split into parts in 0.14.4).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ----------------------------------------------------------------------------------------------
 * The search and filter bar's short code. It stays in this file because the Features tab looks
 * for tcc_sermon_filter_shortcode() to say this feature is working. The pieces it is built from
 * (tcc_sermon_filter_choices, tcc_sermon_filter_options, tcc_sermons_plain_list, tcc_sermons_cards
 * and the script, tcc_sermon_filter_script) are in sermon-filters/filter-bar.php.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_filter_shortcode' ) ) {

	function tcc_sermon_filter_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'target' => 'tcc-sermons',
				'first'  => 12,
			),
			$atts,
			'tcc_sermon_filter'
		);
		try {
			$index   = tcc_sermons_index();
			$choices = tcc_sermon_filter_choices();
			$series  = array();
			$notes   = array();
			foreach ( $index['series'] as $row ) {
				$series[ $row['slug'] ] = $row['name'];
				$notes[ $row['slug'] ]  = array(
					'n' => $row['name'],
					'u' => $row['url'],
					'i' => $row['img'],
					'd' => $row['desc'],
				);
			}
			$books = '';
			if ( $choices['ot'] ) {
				$books .= '<optgroup label="Old Testament">' . tcc_sermon_filter_options( $choices['ot'] ) . '</optgroup>';
			}
			if ( $choices['nt'] ) {
				$books .= '<optgroup label="New Testament">' . tcc_sermon_filter_options( $choices['nt'] ) . '</optgroup>';
			}
			$books .= tcc_sermon_filter_options( $choices['book'] );

			$target = sanitize_html_class( $atts['target'] );
			$first  = max( 3, (int) $atts['first'] );
			$uid    = 'tcc-sf';
			$json   = JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;

			$html  = tcc_sermons_css_once();
			$html .= '<noscript><style>.tcc-sf{display:none}</style>' . tcc_sermons_plain_list() . '</noscript>';
			$html .= '<form class="tcc-sf" id="' . $uid . '" role="search" aria-label="Search and filter sermons" data-target="' . esc_attr( $target ) . '" data-first="' . (int) $first . '" onsubmit="return false">';
			$html .= '<span class="tcc-sf-label" aria-hidden="true">Find a sermon</span>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-series">Series</label>';
			$html .= '<select id="' . $uid . '-series" data-key="series" data-name="Series"><option value="">All series</option>' . tcc_sermon_filter_options( $series ) . '</select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-speaker">Speaker</label>';
			$html .= '<select id="' . $uid . '-speaker" data-key="speaker" data-name="Speaker"><option value="">All speakers</option></select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-book">Book of the Bible</label>';
			$html .= '<select id="' . $uid . '-book" data-key="book" data-name="Book"><option value="">All books</option>' . $books . '</select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-topic">Topic</label>';
			$html .= '<select id="' . $uid . '-topic" data-key="topic" data-name="Topic"><option value="">All topics</option>' . tcc_sermon_filter_options( $choices['topic'] ) . '</select>';
			// The search box comes last and takes the room that is left, as on the Events and Community Groups bars.
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-q">Search sermons</label>';
			$html .= '<input type="search" id="' . $uid . '-q" data-key="q" placeholder="Search sermons" title="Search by title, speaker, scripture or topic" autocomplete="off" enterkeyhint="search">';
			$html .= '<div class="tcc-sf-status" hidden></div>';
			$html .= '<span class="tcc-sf-sr" role="status" aria-live="polite"></span>';
			$html .= '</form>';
			$html .= '<a class="tcc-sf-note" hidden></a>';
			$html .= '<script type="application/json" id="' . $uid . '-series-data">' . wp_json_encode( $notes, $json ) . '</script>';
			$html .= '<script type="application/json" id="' . $uid . '-cards">' . wp_json_encode( tcc_sermons_cards(), $json ) . '</script>';
			add_action( 'wp_footer', 'tcc_sermon_filter_script', 50 );
			return $html;
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_filter', 'tcc_sermon_filter_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * The three parts, in this order (the later ones use what the first one works out).
 * Each runs the saved edit of its file if there is a healthy one, otherwise the original
 * (code-edits.php). They are loaded outside the "if" above on purpose: each part has its own
 * "if ( ! function_exists() )" line, and if a saved edit of this file stops part-way and the
 * original is loaded instead, the parts are still loaded.
 * -------------------------------------------------------------------------------------------- */

tcc_code_require( 'tcc-site-features', 'features/sermon-filters/facts.php' );
tcc_code_require( 'tcc-site-features', 'features/sermon-filters/series.php' );
tcc_code_require( 'tcc-site-features', 'features/sermon-filters/filter-bar.php' );

/* ----------------------------------------------------------------------------------------------
 * Looks, and the "See all series" button.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermons_css' ) ) {

	/**
	 * The styles for the filter bar, the cards' hover, the series cards and the series page rows.
	 * Colours, corner size and fonts match the rest of the site: Trinity teal #00A4CF. Buttons are not
	 * styled here at all: they carry Divi's own button class, so they look and behave like every
	 * other button on the website and follow any change made to the site's button settings.
	 *
	 * The rules themselves are in features/sermon-filters.css. Like the rest of the site's styles they
	 * are printed inside the page (see tcc_sermons_css_once below), not loaded as a separate file.
	 */
	function tcc_sermons_css() {
		return tcc_site_asset( 'features/sermon-filters.css' ); // tcc_site_asset() is in the plugin's main file.
	}

	/** Returns the style block the first time it is asked for on a page, and nothing after that. */
	function tcc_sermons_css_once() {
		static $printed = false;
		if ( $printed ) {
			return '';
		}
		$printed = true;
		return '<style id="tcc-sermons-css">' . tcc_sermons_css() . '</style>';
	}

	/**
	 * On the Sermons page and category pages the styles go in the head, so nothing flashes unstyled.
	 * The Divi editor gets them too: it previews the Sermons layout away from the Sermons page, and
	 * without them the filter bar showed there as plain words and bare menus.
	 */
	add_action(
		'wp_head',
		function () {
			if ( tcc_sermons_is_list_page() || ( function_exists( 'tcc_site_in_divi_editor' ) && tcc_site_in_divi_editor() ) ) {
				echo tcc_sermons_css_once(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		},
		30
	);

	/** Makes the "See all series" button open and close the rest of the series cards. */
	add_action(
		'wp_footer',
		function () {
			if ( ! tcc_sermons_is_list_page() ) {
				return;
			}
			?>
<script id="tcc-series-toggle-js">
(function () {
	var btn = document.querySelector('.tcc-series-toggle');
	var list = document.querySelector('.tcc-series-list');
	if (!btn || !list) { if (btn) { btn.hidden = true; } return; }
	btn.addEventListener('click', function () {
		var open = list.classList.toggle('is-open');
		btn.setAttribute('aria-expanded', open ? 'true' : 'false');
		btn.textContent = btn.getAttribute(open ? 'data-less' : 'data-more');
	});
})();
</script>
			<?php
		},
		51
	);
}
