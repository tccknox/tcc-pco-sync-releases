<?php
/**
 * TCC Sermons page: search, filters and sermon series.
 *
 * The Sermons page and the series pages are ordinary Divi layouts (Theme Builder). Divi draws the
 * cards with its own loops. This file adds only the pieces Divi cannot do by itself:
 *
 *  1. The search and filter bar above the sermon cards. Divi draws the newest cards; the bar's script
 *     copies that card for every older sermon and shows or hides cards in the visitor's browser, so
 *     nothing is asked of the server while someone searches and the page stays quick to build.
 *  2. A list Divi can loop over: "Sermon series - newest first (automatic)". It is the categories
 *     filed under "Series" that have at least one sermon, newest series first.
 *  3. A few lines of text for the cards and the series page (speaker and date, series name,
 *     "27 sermons - 2025 to 2026", the "Start with part 1" button).
 *  4. A second list for Divi: "Sermons in this series - oldest first (automatic)", so a series page
 *     reads as part 1, 2, 3. And it shows the "Sermon series page" layout on every series page, so
 *     nobody has to assign that layout to each new series.
 *  5. A sermon with no graphic of its own borrows its series graphic, or failing that the church's
 *     default graphic, on these pages only. A sermon with no title shows as "Sermon from <date>".
 *
 * Where the facts come from (nothing is typed in twice):
 *   Series, speaker, book of the Bible, topic   the sermon's categories (Posts > Categories)
 *   Speaker name                                the speakers ticked in the Speakers box (main speaker
 *                                               first; needs the "Sermon speakers" feature to tick them),
 *                                               else the "Speaker Name" field, else the Speaker category,
 *                                               else the sermon's author
 *   Series description                          the Description box of that series category
 *   Series graphic                              the "Series graphic" field on that category;
 *                                               until one is added, the series' first sermon graphic
 *
 * Short codes:
 *   [tcc_sermon_filter]        the search and filter bar (put it above the list of cards)
 *   [tcc_sermon_meta]          inside a sermon card: "Speaker name - Nov 1, 2026" (also carries the
 *                              hidden marker the filter bar reads, so every card needs it)
 *   [tcc_sermon_series]        inside a sermon card: the name of its series
 *   [tcc_sermon_count]         how many sermons there are; what="series" for how many series
 *   [tcc_series_toggle]        the "See all 19 series" button
 *   [tcc_series_graphic]       on a series page: the series graphic
 *   [tcc_series_facts]         on a series page: "27 sermons - September 7, 2025 to May 31, 2026"
 *   [tcc_series_start]         on a series page: the "Start with part 1" button
 *
 * Everything is worked out once and remembered for 12 hours; it is worked out again whenever a
 * sermon or a category is saved.
 *
 * The looks and the script are in files of their own beside this one, printed inside the page:
 *   features/sermon-filters.css   the filter bar, the cards' hover, the series cards and the series page rows
 *   features/sermon-filters.js    the filter bar's script (copies the cards, searches, filters)
 * The script for the "See all series" button is short and stays at the end of this file.
 *
 * Part of the TCC Website Features plugin (added in 0.3.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermons_index' ) ) {

	/** The name of the list Divi loops over for series cards. */
	function tcc_sermons_series_source() {
		return 'tcc_sermon_series';
	}

	/** The four parent categories, by their slug (the last part of their address). */
	function tcc_sermons_parent_slugs() {
		return apply_filters(
			'tcc_sermons_parent_slugs',
			array(
				'series'  => 'sermons-series',
				'speaker' => 'speaker',
				'topic'   => 'topics',
				'book'    => 'bible',
			)
		);
	}

	/** Books of the Bible in their usual order, so the Book menu reads Genesis to Revelation. */
	function tcc_sermons_bible_order() {
		static $order = null;
		if ( null === $order ) {
			$books = 'Genesis,Exodus,Leviticus,Numbers,Deuteronomy,Joshua,Judges,Ruth,1 Samuel,2 Samuel,1 Kings,2 Kings,1 Chronicles,2 Chronicles,Ezra,Nehemiah,Esther,Job,Psalms,Proverbs,Ecclesiastes,Song of Solomon,Isaiah,Jeremiah,Lamentations,Ezekiel,Daniel,Hosea,Joel,Amos,Obadiah,Jonah,Micah,Nahum,Habakkuk,Zephaniah,Haggai,Zechariah,Malachi,Matthew,Mark,Luke,John,Acts,Romans,1 Corinthians,2 Corinthians,Galatians,Ephesians,Philippians,Colossians,1 Thessalonians,2 Thessalonians,1 Timothy,2 Timothy,Titus,Philemon,Hebrews,James,1 Peter,2 Peter,1 John,2 John,3 John,Jude,Revelation';
			$order = array_flip( array_map( 'strtolower', explode( ',', $books ) ) );
			$order['psalm']           = $order['psalms'];
			$order['song of songs']   = $order['song of solomon'];
			$order['revelations']     = $order['revelation'];
		}
		return $order;
	}

	/**
	 * Everything these pages need to know, worked out once and remembered.
	 *
	 * 'cats'   category id => array( group, name, slug, testament )   group is series, speaker, topic or book
	 * 'series' series category id => array( name, slug, url, count, first, last, first_post, img, img_id, desc ),
	 *          newest series first; only series with at least one sermon
	 * 'posts'  sermon id => series category id (0 when it is in no series)
	 * 'used'   category id => how many sermons carry it
	 * 'total'  number of published sermons
	 */
	function tcc_sermons_index() {
		// Remembered per "generation", so a change to the sermons (which starts a new generation) is never hidden by an old copy.
		static $memo = array();
		$gen = tcc_site_gen( 'sermons' );
		if ( isset( $memo[ $gen ] ) ) {
			return $memo[ $gen ];
		}
		$key    = 'tcc_sermons_idx_' . $gen;
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['series'], $cached['cats'] ) ) {
			$memo[ $gen ] = $cached;
			return $memo[ $gen ];
		}

		$index = array(
			'cats'   => array(),
			'series' => array(),
			'posts'  => array(),
			'used'   => array(),
			'total'  => 0,
		);
		$GLOBALS['tcc_sermons_building'] = true;
		try {
			// 1. Sort every category into series, speaker, topic or book by the parent it sits under.
			$terms = get_terms(
				array(
					'taxonomy'   => 'category',
					'hide_empty' => false,
				)
			);
			$terms  = is_array( $terms ) ? $terms : array();
			$by_id  = array();
			$groups = array();
			foreach ( $terms as $term ) {
				$by_id[ (int) $term->term_id ] = $term;
			}
			foreach ( tcc_sermons_parent_slugs() as $group => $slug ) {
				foreach ( $terms as $term ) {
					if ( $term->slug === $slug && 0 === (int) $term->parent ) {
						$groups[ (int) $term->term_id ] = $group;
					}
				}
			}
			foreach ( $terms as $term ) {
				$id        = (int) $term->term_id;
				$walk      = $term;
				$testament = '';
				$group     = '';
				$steps     = 0;
				while ( $walk && $steps < 6 ) {
					$parent = (int) $walk->parent;
					if ( ! $parent || ! isset( $by_id[ $parent ] ) ) {
						break;
					}
					if ( isset( $groups[ $parent ] ) ) {
						$group = $groups[ $parent ];
						break;
					}
					if ( 'old-testament' === $by_id[ $parent ]->slug ) {
						$testament = 'ot';
					} elseif ( 'new-testament' === $by_id[ $parent ]->slug ) {
						$testament = 'nt';
					}
					$walk = $by_id[ $parent ];
					++$steps;
				}
				if ( '' === $group ) {
					continue;
				}
				// "Old Testament" and "New Testament" are headings in the Book menu, not books.
				if ( 'book' === $group && in_array( $term->slug, array( 'old-testament', 'new-testament' ), true ) ) {
					continue;
				}
				$index['cats'][ $id ] = array(
					'group'     => $group,
					'name'      => wp_specialchars_decode( $term->name, ENT_QUOTES ),
					'slug'      => $term->slug,
					'testament' => $testament,
				);
			}

			// 2. Every published sermon, oldest first, and the categories each one carries.
			$ids = get_posts(
				array(
					'post_type'              => 'post',
					'post_status'            => 'publish',
					'has_password'           => false, // A password-protected sermon is never listed or summarised.
					'posts_per_page'         => 2000,
					'orderby'                => 'date',
					'order'                  => 'ASC',
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'suppress_filters'       => true,
				)
			);
			$ids            = array_map( 'intval', is_array( $ids ) ? $ids : array() );
			$index['total'] = count( $ids );
			$series         = array();
			if ( $ids ) {
				_prime_post_caches( $ids, false, true );
				$links = wp_get_object_terms( $ids, 'category', array( 'fields' => 'all_with_object_id' ) );
				$links = is_array( $links ) ? $links : array();
				foreach ( $ids as $id ) {
					$index['posts'][ $id ] = 0;
				}
				foreach ( $links as $link ) {
					$term_id = (int) $link->term_id;
					$post_id = (int) $link->object_id;
					if ( ! isset( $index['cats'][ $term_id ] ) ) {
						continue;
					}
					$index['used'][ $term_id ] = isset( $index['used'][ $term_id ] ) ? $index['used'][ $term_id ] + 1 : 1;
					if ( 'series' === $index['cats'][ $term_id ]['group'] && ! $index['posts'][ $post_id ] ) {
						$index['posts'][ $post_id ] = $term_id;
					}
				}
				foreach ( $ids as $id ) {
					$term_id = $index['posts'][ $id ];
					if ( ! $term_id ) {
						continue;
					}
					$time  = (int) get_post_time( 'U', false, $id );
					$thumb = (int) get_post_meta( $id, '_thumbnail_id', true );
					if ( ! isset( $series[ $term_id ] ) ) {
						$term               = $by_id[ $term_id ];
						$link               = get_term_link( $term );
						$series[ $term_id ] = array(
							'name'       => $index['cats'][ $term_id ]['name'],
							'slug'       => $term->slug,
							'url'        => is_wp_error( $link ) ? '' : $link,
							'count'      => 0,
							'first'      => $time,
							'last'       => $time,
							'first_post' => $id,
							'img'        => '',
							'img_id'     => 0,
							'desc'       => trim( wp_strip_all_tags( (string) $term->description ) ),
						);
					}
					++$series[ $term_id ]['count'];
					$series[ $term_id ]['last'] = max( $series[ $term_id ]['last'], $time );
					// Stand-in graphic: the first sermon in the series that has one.
					if ( $thumb && ! $series[ $term_id ]['img_id'] ) {
						$series[ $term_id ]['img_id'] = $thumb;
					}
				}
			}
			foreach ( $series as $term_id => $row ) {
				// A graphic chosen on the category itself always wins.
				$own = (int) get_term_meta( $term_id, 'series_graphic', true );
				if ( $own && wp_attachment_is_image( $own ) ) {
					$row['img_id'] = $own;
				}
				if ( $row['img_id'] ) {
					$url        = wp_get_attachment_image_url( $row['img_id'], 'medium_large' );
					$row['img'] = $url ? $url : (string) wp_get_attachment_url( $row['img_id'] );
				}
				$series[ $term_id ] = $row;
			}
			uasort(
				$series,
				function ( $a, $b ) {
					return $b['last'] <=> $a['last'];
				}
			);
			$index['series'] = $series;
		} catch ( \Throwable $e ) {
			$index['error'] = $e->getMessage();
		}
		unset( $GLOBALS['tcc_sermons_building'] );

		if ( empty( $index['error'] ) ) {
			set_transient( $key, $index, 12 * HOUR_IN_SECONDS );
		}
		$memo[ $gen ] = $index;
		return $memo[ $gen ];
	}

	/** Forget the remembered facts, so they are worked out again on the next visit. */
	function tcc_sermons_bump() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		tcc_site_new_gen( 'sermons' );
	}
	add_action(
		'save_post_post',
		function ( $post_id ) {
			if ( ! wp_is_post_revision( $post_id ) && ! wp_is_post_autosave( $post_id ) ) {
				tcc_sermons_bump();
			}
		}
	);
	add_action( 'deleted_post', 'tcc_sermons_bump' );
	add_action( 'created_category', 'tcc_sermons_bump' );
	add_action( 'edited_category', 'tcc_sermons_bump' );
	add_action( 'delete_category', 'tcc_sermons_bump' );
	add_action(
		'set_object_terms',
		function ( $object_id, $terms, $tt_ids, $taxonomy ) {
			if ( 'category' === $taxonomy ) {
				tcc_sermons_bump();
			}
		},
		10,
		4
	);

	/** Is this the Sermons page (the list of posts) or a category page? Only true once WordPress knows. */
	function tcc_sermons_is_list_page() {
		return did_action( 'wp' ) && ! is_admin() && ( is_home() || is_category() );
	}

	/** Is the Divi editor asking for a list to preview? (So its preview can match the website.) */
	function tcc_sermons_is_divi_preview() {
		if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
			return false;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return false !== strpos( $uri, 'divi/v1/loop/' ) || false !== strpos( rawurldecode( $uri ), 'divi/v1/loop/' );
	}

	/** The series category id of the page being shown, or 0 when it is not a series page. */
	function tcc_sermons_current_series() {
		if ( ! did_action( 'wp' ) || ! is_category() ) {
			return 0;
		}
		$term  = get_queried_object();
		$index = tcc_sermons_index();
		$id    = ( $term instanceof WP_Term ) ? (int) $term->term_id : 0;
		return ( $id && isset( $index['cats'][ $id ] ) && 'series' === $index['cats'][ $id ]['group'] ) ? $id : 0;
	}

	/** The id of the "Speaker" category (the parent every speaker is filed under), or 0 if there is none. */
	function tcc_sermons_speaker_root() {
		static $root = 0;
		if ( $root ) {
			return $root;
		}
		$slugs = tcc_sermons_parent_slugs();
		$term  = get_term_by( 'slug', $slugs['speaker'], 'category' );
		$root  = ( $term && 0 === (int) $term->parent ) ? (int) $term->term_id : 0;
		return $root;
	}

	/** Speakers (id => name) with the main speaker first and the rest A to Z. A main speaker not among them is ignored. */
	function tcc_sermons_order_speakers( $names, $main ) {
		$names = (array) $names;
		uasort( $names, 'strnatcasecmp' );
		$main = (int) $main;
		if ( ! isset( $names[ $main ] ) ) {
			return $names;
		}
		return array( $main => $names[ $main ] ) + $names;
	}

	/** "A", "A & B", "A, B & C". $and is " &amp; " when the names are already HTML. */
	function tcc_sermons_join_names( $names, $and = ' & ' ) {
		$names = array_values(
			array_filter(
				array_map( 'strval', (array) $names ),
				function ( $name ) {
					return '' !== trim( $name );
				}
			)
		);
		$last = array_pop( $names );
		if ( null === $last ) {
			return '';
		}
		return $names ? implode( ', ', $names ) . $and . $last : $last;
	}

	/**
	 * The speakers ticked on a sermon, main speaker first: term id => name.
	 * Empty until the sermon has a main speaker saved (the Speakers box or the fill-in does that),
	 * so older sermons keep showing their typed Speaker Name until they are filled in.
	 * Only speakers filed straight under Speaker count (that is how every speaker is filed).
	 */
	function tcc_sermons_speaker_list( $post_id ) {
		$main = (int) get_post_meta( $post_id, '_tcc_main_speaker', true );
		$root = tcc_sermons_speaker_root();
		if ( ! $main || ! $root ) {
			return array();
		}
		$names = array();
		$terms = get_the_terms( $post_id, 'category' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( (int) $term->parent === $root ) {
					$names[ (int) $term->term_id ] = wp_specialchars_decode( $term->name, ENT_QUOTES );
				}
			}
		}
		return $names ? tcc_sermons_order_speakers( $names, $main ) : array();
	}

	/**
	 * The speaker line of one sermon, for example "Tyler Lynde & Amy Lynde":
	 * the speakers ticked in the Speakers box (main speaker first), else the Speaker Name field,
	 * else the Speaker category, else the author.
	 */
	function tcc_sermons_speaker( $post_id ) {
		$list = tcc_sermons_speaker_list( $post_id );
		if ( $list ) {
			return tcc_sermons_join_names( $list );
		}
		$name = trim( (string) get_post_meta( $post_id, 'speaker_name', true ) );
		if ( '' !== $name ) {
			return $name;
		}
		$index = tcc_sermons_index();
		$terms = get_the_terms( $post_id, 'category' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( isset( $index['cats'][ $id ] ) && 'speaker' === $index['cats'][ $id ]['group'] ) {
					return $index['cats'][ $id ]['name'];
				}
			}
		}
		$post = get_post( $post_id );
		return $post ? trim( (string) get_the_author_meta( 'display_name', (int) $post->post_author ) ) : '';
	}

	/** One sermon's facts, grouped: array( series => [slug => name], speaker => ..., book => ..., topic => ... ). */
	function tcc_sermons_facts( $post_id ) {
		$facts = array(
			'series'  => array(),
			'speaker' => array(),
			'book'    => array(),
			'topic'   => array(),
		);
		$index = tcc_sermons_index();
		$terms = get_the_terms( $post_id, 'category' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( isset( $index['cats'][ $id ] ) ) {
					$facts[ $index['cats'][ $id ]['group'] ][ $index['cats'][ $id ]['slug'] ] = $index['cats'][ $id ]['name'];
				}
			}
		}
		// Keep to the one series the rest of the page uses for this sermon.
		$series_id = isset( $index['posts'][ $post_id ] ) ? (int) $index['posts'][ $post_id ] : 0;
		if ( $series_id && isset( $index['cats'][ $series_id ] ) ) {
			$facts['series'] = array( $index['cats'][ $series_id ]['slug'] => $index['cats'][ $series_id ]['name'] );
		}
		return $facts;
	}

	/* ------------------------------------------------------------------------------------------
	 * The list Divi loops over for series cards.
	 * ---------------------------------------------------------------------------------------- */

	function tcc_sermons_register_source() {
		register_taxonomy(
			tcc_sermons_series_source(),
			'post',
			array(
				'labels'             => array(
					'name'          => 'Sermon series - newest first (automatic)',
					'singular_name' => 'Sermon series - newest first (automatic)',
				),
				'public'             => true,
				'publicly_queryable' => true,
				'hierarchical'       => false,
				'show_ui'            => false,
				'show_in_menu'       => false,
				'show_in_nav_menus'  => false,
				'show_tagcloud'      => false,
				'show_in_quick_edit' => false,
				'show_admin_column'  => false,
				'show_in_rest'       => false,
				'rewrite'            => false,
				'query_var'          => false,
			)
		);
	}
	add_action( 'init', 'tcc_sermons_register_source', 30 );

	add_filter(
		'wpseo_sitemap_exclude_taxonomy',
		function ( $excluded, $taxonomy ) {
			return tcc_sermons_series_source() === $taxonomy ? true : $excluded;
		},
		10,
		2
	);

	/**
	 * Answers Divi's request for the "Sermon series" list with the real series categories.
	 * On a series page the series being shown is left out, so "More series" never repeats it.
	 */
	function tcc_sermons_series_terms( $terms, $query ) {
		try {
			if ( ! ( $query instanceof WP_Term_Query ) ) {
				return $terms;
			}
			$vars = $query->query_vars;
			$tax  = isset( $vars['taxonomy'] ) ? array_values( (array) $vars['taxonomy'] ) : array();
			if ( array( tcc_sermons_series_source() ) !== $tax ) {
				return $terms;
			}
			// A question about one sermon's terms is not a request for the list.
			if ( ! empty( $vars['object_ids'] ) ) {
				return 'count' === ( isset( $vars['fields'] ) ? $vars['fields'] : '' ) ? 0 : array();
			}
			$index = tcc_sermons_index();
			$ids   = array_keys( $index['series'] );
			$skip  = tcc_sermons_current_series();
			if ( $skip ) {
				$ids = array_values( array_diff( $ids, array( $skip ) ) );
			}
			if ( ! empty( $vars['include'] ) ) {
				$ids = array_values( array_intersect( $ids, array_map( 'intval', (array) $vars['include'] ) ) );
			}
			if ( ! empty( $vars['exclude'] ) ) {
				$ids = array_values( array_diff( $ids, array_map( 'intval', (array) $vars['exclude'] ) ) );
			}
			$fields = isset( $vars['fields'] ) ? $vars['fields'] : 'all';
			if ( 'count' === $fields ) {
				return count( $ids );
			}
			$offset = isset( $vars['offset'] ) ? max( 0, (int) $vars['offset'] ) : 0;
			$number = isset( $vars['number'] ) ? (int) $vars['number'] : 0;
			if ( $offset || $number > 0 ) {
				$ids = array_slice( $ids, $offset, $number > 0 ? $number : null );
			}
			if ( 'ids' === $fields ) {
				return $ids;
			}
			$out = array();
			foreach ( $ids as $id ) {
				$term = get_term( $id, 'category' );
				if ( ! ( $term instanceof WP_Term ) ) {
					continue;
				}
				if ( 'names' === $fields ) {
					$out[] = $term->name;
				} elseif ( 'id=>name' === $fields ) {
					$out[ $id ] = $term->name;
				} elseif ( 'id=>slug' === $fields ) {
					$out[ $id ] = $term->slug;
				} elseif ( 'slugs' === $fields ) {
					$out[] = $term->slug;
				} else {
					$out[] = $term;
				}
			}
			return $out;
		} catch ( \Throwable $e ) {
			return $terms;
		}
	}
	add_filter( 'terms_pre_query', 'tcc_sermons_series_terms', 10, 2 );

	/**
	 * What Divi can read on a series category:
	 *   "Category Image"     the series graphic (its own, or the stand-in). This is what the cards use.
	 *   and two made-up fields for "Loop Term Custom Field":
	 *   tcc_series_summary  "27 sermons - 2025 to 2026"
	 *   tcc_series_image    the address of the series graphic (not used by the cards any more; kept for other layouts)
	 */
	function tcc_sermons_term_fields( $value, $term_id, $meta_key ) {
		if ( 'tcc_series_image' !== $meta_key && 'tcc_series_summary' !== $meta_key && 'thumbnail_id' !== $meta_key ) {
			return $value;
		}
		if ( ! empty( $GLOBALS['tcc_sermons_building'] ) ) {
			return $value;
		}
		$index = tcc_sermons_index();
		$row   = isset( $index['series'][ (int) $term_id ] ) ? $index['series'][ (int) $term_id ] : null;
		if ( 'thumbnail_id' === $meta_key ) {
			// Divi's "Category Image" reads this. Only series categories are given one.
			return ( $row && $row['img_id'] ) ? array( (int) $row['img_id'] ) : $value;
		}
		if ( ! $row ) {
			return array( '' );
		}
		return array( 'tcc_series_image' === $meta_key ? $row['img'] : tcc_sermons_series_summary( $row, false ) );
	}
	add_filter( 'get_term_metadata', 'tcc_sermons_term_fields', 10, 3 );

	/**
	 * The series cards use Divi's own "Category Image" for their picture, because that is the one
	 * picture setting the Divi editor can preview card by card. Divi always uses the full-size
	 * file, though (a series graphic can be several hundred kB, or more if a large PNG is uploaded),
	 * and a card is never wider than about 430 pixels. So on the Sermons page and category pages,
	 * when the address of a series graphic's full-size file is asked for, the 768-pixel-wide copy
	 * is given instead. Nothing else on those pages uses the full-size file of a series graphic:
	 * the large picture at the top of a series page and the sermon cards ask for a named size, and
	 * those requests are left alone (see tcc_sermons_sized_request below).
	 */
	function tcc_sermons_smaller_series_image( $url, $attachment_id ) {
		static $busy = false, $ids = null;
		$id = (int) $attachment_id;
		// WordPress is working out a named size for this picture: it needs the real full-size address.
		if ( ! empty( $GLOBALS['tcc_sermons_sized'][ $id ] ) ) {
			unset( $GLOBALS['tcc_sermons_sized'][ $id ] );
			return $url;
		}
		if ( $busy || ! empty( $GLOBALS['tcc_sermons_building'] ) || ! tcc_sermons_is_list_page() ) {
			return $url;
		}
		if ( null === $ids ) {
			$ids   = array();
			$index = tcc_sermons_index();
			foreach ( $index['series'] as $row ) {
				if ( ! empty( $row['img_id'] ) ) {
					$ids[ (int) $row['img_id'] ] = true;
				}
			}
		}
		if ( empty( $ids[ $id ] ) ) {
			return $url;
		}
		$busy  = true;
		$small = wp_get_attachment_image_url( $id, 'medium_large' );
		$busy  = false;
		return $small ? $small : $url;
	}
	add_filter( 'wp_get_attachment_url', 'tcc_sermons_smaller_series_image', 10, 2 );

	/**
	 * Notes that WordPress is about to work out a named size (thumbnail, large and so on) of a picture.
	 * Its very next step is to ask for the picture's full-size address, which must not be swapped.
	 */
	function tcc_sermons_sized_request( $out, $attachment_id ) {
		if ( false === $out ) {
			$GLOBALS['tcc_sermons_sized'][ (int) $attachment_id ] = true;
		}
		return $out;
	}
	add_filter( 'image_downsize', 'tcc_sermons_sized_request', 9999, 2 );

	/** "27 sermons - 2025 to 2026", or with full dates when $long is true. */
	function tcc_sermons_series_summary( $row, $long ) {
		$count = (int) $row['count'];
		$text  = $count . ( 1 === $count ? ' sermon' : ' sermons' );
		if ( $long ) {
			$from = wp_date( 'F j, Y', $row['first'] );
			$to   = wp_date( 'F j, Y', $row['last'] );
		} else {
			$from = wp_date( 'Y', $row['first'] );
			$to   = wp_date( 'Y', $row['last'] );
		}
		// A real middle dot, not "&middot;": Divi prints custom fields as plain text.
		return $text . " \xC2\xB7 " . ( $from === $to ? $from : $from . ' to ' . $to );
	}

	/* ------------------------------------------------------------------------------------------
	 * A sermon with no graphic borrows its series graphic (Sermons page, category pages and the Divi editor's preview of them).
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The stand-in picture for a sermon that has no graphic and is in no series with one.
	 * It is the default event graphic chosen under Planning Center > Settings > Graphics (the church
	 * logo on soft grey). To use another picture, choose it there.
	 */
	function tcc_sermons_default_graphic() {
		static $id = null;
		if ( null === $id ) {
			$id = tcc_site_default_graphic(); // In the plugin's main file.
		}
		return $id;
	}

	/** The picture to show for a sermon that has none of its own: its series graphic, else the stand-in. 0 for none. */
	function tcc_sermons_stand_in_graphic( $post_id ) {
		$index     = tcc_sermons_index();
		$series_id = isset( $index['posts'][ (int) $post_id ] ) ? (int) $index['posts'][ (int) $post_id ] : 0;
		if ( $series_id && ! empty( $index['series'][ $series_id ]['img_id'] ) ) {
			return (int) $index['series'][ $series_id ]['img_id'];
		}
		return tcc_sermons_default_graphic();
	}

	function tcc_sermons_borrowed_graphic( $value, $post_id, $meta_key ) {
		if ( '_thumbnail_id' !== $meta_key || ! empty( $GLOBALS['tcc_sermons_building'] ) ) {
			return $value;
		}
		// On the Sermons page and category pages, and in the Divi editor's preview of those lists.
		if ( ! tcc_sermons_is_list_page() && ! tcc_sermons_is_divi_preview() ) {
			return $value;
		}
		static $busy = false;
		if ( $busy || 'post' !== get_post_type( $post_id ) ) {
			return $value;
		}
		$busy = true;
		$own  = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		$busy = false;
		if ( $own ) {
			return $value;
		}
		$stand_in = tcc_sermons_stand_in_graphic( $post_id );
		return $stand_in ? array( $stand_in ) : $value;
	}
	add_filter( 'get_post_metadata', 'tcc_sermons_borrowed_graphic', 10, 3 );

	/* ------------------------------------------------------------------------------------------
	 * The list Divi loops over on a series page: that series' sermons, oldest first.
	 * ---------------------------------------------------------------------------------------- */

	function tcc_sermons_parts_source() {
		return 'tcc_series_parts';
	}

	// An automatic list for Divi loops (tcc_site_loop_source() is in the plugin's main file).
	add_action(
		'init',
		function () {
			tcc_site_loop_source( tcc_sermons_parts_source(), 'Sermons in this series - oldest first (automatic)', 'tcc_sermons_parts_answer' );
		},
		30
	);

	/** The sermons of one series, oldest first. */
	function tcc_sermons_series_post_ids( $series_id ) {
		$index = tcc_sermons_index();
		$ids   = array();
		foreach ( $index['posts'] as $post_id => $term_id ) {
			if ( (int) $term_id === (int) $series_id ) {
				$ids[] = (int) $post_id;
			}
		}
		return $ids;
	}

	/**
	 * Answers Divi's request for "Sermons in this series" with the sermons of the series being shown.
	 * Anywhere else (the Divi editor, for one) it answers with the newest series, as an example.
	 */
	function tcc_sermons_parts_answer( $name, $query ) {
		$series_id = tcc_sermons_current_series();
		if ( ! $series_id ) {
			$index     = tcc_sermons_index();
			$series_id = (int) key( $index['series'] );
		}
		$all   = $series_id ? tcc_sermons_series_post_ids( $series_id ) : array();
		$count = (int) $query->get( 'posts_per_page' );
		if ( $count < 1 ) {
			$count = 200;
		}
		$offset = max( 0, (int) $query->get( 'offset' ) );
		return array(
			'ids'   => array_slice( $all, $offset, $count ),
			'found' => count( $all ),
			'pages' => (int) ceil( count( $all ) / $count ),
		);
	}

	/* ------------------------------------------------------------------------------------------
	 * Every series page uses the "Sermon series page" layout, without anyone assigning it.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The Theme Builder body layout that holds [tcc_series_facts], or 0 when there is none.
	 * Found by looking, not by name or number, so renaming the template does not break anything.
	 */
	function tcc_sermons_series_layout_id() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		$found = tcc_site_body_layouts( array( 'series' => 'tcc_series_facts' ) );
		return (int) $found['series'];
	}

	/** Shows the series layout on the page of any category filed under "Series". */
	function tcc_sermons_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) || ! tcc_sermons_current_series() ) {
				return $layouts;
			}
			return tcc_site_use_body_layout( $layouts, tcc_sermons_series_layout_id() );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_sermons_swap_layout', 20 );
}

/* ----------------------------------------------------------------------------------------------
 * The facts about every sermon, for the filter bar.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermons_cards' ) ) {

	/** A sermon with no title is shown as "Sermon from August 16, 2026" instead of a blank. */
	function tcc_sermons_title_fallback( $title, $post_id = 0 ) {
		if ( '' !== trim( (string) $title ) || is_admin() || ! $post_id || 'post' !== get_post_type( $post_id ) ) {
			return $title;
		}
		$date = get_the_date( 'F j, Y', $post_id );
		return $date ? 'Sermon from ' . $date : 'Sermon';
	}
	add_filter( 'the_title', 'tcc_sermons_title_fallback', 10, 2 );

	/**
	 * The people named in a Speaker Name field, as key => name. Two or more people typed on one line
	 * ("Tyler Lynde / Amy Lynde", "A | B", "A, B and C") become separate speakers, so the Speaker
	 * menu lists each person once instead of listing the pair as one more "speaker".
	 */
	function tcc_sermons_speaker_names( $speaker ) {
		$out   = array();
		$parts = preg_split( '#\s*(?:/|\||,|&|\band\b)\s*#i', (string) $speaker );
		foreach ( (array) $parts as $part ) {
			$name = trim( (string) $part );
			$key  = sanitize_title( $name );
			if ( '' !== $name && '' !== $key ) {
				$out[ (string) $key ] = $name;
			}
		}
		return $out;
	}

	/**
	 * The people who spoke, as key => name (key = sanitize_title of the name, as the Speaker filter and
	 * links use). Ticked speakers are taken as they are, so a name like "Martin Luther King, Jr." is
	 * never cut into pieces; a typed line is split into people.
	 */
	function tcc_sermons_speaker_people( $post_id ) {
		$list = tcc_sermons_speaker_list( $post_id );
		if ( $list ) {
			$out = array();
			foreach ( $list as $name ) {
				$key = sanitize_title( $name );
				if ( '' !== $key ) {
					$out[ (string) $key ] = $name;
				}
			}
			return $out;
		}
		return tcc_sermons_speaker_names( tcc_sermons_speaker( $post_id ) );
	}

	/**
	 * One short row per published sermon, newest first, remembered with the other facts:
	 *   id, t title, u address, d date as shown, sp speaker line, k speaker keys, kn speaker names, s series key, sn series name,
	 *   b book keys, tp topic keys, i picture address, x the words the search box looks through.
	 * Divi draws only the newest cards itself. The filter bar's script copies that card for every
	 * other sermon from these rows, so the page stays quick to build however many sermons there are.
	 */
	function tcc_sermons_cards() {
		$key    = 'tcc_sermons_cards2_' . tcc_site_gen( 'sermons' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$index = tcc_sermons_index();
		$ids   = array_reverse( array_keys( $index['posts'] ) );
		$rows  = array();
		$GLOBALS['tcc_sermons_building'] = true;
		try {
			_prime_post_caches( $ids, true, true );
			$thumbs = array();
			foreach ( $ids as $id ) {
				$thumb = (int) get_post_meta( $id, '_thumbnail_id', true );
				if ( ! $thumb ) {
					$thumb = tcc_sermons_stand_in_graphic( $id );
				}
				$thumbs[ $id ] = $thumb;
			}
			$need = array_values( array_unique( array_filter( $thumbs ) ) );
			if ( $need ) {
				_prime_post_caches( $need, false, true );
			}
			foreach ( $ids as $id ) {
				$speaker = tcc_sermons_speaker( $id );
				$who     = tcc_sermons_speaker_people( $id );
				$facts   = tcc_sermons_facts( $id );
				$title   = html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES, 'UTF-8' );
				$words   = array( $title, $speaker, get_post_meta( $id, 'sermon_description_short', true ) );
				foreach ( $facts as $group ) {
					foreach ( $group as $name ) {
						$words[] = $name;
					}
				}
				$text  = strtolower( remove_accents( wp_strip_all_tags( html_entity_decode( implode( ' ', array_filter( array_map( 'strval', $words ) ) ), ENT_QUOTES, 'UTF-8' ) ) ) );
				$text  = trim( preg_replace( '/\s+/', ' ', $text ) );
				$image = '';
				if ( $thumbs[ $id ] ) {
					$image = (string) wp_get_attachment_image_url( $thumbs[ $id ], 'medium_large' );
					if ( '' === $image ) {
						$image = (string) wp_get_attachment_url( $thumbs[ $id ] );
					}
				}
				$rows[] = array(
					'id' => (int) $id,
					't'  => $title,
					'u'  => (string) get_permalink( $id ),
					'd'  => (string) get_the_date( 'M j, Y', $id ),
					'sp' => $speaker,
					'k'  => array_map( 'strval', array_keys( $who ) ),
					'kn' => array_values( $who ),
					's'  => (string) key( $facts['series'] ),
					'sn' => (string) reset( $facts['series'] ),
					'b'  => array_keys( $facts['book'] ),
					'tp' => array_keys( $facts['topic'] ),
					'i'  => $image,
					'x'  => $text,
				);
			}
		} catch ( \Throwable $e ) {
			unset( $GLOBALS['tcc_sermons_building'] );
			return array();
		}
		unset( $GLOBALS['tcc_sermons_building'] );
		set_transient( $key, $rows, 12 * HOUR_IN_SECONDS );
		return $rows;
	}
}

/* ----------------------------------------------------------------------------------------------
 * Short codes for the cards.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_meta_shortcode' ) ) {

	/** "Speaker name - Nov 1, 2026", plus a hidden marker that tells the filter bar which sermon the card is. */
	function tcc_sermon_meta_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || 'post' !== get_post_type( $id ) ) {
				return '';
			}
			$speaker = tcc_sermons_speaker( $id );
			$date    = get_the_date( 'M j, Y', $id );
			$line    = esc_html( $speaker ) . ( '' !== $speaker && $date ? ' &middot; ' : '' ) . esc_html( (string) $date );
			return $line . '<span class="tcc-sermon-data" hidden data-id="' . (int) $id . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_meta', 'tcc_sermon_meta_shortcode' );

	/** The name of the sermon's series, or nothing when it is in no series. */
	function tcc_sermon_series_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id ) {
				return '';
			}
			$facts = tcc_sermons_facts( $id );
			return esc_html( (string) reset( $facts['series'] ) );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_series', 'tcc_sermon_series_shortcode' );

	/** How many sermons (or series) there are. */
	function tcc_sermon_count_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'what' => 'sermons' ), $atts, 'tcc_sermon_count' );
		try {
			$index = tcc_sermons_index();
			if ( 'series' === $atts['what'] ) {
				return (string) count( $index['series'] );
			}
			$series_id = tcc_sermons_current_series();
			return (string) ( $series_id ? (int) $index['series'][ $series_id ]['count'] : (int) $index['total'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_count', 'tcc_sermon_count_shortcode' );

	/** The "See all 19 series" button. The script that makes it work is printed with the page styles. */
	function tcc_series_toggle_shortcode() {
		try {
			$index = tcc_sermons_index();
			$count = count( $index['series'] );
			if ( $count <= 4 ) {
				return '';
			}
			return '<button type="button" class="tcc-series-toggle" aria-expanded="false" data-more="See all ' . (int) $count . ' series" data-less="Show fewer series">See all ' . (int) $count . ' series</button>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_toggle', 'tcc_series_toggle_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * Short codes for the top of a series page.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_series_graphic_shortcode' ) ) {

	function tcc_series_row() {
		$series_id = tcc_sermons_current_series();
		$index     = tcc_sermons_index();
		return ( $series_id && isset( $index['series'][ $series_id ] ) ) ? $index['series'][ $series_id ] : null;
	}

	function tcc_series_graphic_shortcode() {
		try {
			$row = tcc_series_row();
			if ( ! $row || ! $row['img_id'] ) {
				return '';
			}
			return wp_get_attachment_image(
				$row['img_id'],
				'large',
				false,
				array(
					'class'   => 'tcc-series-graphic',
					'alt'     => $row['name'] . ' sermon series',
					'loading' => 'eager',
					'sizes'   => '(max-width: 980px) 90vw, 600px',
				)
			);
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_graphic', 'tcc_series_graphic_shortcode' );

	function tcc_series_facts_shortcode() {
		try {
			$row = tcc_series_row();
			return $row ? esc_html( tcc_sermons_series_summary( $row, true ) ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_facts', 'tcc_series_facts_shortcode' );

	function tcc_series_start_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'Start with part 1' ), $atts, 'tcc_series_start' );
		try {
			$row = tcc_series_row();
			if ( ! $row || ! $row['first_post'] ) {
				return '';
			}
			return '<a class="et_pb_button et_pb_bg_layout_light tcc-series-start" href="' . esc_url( get_permalink( $row['first_post'] ) ) . '">' . esc_html( $atts['label'] ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_start', 'tcc_series_start_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * The search and filter bar.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermon_filter_shortcode' ) ) {

	/** The choices for the Speaker, Book and Topic menus: only ones that at least one sermon carries. */
	function tcc_sermon_filter_choices() {
		$index   = tcc_sermons_index();
		$choices = array(
			'speaker' => array(),
			'topic'   => array(),
			'ot'      => array(),
			'nt'      => array(),
			'book'    => array(),
		);
		foreach ( $index['cats'] as $id => $cat ) {
			if ( empty( $index['used'][ $id ] ) || 'series' === $cat['group'] ) {
				continue;
			}
			if ( 'book' === $cat['group'] ) {
				$choices[ $cat['testament'] ? $cat['testament'] : 'book' ][ $cat['slug'] ] = $cat['name'];
			} else {
				$choices[ $cat['group'] ][ $cat['slug'] ] = $cat['name'];
			}
		}
		// Speakers named only in the Speaker Name field or as the author are found from the cards by the script.
		natcasesort( $choices['speaker'] );
		natcasesort( $choices['topic'] );
		$order = tcc_sermons_bible_order();
		foreach ( array( 'ot', 'nt', 'book' ) as $part ) {
			uasort(
				$choices[ $part ],
				function ( $a, $b ) use ( $order ) {
					$x = isset( $order[ strtolower( $a ) ] ) ? $order[ strtolower( $a ) ] : 999;
					$y = isset( $order[ strtolower( $b ) ] ) ? $order[ strtolower( $b ) ] : 999;
					return $x === $y ? strcasecmp( $a, $b ) : $x <=> $y;
				}
			);
		}
		return $choices;
	}

	function tcc_sermon_filter_options( $list ) {
		$html = '';
		foreach ( $list as $slug => $name ) {
			$html .= '<option value="' . esc_attr( $slug ) . '">' . esc_html( $name ) . '</option>';
		}
		return $html;
	}

	/**
	 * For a visitor whose browser has JavaScript switched off: a note, and a plain list of every sermon
	 * that opens with one press. Browsers with JavaScript on never show it.
	 */
	function tcc_sermons_plain_list() {
		$rows = tcc_sermons_cards();
		$html = '<div class="tcc-sf-nojs"><p>The cards below are the newest sermons. Searching and filtering need JavaScript, which is switched off in this browser. Every sermon is in the list here, newest first, and each series above has its own page.</p>';
		if ( $rows ) {
			$html .= '<details><summary>See all ' . count( $rows ) . ' sermons as a plain list</summary><ul>';
			foreach ( $rows as $row ) {
				$line  = $row['sp'] . ( '' !== $row['sp'] && '' !== $row['d'] ? " \xC2\xB7 " : '' ) . $row['d'];
				$html .= '<li><a href="' . esc_url( $row['u'] ) . '">' . esc_html( $row['t'] ) . '</a> <span>' . esc_html( $line ) . '</span></li>';
			}
			$html .= '</ul></details>';
		}
		return $html . '</div>';
	}

	function tcc_sermon_filter_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'target' => 'tcc-sermons',
				'first'  => 12,
			),
			$atts,
			'tcc_sermon_filter'
		);
		try {
			$index   = tcc_sermons_index();
			$choices = tcc_sermon_filter_choices();
			$series  = array();
			$notes   = array();
			foreach ( $index['series'] as $row ) {
				$series[ $row['slug'] ] = $row['name'];
				$notes[ $row['slug'] ]  = array(
					'n' => $row['name'],
					'u' => $row['url'],
					'i' => $row['img'],
					'd' => $row['desc'],
				);
			}
			$books = '';
			if ( $choices['ot'] ) {
				$books .= '<optgroup label="Old Testament">' . tcc_sermon_filter_options( $choices['ot'] ) . '</optgroup>';
			}
			if ( $choices['nt'] ) {
				$books .= '<optgroup label="New Testament">' . tcc_sermon_filter_options( $choices['nt'] ) . '</optgroup>';
			}
			$books .= tcc_sermon_filter_options( $choices['book'] );

			$target = sanitize_html_class( $atts['target'] );
			$first  = max( 3, (int) $atts['first'] );
			$uid    = 'tcc-sf';
			$json   = JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;

			$html  = tcc_sermons_css_once();
			$html .= '<noscript><style>.tcc-sf{display:none}</style>' . tcc_sermons_plain_list() . '</noscript>';
			$html .= '<form class="tcc-sf" id="' . $uid . '" role="search" aria-label="Search and filter sermons" data-target="' . esc_attr( $target ) . '" data-first="' . (int) $first . '" onsubmit="return false">';
			$html .= '<span class="tcc-sf-label" aria-hidden="true">Find a sermon</span>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-series">Series</label>';
			$html .= '<select id="' . $uid . '-series" data-key="series" data-name="Series"><option value="">All series</option>' . tcc_sermon_filter_options( $series ) . '</select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-speaker">Speaker</label>';
			$html .= '<select id="' . $uid . '-speaker" data-key="speaker" data-name="Speaker"><option value="">All speakers</option></select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-book">Book of the Bible</label>';
			$html .= '<select id="' . $uid . '-book" data-key="book" data-name="Book"><option value="">All books</option>' . $books . '</select>';
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-topic">Topic</label>';
			$html .= '<select id="' . $uid . '-topic" data-key="topic" data-name="Topic"><option value="">All topics</option>' . tcc_sermon_filter_options( $choices['topic'] ) . '</select>';
			// The search box comes last and takes the room that is left, as on the Events and Community Groups bars.
			$html .= '<label class="tcc-sf-sr" for="' . $uid . '-q">Search sermons</label>';
			$html .= '<input type="search" id="' . $uid . '-q" data-key="q" placeholder="Search sermons" title="Search by title, speaker, scripture or topic" autocomplete="off" enterkeyhint="search">';
			$html .= '<div class="tcc-sf-status" hidden></div>';
			$html .= '<span class="tcc-sf-sr" role="status" aria-live="polite"></span>';
			$html .= '</form>';
			$html .= '<a class="tcc-sf-note" hidden></a>';
			$html .= '<script type="application/json" id="' . $uid . '-series-data">' . wp_json_encode( $notes, $json ) . '</script>';
			$html .= '<script type="application/json" id="' . $uid . '-cards">' . wp_json_encode( tcc_sermons_cards(), $json ) . '</script>';
			add_action( 'wp_footer', 'tcc_sermon_filter_script', 50 );
			return $html;
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_filter', 'tcc_sermon_filter_shortcode' );

	/**
	 * The filter bar's script.
	 *
	 * Divi draws the newest cards. For every other sermon this script makes a copy of the first card
	 * and fills in that sermon's picture, speaker, date, title and series, so a change to the card in
	 * Divi is picked up by every card. Then it only shows and hides cards; nothing is asked of the server.
	 *
	 * The script itself is in features/sermon-filters.js. It reads the sermons from the two data
	 * blocks the filter bar prints (tcc-sf-cards and tcc-sf-series-data), so it needs nothing from PHP.
	 * The "\n" after it is the line break the file's last line had.
	 */
	function tcc_sermon_filter_script() {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;
		?>
<script id="tcc-sermon-filter-js">
<?php echo tcc_site_asset( 'features/sermon-filters.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
		<?php
	}
}

/* ----------------------------------------------------------------------------------------------
 * Looks, and the "See all series" button.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermons_css' ) ) {

	/**
	 * The styles for the filter bar, the cards' hover, the series cards and the series page rows.
	 * Colours, corner size and fonts match the rest of the site: Trinity teal #00A4CF. Buttons are not
	 * styled here at all: they carry Divi's own button class, so they look and behave like every
	 * other button on the website and follow any change made to the site's button settings.
	 *
	 * The rules themselves are in features/sermon-filters.css. Like the rest of the site's styles they
	 * are printed inside the page (see tcc_sermons_css_once below), not loaded as a separate file.
	 */
	function tcc_sermons_css() {
		return tcc_site_asset( 'features/sermon-filters.css' ); // tcc_site_asset() is in the plugin's main file.
	}

	/** Returns the style block the first time it is asked for on a page, and nothing after that. */
	function tcc_sermons_css_once() {
		static $printed = false;
		if ( $printed ) {
			return '';
		}
		$printed = true;
		return '<style id="tcc-sermons-css">' . tcc_sermons_css() . '</style>';
	}

	/**
	 * On the Sermons page and category pages the styles go in the head, so nothing flashes unstyled.
	 * The Divi editor gets them too: it previews the Sermons layout away from the Sermons page, and
	 * without them the filter bar showed there as plain words and bare menus.
	 */
	add_action(
		'wp_head',
		function () {
			if ( tcc_sermons_is_list_page() || ( function_exists( 'tcc_site_in_divi_editor' ) && tcc_site_in_divi_editor() ) ) {
				echo tcc_sermons_css_once(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		},
		30
	);

	/** Makes the "See all series" button open and close the rest of the series cards. */
	add_action(
		'wp_footer',
		function () {
			if ( ! tcc_sermons_is_list_page() ) {
				return;
			}
			?>
<script id="tcc-series-toggle-js">
(function () {
	var btn = document.querySelector('.tcc-series-toggle');
	var list = document.querySelector('.tcc-series-list');
	if (!btn || !list) { if (btn) { btn.hidden = true; } return; }
	btn.addEventListener('click', function () {
		var open = list.classList.toggle('is-open');
		btn.setAttribute('aria-expanded', open ? 'true' : 'false');
		btn.textContent = btn.getAttribute(open ? 'data-less' : 'data-more');
	});
})();
</script>
			<?php
		},
		51
	);
}
