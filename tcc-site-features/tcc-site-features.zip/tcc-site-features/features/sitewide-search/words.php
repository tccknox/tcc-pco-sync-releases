<?php
/**
 * TCC Website, Sitewide search page: other words for a search, and the Search tab.
 * Part: Words that mean the same, spelling help, and the Search tab
 *
 * Loaded by features/sitewide-search.php (read the comment at the top of that file first). In this part:
 *   - the starting list of words that mean the same (tcc_search_default_synonyms), the list as
 *     volunteers saved it under TCC Website > Search (the option tcc_search_synonyms), and the other
 *     wordings of a search made from it (tcc_search_variants: "kids ministry" also tries
 *     "children ministry"; at most four);
 *   - tcc_search_collect_wide(), which runs a search and its other wordings and puts the results together;
 *   - the list of searches that found nothing (tcc_search_log_miss, the option tcc_search_misses);
 *   - the spelling help: every word used in a title on the website (tcc_search_vocabulary) and the
 *     closest of them to a misspelt word (tcc_search_fix_spelling);
 *   - the Search tab on the TCC Website screen and its buttons (tcc_search_admin_tab, tcc_search_admin_save),
 *     which admin.php draws.
 *
 * What it leans on: tcc_search_collect() in finding.php, tcc_search_lower() and tcc_search_type_map()
 * in page.php, tcc_search_extra_words() in features/sitewide-search.php, tcc_search_gen() and
 * tcc_search_client_address() in remembering.php, and the plugin's main file and admin.php for the
 * screen (tcc_site_new_gen, tcc_site_button). When the list of words that mean the same changes, the
 * remembered searches start afresh (the hooks for that are in remembering.php).
 *
 * Part of the TCC Website plugin (in its own file since 0.14.4; before that it was in sitewide-search.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_default_synonyms' ) ) {

	/* ------------------------------------------------------------------
	 * Words that mean the same, and searches that found nothing
	 * ------------------------------------------------------------------ */

	/**
	 * The starting list of words that mean the same thing on this website: one group per line,
	 * words separated by commas. Volunteers change the list under TCC Website > Search; this is
	 * what they get back when they press "Put the starting list back".
	 */
	function tcc_search_default_synonyms() {
		return implode(
			"\n",
			array(
				'kids, children, child, nursery',
				'youth, students, teens, teenagers',
				'giving, give, tithe, tithing, donate, offering',
				'small group, small groups, community group, community groups, life group, life groups',
				'volunteer, volunteering, serve, serving',
				'sermon, sermons, message, messages',
				'pastor, pastors, elders, leadership, staff',
				'membership, member, partner, partnership',
				'women, ladies',
				'baptism, baptized, baptize',
				'livestream, live stream, watch online',
				'jobs, job, employment, careers',
				'directions, address, location',
			)
		);
	}

	/** The list as volunteers last saved it, or the starting list. Text, one group per line. */
	function tcc_search_synonym_text() {
		$saved = get_option( 'tcc_search_synonyms', null );
		return ( is_string( $saved ) && '' !== trim( $saved ) ) ? $saved : tcc_search_default_synonyms();
	}

	/** The list as groups of lower-case words: array( array( 'kids', 'children' ), ... ). */
	function tcc_search_synonym_groups() {
		static $groups = null;
		if ( null !== $groups ) {
			return $groups;
		}
		$groups = array();
		foreach ( preg_split( '/[\r\n]+/', tcc_search_synonym_text() ) as $line ) {
			$entries = array();
			foreach ( explode( ',', $line ) as $entry ) {
				$entry = trim( preg_replace( '/\s+/', ' ', preg_replace( '/[^a-z0-9\' ]+/', ' ', tcc_search_lower( $entry ) ) ) );
				if ( strlen( $entry ) > 1 && ! in_array( $entry, $entries, true ) ) {
					$entries[] = $entry;
				}
			}
			if ( count( $entries ) > 1 ) {
				$groups[] = $entries;
			}
			if ( count( $groups ) >= 80 ) {
				break;
			}
		}
		return $groups;
	}

	/**
	 * Other ways of saying the same search: "kids ministry" gives "children ministry",
	 * "nursery ministry"... At most four, so a search never turns into dozens.
	 */
	function tcc_search_variants( $term ) {
		$term     = trim( preg_replace( '/\s+/', ' ', tcc_search_lower( $term ) ) );
		$variants = array();
		foreach ( tcc_search_synonym_groups() as $group ) {
			// Longest first, so "community groups" is tried before "community group".
			$by_length = $group;
			usort(
				$by_length,
				function ( $a, $b ) {
					return strlen( $b ) <=> strlen( $a );
				}
			);
			foreach ( $by_length as $entry ) {
				$pattern = '/(?<![a-z0-9])' . preg_quote( $entry, '/' ) . '(?![a-z0-9])/';
				if ( 1 !== preg_match( $pattern, $term ) ) {
					continue;
				}
				foreach ( $group as $other ) {
					if ( $other === $entry ) {
						continue;
					}
					$variant = trim( preg_replace( $pattern, $other, $term, 1 ) );
					if ( '' !== $variant && $variant !== $term && ! in_array( $variant, $variants, true ) ) {
						$variants[] = $variant;
					}
				}
				break; // one entry per group is enough
			}
		}
		return array_slice( $variants, 0, 4 );
	}

	/**
	 * tcc_search_collect(), plus the same search in other words.
	 * $also is filled with the other wordings that added something.
	 */
	function tcc_search_collect_wide( $term, $any, &$also, $with_variants = true ) {
		$items = array();
		foreach ( tcc_search_collect( $term, $any ) as $item ) {
			$items[ $item[0] ] = $item;
		}
		foreach ( ( $with_variants ? tcc_search_variants( $term ) : array() ) as $variant ) {
			$added = false;
			foreach ( tcc_search_collect( $variant, $any ) as $item ) {
				if ( ! isset( $items[ $item[0] ] ) ) {
					// Found by another word for it: a touch below the same match on the word typed.
					$item[2]           = max( 1, $item[2] - 6 );
					$items[ $item[0] ] = $item;
					$added             = true;
				} elseif ( $item[2] - 6 > $items[ $item[0] ][2] ) {
					$item[2]           = $item[2] - 6;
					$items[ $item[0] ] = $item;
				}
			}
			if ( $added && ! in_array( $variant, (array) $also, true ) ) {
				$also[] = $variant;
			}
		}
		return array_values( $items );
	}

	/**
	 * Remembers a search that found nothing, for TCC Website > Search, so the church can see what
	 * people look for and cannot find. Only the words are kept: no names, no addresses, nothing
	 * about who searched. Searches that do not come from a page of this website (mostly robots)
	 * and anything that looks like an email address, a link or a long number are not kept.
	 */
	function tcc_search_log_miss( $term ) {
		try {
			$term = trim( preg_replace( '/\s+/', ' ', tcc_search_lower( $term ) ) );
			$len  = strlen( $term );
			if ( $len < 3 || $len > 40 || false !== strpos( $term, '@' ) || false !== strpos( $term, 'http' ) || false !== strpos( $term, '://' ) || preg_match( '/\d{4,}|[<>{}\[\]=;]/', $term ) ) {
				return;
			}
			$from = isset( $_SERVER['HTTP_REFERER'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['HTTP_REFERER'] ), PHP_URL_HOST ) : '';
			if ( '' === $from || strtolower( $from ) !== strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ) {
				return;
			}
			$misses = get_option( 'tcc_search_misses', array() );
			$misses = is_array( $misses ) ? $misses : array();
			$count  = isset( $misses[ $term ][0] ) ? (int) $misses[ $term ][0] : 0;
			// A word goes on the list the second time it is searched (within a day), so one robot
			// or one stray search cannot fill the list with nonsense.
			if ( 0 === $count ) {
				$seen = get_option( 'tcc_search_misses_once', array() );
				$seen = is_array( $seen ) ? array_filter(
					$seen,
					function ( $when ) {
						return (int) $when > time() - DAY_IN_SECONDS;
					}
				) : array();
				if ( ! isset( $seen[ $term ] ) ) {
					$seen[ $term ] = time();
					update_option( 'tcc_search_misses_once', array_slice( $seen, -100, null, true ), false );
					return;
				}
				unset( $seen[ $term ] );
				update_option( 'tcc_search_misses_once', $seen, false );
				$count = 1; // The first time counts too.
			}
			$misses[ $term ] = array( $count + 1, time() );
			if ( count( $misses ) > 150 ) {
				// Full: drop the ones searched longest ago.
				uasort(
					$misses,
					function ( $a, $b ) {
						return $b[1] <=> $a[1];
					}
				);
				$misses = array_slice( $misses, 0, 150, true );
			}
			update_option( 'tcc_search_misses', $misses, false );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/** Every word the website uses in a title, with how often: the spelling help's dictionary. */
	function tcc_search_vocabulary() {
		$key    = 'tcc_search_vocab_' . tcc_search_gen();
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		$types  = array_merge( array_keys( tcc_search_type_map( true ) ), array( 'tribe_events' ) );
		$marks  = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$titles = (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_title FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($marks)", $types ) );
		foreach ( array( 'category', 'trinity-talk', 'tribe_events_cat' ) as $taxonomy ) {
			if ( taxonomy_exists( $taxonomy ) ) {
				$names = get_terms(
					array(
						'taxonomy'   => $taxonomy,
						'fields'     => 'names',
						'hide_empty' => true,
					)
				);
				if ( is_array( $names ) ) {
					$titles = array_merge( $titles, $names );
				}
			}
		}
		$vocab = array();
		foreach ( $titles as $title ) {
			foreach ( preg_split( '/[^a-z]+/', tcc_search_lower( $title ) ) as $word ) {
				if ( strlen( $word ) >= 4 ) {
					$vocab[ $word ] = isset( $vocab[ $word ] ) ? $vocab[ $word ] + 1 : 1;
				}
			}
		}
		foreach ( tcc_search_extra_words() as $word ) {
			$vocab[ $word ] = isset( $vocab[ $word ] ) ? $vocab[ $word ] + 5 : 5;
		}
		set_transient( $key, $vocab, 12 * HOUR_IN_SECONDS );
		return $vocab;
	}

	/**
	 * Swaps each misspelt word for the closest word the website knows.
	 * Returns the corrected search, or '' when there is nothing to correct.
	 */
	function tcc_search_fix_spelling( $term ) {
		$vocab   = tcc_search_vocabulary();
		$changed = false;
		$out     = array();
		foreach ( preg_split( '/\s+/', tcc_search_lower( $term ) ) as $word ) {
			$plain = preg_replace( '/[^a-z]/', '', $word );
			$len   = strlen( $plain );
			if ( $len < 4 || $len > 24 || isset( $vocab[ $plain ] ) ) {
				$out[] = $word;
				continue;
			}
			$allowed = ( $len <= 5 ) ? 1 : ( ( $len <= 8 ) ? 2 : 3 );
			$best    = '';
			$best_d  = 99;
			foreach ( $vocab as $known => $count ) {
				$known = (string) $known;
				if ( abs( strlen( $known ) - $len ) > $allowed ) {
					continue;
				}
				$distance = levenshtein( $plain, $known );
				if ( $distance > $allowed ) {
					continue;
				}
				// A different first letter is a less likely slip; a common word is a likelier target.
				$rank = $distance + ( ( $known[0] !== $plain[0] ) ? 0.6 : 0 ) - min( 0.4, $count / 100 );
				if ( $rank < $best_d ) {
					$best_d = $rank;
					$best   = $known;
				}
			}
			if ( '' !== $best ) {
				$out[]   = $best;
				$changed = true;
			} else {
				$out[] = $word;
			}
		}
		return $changed ? implode( ' ', $out ) : '';
	}

	/* ------------------------------------------------------------------
	 * The Search tab on the TCC Website screen (drawn from admin.php)
	 * ------------------------------------------------------------------ */

	/** Saves or resets the list of words that mean the same, or clears the "found nothing" list. */
	function tcc_search_admin_save( $op ) {
		if ( 'search_synonyms' === $op ) {
			$text = isset( $_POST['tcc_search_synonyms'] ) ? sanitize_textarea_field( wp_unslash( $_POST['tcc_search_synonyms'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked by tcc_site_handle_post.
			update_option( 'tcc_search_synonyms', substr( $text, 0, 6000 ), false );
			$done = 'saved';
		} elseif ( 'search_synonyms_reset' === $op ) {
			delete_option( 'tcc_search_synonyms' );
			$done = 'reset';
		} elseif ( 'search_misses_clear' === $op ) {
			delete_option( 'tcc_search_misses' );
			delete_option( 'tcc_search_misses_once' );
			return 'cleared';
		} else {
			return '';
		}
		// Remembered searches were made with the old list: start them afresh.
		tcc_site_new_gen( 'search' );
		return $done;
	}

	function tcc_search_admin_tab() {
		$done = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only chooses a message.
		$said = array(
			'saved'   => 'Saved. Searches use the new list straight away.',
			'reset'   => 'The starting list is back.',
			'cleared' => 'The list of searches that found nothing has been emptied.',
		);
		if ( isset( $said[ $done ] ) ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html( $said[ $done ] ) . '</p></div>';
		}

		// 1. Searches that found nothing.
		$misses = get_option( 'tcc_search_misses', array() );
		$misses = is_array( $misses ) ? $misses : array();
		uasort(
			$misses,
			function ( $a, $b ) {
				return ( $b[0] <=> $a[0] ) ? ( $b[0] <=> $a[0] ) : ( $b[1] <=> $a[1] );
			}
		);
		echo '<div class="tcc-card"><h2>Searches that found nothing</h2>';
		echo '<p class="tcc-muted">What visitors typed into the website search and got no results for. Use it to spot a page that is missing, or a word to add to the list below. Only the words are kept, nothing about who searched. A search is counted at most once every 10 minutes, a word only shows here once it has been searched twice within a day (so one robot or one stray search cannot fill the list), and the list holds the 150 most recent.</p>';
		if ( ! $misses ) {
			echo '<p><span class="tcc-pill tcc-pill--ok">Nothing yet</span> No search has come up empty since this list was last emptied.</p>';
		} else {
			// A plain list, most-searched first: it reads the same on a phone as on a computer.
			echo '<ul style="margin:12px 0;padding:0;list-style:none">';
			foreach ( array_slice( $misses, 0, 150, true ) as $term => $miss ) {
				$times = (int) $miss[0];
				echo '<li style="margin:0;padding:8px 0;border-top:1px solid #f0f0f1"><strong>' . esc_html( (string) $term ) . '</strong> <span class="tcc-muted">&nbsp;' . $times . ( 1 === $times ? ' time' : ' times' ) . ', last ' . esc_html( human_time_diff( (int) $miss[1] ) ) . ' ago</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a whole number.
			}
			echo '</ul><p>' . tcc_site_button( 'search_misses_clear', 'Empty this list', array(), 'button', 'Empty the list of searches that found nothing? This cannot be undone.' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped by tcc_site_button.
		}
		echo '</div>';

		// 1b. How visitors are told apart, so one busy visitor cannot use up search for everyone.
		$client = tcc_search_client_address();
		$alone  = 'proxy, no visitor address' !== $client['via'] && '' !== $client['address'];
		echo '<div class="tcc-card"><h2>How visitors are counted</h2>';
		echo '<p>' . ( $alone ? '<span class="tcc-pill tcc-pill--ok">Each visitor on their own</span> ' : '<span class="tcc-pill tcc-pill--warn">Needs a look</span> ' );
		echo 'To keep the website fast, one visitor can start at most 15 new searches a minute, and the whole website 90 a minute (signed-in editors are never held back). Visitors are told apart by their internet address. ';
		if ( $alone ) {
			echo 'This website sees yours as <code>' . esc_html( $client['address'] ) . '</code>' . ( 'proxy' === $client['via'] ? ', passed on by the host\'s proxy' : '' ) . '. If that is your own address (searching "what is my IP" shows it), every visitor is counted on their own.</p>';
		} else {
			echo 'This website only sees the host\'s own address (<code>' . esc_html( $client['address'] ) . '</code>), so every visitor may share one count and search may say it is busy too soon. Ask whoever looks after the website\'s code.</p>';
		}
		echo '</div>';

		// 2. Words that mean the same.
		$custom = is_string( get_option( 'tcc_search_synonyms', null ) ) && '' !== trim( (string) get_option( 'tcc_search_synonyms', '' ) );
		echo '<div class="tcc-card"><h2>Words that mean the same</h2>';
		echo '<p class="tcc-muted">When a visitor searches for one of these words, the website also searches for the others on the same line. One group per line, words separated by commas. Example: <code>kids, children, nursery</code> means a search for "kids" also finds pages that only say "children".</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="tcc_site_do"><input type="hidden" name="op" value="search_synonyms">';
		wp_nonce_field( 'tcc_site_do', '_tcc_site_nonce' );
		echo '<label class="screen-reader-text" for="tcc-search-synonyms">Words that mean the same, one group per line</label>';
		echo '<textarea id="tcc-search-synonyms" name="tcc_search_synonyms" rows="14" style="width:100%;max-width:760px;font-family:inherit;font-size:14px;line-height:1.6" spellcheck="false">' . esc_textarea( tcc_search_synonym_text() ) . '</textarea>';
		echo '<p><button type="submit" class="button button-primary">Save the list</button> <span class="tcc-muted">' . count( tcc_search_synonym_groups() ) . ' groups in use. ' . ( $custom ? 'This is your own list.' : 'This is the starting list.' ) . '</span></p></form>';
		if ( $custom ) {
			echo tcc_site_button( 'search_synonyms_reset', 'Put the starting list back', array(), 'button', 'Replace your list with the starting list? Your changes to it will be lost.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<p class="tcc-muted" style="margin-bottom:0">Tips: keep groups small and truly alike, or searches get noisy. A word can be two words ("small group"). Lines with only one word are ignored. Only the first four other words on a line are tried for any one search.</p></div>';

		// 3. What search reads.
		echo '<div class="tcc-card"><h2>What the search reads</h2><ul style="list-style:disc;margin-left:20px">';
		echo '<li><strong>Pages and Trinity Talk articles:</strong> the title and the words on the page.</li>';
		echo '<li><strong>Sermons:</strong> the title, both descriptions, the Speaker Name, and the categories (Bible book, topic, series, speaker).</li>';
		echo '<li><strong>Community groups:</strong> the title, description, organizer, meeting time, location and ages. A group with "Is This Group Active?" unticked is left out.</li>';
		echo '<li><strong>Events:</strong> only ones still to come: the title, description, category and venue.</li>';
		echo '</ul><p class="tcc-muted" style="margin-bottom:0">A word is matched where a word starts, so "men" finds "Men\'s Ministry" but not "moment". A page set to "do not show in search results" in Yoast is left out. Results are remembered for up to 6 hours (10 minutes when nothing was found) and start afresh as soon as something is saved.</p></div>';
	}
}
