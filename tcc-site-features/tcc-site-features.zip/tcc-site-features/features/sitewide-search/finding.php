<?php
/**
 * TCC Website, Sitewide search page: finding the matches and scoring them.
 * Part: Finding the matches and scoring them
 *
 * Loaded by features/sitewide-search.php (read the comment at the top of that file first). In this part:
 *   - the useful words of a search (tcc_search_words) and how good a match one item is
 *     (tcc_search_score: the title counts most, then the kind of thing it is);
 *   - the extra places searched besides a title and the page text (tcc_search_meta_keys), the kinds of
 *     label searched (tcc_search_taxonomies), and the accounts whose name is not searched
 *     (tcc_search_author_skip): add to these lists to change what search reads;
 *   - the database lookups, each made once per word per page view (tcc_search_remember,
 *     tcc_search_whole_word_ids, tcc_search_extra_ids, tcc_search_core_ids), and the words of the
 *     upcoming events (tcc_search_event_texts);
 *   - tcc_search_collect(), which puts them together: every match for one wording of a search.
 *
 * What it leans on: WordPress's own search and database, tcc_search_lower() and the other small helpers
 * in page.php, and the "Event feeds" feature for the list of upcoming events (tcc_upcoming_ids_for).
 * The other wordings of a search are tried in words.php and remembering.php, which call tcc_search_collect().
 * The SQL patterns strip each word to plain letters and numbers (tcc_search_word_pattern) and pass it
 * through $wpdb->prepare(); keep it that way.
 *
 * Part of the TCC Website plugin (in its own file since 0.14.4; before that it was in sitewide-search.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_words' ) ) {

	/* ------------------------------------------------------------------
	 * Finding and ranking
	 * ------------------------------------------------------------------ */

	/** The useful words of a search, lower case, without little joining words. */
	function tcc_search_words( $term ) {
		$skip  = array( 'the', 'and', 'for', 'with', 'what', 'when', 'where', 'how', 'are', 'is', 'to', 'of', 'in', 'at', 'on', 'a', 'an', 'do', 'does', 'can', 'i', 'my', 'we', 'you', 'your', 'our' );
		$words = array();
		foreach ( preg_split( '/[^a-z0-9\']+/', tcc_search_lower( $term ) ) as $word ) {
			$word = trim( $word, "'" );
			if ( strlen( $word ) > 1 && ! in_array( $word, $skip, true ) && ! in_array( $word, $words, true ) ) {
				$words[] = $word;
			}
		}
		return array_slice( $words, 0, 6 );
	}

	/**
	 * True when the text has a word that starts with $word: "men" is in "Men's Ministry"
	 * but not in "judgement".
	 */
	function tcc_search_has_word( $text, $word ) {
		return 1 === preg_match( '/(?<![a-z0-9])' . preg_quote( $word, '/' ) . '/', $text );
	}

	/**
	 * Words that ask for a whole kind of thing. Searching "groups" lists the community groups,
	 * "sermons" the latest sermons and "events" what is coming up, even though those words are
	 * not in their titles.
	 */
	function tcc_search_kind_words() {
		return array(
			'group'  => array( 'group', 'groups' ),
			'sermon' => array( 'sermon', 'sermons', 'message', 'messages', 'preaching' ),
			'event'  => array( 'event', 'events', 'calendar', 'happening' ),
		);
	}

	/**
	 * How good a match one item is. Higher is better.
	 * The title counts most; then the kind of thing it is (events coming up, groups and recent
	 * sermons are what people are usually after).
	 */
	function tcc_search_score( $title, $kind, $timestamp, $phrase, $words ) {
		$title = tcc_search_lower( $title );
		$score = 10;
		if ( '' !== $phrase && $title === $phrase ) {
			$score = 100;
		} elseif ( '' !== $phrase && tcc_search_has_word( $title, $phrase ) ) {
			$score = 70;
		} elseif ( $words ) {
			$hits = 0;
			foreach ( $words as $word ) {
				if ( tcc_search_has_word( $title, $word ) ) {
					$hits++;
				}
			}
			if ( $hits === count( $words ) ) {
				$score = 55;
			} elseif ( $hits > 0 ) {
				$score = 10 + (int) round( 25 * $hits / count( $words ) );
			}
		}
		$age_days = max( 0, ( time() - (int) $timestamp ) / DAY_IN_SECONDS );
		if ( 'event' === $kind ) {
			$score += 30;
		} elseif ( 'group' === $kind ) {
			$score += 22;
		} elseif ( 'page' === $kind ) {
			$score += 20;
		} elseif ( 'sermon' === $kind ) {
			$score += ( $age_days <= 183 ) ? 28 : ( ( $age_days <= 548 ) ? 18 : ( ( $age_days <= 1096 ) ? 8 : 0 ) );
		} elseif ( 'article' === $kind && $age_days <= 365 ) {
			$score += 5;
		}
		return $score;
	}

	/**
	 * The extra places searched besides a title and the page text. On this website most of what a
	 * sermon or a community group says about itself is in these fields, not in the page text.
	 * Add a field's name here to make it searchable.
	 */
	function tcc_search_meta_keys() {
		return array(
			'sermon_description_short',
			'sermon_description_long',
			'speaker_name',
			'group_description',
			'organizer_name',
			'date_and_meeting_time',
			'group_location',
			'ages',
			'_yoast_wpseo_metadesc',
		);
	}

	/**
	 * Accounts whose name is not searched, because they are not a person who wrote something:
	 * the church's own account, the sermon upload app, and the web support accounts.
	 * Write the account's name exactly as Users shows it ("Name" column). Add one here if a search
	 * for an everyday word starts bringing back everything that account saved.
	 */
	function tcc_search_author_skip() {
		return array( 'Trinity Community Church', 'Sermon-Publisher app', 'TCC Media', 'Divi Admin', 'USCNi Staff', 'BIC Web Support' );
	}

	/** The kinds of label searched: sermon categories (Bible book, topic, series, speaker), tags, Trinity Talk books. */
	function tcc_search_taxonomies() {
		return array_values( array_filter( array( 'category', 'post_tag', 'trinity-talk', 'project_category', 'project_tag' ), 'taxonomy_exists' ) );
	}

	/**
	 * A pattern the database uses to find a word only where a word STARTS: "men" is found in
	 * "Men's Ministry" and "mentor" but not in "moment" or "commandment".
	 * ("u003e" is how Divi stores the end of a tag, so a word straight after a tag still counts.)
	 */
	function tcc_search_word_pattern( $word ) {
		return '(^|[^[:alnum:]]|u003e)' . preg_replace( '/[^a-z0-9\']/', '', strtolower( (string) $word ) );
	}

	/**
	 * Remembers the answer of each database lookup the search makes, for this one page view only.
	 * (Added November 2026, to make a search lighter on the server. The answers are the same.)
	 *
	 * Why: one search is tried in several wordings ("kids ministry", then "children ministry",
	 * "nursery ministry" from the words that mean the same, then the closest spelling or any of the
	 * words). The wordings share words, and before this every wording looked the same word up in the
	 * database again. Now the second time a word comes up, its answer is taken from here.
	 *
	 * $kind names the lookup ('extra', 'words', 'core' or 'events'), $args are what it was asked, and
	 * $work does the lookup; it only runs the first time. Nothing is kept once the page has been sent,
	 * and tcc_search_start_afresh() (in remembering.php) forgets everything at once when content is saved.
	 * Called with no $work, it forgets everything (that is what tcc_search_forget_lookups() does).
	 */
	function tcc_search_remember( $kind, $args, $work = null ) {
		static $memo = array();
		if ( null === $work ) {
			$memo = array();
			return null;
		}
		$key = $kind . ':' . md5( serialize( $args ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- only to make a name for the answer.
		if ( ! array_key_exists( $key, $memo ) ) {
			if ( count( $memo ) >= 300 ) {
				$memo = array(); // Never more than a few dozen in a real search; this only guards against an odd caller.
			}
			$memo[ $key ] = $work();
		}
		return $memo[ $key ];
	}

	/** Forgets the lookups remembered for this page view (see tcc_search_remember). */
	function tcc_search_forget_lookups() {
		tcc_search_remember( '', null );
	}

	/**
	 * Of these ids (found by WordPress's own search, which matches letters anywhere), keeps the
	 * ones that really have the words as words, in the title, the page text, the excerpt or the
	 * author's name. If the database cannot do it, every id is kept.
	 * Asked the same thing twice in one page view, it answers from memory (tcc_search_remember).
	 */
	function tcc_search_whole_word_ids( $ids, $words, $any = false ) {
		$ids   = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		$words = array_slice( array_values( (array) $words ), 0, 6 );
		if ( ! $ids || ! $words ) {
			return $ids;
		}
		return tcc_search_remember(
			'words',
			array( $ids, $words, (bool) $any ),
			function () use ( $ids, $words, $any ) {
				global $wpdb;
				$parts = array();
				$args  = array();
				foreach ( $words as $word ) {
					$pattern = tcc_search_word_pattern( $word );
					$parts[] = '( p.post_title REGEXP %s OR p.post_content REGEXP %s OR p.post_excerpt REGEXP %s OR u.display_name REGEXP %s )';
					array_push( $args, $pattern, $pattern, $pattern, $pattern );
				}
				$id_list = implode( ',', $ids );
				$sql     = "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->users} u ON u.ID = p.post_author WHERE p.ID IN ($id_list) AND ( " . implode( $any ? ' OR ' : ' AND ', $parts ) . ' )';
				$before  = $wpdb->suppress_errors( true );
				$kept    = $wpdb->get_col( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- built from fixed text and whole numbers above.
				$failed  = '' !== (string) $wpdb->last_error;
				$wpdb->suppress_errors( $before );
				if ( $failed || ! is_array( $kept ) ) {
					return $ids;
				}
				$kept = array_flip( array_map( 'intval', $kept ) );
				return array_values(
					array_filter(
						$ids,
						function ( $id ) use ( $kept ) {
							return isset( $kept[ $id ] );
						}
					)
				);
			}
		);
	}

	/**
	 * Ids of items that have this word in one of the extra fields, in the name of the account that
	 * saved them, or in the name of one of their labels: array( 'meta' => ids, 'label' => ids ).
	 * Three small database lookups, made once per word per page view (tcc_search_remember).
	 */
	function tcc_search_extra_ids( $word ) {
		return tcc_search_remember(
			'extra',
			array( (string) $word ),
			function () use ( $word ) {
				global $wpdb;
				$out  = array(
					'meta'  => array(),
					'label' => array(),
				);
				$like = tcc_search_word_pattern( $word );
				$keys = tcc_search_meta_keys();
				if ( $keys ) {
					$marks       = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
					$out['meta'] = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ($marks) AND meta_value REGEXP %s LIMIT 600", array_merge( $keys, array( $like ) ) ) ) );
				}
				// The name of the person who wrote it (a Trinity Talk piece is saved under its writer's account).
				// This used to come from the WP Extended Search plugin; it is done here since 0.10.0.
				// Accounts that are not a person (see tcc_search_author_skip) are left out, so a search for
				// "church" or "sermon" does not bring back everything those accounts ever saved.
				$skip  = tcc_search_author_skip();
				$names = $skip ? ' AND u.display_name NOT IN (' . implode( ',', array_fill( 0, count( $skip ), '%s' ) ) . ')' : '';
				$by    = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->users} u ON u.ID = p.post_author WHERE p.post_status = 'publish' AND u.display_name REGEXP %s" . $names . ' LIMIT 600', array_merge( array( $like ), $skip ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders only.
				$out['meta'] = array_values( array_unique( array_merge( $out['meta'], array_map( 'intval', (array) $by ) ) ) );

				$taxonomies = tcc_search_taxonomies();
				if ( $taxonomies ) {
					$marks        = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );
					$out['label'] = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT tr.object_id FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id JOIN {$wpdb->terms} t ON t.term_id = tt.term_id WHERE tt.taxonomy IN ($marks) AND t.name REGEXP %s LIMIT 600", array_merge( $taxonomies, array( $like ) ) ) ) );
				}
				return $out;
			}
		);
	}

	/**
	 * Ids from WordPress's ordinary search (titles and page text) for these words, best first.
	 * Once per wording per page view (tcc_search_remember).
	 */
	function tcc_search_core_ids( $lookup, $types ) {
		if ( ! $types ) {
			return array();
		}
		return tcc_search_remember(
			'core',
			array( (string) $lookup, array_values( (array) $types ) ),
			function () use ( $lookup, $types ) {
				$query = new WP_Query(
					array(
						's'                      => $lookup,
						'post_type'              => $types,
						'post_status'            => 'publish',
						'has_password'           => false,
						'posts_per_page'         => 400,
						'orderby'                => 'relevance',
						'fields'                 => 'ids',
						'ignore_sticky_posts'    => true,
						'no_found_rows'          => true,
						'update_post_term_cache' => false,
						'update_post_meta_cache' => false,
						'tcc_search'             => 400,
					)
				);
				return array_map( 'intval', (array) $query->posts );
			}
		);
	}

	/**
	 * The upcoming events the search reads, with the words of each worked out once per page view
	 * (before November 2026 they were worked out again for every wording of a search):
	 * array( event id => array( its title, the lower-case words of its title, description,
	 * categories and venue ) ), soonest first. Password-protected events are left out, like every
	 * other protected page, so their words cannot be found by searching.
	 * The list comes from the "Event feeds" feature, the same list the event cards use, so past
	 * dates never show and a repeating event shows once.
	 */
	function tcc_search_event_texts() {
		if ( ! function_exists( 'tcc_upcoming_ids_for' ) ) {
			return array();
		}
		$event_ids = array_map( 'intval', (array) tcc_upcoming_ids_for( 'series', 0 ) );
		return tcc_search_remember(
			'events',
			$event_ids,
			function () use ( $event_ids ) {
				if ( $event_ids && function_exists( '_prime_post_caches' ) ) {
					// All the events in one lookup. Their fields too when The Events Calendar is on, because it
					// reads each event's venue (and later its start and end) from them: one lookup, not one per event.
					_prime_post_caches( $event_ids, true, function_exists( 'tribe_get_venue' ) );
				}
				$texts = array();
				foreach ( $event_ids as $event_id ) {
					$event = get_post( $event_id );
					if ( ! ( $event instanceof WP_Post ) || '' !== (string) $event->post_password ) {
						continue;
					}
					$labels = '';
					$terms  = taxonomy_exists( 'tribe_events_cat' ) ? get_the_terms( $event_id, 'tribe_events_cat' ) : false;
					if ( is_array( $terms ) ) {
						$labels = implode( ' ', wp_list_pluck( $terms, 'name' ) );
					}
					if ( function_exists( 'tribe_get_venue' ) ) {
						$labels .= ' ' . (string) tribe_get_venue( $event_id );
					}
					$texts[ $event_id ] = array( $event->post_title, tcc_search_lower( $event->post_title . ' ' . preg_replace( '/<!--.*?-->/s', ' ', $event->post_content ) . ' ' . $labels ) );
				}
				return $texts;
			}
		);
	}

	/**
	 * Every match for these words: array of array( id, kind, score, time, strong ).
	 * $any = false: all the words must be there. $any = true: any one of them.
	 */
	function tcc_search_collect( $term, $any = false ) {
		global $wpdb;
		$phrase = tcc_search_lower( $term );
		$words  = tcc_search_words( $term );
		if ( '' === $phrase ) {
			return array();
		}
		$map   = tcc_search_type_map();
		$types = array_keys( $map );
		$only  = tcc_search_only_type();
		$items = array();
		$long  = array_values(
			array_filter(
				$words,
				function ( $word ) {
					return strlen( $word ) > 2;
				}
			)
		);

		// 1. Titles and page text.
		$found = array(); // id => how it was found: 1 = title or page text, 2 = an extra field, 3 = a label.
		if ( $any ) {
			foreach ( array_slice( $long, 0, 4 ) as $word ) {
				foreach ( tcc_search_core_ids( $word, $types ) as $id ) {
					$found[ $id ] = 1;
				}
			}
		} else {
			foreach ( tcc_search_core_ids( $term, $types ) as $id ) {
				$found[ $id ] = 1;
			}
		}
		// WordPress matches letters anywhere ("men" in "moment"). Keep only real word matches.
		if ( $found ) {
			$found = array_fill_keys( tcc_search_whole_word_ids( array_keys( $found ), $any ? array_slice( $long, 0, 4 ) : $words, $any ), 1 );
		}

		// 2. The extra fields and labels (sermon descriptions, speaker, Bible book, group details...).
		if ( $types && $long ) {
			$extra = array();
			foreach ( array_slice( $long, 0, 4 ) as $word ) {
				$extra[ $word ] = tcc_search_extra_ids( $word );
			}
			if ( $any || 1 === count( $long ) ) {
				foreach ( $extra as $sets ) {
					foreach ( $sets['meta'] as $id ) {
						$found[ $id ] = max( 2, isset( $found[ $id ] ) ? $found[ $id ] : 0 );
					}
					foreach ( $sets['label'] as $id ) {
						$found[ $id ] = 3;
					}
				}
			} else {
				// Several words: each one must be somewhere on the item, in any mix of places
				// ("tyler" as the speaker and "baptism" in the title).
				$has_extra = false;
				foreach ( $extra as $sets ) {
					if ( $sets['meta'] || $sets['label'] ) {
						$has_extra = true;
					}
				}
				if ( $has_extra ) {
					$all = null;
					foreach ( $extra as $word => $sets ) {
						$here = array_fill_keys( array_merge( $sets['meta'], $sets['label'], tcc_search_whole_word_ids( tcc_search_core_ids( $word, $types ), array( $word ) ) ), true );
						$all  = ( null === $all ) ? $here : array_intersect_key( $all, $here );
					}
					foreach ( array_keys( (array) $all ) as $id ) {
						$found[ $id ] = max( 2, isset( $found[ $id ] ) ? $found[ $id ] : 0 );
					}
				}
			}
		}

		// 3. Look the found items up lightly (no page text), and leave out what should not show.
		$ids = array_slice( array_keys( $found ), 0, 900 );
		if ( $ids && $types ) {
			$id_list   = implode( ',', array_map( 'intval', $ids ) );
			$type_mark = implode( ',', array_fill( 0, count( $types ), '%s' ) );
			$rows      = (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_date_gmt FROM {$wpdb->posts} WHERE ID IN ($id_list) AND post_status = 'publish' AND post_password = '' AND post_type IN ($type_mark)", $types ) );
			// Left out (one lookup for both):
			//  - pages the church has asked search engines to leave out (thank-you pages and the like:
			//    Yoast "do not show in search results"), and
			//  - community groups marked as not active (Community Groups Info > "Is This Group Active?" unticked).
			$hidden = array_fill_keys( array_map( 'intval', (array) $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE post_id IN ($id_list) AND ( ( meta_key = '_yoast_wpseo_meta-robots-noindex' AND meta_value = '1' ) OR ( meta_key = 'is_this_group_active' AND meta_value = '0' ) )" ) ), true );
			foreach ( $rows as $row ) {
				$id = (int) $row->ID;
				if ( isset( $hidden[ $id ] ) || ! isset( $map[ $row->post_type ] ) ) {
					continue;
				}
				$kind  = $map[ $row->post_type ];
				$time  = (int) strtotime( $row->post_date_gmt . ' UTC' );
				$plain = tcc_search_score( '', $kind, $time, '', array() ); // what its kind and age alone are worth
				$score = tcc_search_score( $row->post_title, $kind, $time, $phrase, $words );
				// "Strong" = the words are in its title, or it is filed under a label with this name
				// (the book of Ephesians, the speaker). Only strong matches can be a Top result.
				// The words in its description alone is a fair match, not a strong one.
				$strong = ( $score - $plain ) >= 30 ? 1 : 0;
				if ( 3 === $found[ $id ] ) {
					$score  = max( $score, 35 + $plain );
					$strong = 1;
				} elseif ( 2 === $found[ $id ] ) {
					$score += 12;
				}
				$items[ $id ] = array( $id, $kind, $score, $time, $strong );
			}
		}

		// Upcoming events come from the same list the event cards use, so past dates never show
		// and a repeating event shows once. Their words are worked out once per page view
		// (tcc_search_event_texts, which also leaves out password-protected events).
		if ( function_exists( 'tcc_upcoming_ids_for' ) && ( '' === $only || 'tribe_events' === $only ) ) {
			foreach ( tcc_search_event_texts() as $event_id => $event_words ) {
				if ( isset( $items[ $event_id ] ) ) {
					continue;
				}
				list( $event_title, $text ) = $event_words;
				$hits = 0;
				foreach ( $words as $word ) {
					if ( false !== strpos( $text, $word ) ) {
						$hits++;
					}
				}
				$match = $any ? ( $hits > 0 ) : ( false !== strpos( $text, $phrase ) || ( $words && $hits === count( $words ) ) );
				if ( ! $match ) {
					continue;
				}
				$start  = function_exists( 'tribe_get_start_date' ) ? (int) tribe_get_start_date( $event_id, true, 'U' ) : 0;
				$score  = tcc_search_score( $event_title, 'event', time(), $phrase, $words );
				$strong = ( $score - tcc_search_score( '', 'event', time(), '', array() ) ) >= 30 ? 1 : 0;
				$items[ $event_id ] = array( $event_id, 'event', $score, $start, $strong );
			}
		}

		// A search that names a kind of thing ("groups", "sermons", "events") lists that kind.
		// Only when the search is about nothing else: "groups" or "community groups" lists the groups,
		// but "youth group times" is a search for something specific and does not.
		$filler = array( 'community', 'small', 'church', 'tcc', 'trinity', 'latest', 'recent', 'new', 'upcoming', 'next', 'all', 'list' );
		foreach ( tcc_search_kind_words() as $kind => $names ) {
			if ( '' !== $only || ! array_intersect( $words, $names ) || array_diff( $words, $names, $filler ) ) {
				continue;
			}
			if ( 'event' === $kind ) {
				$extra = function_exists( 'tcc_upcoming_ids_for' ) ? array_slice( array_map( 'intval', (array) tcc_upcoming_ids_for( 'series', 0 ) ), 0, 6 ) : array();
			} else {
				$extra = get_posts(
					array(
						'post_type'        => ( 'group' === $kind ) ? 'project' : 'post',
						'post_status'      => 'publish',
						'has_password'     => false,
						'numberposts'      => ( 'group' === $kind ) ? 30 : 5,
						'orderby'          => ( 'group' === $kind ) ? 'title' : 'date',
						'order'            => ( 'group' === $kind ) ? 'ASC' : 'DESC',
						'fields'           => 'ids',
						'suppress_filters' => true,
						// Leave out community groups marked as not active.
						'meta_query'       => ( 'group' === $kind ) ? array(
							'relation' => 'OR',
							array(
								'key'     => 'is_this_group_active',
								'compare' => 'NOT EXISTS',
							),
							array(
								'key'     => 'is_this_group_active',
								'value'   => '0',
								'compare' => '!=',
							),
						) : array(),
					)
				);
			}
			$place = 0;
			foreach ( (array) $extra as $extra_id ) {
				$extra_id = (int) $extra_id;
				if ( $extra_id > 0 && ! isset( $items[ $extra_id ] ) ) {
					// The time is only used to keep them in this order within their group.
					$time               = ( 'event' === $kind && function_exists( 'tribe_get_start_date' ) ) ? (int) tribe_get_start_date( $extra_id, true, 'U' ) : ( time() - $place );
					$items[ $extra_id ] = array( $extra_id, $kind, 45, $time, 1 );
					$place++;
				}
			}
		}

		return array_values( $items );
	}
}
