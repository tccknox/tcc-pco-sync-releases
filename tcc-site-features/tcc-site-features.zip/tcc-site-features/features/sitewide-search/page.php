<?php
/**
 * TCC Website, Sitewide search page: which searches it takes over, and drawing the results page.
 * Part: Which searches it takes over, its health check, and drawing the page
 *
 * Loaded by features/sitewide-search.php (read the comment at the top of that file first). In this part:
 *   - which searches the new page is for: a search of the whole website, not one limited to one kind
 *     of content (tcc_search_is_sitewide, tcc_search_only_type), and which kinds of content go in
 *     which group (tcc_search_type_map);
 *   - finding the Divi Theme Builder template that holds [tcc_search_results] and showing it for
 *     those searches (tcc_search_layout_id, tcc_search_swap_layout), and keeping a note when Divi
 *     did not show it (tcc_search_note_outcome);
 *   - the health check the Features tab reads (tcc_search_health): an empty list means all is well;
 *   - putting back the search's own settings after Divi's Search box changes them (tcc_search_keep_our_query);
 *   - the pieces of the results page: one result's title, link, line and picture (tcc_search_view),
 *     a row and a Top results card (tcc_search_row_html, tcc_search_card_html), the short codes
 *     [tcc_search_heading] and [tcc_search_form], and printing the styles (tcc_search_css).
 *
 * What it leans on: the plugin's main file (tcc_site_body_layouts, tcc_site_use_body_layout,
 * tcc_site_asset), the groups in tcc_search_kinds() and the short code [tcc_search_results] in
 * features/sitewide-search.php, the results worked out in remembering.php (tcc_search_data), the
 * styles in features/sitewide-search.css, and the Sermons page feature for the speaker line
 * (tcc_sermons_speaker, when it is on).
 *
 * Part of the TCC Website plugin (in its own file since 0.14.4; before that it was in sitewide-search.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_type_map' ) ) {

	/* ------------------------------------------------------------------
	 * Which searches it takes over, and its health check
	 * ------------------------------------------------------------------ */

	/**
	 * Which kind of content goes in which group.
	 * When the search is limited to one kind (see tcc_search_only_type) only that kind is returned,
	 * unless $all is true.
	 */
	function tcc_search_type_map( $all = false ) {
		$map = array(
			'page'    => 'page',
			'post'    => 'sermon',
			'article' => 'article',
			'project' => 'group',
		);
		$only = $all ? '' : tcc_search_only_type();
		if ( isset( $map[ $only ] ) ) {
			return array( $only => $map[ $only ] );
		}
		if ( 'tribe_events' === $only ) {
			return array();
		}
		return $map;
	}

	/**
	 * Looks a page up by its address and returns its link, or '' when there is no such published
	 * page. So a renamed or removed page never leaves a dead link on the search page.
	 */
	function tcc_search_link( $path ) {
		$path = trim( (string) $path, '/' );
		if ( '' === $path ) {
			return '';
		}
		$page = get_page_by_path( $path );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			return (string) get_permalink( $page );
		}
		if ( 'events' === $path && post_type_exists( 'tribe_events' ) ) {
			return (string) get_post_type_archive_link( 'tribe_events' );
		}
		return '';
	}

	function tcc_search_lower( $text ) {
		$text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	}

	/** The words typed into the search box, tidied. */
	function tcc_search_term() {
		if ( ! isset( $_GET['s'] ) || is_array( $_GET['s'] ) ) {
			return '';
		}
		$term = trim( preg_replace( '/\s+/', ' ', sanitize_text_field( wp_unslash( $_GET['s'] ) ) ) );
		// At most 80 letters. Counted as letters, not bytes, so an accented letter (é takes two bytes)
		// at the end is never cut in half.
		return (string) ( function_exists( 'mb_substr' ) ? mb_substr( $term, 0, 80, 'UTF-8' ) : substr( $term, 0, 80 ) );
	}

	/**
	 * True for a search of the whole website. False when the address limits the search to one
	 * kind of content (post_type=post, or a Divi Search box set to one kind), so that a
	 * sermon-only search can have its own page.
	 */
	function tcc_search_is_sitewide() {
		return ! is_admin() && isset( $_GET['s'] ) && '' === tcc_search_only_type();
	}

	/**
	 * The one kind of content the address limits the search to ('post' for a sermon-only search),
	 * or '' for a search of the whole website.
	 */
	function tcc_search_only_type() {
		$type = '';
		if ( isset( $_GET['post_type'] ) ) {
			$type = wp_unslash( $_GET['post_type'] );
			if ( is_array( $type ) ) {
				$type = ( 1 === count( $type ) ) ? reset( $type ) : '';
			}
			$type = is_string( $type ) ? sanitize_key( $type ) : '';
			if ( 'any' === $type ) {
				$type = '';
			}
		}
		if ( '' === $type && isset( $_GET['search_post_types'] ) && ! is_array( $_GET['search_post_types'] ) ) {
			$list = array_values( array_filter( array_map( 'trim', explode( ',', (string) wp_unslash( $_GET['search_post_types'] ) ) ) ) );
			if ( 1 === count( $list ) ) {
				$type = sanitize_key( $list[0] );
			}
		}
		return $type;
	}

	/**
	 * The Theme Builder body layout that holds [tcc_search_results], or 0 when there is none.
	 * Found by looking, not by name or number, so renaming the template does not break anything.
	 */
	function tcc_search_layout_id() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		$found = tcc_site_body_layouts( array( 'search' => 'tcc_search_results' ) );
		return (int) $found['search'];
	}

	/** True when this page view is a sitewide search AND the new search page exists to show it. */
	function tcc_search_active() {
		static $active = null;
		if ( null === $active ) {
			$active = tcc_search_is_sitewide() && tcc_search_layout_id() > 0;
		}
		return $active;
	}

	/** Shows the new search page for sitewide searches, whatever is assigned to "Search Results". */
	function tcc_search_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) || ! is_search() || ! tcc_search_active() ) {
				return $layouts;
			}
			return tcc_site_use_body_layout( $layouts, tcc_search_layout_id() );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_search_swap_layout', 20 );

	/*
	 * WordPress's own ordinary search for the page is deliberately left running, although the new
	 * page does not use it. It is one small query, and it means that if Divi ever stops showing
	 * our template the old results page underneath still has its results.
	 */

	/**
	 * Keeps a note when a sitewide search did NOT end up showing the new page (for example after a
	 * Divi update changed how templates are chosen), and clears the note once it shows again.
	 * The Features tab reads the note.
	 */
	function tcc_search_note_outcome() {
		try {
			if ( ! tcc_search_active() || ! is_search() ) {
				return;
			}
			$noted = (int) get_option( 'tcc_search_not_shown', 0 );
			if ( ! empty( $GLOBALS['tcc_search_drawn'] ) ) {
				if ( $noted ) {
					delete_option( 'tcc_search_not_shown' );
				}
			} elseif ( ! $noted ) {
				update_option( 'tcc_search_not_shown', time(), false );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}
	add_action( 'wp_footer', 'tcc_search_note_outcome', 99 );

	/** True when the template that holds the search page is assigned to "Search Results" in the Theme Builder. */
	function tcc_search_template_assigned() {
		$layout_id = tcc_search_layout_id();
		if ( $layout_id < 1 ) {
			return false;
		}
		$templates = get_posts(
			array(
				'post_type'        => 'et_template',
				'post_status'      => 'publish',
				'numberposts'      => 100,
				'fields'           => 'ids',
				'suppress_filters' => true,
			)
		);
		foreach ( (array) $templates as $template_id ) {
			if ( (int) get_post_meta( $template_id, '_et_body_layout_id', true ) === $layout_id && in_array( 'search', (array) get_post_meta( $template_id, '_et_use_on', false ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Things that would quietly make the search page worse, in plain words, for the Features tab.
	 * An empty list means all is well.
	 */
	function tcc_search_health() {
		$problems = array();
		try {
			if ( tcc_search_layout_id() < 1 ) {
				$problems[] = 'Its page cannot be found, so searches are using the older results page. In Divi > Theme Builder there should be a template called "Search results - SITEWIDE (new)" whose body holds a layer with [tcc_search_results] in it.';
			}
			$noted = (int) get_option( 'tcc_search_not_shown', 0 );
			if ( $noted ) {
				$problems[] = 'Divi did not show the new search page when someone searched on ' . wp_date( 'F j', $noted ) . ', so visitors are getting the older results page (it still works). This usually follows a Divi update. Try a search yourself: if the new page shows, this message clears itself; if not, tell whoever looks after the website\'s code.';
			}
			if ( tcc_search_template_assigned() ) {
				$problems[] = 'The template "Search results - SITEWIDE (new)" has been assigned to Search Results in the Theme Builder. It still works, but it is meant to be left unassigned, with the OLD search template assigned instead, so that switching this feature off has a working page to fall back to.';
			}
			if ( ! post_type_exists( 'project' ) ) {
				$problems[] = 'The Community Groups content type cannot be found, so groups are missing from search.';
			}
			if ( ! post_type_exists( 'article' ) ) {
				$problems[] = 'The Articles (Trinity Talk) content type cannot be found, so articles are missing from search.';
			}
			if ( ! function_exists( 'tcc_upcoming_ids_for' ) ) {
				$problems[] = 'The "Event feeds" feature is switched off, so upcoming events are missing from search.';
			} elseif ( ! function_exists( 'tribe_get_events' ) ) {
				$problems[] = 'The Events Calendar plugin is switched off, so upcoming events are missing from search.';
			}
			foreach ( tcc_search_kinds() as $setup ) {
				if ( '' !== $setup[3] && '' === tcc_search_link( $setup[3] ) ) {
					$problems[] = 'The page ' . $setup[3] . ' cannot be found, so the "' . $setup[4] . '" link is left off the search page.';
				}
			}
		} catch ( \Throwable $e ) {
			return $problems;
		}
		return $problems;
	}

	/** Divi's Search box rewrites every search on the page to its own settings. Put ours back. */
	function tcc_search_keep_our_query( $query ) {
		if ( $query instanceof WP_Query && $query->get( 'tcc_search' ) ) {
			$query->set( 'post_type', array_keys( tcc_search_type_map() ) );
			$query->set( 'posts_per_page', (int) $query->get( 'tcc_search' ) );
			$query->set( 'orderby', 'relevance' );
			$query->set( 'paged', 1 );
			$query->set( 'offset', 0 );
		}
	}
	add_action( 'pre_get_posts', 'tcc_search_keep_our_query', 9999 );

	/** Marks the page so styles (and anyone curious) can tell which search page this is. */
	function tcc_search_body_class( $classes ) {
		if ( tcc_search_active() ) {
			$classes[] = 'tcc-search-page';
		}
		return $classes;
	}
	add_filter( 'body_class', 'tcc_search_body_class' );

	/* ------------------------------------------------------------------
	 * Drawing the page
	 * ------------------------------------------------------------------ */

	/** A short plain description of a page, article or group, or ''. */
	function tcc_search_blurb( $post ) {
		$text = (string) get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true );
		if ( '' === trim( $text ) || false !== strpos( $text, '%%' ) ) {
			$text = ( '' !== trim( $post->post_excerpt ) ) ? $post->post_excerpt : $post->post_content;
			$text = preg_replace( '/<!--.*?-->/s', ' ', $text );
			$text = preg_replace( '/\[\/?[a-zA-Z_][^\]]*\]/', ' ', $text );
			$text = preg_replace( '/<(script|style)\b.*?<\/\1>/is', ' ', $text );
		}
		$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) );
		if ( strlen( $text ) < 25 ) {
			return '';
		}
		return wp_trim_words( $text, 26, '…' );
	}

	/** The pieces shown for one result: title, link, small line, description, picture, date tile. */
	function tcc_search_view( $item ) {
		$post = get_post( $item[0] );
		if ( ! ( $post instanceof WP_Post ) ) {
			return null;
		}
		$kind = $item[1];
		$view = array(
			'kind'  => $kind,
			'title' => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'url'   => (string) get_permalink( $post ),
			'meta'  => '',
			'blurb' => '',
			'image' => (string) get_the_post_thumbnail_url( $post, 'medium_large' ),
			'month' => '',
			'day'   => '',
		);
		if ( 'event' === $kind && function_exists( 'tribe_get_start_date' ) ) {
			$view['month'] = (string) tribe_get_start_date( $post->ID, false, 'M' );
			$view['day']   = (string) tribe_get_start_date( $post->ID, false, 'j' );
			$when          = (string) tribe_get_start_date( $post->ID, false, 'l, F j' );
			if ( function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $post->ID ) ) {
				$time = 'All Day';
			} else {
				$start = (string) tribe_get_start_date( $post->ID, false, 'g:i A' );
				$end   = function_exists( 'tribe_get_end_date' ) ? (string) tribe_get_end_date( $post->ID, false, 'g:i A' ) : '';
				$time  = ( '' !== $end && $end !== $start ) ? $start . ' - ' . $end : $start;
			}
			$view['meta'] = trim( $when . ' · ' . $time, ' ·' );
		} elseif ( 'sermon' === $kind ) {
			// The same speaker line as the Sermons page ("Tyler Lynde & Amy Lynde"). Without that
			// feature: the typed Speaker Name, or failing that the sermon's author.
			if ( function_exists( 'tcc_sermons_speaker' ) ) {
				$speaker = (string) tcc_sermons_speaker( $post->ID );
			} else {
				$speaker = trim( (string) get_post_meta( $post->ID, 'speaker_name', true ) );
				if ( '' === $speaker ) {
					$speaker = (string) get_the_author_meta( 'display_name', (int) $post->post_author );
				}
			}
			if ( false !== stripos( $speaker, 'Trinity Community' ) ) {
				$speaker = '';
			}
			$view['meta'] = trim( $speaker . ' · ' . get_the_date( 'F j, Y', $post ), ' ·' );
			$short        = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) get_post_meta( $post->ID, 'sermon_description_short', true ) ) ) );
			if ( strlen( $short ) >= 25 ) {
				$view['blurb'] = wp_trim_words( $short, 26, '…' );
			}
		} elseif ( 'group' === $kind ) {
			// Community groups keep their words in their own fields (Community Groups Info).
			$about = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) get_post_meta( $post->ID, 'group_description', true ) ) ) );
			$when  = trim( (string) get_post_meta( $post->ID, 'date_and_meeting_time', true ) );
			$view['blurb'] = ( strlen( $about ) >= 25 ) ? wp_trim_words( $about, 26, '…' ) : tcc_search_blurb( $post );
			if ( '' !== $when ) {
				$view['blurb'] = trim( $when . ' · ' . $view['blurb'], ' ·' );
			}
		} else {
			$view['blurb'] = tcc_search_blurb( $post );
		}
		return $view;
	}

	function tcc_search_row_html( $view ) {
		$html = '<a class="tcc-s-row" href="' . esc_url( $view['url'] ) . '">';
		if ( 'event' === $view['kind'] && '' !== $view['day'] ) {
			$html .= '<span class="tcc-s-date"><small>' . esc_html( $view['month'] ) . '</small><b>' . esc_html( $view['day'] ) . '</b></span>';
		} elseif ( 'sermon' === $view['kind'] ) {
			// A real picture that the browser only fetches when its row is about to be seen.
			$html .= '<span class="tcc-s-thumb">' . ( '' !== $view['image'] ? '<img src="' . esc_url( $view['image'] ) . '" alt="" loading="lazy" decoding="async">' : '' ) . '</span>';
		}
		$html .= '<span class="tcc-s-text">';
		if ( 'sermon' === $view['kind'] && '' !== $view['meta'] ) {
			$html .= '<span class="tcc-s-meta">' . esc_html( $view['meta'] ) . '</span>';
		}
		$html .= '<span class="tcc-s-title">' . esc_html( $view['title'] ) . '</span>';
		if ( 'event' === $view['kind'] && '' !== $view['meta'] ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $view['meta'] ) . '</span>';
		} elseif ( '' !== $view['blurb'] ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $view['blurb'] ) . '</span>';
		}
		return $html . '</span></a>';
	}

	function tcc_search_card_html( $view, $label ) {
		$html  = '<a class="tcc-s-card" href="' . esc_url( $view['url'] ) . '">';
		$html .= '<span class="tcc-s-card-img"' . ( '' !== $view['image'] ? ' style="background-image:url(&quot;' . esc_url( $view['image'] ) . '&quot;)"' : '' ) . '></span>';
		$html .= '<span class="tcc-s-card-text"><span class="tcc-s-kind">' . esc_html( $label ) . '</span>';
		$html .= '<span class="tcc-s-title">' . esc_html( $view['title'] ) . '</span>';
		$line  = ( '' !== $view['meta'] ) ? $view['meta'] : wp_trim_words( $view['blurb'], 14, '…' );
		if ( '' !== $line ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $line ) . '</span>';
		}
		return $html . '</span></a>';
	}

	/** [tcc_search_heading]: Results for "baptism". */
	function tcc_search_heading_shortcode() {
		try {
			$data = tcc_search_data();
			if ( '' === $data['typed'] ) {
				return 'Search the website';
			}
			if ( 'busy' === $data['note'] ) {
				return 'Search the website';
			}
			if ( ! $data['items'] ) {
				return 'No results for &ldquo;' . esc_html( $data['typed'] ) . '&rdquo;';
			}
			return 'Results for &ldquo;' . esc_html( $data['used'] ) . '&rdquo;';
		} catch ( \Throwable $e ) {
			return 'Search results';
		}
	}
	add_shortcode( 'tcc_search_heading', 'tcc_search_heading_shortcode' );

	/** [tcc_search_form]: the search-again box. It searches the whole website, unless this search was limited to one kind. */
	function tcc_search_form_shortcode() {
		$data = tcc_search_data();
		$only = tcc_search_only_type();
		return tcc_search_css( true ) . '<div class="tcc-search"><form class="tcc-s-form" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '">'
			. ( '' !== $only ? '<input type="hidden" name="post_type" value="' . esc_attr( $only ) . '">' : '' )
			. '<label class="screen-reader-text" for="tcc-s-box">Search the website</label>'
			. '<input id="tcc-s-box" type="search" name="s" value="' . esc_attr( $data['typed'] ) . '" placeholder="Search the website" autocomplete="off">'
			. '<button type="submit">Search</button></form></div>';
	}
	add_shortcode( 'tcc_search_form', 'tcc_search_form_shortcode' );

	/**
	 * The look of the search page. Colours: teal #00A4CF (outlines, arrows), teal again for words (a darker teal, 007DA1, was used for words until 0.9.0; it is not one of the church's brand colours, so it was retired)
	 * (buttons, small labels), grey #f4f4f4 (rows), text #404041.
	 *
	 * The rules are in sitewide-search.css. Every rule is written twice: first starting with plain
	 * "body", so the page keeps its look even if a Divi update renames Divi's page ids, then (from the
	 * line starting "#page-container #et-boc .tcc-search{") again starting with Divi's two page ids, so
	 * Divi's own rules do not override it. A change to one copy needs making in the other copy too.
	 * Each copy runs in this order: the general rules, the search-again box and notes, Top results, the jump buttons, the
	 * groups and rows, the "nothing found" box, the narrower screens, then the two Divi text layers
	 * above the results (.tcc-search-eyebrow and .tcc-search-heading, which are outside .tcc-search).
	 * On tablets and phones (800 wide or less) the three Top results cards become rows with the
	 * picture on the left.
	 *
	 * It is printed in the page head for a sitewide search. A short code that finds it has not
	 * been printed (the template is being shown some other way) prints it itself: $inline = true.
	 */
	function tcc_search_css( $inline = false ) {
		static $printed = false;
		if ( $printed || ( ! $inline && ! tcc_search_active() ) ) {
			return '';
		}
		$printed = true;
		// The rules are in features/sitewide-search.css (beside sitewide-search.php), one rule to a line. The line break
		// after each closing } is only there to make the file easy to read: it is taken out here, so the
		// page gets the rules run together on one line, as it always has.
		$out = '<style id="tcc-sitewide-search">' . str_replace( "}\n", '}', tcc_site_asset( 'features/sitewide-search.css' ) ) . '</style>' . "\n";
		if ( $inline ) {
			return $out;
		}
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own styles file.
		return '';
	}
	add_action( 'wp_head', 'tcc_search_css', 30 );

	// WP Rocket is told to leave these styles alone (id tcc-sitewide-search) by the plugin's main file,
	// which keeps every style block whose id starts "tcc-".
}
