<?php
/**
 * TCC Website, Sitewide search page: working out a search, remembering it, and starting afresh.
 * Part: Working out a search, remembering it, and starting afresh
 *
 * Loaded by features/sitewide-search.php (read the comment at the top of that file first). In this part:
 *   - working out everything the page needs for the search typed (tcc_search_data, tcc_search_find):
 *     the search as typed and in other words; if that finds nothing, the closest spelling; then, for a
 *     search of several words, any of the words. The note it leaves ('spelling', 'any' or 'busy') is
 *     what the results page says above the results;
 *   - remembering a search for up to 6 hours (tcc_search_cache_key, tcc_search_keep_for);
 *   - the results of one group, and the three Top results (tcc_search_one_kind, tcc_search_group, tcc_search_top);
 *   - the "busy" limit: 15 fresh searches a minute for one visitor, 90 for the whole website
 *     (tcc_search_client_address, tcc_search_too_busy);
 *   - starting every remembered search afresh as soon as something it reads changes
 *     (tcc_search_start_afresh, and the hooks on saving, trashing, labels, names and the list of words
 *     that mean the same).
 *
 * What it leans on: tcc_search_collect_wide() and tcc_search_fix_spelling() in words.php, the helpers in
 * page.php and finding.php, the plugin's main file for the generation numbers (tcc_site_gen,
 * tcc_site_new_gen), and the "Event feeds" feature for how long the upcoming events stay
 * (tcc_upcoming_ids_for, tcc_upcoming_keep_for).
 *
 * Part of the TCC Website plugin (in its own file since 0.14.4; before that it was in sitewide-search.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_data' ) ) {

	/* ------------------------------------------------------------------
	 * Working out a search, and remembering it
	 * ------------------------------------------------------------------ */

	/**
	 * Everything the page needs for the current search:
	 * array( 'typed', 'used', 'note' ('' | 'spelling' | 'any' | 'busy'), 'also', 'items' ).
	 */
	function tcc_search_data() {
		static $data = null;
		if ( null === $data ) {
			$data = tcc_search_find( tcc_search_term() );
		}
		return $data;
	}

	/**
	 * The name a search is remembered under. It changes by itself (so the search is worked out
	 * afresh) when content changes (tcc_search_gen), when the upcoming events change (the
	 * "upcoming" generation, from Event feeds), when this plugin is updated, and when Event feeds
	 * or The Events Calendar is switched on or off.
	 */
	function tcc_search_cache_key( $typed ) {
		$setup = ( defined( 'TCC_SITE_VERSION' ) ? TCC_SITE_VERSION : '' ) . '|' . ( function_exists( 'tcc_upcoming_ids_for' ) ? 'events' : '' ) . '|' . ( function_exists( 'tribe_get_start_date' ) ? 'tec' : '' );
		return 'tcc_search6_' . tcc_search_gen() . '_' . tcc_site_gen( 'upcoming' ) . '_' . md5( tcc_search_lower( $typed ) . '|' . tcc_search_only_type() . '|' . $setup );
	}

	/**
	 * How long a search is remembered, in seconds (before November 2026: always 10 minutes).
	 * A remembered search is thrown away anyway as soon as anything it came from changes (see
	 * tcc_search_start_afresh and tcc_search_cache_key), so it can be kept a good while:
	 *   - at most 6 hours;
	 *   - less when an upcoming event is about to be over, so that it leaves the results when it
	 *     does: until the first event on the list of upcoming events ends, the same rule that list
	 *     itself follows (tcc_upcoming_keep_for, in event-feeds.php);
	 *   - 10 minutes for a search that found nothing, as before, so the list of searches that found
	 *     nothing (TCC Website > Search) still counts one at most once every 10 minutes.
	 */
	function tcc_search_keep_for( $data ) {
		if ( empty( $data['items'] ) ) {
			return 10 * MINUTE_IN_SECONDS;
		}
		$keep = 6 * HOUR_IN_SECONDS;
		if ( function_exists( 'tcc_upcoming_ids_for' ) && function_exists( 'tcc_upcoming_keep_for' ) ) {
			$event_ids = array_map( 'intval', (array) tcc_upcoming_ids_for( 'series', 0 ) );
			if ( $event_ids ) {
				update_meta_cache( 'post', $event_ids ); // Their end times in one lookup (usually already loaded).
			}
			$keep = min( $keep, (int) tcc_upcoming_keep_for( $event_ids ) );
		}
		return max( MINUTE_IN_SECONDS, $keep );
	}

	/**
	 * Everything the page needs for this search (see tcc_search_data): remembered, or worked out
	 * fresh and then remembered (tcc_search_keep_for says for how long). Searches that were turned
	 * away as "busy" are not remembered.
	 */
	function tcc_search_find( $typed ) {
		$typed = (string) $typed;
		$data  = array(
			'typed' => $typed,
			'used'  => $typed,
			'note'  => '',
			'also'  => array(),
			'items' => array(),
		);
		if ( '' === $typed ) {
			return $data;
		}
		$key    = tcc_search_cache_key( $typed );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['items'], $cached['also'] ) ) {
			$cached['typed'] = $typed;
			return $cached;
		}
		// A fresh search (not remembered) is real work for the server.
		// One visitor, or a robot, sending many different searches a minute is told to wait.
		if ( tcc_search_too_busy() ) {
			$data['note'] = 'busy';
			return $data;
		}
		try {
			$also  = array();
			$items = tcc_search_collect_wide( $typed, false, $also );
			if ( ! $items ) {
				// The second tries (closest spelling, then any of the words) skip the other wordings,
				// so a search that finds nothing costs a few lookups, not dozens.
				$fixed = tcc_search_fix_spelling( $typed );
				if ( '' !== $fixed ) {
					$items = tcc_search_collect_wide( $fixed, false, $also, false );
					if ( $items ) {
						$data['used'] = $fixed;
						$data['note'] = 'spelling';
					}
				}
				if ( ! $items && count( tcc_search_words( $typed ) ) > 1 ) {
					$loose = ( '' !== $fixed ) ? $fixed : $typed;
					$items = tcc_search_collect_wide( $loose, true, $also, false );
					if ( $items ) {
						$data['used'] = $loose;
						$data['note'] = 'any';
					}
				}
			}
			$data['items'] = $items;
			$data['also']  = $also;
			if ( ! $items ) {
				tcc_search_log_miss( $typed );
			}
		} catch ( \Throwable $e ) {
			$data['items'] = array();
		}
		set_transient( $key, $data, tcc_search_keep_for( $data ) );
		return $data;
	}

	/**
	 * The one group being looked at on its own page (the address ends in &tcc_kind=sermon after
	 * someone pressed "See all 59 Sermons"), or '' for the ordinary page with every group.
	 */
	function tcc_search_one_kind() {
		$kind  = isset( $_GET['tcc_kind'] ) && ! is_array( $_GET['tcc_kind'] ) ? sanitize_key( wp_unslash( $_GET['tcc_kind'] ) ) : '';
		$kinds = tcc_search_kinds();
		return isset( $kinds[ $kind ] ) ? $kind : '';
	}

	/** The items of one kind, best first (events: soonest first). */
	function tcc_search_group( $items, $kind ) {
		$group = array();
		foreach ( $items as $item ) {
			if ( $item[1] === $kind ) {
				$group[] = $item;
			}
		}
		usort(
			$group,
			function ( $a, $b ) use ( $kind ) {
				if ( 'event' === $kind ) {
					return $a[3] <=> $b[3];
				}
				return ( $b[2] <=> $a[2] ) ? ( $b[2] <=> $a[2] ) : ( $b[3] <=> $a[3] );
			}
		);
		return $group;
	}

	/** The three best matches overall, one of each kind where possible. Empty when there are few results. */
	function tcc_search_top( $items ) {
		if ( count( $items ) < 7 ) {
			return array();
		}
		$sorted = $items;
		usort(
			$sorted,
			function ( $a, $b ) {
				return ( $b[2] <=> $a[2] ) ? ( $b[2] <=> $a[2] ) : ( $b[3] <=> $a[3] );
			}
		);
		$top   = array();
		$kinds = array();
		foreach ( $sorted as $item ) {
			// Only strong matches (see tcc_search_collect) lead the page.
			if ( count( $top ) < 3 && ! empty( $item[4] ) && ! isset( $kinds[ $item[1] ] ) ) {
				$top[ $item[0] ]   = $item;
				$kinds[ $item[1] ] = true;
			}
		}
		foreach ( $sorted as $item ) {
			if ( count( $top ) < 3 && ! empty( $item[4] ) && ! isset( $top[ $item[0] ] ) ) {
				$top[ $item[0] ] = $item;
			}
		}
		return ( count( $top ) >= 2 ) ? array_values( $top ) : array();
	}

	/* ------------------------------------------------------------------
	 * Holding back a visitor who starts too many searches at once
	 * ------------------------------------------------------------------ */

	/**
	 * The visitor's internet address, for counting searches per visitor. Normally the address the
	 * request came from. Only when that is a private or local address (a proxy at the host, in front
	 * of the website) is the address the proxy passed on used instead: the last one in X-Forwarded-For,
	 * else X-Real-IP. A visitor cannot fool this by sending those headers, because they are only read
	 * when the request really came through such a proxy.
	 * Returns array( 'address' => ..., 'via' => 'direct' | 'proxy' | 'proxy, no visitor address' ).
	 */
	function tcc_search_client_address() {
		$public = function ( $ip ) {
			return false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		};
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? trim( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked as an IP address.
		if ( '' === $remote || $public( $remote ) ) {
			return array( 'address' => $remote, 'via' => 'direct' );
		}
		$passed = array();
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$passed = array_reverse( array_map( 'trim', explode( ',', (string) wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		if ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
			$passed[] = trim( (string) wp_unslash( $_SERVER['HTTP_X_REAL_IP'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		foreach ( $passed as $ip ) {
			if ( $public( $ip ) ) {
				return array( 'address' => $ip, 'via' => 'proxy' );
			}
		}
		return array( 'address' => $remote, 'via' => 'proxy, no visitor address' );
	}

	/**
	 * Is the search too busy to start a fresh search for this visitor? Counts fresh searches per
	 * minute: 15 for one visitor (known only by a scrambled form of their internet address, which
	 * is not kept) and 90 for the whole website. Searches already remembered (see tcc_search_find)
	 * do not count. Signed-in editors are never held back. The counts sit in the server's memory
	 * cache (or as short-lived WordPress settings) and are forgotten after two minutes.
	 *
	 * A search that is turned away is not counted at all. So a visitor (or a robot) who keeps
	 * searching past their own 15 uses up only those 15 of the website's 90, and cannot make the
	 * search say "busy" for everyone else.
	 */
	function tcc_search_too_busy() {
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return false;
		}
		$minute  = (int) floor( time() / 60 );
		$client  = tcc_search_client_address();
		$address = $client['address'];
		$mine    = 'tcc_sq_' . substr( md5( $address . wp_salt( 'nonce' ) ), 0, 12 ) . '_' . $minute;
		$all     = 'tcc_sq_all_' . $minute;
		// This visitor's own 15 first: over it, they wait, and nothing is counted.
		if ( (int) get_transient( $mine ) >= 15 ) {
			return true;
		}
		// Then the whole website's 90. Over it, everyone waits; again nothing is counted.
		if ( (int) get_transient( $all ) >= 90 ) {
			return true;
		}
		// Let through: count it for this visitor and for the website.
		foreach ( array( $mine, $all ) as $key ) {
			set_transient( $key, (int) get_transient( $key ) + 1, 2 * MINUTE_IN_SECONDS );
		}
		return false;
	}

	/* ------------------------------------------------------------------
	 * Starting the remembered searches afresh when content changes
	 * ------------------------------------------------------------------ */

	/**
	 * The "search" generation number, which is part of the name of every remembered search and of
	 * the spelling dictionary (tcc_site_gen, in the plugin's main file). Also notes that this page
	 * view has used it, for tcc_search_start_afresh().
	 */
	function tcc_search_gen() {
		$GLOBALS['tcc_search_gen_used'] = true;
		return tcc_site_gen( 'search' );
	}

	/**
	 * Starts the remembered searches and the spelling dictionary afresh: a new "search" generation,
	 * so every one of them is out of date at once (the old ones simply expire). The hooks below call
	 * it whenever something the search reads changes. Since November 2026 searches are remembered
	 * for hours, not 10 minutes, so this has to catch every change:
	 *   - It also runs once more when the page view that made the change has finished, because
	 *     WordPress saves an item's extra fields (ACF, Yoast) and labels just after it says
	 *     "saved"; a visitor's search made in that split second would otherwise be remembered
	 *     without them.
	 *   - Many changes in one go (a bulk edit, or Planning Center events bringing in many events)
	 *     start afresh once, plus that once at the end, unless a search was worked out in between.
	 * It also forgets this page view's own lookups (tcc_search_forget_lookups).
	 */
	function tcc_search_start_afresh() {
		static $started = false;
		tcc_search_forget_lookups();
		if ( $started && empty( $GLOBALS['tcc_search_gen_used'] ) ) {
			return; // Already started afresh in this page view, and nothing has been remembered since.
		}
		if ( ! $started ) {
			add_action( 'shutdown', 'tcc_search_start_afresh_at_end' );
		}
		$started                        = true;
		$GLOBALS['tcc_search_gen_used'] = false;
		tcc_site_new_gen( 'search' );
	}

	/** See tcc_search_start_afresh: once more when the page view that changed something ends. */
	function tcc_search_start_afresh_at_end() {
		tcc_site_new_gen( 'search' );
	}

	/** The kinds of content the search reads (a venue's name is read with its events). */
	function tcc_search_watched_types() {
		return array( 'page', 'post', 'article', 'project', 'tribe_events', 'tribe_venue' );
	}

	/** A page, sermon, article, group, event or venue was saved, published, trashed or brought back. */
	function tcc_search_content_changed( $post_id = 0 ) {
		if ( $post_id && ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) ) {
			return;
		}
		tcc_search_start_afresh();
	}
	foreach ( tcc_search_watched_types() as $tcc_search_type ) {
		add_action( 'save_post_' . $tcc_search_type, 'tcc_search_content_changed' );
	}
	unset( $tcc_search_type );
	add_action( 'trashed_post', 'tcc_search_content_changed' );
	add_action( 'untrashed_post', 'tcc_search_content_changed' );

	/** One of them was deleted for good (without going to the Trash first). */
	function tcc_search_post_deleted( $post_id, $post = null ) {
		if ( $post instanceof WP_Post && ! in_array( $post->post_type, tcc_search_watched_types(), true ) ) {
			return;
		}
		tcc_search_start_afresh();
	}
	add_action( 'deleted_post', 'tcc_search_post_deleted', 10, 2 );

	/**
	 * One of the fields the search reads (tcc_search_meta_keys), or "do not show in search results"
	 * (Yoast), or "Is This Group Active?", was changed on its own, without the item being saved.
	 */
	function tcc_search_field_changed( $meta_ids, $object_id, $meta_key ) {
		if ( in_array( $meta_key, array_merge( tcc_search_meta_keys(), array( '_yoast_wpseo_meta-robots-noindex', 'is_this_group_active' ) ), true ) ) {
			tcc_search_start_afresh();
		}
	}
	add_action( 'added_post_meta', 'tcc_search_field_changed', 10, 3 );
	add_action( 'updated_post_meta', 'tcc_search_field_changed', 10, 3 );
	add_action( 'deleted_post_meta', 'tcc_search_field_changed', 10, 3 );

	/** The kinds of label the search or the spelling dictionary reads, event categories included. */
	function tcc_search_watched_taxonomies() {
		return array( 'category', 'post_tag', 'trinity-talk', 'project_category', 'project_tag', 'tribe_events_cat' );
	}

	/** A label (a Bible book, a topic, a speaker, a series...) was renamed or deleted. */
	function tcc_search_label_changed( $term_id, $tt_id = 0, $taxonomy = '' ) {
		if ( in_array( $taxonomy, tcc_search_watched_taxonomies(), true ) ) {
			tcc_search_start_afresh();
		}
	}
	add_action( 'edited_term', 'tcc_search_label_changed', 10, 3 );
	add_action( 'delete_term', 'tcc_search_label_changed', 10, 3 );

	/** An item was given other labels without being saved. */
	function tcc_search_labels_given( $object_id, $terms, $tt_ids, $taxonomy, $append = false, $old_tt_ids = array() ) {
		if ( ! in_array( $taxonomy, tcc_search_watched_taxonomies(), true ) ) {
			return;
		}
		$new = array_map( 'intval', (array) $tt_ids );
		$old = array_map( 'intval', (array) $old_tt_ids );
		sort( $new );
		sort( $old );
		if ( $new !== $old ) {
			tcc_search_start_afresh();
		}
	}
	add_action( 'set_object_terms', 'tcc_search_labels_given', 10, 6 );

	/** Someone's name changed (Users > the person > "Display name publicly as"): it finds what they wrote. */
	function tcc_search_person_changed( $user_id, $old = null ) {
		$now = get_userdata( $user_id );
		if ( $old instanceof WP_User && $now instanceof WP_User && $now->display_name === $old->display_name ) {
			return;
		}
		tcc_search_start_afresh();
	}
	add_action( 'profile_update', 'tcc_search_person_changed', 10, 2 );
	add_action( 'deleted_user', 'tcc_search_start_afresh', 10, 0 );

	// The list of words that mean the same (TCC Website > Search), however it was changed.
	add_action( 'add_option_tcc_search_synonyms', 'tcc_search_start_afresh', 10, 0 );
	add_action( 'update_option_tcc_search_synonyms', 'tcc_search_start_afresh', 10, 0 );
	add_action( 'delete_option_tcc_search_synonyms', 'tcc_search_start_afresh', 10, 0 );
}
