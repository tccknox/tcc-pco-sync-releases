<?php
/**
 * TCC first-view styles: no flash of unstyled page.
 *
 * What goes wrong without it:
 *   Divi normally keeps each page's styles in a file that is linked at the top of the page. In two
 *   cases it has no file and prints the styles inside the page instead, far down, after the content
 *   they style:
 *     1. the first time each page is viewed after anything is saved in the Divi builder or the
 *        Theme Builder (a save throws the files away for the whole website), and
 *     2. on every view of a page that holds an automatic list (a Divi loop): the Sermons page, a
 *        sermon series page, the Events page, the search page.
 *   The browser then draws the top of the page with plain default styles (teal pill buttons, wrong
 *   widths) and redraws it a moment later.
 *
 * What this does:
 *   It lifts those late style blocks up into the top of the page (the "head"), where styles
 *   belong, before the page is sent. Nothing else is changed, and the order of the styles among
 *   themselves is kept. When a page holds no such block, it does nothing at all.
 *
 * It never runs in the admin screens, in the Divi editor, or for feeds and background requests.
 * To switch it off, use TCC Website > Features: those pages go back to flashing.
 *
 * It also keeps WP Rocket away from those blocks (since 0.5.4). WP Rocket's "Remove Unused CSS"
 * rebuilds each page's styles as one trimmed block. When Divi's styles were inside the page, it put
 * them BEFORE Divi's own defaults instead of after, so the defaults won. On phones that stacked the
 * logo, Give and Menu on three lines in the header, on the pages named above. WP Rocket is now told
 * to leave those blocks alone, in their place, so the order stays right.
 *
 * And it puts Divi's default styles back in front of WP Rocket's trimmed block (since 0.12.1).
 * WP Rocket leaves Divi 5's in-page copy of its main stylesheet where it is, which is after the
 * trimmed block, so Divi's defaults beat the page's own settings (14px text where the page says
 * 20px) for signed-out visitors. See tcc_first_view_styles_defaults_first() at the foot of the file.
 *
 * Part of the TCC Website Features plugin (added in 0.3.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_first_view_styles_start' ) ) {

	/**
	 * Given the finished page, moves Divi's late style blocks into the head.
	 * It looks for <style ... id="et-...cached-inline-styles..."> blocks that sit after </head>.
	 * If anything looks unusual it hands the page back exactly as it was.
	 */
	function tcc_first_view_styles_move( $html ) {
		if ( ! is_string( $html ) || false === strpos( $html, 'cached-inline-styles' ) ) {
			return $html;
		}
		$head_end = stripos( $html, '</head>' );
		if ( false === $head_end ) {
			return $html;
		}
		$head  = substr( $html, 0, $head_end );
		$body  = substr( $html, $head_end );
		$moved = '';
		$out   = '';
		$at    = 0;
		$guard = 0;
		while ( $guard++ < 50 ) {
			$open = stripos( $body, '<style', $at );
			if ( false === $open ) {
				break;
			}
			$tag_end = strpos( $body, '>', $open );
			$close   = false === $tag_end ? false : stripos( $body, '</style>', $tag_end );
			if ( false === $tag_end || false === $close ) {
				break;
			}
			$close += 8; // The length of "</style>".
			$tag    = substr( $body, $open, $tag_end - $open + 1 );
			if ( preg_match( '/\bid=["\']et-[^"\']*cached-inline-styles/i', $tag ) ) {
				$out   .= substr( $body, $at, $open - $at );
				$moved .= substr( $body, $open, $close - $open ) . "\n";
			} else {
				$out .= substr( $body, $at, $close - $at );
			}
			$at = $close;
		}
		if ( '' === $moved ) {
			return $html;
		}
		$out .= substr( $body, $at );
		return $head . $moved . $out;
	}

	/** Starts watching the page as it is built, on ordinary visitor pages only. */
	function tcc_first_view_styles_start() {
		if ( is_admin() || is_feed() || is_robots() || is_trackback() || wp_doing_ajax() || isset( $_GET['et_fb'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) ) {
			return;
		}
		ob_start( 'tcc_first_view_styles_move' );
	}
	add_action( 'template_redirect', 'tcc_first_view_styles_start', 1 );
}

if ( ! function_exists( 'tcc_first_view_styles_keep_from_wp_rocket' ) ) {

	/**
	 * Tells WP Rocket's "Remove Unused CSS" to leave Divi's in-page style blocks alone.
	 * WP Rocket skips any <style> tag whose attributes contain one of the words in this list;
	 * every block this file moves has "cached-inline-styles" in its id.
	 * Without this, WP Rocket puts those styles before Divi's defaults and the defaults win
	 * (the phone header's logo, Give and Menu stacked on three lines).
	 */
	function tcc_first_view_styles_keep_from_wp_rocket( $words ) {
		$words   = is_array( $words ) ? $words : array();
		$words[] = 'cached-inline-styles';
		return $words;
	}
	add_filter( 'rocket_rucss_inline_atts_exclusions', 'tcc_first_view_styles_keep_from_wp_rocket' );
}

if ( ! function_exists( 'tcc_first_view_styles_defaults_first' ) ) {

	/**
	 * Puts Divi's default styles back in front of WP Rocket's trimmed styles (since 0.12.1).
	 *
	 * Divi 5 prints its main stylesheet (its defaults, such as plain 14px text) inside the page,
	 * as <style id="divi-style-parent-inline-inline-css">. WP Rocket's own built-in list tells
	 * "Remove Unused CSS" to leave that one block where it is, so in WP Rocket's saved copy it
	 * ends up AFTER WP Rocket's trimmed block, which holds the page's own Divi settings. The
	 * defaults then win: on 24 November 2026 signed-out visitors saw the home page with 14px text
	 * where the page says 20px. This moves that block to just before WP Rocket's trimmed block,
	 * which is the order Divi itself uses (defaults first, the page's settings after).
	 *
	 * It runs only while WP Rocket builds its saved copy of a page (WP Rocket's "rocket_buffer"
	 * step, after Remove Unused CSS), not on every visit. If either block is missing, or Divi's
	 * block is already in front, it hands the page back exactly as it was.
	 */
	function tcc_first_view_styles_defaults_first( $html ) {
		if ( ! is_string( $html ) ) {
			return $html;
		}
		$used = tcc_first_view_styles_find_block( $html, 'wpr-usedcss' );
		if ( null === $used ) {
			return $html;
		}
		// The first id is Divi with a child theme (this website); the second is Divi on its own.
		foreach ( array( 'divi-style-parent-inline-inline-css', 'divi-style-inline-inline-css' ) as $id ) {
			$divi = tcc_first_view_styles_find_block( $html, $id );
			if ( null === $divi || $divi[0] < $used[0] ) {
				continue;
			}
			$block = substr( $html, $divi[0], $divi[1] - $divi[0] );
			$html  = substr( $html, 0, $divi[0] ) . substr( $html, $divi[1] );
			$html  = substr( $html, 0, $used[0] ) . $block . "\n" . substr( $html, $used[0] );
			$used  = tcc_first_view_styles_find_block( $html, 'wpr-usedcss' );
			if ( null === $used ) {
				break;
			}
		}
		return $html;
	}

	/**
	 * Finds <style id="..."> ... </style> with the given id.
	 * Gives back array( where it starts, where it ends ), or null if it is not there.
	 */
	function tcc_first_view_styles_find_block( $html, $id ) {
		foreach ( array( 'id="' . $id . '"', "id='" . $id . "'" ) as $needle ) {
			$attr = strpos( $html, $needle );
			if ( false === $attr ) {
				continue;
			}
			$open  = strrpos( substr( $html, 0, $attr ), '<style' );
			$close = stripos( $html, '</style>', $attr );
			if ( false === $open || false === $close ) {
				return null;
			}
			// The id must belong to that <style> tag, not to something later in the page.
			if ( false !== strpos( substr( $html, $open, $attr - $open ), '>' ) ) {
				return null;
			}
			return array( $open, $close + 8 ); // 8 is the length of "</style>".
		}
		return null;
	}
	add_filter( 'rocket_buffer', 'tcc_first_view_styles_defaults_first', 100000 );
}
