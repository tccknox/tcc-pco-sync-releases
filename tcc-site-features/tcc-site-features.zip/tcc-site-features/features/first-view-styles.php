<?php
/**
 * TCC first-view styles: no flash of unstyled page.
 *
 * What goes wrong without it:
 *   Divi normally keeps each page's styles in a file that is linked at the top of the page. In two
 *   cases it has no file and prints the styles inside the page instead, far down, after the content
 *   they style:
 *     1. the first time each page is viewed after anything is saved in the Divi builder or the
 *        Theme Builder (a save throws the files away for the whole website), and
 *     2. on every view of a page that holds an automatic list (a Divi loop): the Sermons page, a
 *        sermon series page, the Events page, the search page.
 *   The browser then draws the top of the page with plain default styles (teal pill buttons, wrong
 *   widths) and redraws it a moment later.
 *
 * What this does:
 *   It lifts those late style blocks up into the top of the page (the "head"), where styles
 *   belong, before the page is sent. Nothing else is changed, and the order of the styles among
 *   themselves is kept. When a page holds no such block, it does nothing at all.
 *
 * It never runs in the admin screens, in the Divi editor, or for feeds and background requests.
 * To switch it off, use TCC Website > Features: those pages go back to flashing.
 *
 * It also keeps WP Rocket away from those blocks (since 0.5.4). WP Rocket's "Remove Unused CSS"
 * rebuilds each page's styles as one trimmed block. When Divi's styles were inside the page, it put
 * them BEFORE Divi's own defaults instead of after, so the defaults won. On phones that stacked the
 * logo, Give and Menu on three lines in the header, on the pages named above. WP Rocket is now told
 * to leave those blocks alone, in their place, so the order stays right.
 *
 * Part of the TCC Website Features plugin (added in 0.3.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_first_view_styles_start' ) ) {

	/**
	 * Given the finished page, moves Divi's late style blocks into the head.
	 * It looks for <style ... id="et-...cached-inline-styles..."> blocks that sit after </head>.
	 * If anything looks unusual it hands the page back exactly as it was.
	 */
	function tcc_first_view_styles_move( $html ) {
		if ( ! is_string( $html ) || false === strpos( $html, 'cached-inline-styles' ) ) {
			return $html;
		}
		$head_end = stripos( $html, '</head>' );
		if ( false === $head_end ) {
			return $html;
		}
		$head  = substr( $html, 0, $head_end );
		$body  = substr( $html, $head_end );
		$moved = '';
		$out   = '';
		$at    = 0;
		$guard = 0;
		while ( $guard++ < 50 ) {
			$open = stripos( $body, '<style', $at );
			if ( false === $open ) {
				break;
			}
			$tag_end = strpos( $body, '>', $open );
			$close   = false === $tag_end ? false : stripos( $body, '</style>', $tag_end );
			if ( false === $tag_end || false === $close ) {
				break;
			}
			$close += 8; // The length of "</style>".
			$tag    = substr( $body, $open, $tag_end - $open + 1 );
			if ( preg_match( '/\bid=["\']et-[^"\']*cached-inline-styles/i', $tag ) ) {
				$out   .= substr( $body, $at, $open - $at );
				$moved .= substr( $body, $open, $close - $open ) . "\n";
			} else {
				$out .= substr( $body, $at, $close - $at );
			}
			$at = $close;
		}
		if ( '' === $moved ) {
			return $html;
		}
		$out .= substr( $body, $at );
		return $head . $moved . $out;
	}

	/** Starts watching the page as it is built, on ordinary visitor pages only. */
	function tcc_first_view_styles_start() {
		if ( is_admin() || is_feed() || is_robots() || is_trackback() || wp_doing_ajax() || isset( $_GET['et_fb'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) ) {
			return;
		}
		ob_start( 'tcc_first_view_styles_move' );
	}
	add_action( 'template_redirect', 'tcc_first_view_styles_start', 1 );
}

if ( ! function_exists( 'tcc_first_view_styles_keep_from_wp_rocket' ) ) {

	/**
	 * Tells WP Rocket's "Remove Unused CSS" to leave Divi's in-page style blocks alone.
	 * WP Rocket skips any <style> tag whose attributes contain one of the words in this list;
	 * every block this file moves has "cached-inline-styles" in its id.
	 * Without this, WP Rocket puts those styles before Divi's defaults and the defaults win
	 * (the phone header's logo, Give and Menu stacked on three lines).
	 */
	function tcc_first_view_styles_keep_from_wp_rocket( $words ) {
		$words   = is_array( $words ) ? $words : array();
		$words[] = 'cached-inline-styles';
		return $words;
	}
	add_filter( 'rocket_rucss_inline_atts_exclusions', 'tcc_first_view_styles_keep_from_wp_rocket' );
}
