<?php
/**
 * TCC Sermon speakers: pick the speakers of a sermon from a list.
 *
 * Speakers are the categories filed under "Speaker" (Posts > Categories), as they always were.
 * This file adds:
 *  1. Helpers: the list of speakers, finding or adding one, the login with a speaker's name.
 *  2. Saving: the sermon's Speaker categories, the main speaker (post meta _tcc_main_speaker), and
 *     the Speaker Name field filled in for anything still reading it ("Tyler Lynde & Amy Lynde").
 *     The Author follows the main speaker when exactly one login has that name, and only when an
 *     Editor or Administrator saves, so a pastor who posts someone else's sermon keeps their own post.
 *  3. The Speakers box on a sermon's edit screen. The Speaker part of the ordinary Categories box is
 *     hidden so there is one place to pick speakers, and Speaker Name becomes read-only once a main
 *     speaker is saved.
 *
 * Until 0.14.0 it also had a one-time fill-in (Posts > Sermon speakers) that ticked the speakers of
 * the older sermons from their typed Speaker Name, with Undo. It was run on staging on 2026-11-23 and
 * then removed. If live ever needs it (when live is not simply replaced by staging), install TCC
 * Website 0.13.3 there, run it, then update; see docs/open-items.md.
 *
 * The Speakers box's script (the "Main speaker" choice, the search line, "Add a new speaker" and
 * moving the box under Categories) is in a file of its own beside this one: features/sermon-speakers.js.
 * Its styles stay in this file: the rules that hide the Speaker part of the Categories box are built
 * from the speakers' ids, and the rest are short.
 *
 * How the website SHOWS the speakers is worked out in sermon-filters.php (tcc_sermons_speaker),
 * so it is the same whether this feature is on or off. This feature needs that one switched on.
 *
 * Part of the TCC Website Features plugin (added in 0.11.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Needs "Sermons page: search, filters and series" (sermon-filters.php). Without it, do nothing:
// the Features tab then shows this feature as needing a look.
if ( ! function_exists( 'tcc_sermons_speaker_root' ) ) {
	return;
}

/* ----------------------------------------------------------------------------------------------
 * 1. Helpers.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_norm' ) ) {

	/** A name made easy to compare: small letters, no accents, single spaces. */
	function tcc_speakers_norm( $name ) {
		$name = remove_accents( wp_specialchars_decode( (string) $name, ENT_QUOTES ) );
		$name = trim( (string) preg_replace( '/\s+/', ' ', $name ) );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
	}

	/** Every speaker (the categories filed straight under "Speaker"), A to Z: term id => name. */
	function tcc_speakers_all() {
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return array();
		}
		$terms = get_terms(
			array(
				'taxonomy'   => 'category',
				'parent'     => $root,
				'hide_empty' => false,
			)
		);
		$out = array();
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$out[ (int) $term->term_id ] = wp_specialchars_decode( $term->name, ENT_QUOTES );
		}
		uasort( $out, 'strnatcasecmp' );
		return $out;
	}

	/** The speaker with this name (ignoring capitals, accents and extra spaces), or 0. */
	function tcc_speakers_find( $name ) {
		$want = tcc_speakers_norm( $name );
		if ( '' === $want ) {
			return 0;
		}
		foreach ( tcc_speakers_all() as $id => $have ) {
			if ( tcc_speakers_norm( $have ) === $want ) {
				return (int) $id;
			}
		}
		return 0;
	}

	/**
	 * Adds a speaker under "Speaker", or finds the one already there with the same name.
	 * Returns array( 'id', 'name', 'existed' ), or a WP_Error with a message a volunteer can act on.
	 */
	function tcc_speakers_add( $name ) {
		$name = trim( (string) preg_replace( '/\s+/', ' ', (string) $name ) );
		if ( '' === $name ) {
			return new WP_Error( 'tcc_speakers_empty', 'Type the speaker\'s name first.' );
		}
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return new WP_Error( 'tcc_speakers_no_root', 'There is no "Speaker" category. Add one under Posts > Categories, with the slug "speaker".' );
		}
		$found = tcc_speakers_find( $name );
		if ( $found ) {
			$all = tcc_speakers_all();
			return array(
				'id'      => $found,
				'name'    => $all[ $found ],
				'existed' => true,
			);
		}
		$made = wp_insert_term( $name, 'category', array( 'parent' => $root ) );
		if ( is_wp_error( $made ) ) {
			return new WP_Error( 'tcc_speakers_add', 'The speaker could not be added: ' . $made->get_error_message() );
		}
		return array(
			'id'      => (int) $made['term_id'],
			'name'    => $name,
			'existed' => false,
		);
	}

	/** The login whose display name is this speaker's name, when exactly one matches; else 0. */
	function tcc_speakers_user_for( $name ) {
		$want = tcc_speakers_norm( $name );
		if ( '' === $want ) {
			return 0;
		}
		$users = get_users(
			array(
				'search'         => '*' . trim( (string) preg_replace( '/\s+/', ' ', (string) $name ) ) . '*',
				'search_columns' => array( 'display_name' ),
				'capability'     => 'edit_posts', // Only logins that can post, as in the Author dropdown.
				'fields'         => array( 'ID', 'display_name' ),
				'number'         => 20,
			)
		);
		$hits = array();
		foreach ( $users as $user ) {
			if ( tcc_speakers_norm( $user->display_name ) === $want ) {
				$hits[] = (int) $user->ID;
			}
		}
		return 1 === count( $hits ) ? $hits[0] : 0;
	}

	/** The main speaker among the ticked ones: the one asked for if it is ticked, else the first A to Z; 0 if none. */
	function tcc_speakers_pick_main( $ticked, $wanted ) {
		$all   = tcc_speakers_all();
		$names = array();
		foreach ( (array) $ticked as $id ) {
			$id = (int) $id;
			if ( isset( $all[ $id ] ) ) {
				$names[ $id ] = $all[ $id ];
			}
		}
		if ( ! $names ) {
			return 0;
		}
		$ordered = tcc_sermons_order_speakers( $names, (int) $wanted );
		return (int) key( $ordered );
	}

	/**
	 * Changes only a sermon's Author. wp_update_post would run the whole save again (re-cleaning the
	 * sermon text and firing every save hook), so the one column is changed directly.
	 */
	function tcc_speakers_set_author( $post_id, $user ) {
		global $wpdb;
		$wpdb->update( $wpdb->posts, array( 'post_author' => (int) $user ), array( 'ID' => (int) $post_id ) );
		clean_post_cache( (int) $post_id );
	}

	/** "Filled in": the sermon has a main speaker saved AND speakers ticked. The one rule used everywhere. */
	function tcc_speakers_is_filled( $post_id ) {
		return (bool) get_post_meta( (int) $post_id, '_tcc_main_speaker', true ) && (bool) tcc_speakers_of( $post_id );
	}

	/** The speaker ids ticked on a sermon. */
	function tcc_speakers_of( $post_id ) {
		$cats = array_map( 'intval', (array) wp_get_post_categories( (int) $post_id ) );
		return array_values( array_intersect( $cats, array_keys( tcc_speakers_all() ) ) );
	}
}

/* ----------------------------------------------------------------------------------------------
 * 2. Saving.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_apply' ) ) {

	/**
	 * Saves who spoke: the sermon's Speaker categories (its other categories are kept), the main
	 * speaker, and the Speaker Name field. With $author true the Author follows the main speaker
	 * when exactly one login has that name. Nothing ticked takes the speakers off and forgets the
	 * main speaker; the typed Speaker Name is then left as it was.
	 */
	function tcc_speakers_apply( $post_id, $ticked, $main, $author ) {
		$post_id = (int) $post_id;
		$all     = tcc_speakers_all();
		$ticked  = array_values( array_intersect( array_map( 'intval', (array) $ticked ), array_keys( $all ) ) );
		$keep    = array_diff( array_map( 'intval', (array) wp_get_post_categories( $post_id ) ), array_keys( $all ) );

		$GLOBALS['tcc_speakers_busy'] = true; // So the save hooks below leave our own saves alone.
		try {
			// The Categories box no longer shows speakers, so a speaker-only save sends no other
			// category and WordPress adds the default one ("Uncategorized"). Do not keep that.
			if ( $ticked && array( (int) get_option( 'default_category' ) ) === array_values( $keep ) ) {
				$keep = array();
			}
			wp_set_post_categories( $post_id, array_values( array_unique( array_merge( $keep, $ticked ) ) ) );
			if ( ! $ticked ) {
				delete_post_meta( $post_id, '_tcc_main_speaker' );
			} else {
				$main  = tcc_speakers_pick_main( $ticked, $main );
				$names = array_intersect_key( $all, array_flip( $ticked ) );
				update_post_meta( $post_id, '_tcc_main_speaker', $main );
				update_post_meta( $post_id, 'speaker_name', tcc_sermons_join_names( tcc_sermons_order_speakers( $names, $main ) ) );
				if ( $author ) {
					$user = tcc_speakers_user_for( $all[ $main ] );
					if ( $user && (int) get_post_field( 'post_author', $post_id ) !== $user ) {
						tcc_speakers_set_author( $post_id, $user );
					}
				}
			}
		} finally {
			$GLOBALS['tcc_speakers_busy'] = false; // Always put back, even if something above failed.
		}
		tcc_sermons_bump();
	}

	/** Did this save come from the Speakers box on THIS sermon's edit screen, with its security check? */
	function tcc_speakers_box_sent( $post_id ) {
		return isset( $_POST['tcc_speakers_nonce'], $_POST['post_ID'] )
			&& (int) wp_unslash( $_POST['post_ID'] ) === (int) $post_id
			&& wp_verify_nonce( sanitize_key( wp_unslash( $_POST['tcc_speakers_nonce'] ) ), 'tcc_speakers_save' );
	}

	/**
	 * Should this save use what the Speakers box sent? Yes when it came from this sermon's box, and
	 * either the sermon already has a main speaker, or someone ticked or unticked something in the box.
	 * A sermon that has not been filled in yet is left alone by an everyday save (fixing a typo), so
	 * its typed speakers are never replaced by whatever categories happened to be ticked.
	 */
	function tcc_speakers_box_applies( $post_id ) {
		if ( ! tcc_speakers_box_sent( $post_id ) ) {
			return false;
		}
		if ( tcc_speakers_is_filled( $post_id ) ) {
			return true;
		}
		$touched = isset( $_POST['tcc_speakers_touched'] ) ? wp_unslash( $_POST['tcc_speakers_touched'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput -- checked in tcc_speakers_box_sent(); only compared with "1".
		return is_string( $touched ) && '1' === $touched;
	}

	/** What the Speakers box sent: array( ticked speaker ids, the main speaker asked for ). */
	function tcc_speakers_box_values() {
		$ticked = isset( $_POST['tcc_speakers'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['tcc_speakers'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification -- checked in tcc_speakers_box_sent().
		$main   = isset( $_POST['tcc_main_speaker'] ) ? (int) wp_unslash( $_POST['tcc_main_speaker'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		return array( $ticked, $main );
	}

	// The Author is set here, before WordPress saves the sermon, so nothing is saved twice.
	// Only for an Editor or Administrator: someone with the Author role keeps their own post.
	add_filter(
		'wp_insert_post_data',
		function ( $data, $postarr = array() ) {
			// No post id given: leave the Author alone (the save_post step still saves the speakers).
			$id = (int) ( $postarr['ID'] ?? 0 );
			if ( ! empty( $GLOBALS['tcc_speakers_busy'] ) || 'post' !== $data['post_type'] || ! $id || ! tcc_speakers_box_applies( $id ) || ! current_user_can( 'edit_others_posts' ) ) {
				return $data;
			}
			list( $ticked, $wanted ) = tcc_speakers_box_values();
			$main = tcc_speakers_pick_main( $ticked, $wanted );
			if ( ! $main ) {
				return $data;
			}
			$all  = tcc_speakers_all();
			$user = tcc_speakers_user_for( $all[ $main ] );
			if ( $user ) {
				$data['post_author'] = $user;
			}
			return $data;
		},
		20,
		2
	);

	// The speakers, main speaker and Speaker Name. On save_post at 20, after ACF has saved its fields
	// (save_post at 10), so the filled-in Speaker Name is the one that stays.
	add_action(
		'save_post',
		function ( $post_id, $post ) {
			if ( ! empty( $GLOBALS['tcc_speakers_busy'] ) || ! ( $post instanceof WP_Post ) || 'post' !== $post->post_type ) {
				return;
			}
			if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! tcc_speakers_box_applies( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
			list( $ticked, $main ) = tcc_speakers_box_values();
			tcc_speakers_apply( $post_id, $ticked, $main, false );
		},
		20,
		2
	);
}

/* ----------------------------------------------------------------------------------------------
 * 3. The Speakers box on a sermon's edit screen.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_box' ) ) {

	add_action(
		'add_meta_boxes_post',
		function () {
			add_meta_box( 'tcc-speakers-box', 'Speakers', 'tcc_speakers_box', 'post', 'side', 'core' );
		}
	);

	// "+ Add New Category" in the ordinary Categories box must not offer Speaker (or a speaker) as the parent.
	add_filter(
		'post_edit_category_parent_dropdown_args',
		function ( $args ) {
			$root = tcc_sermons_speaker_root();
			if ( $root && ( empty( $args['post_type'] ) || 'post' === $args['post_type'] ) ) {
				$args['exclude_tree'] = $root;
			}
			return $args;
		}
	);

	/** One line of the box. The server also sends this markup for a speaker added on the page. */
	function tcc_speakers_row( $id, $name, $on, $main ) {
		return '<li class="tcc-spk-row' . ( $on ? ' is-on' : '' ) . '" data-name="' . esc_attr( tcc_speakers_norm( $name ) ) . '">'
			. '<label class="tcc-spk-tick"><input type="checkbox" name="tcc_speakers[]" value="' . (int) $id . '"' . checked( $on, true, false ) . '> ' . esc_html( $name ) . '</label>'
			. '<label class="tcc-spk-main"><input type="radio" name="tcc_main_speaker" value="' . (int) $id . '"' . checked( $main, true, false ) . '> Main speaker<span class="screen-reader-text"> (' . esc_html( $name ) . ')</span></label>'
			. '</li>';
	}

	/** The Speakers box: a tick for everyone under "Speaker", a Main speaker choice, and Add a new speaker. */
	function tcc_speakers_box( $post ) {
		if ( ! tcc_sermons_speaker_root() ) {
			echo '<p>There is no "Speaker" category yet. Add a category named Speaker (slug <code>speaker</code>) under Posts &rarr; Categories, then reload this page.</p>';
			return;
		}
		$all    = tcc_speakers_all();
		$ticked = tcc_speakers_of( $post->ID );
		$saved  = (int) get_post_meta( $post->ID, '_tcc_main_speaker', true );
		$main   = tcc_speakers_pick_main( $ticked, $saved );
		$typed  = trim( (string) get_post_meta( $post->ID, 'speaker_name', true ) );
		$note   = '';
		$use   = false;
		$first = '';
		if ( '' !== $typed && ! tcc_speakers_is_filled( $post->ID ) ) {
			// Not filled in yet: pre-tick what the typed name says, when that is clear. Nothing is saved
			// until someone ticks or unticks (see tcc_speakers_box_applies).
			$current = array_intersect_key( $all, array_flip( $ticked ) );
			$one     = tcc_speakers_plan_one( $typed, $current, $all );
			$note    = 'The website shows the typed name <strong>' . esc_html( $typed ) . '</strong> until this sermon is saved with its speakers ticked here. Nothing here changes until you tick or untick someone.';
			if ( '' === $one['look'] ) {
				$ids = array();
				foreach ( $one['names'] as $name ) {
					$found = tcc_speakers_find( $name );
					if ( $found ) {
						$ids[] = $found;
					}
				}
				if ( $ids ) {
					$ticked = $ids;
					$use    = true;
					// The first typed name is the main speaker, unless that person is not a speaker yet.
					$first_new = $one['create'] && tcc_speakers_norm( $one['create'][0] ) === tcc_speakers_norm( $one['names'][0] );
					$main      = $first_new ? 0 : $ids[0];
				}
				if ( $one['create'] ) {
					$note .= ' Not in the list yet: ' . esc_html( implode( ', ', $one['create'] ) ) . '. Add them below if they spoke, or they will be left out of Speaker Name when you save.';
					if ( ! empty( $first_new ) ) {
						$note .= ' The first name typed, ' . esc_html( $one['create'][0] ) . ', is not in the list yet: add them below and choose them as main speaker.';
						$first = tcc_speakers_norm( $one['create'][0] );
					}
				}
			} else {
				$note .= ' ' . esc_html( $one['look'] );
			}
		}

		wp_nonce_field( 'tcc_speakers_save', 'tcc_speakers_nonce' );
		echo '<input type="hidden" name="tcc_speakers_touched" value="0" id="tcc-spk-touched" autocomplete="off" data-first="' . esc_attr( $first ) . '">';
		echo '<p class="tcc-spk-help">Tick everyone who spoke, then choose the main speaker. The website shows the main speaker first.</p>';
		if ( '' !== $note ) {
			echo '<p class="tcc-spk-note">' . $note . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every part is escaped above.
		}
		if ( $use ) {
			echo '<p><button type="button" class="button" id="tcc-spk-use">Use these speakers</button> <span class="tcc-spk-use-status" id="tcc-spk-use-status" aria-live="polite"></span></p>';
		}
		if ( count( $all ) > 10 ) {
			echo '<p><label class="screen-reader-text" for="tcc-spk-search">Find a speaker</label><input type="search" id="tcc-spk-search" class="tcc-spk-search" placeholder="Find a speaker" autocomplete="off"></p>';
		}
		echo '<ul class="tcc-spk-list">';
		foreach ( $all as $id => $name ) {
			echo tcc_speakers_row( $id, $name, in_array( (int) $id, $ticked, true ), (int) $id === $main ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in tcc_speakers_row().
		}
		echo '</ul>';
		if ( ! $all ) {
			echo '<p class="tcc-spk-empty">No speakers yet. Add the first one below.</p>';
		}
		if ( current_user_can( 'manage_categories' ) ) {
			echo '<div class="tcc-spk-add"><label for="tcc-spk-new">Add a new speaker</label>'
				. '<div class="tcc-spk-add-row"><input type="text" id="tcc-spk-new" autocomplete="off" placeholder="First and last name">'
				. '<button type="button" class="button" id="tcc-spk-add-btn" data-nonce="' . esc_attr( wp_create_nonce( 'tcc_add_speaker' ) ) . '">Add</button></div>'
				. '<p class="tcc-spk-status" aria-live="polite"></p></div>';
		}
	}

	/** Is this the edit screen of a sermon (a Post)? */
	function tcc_speakers_on_edit_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && 'post' === $screen->base && 'post' === $screen->post_type;
	}

	/**
	 * CSS that hides the Speaker part of the ordinary Categories box, so speakers are picked in one place.
	 * Newer WordPress gives the rows ids like "in-category-2-1", older ones "category-2", so ids alone
	 * do not match. The value of the tick box is the category id WordPress saves, the same in every
	 * version, so each row is found by that (the old id selectors are kept as a fallback). WordPress
	 * also moves ticked categories to the top of the box, outside their parent, so every speaker is
	 * hidden by itself as well as the Speaker branch. The hidden ticks are still sent; the save
	 * replaces them with what the Speakers box says.
	 */
	function tcc_speakers_hide_css() {
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return '';
		}
		$hide = array();
		$old  = array();
		foreach ( array_merge( array( (int) $root ), array_map( 'intval', array_keys( tcc_speakers_all() ) ) ) as $id ) {
			$hide[] = '#categorychecklist li:has(> label > input[value="' . $id . '"])';
			$hide[] = '#categorychecklist-pop li:has(input[value="' . $id . '"])';
			$old[]  = '#categorychecklist #category-' . $id;
			$old[]  = '#categorychecklist-pop #popular-category-' . $id;
		}
		// Two rules: a browser that does not know :has() drops only the first, not the old-id fallback.
		return implode( ',', $hide ) . '{display:none}' . implode( ',', $old ) . '{display:none}';
	}

	add_action(
		'admin_head',
		function () {
			if ( ! tcc_speakers_on_edit_screen() ) {
				return;
			}
			$css = '#tcc-speakers-box .tcc-spk-help{margin:0 0 10px;color:#50575e}'
				. '#tcc-speakers-box .tcc-spk-note{background:#fcf9e8;border-left:4px solid #dba617;padding:6px 10px;margin:0 0 10px}'
				. '#tcc-speakers-box .tcc-spk-search{width:100%;min-height:36px}'
				. '#tcc-speakers-box .tcc-spk-list{margin:0;max-height:320px;overflow:auto;border:1px solid #dcdcde;border-radius:4px;padding:2px 0}'
				. '#tcc-speakers-box .tcc-spk-row{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:2px 12px;margin:0;padding:4px 10px;border-bottom:1px solid #f0f0f1}'
				. '#tcc-speakers-box .tcc-spk-row:last-child{border-bottom:0}'
				. '#tcc-speakers-box .tcc-spk-row[hidden]{display:none}' // The search hides rows with the hidden attribute; display:flex above would otherwise win.
				. '#tcc-speakers-box .tcc-spk-row.is-on{background:#eef8fb}'
				. '#tcc-speakers-box .tcc-spk-row label{display:inline-flex;align-items:center;gap:8px;min-height:36px;cursor:pointer;font-size:14px}'
				. '#tcc-speakers-box .tcc-spk-row input{margin:0}'
				. '#tcc-speakers-box .tcc-spk-tick{flex:1}'
				. '#tcc-speakers-box .tcc-spk-main{color:#50575e;font-size:13px}'
				. '#tcc-speakers-box .tcc-spk-row:not(.is-on) .tcc-spk-main{display:none}'
				. '#tcc-speakers-box .tcc-spk-add{margin-top:12px}'
				. '#tcc-speakers-box .tcc-spk-add label{display:block;font-weight:600;margin-bottom:4px}'
				. '#tcc-speakers-box .tcc-spk-add-row{display:flex;gap:8px}'
				. '#tcc-speakers-box .tcc-spk-add-row input{flex:1;min-width:0;min-height:36px}'
				. '#tcc-speakers-box .tcc-spk-status{margin:6px 0 0;min-height:1em}';
			echo '<style id="tcc-speakers-css">' . tcc_speakers_hide_css() . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed CSS and integer ids.
		}
	);

	// The Speakers box's script, from features/sermon-speakers.js. It needs nothing from PHP: what it
	// uses (the Add button's security code, the first typed name) is on the box's own fields.
	// The "\n" after it is the line break the file's last line had.
	add_action(
		'admin_footer',
		function () {
			if ( ! tcc_speakers_on_edit_screen() ) {
				return;
			}
			?>
<script id="tcc-speakers-js">
<?php echo tcc_site_asset( 'features/sermon-speakers.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
			<?php
		}
	);

	// "Add" in the Speakers box.
	add_action(
		'wp_ajax_tcc_add_speaker',
		function () {
			check_ajax_referer( 'tcc_add_speaker' );
			if ( ! current_user_can( 'manage_categories' ) ) {
				wp_send_json_error( array( 'message' => 'Only an Editor or Administrator can add a speaker. Ask one of them, or tick an existing speaker.' ), 403 );
			}
			$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
			$made = tcc_speakers_add( $name );
			if ( is_wp_error( $made ) ) {
				wp_send_json_error( array( 'message' => $made->get_error_message() ) );
			}
			$made['row'] = tcc_speakers_row( $made['id'], $made['name'], false, false );
			wp_send_json_success( $made );
		}
	);

	// Speaker Name (Sermon Info) is filled in for you once the sermon has a main speaker.
	add_filter(
		'acf/prepare_field/name=speaker_name',
		function ( $field ) {
			$post = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
			if ( is_array( $field ) && $post instanceof WP_Post && tcc_speakers_is_filled( $post->ID ) ) {
				$field['readonly']     = 1;
				$field['instructions'] = 'Filled in automatically from the Speakers box.';
			}
			return $field;
		}
	);
}

/* ----------------------------------------------------------------------------------------------
 * 4. Reading a typed Speaker Name (used by the Speakers box to tick the typed names that are
 *    already speakers, and to say which ones are not in the list yet).
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_plan_one' ) ) {

	/**
	 * How one sermon's typed Speaker Name maps onto the speakers.
	 * $typed its Speaker Name; $current the speakers ticked on it (id => name); $all every speaker (id => name).
	 * Returns array(
	 *   'names'  => the people in order, the main speaker (the first typed name) first,
	 *   'create' => typed names that are not speakers yet,
	 *   'look'   => '' or why a person should look at this sermon instead,
	 * ).
	 */
	function tcc_speakers_plan_one( $typed, $current, $all ) {
		$typed = trim( html_entity_decode( (string) $typed, ENT_QUOTES, 'UTF-8' ) );
		$look  = function ( $why ) {
			return array(
				'names'  => array(),
				'create' => array(),
				'look'   => $why,
			);
		};
		if ( '' !== $typed && false !== stripos( $typed, 'trinity community' ) ) {
			return $look( 'The typed name is the church, not a person. Tick the speaker by hand.' );
		}
		if ( preg_match( '/\s[-\x{2013}\x{2014}]\s/u', $typed ) ) {
			return $look( 'The typed name uses a dash; it may be two people. Tick the speakers by hand.' );
		}
		$typed_names = '' === $typed ? array() : array_values( tcc_sermons_speaker_names( $typed ) );
		if ( ! $typed_names && ! $current ) {
			return $look( 'No speaker is typed or ticked.' );
		}
		$known = array();
		foreach ( (array) $all as $name ) {
			$known[ tcc_speakers_norm( $name ) ] = $name;
		}
		$ticked = array();
		foreach ( (array) $current as $name ) {
			$ticked[ tcc_speakers_norm( $name ) ] = $name;
		}
		$typed_keys = array_flip( array_map( 'tcc_speakers_norm', $typed_names ) );
		if ( $typed_names && $ticked && ! array_intersect_key( $typed_keys, $ticked ) ) {
			return $look( 'The typed name (' . $typed . ') and the ticked speaker (' . implode( ', ', $current ) . ') disagree.' );
		}
		$names  = array();
		$create = array();
		foreach ( $typed_names as $name ) {
			$key = tcc_speakers_norm( $name );
			if ( isset( $names[ $key ] ) ) {
				continue;
			}
			if ( isset( $known[ $key ] ) ) {
				$names[ $key ] = $known[ $key ];
			} else {
				if ( ! preg_match( '/\s/', $name ) || preg_match( '/\d/', $name ) || preg_match( '/[()]/', $name ) || preg_match( '/\b(?:guest|speakers?|team|various|panel|staff|worship)\b/i', $name ) || preg_match( '/^(?:pastor|pr|rev|reverend|dr|elder|bishop|brother|sister|mr|mrs|ms)\.?(?:\s|$)/i', $name ) ) {
					return $look( $name . ' looks like part of a name or has a title. Tick the speakers by hand.' );
				}
				$names[ $key ] = $name;
				$create[]      = $name;
			}
		}
		foreach ( $ticked as $key => $name ) {
			if ( ! isset( $names[ $key ] ) ) {
				$names[ $key ] = $name;
			}
		}
		return array(
			'names'  => array_values( $names ),
			'create' => $create,
			'look'   => '',
		);
	}
}
