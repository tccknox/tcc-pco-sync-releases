<?php
/**
 * TCC Sermon speakers: pick the speakers of a sermon from a list.
 *
 * Speakers are the categories filed under "Speaker" (Posts > Categories), as they always were.
 * This file adds:
 *  1. Helpers: the list of speakers, finding or adding one, the login with a speaker's name.
 *  2. Saving: the sermon's Speaker categories, the main speaker (post meta _tcc_main_speaker), and
 *     the Speaker Name field filled in for anything still reading it ("Tyler Lynde & Amy Lynde").
 *     The Author follows the main speaker when exactly one login has that name, and only when an
 *     Editor or Administrator saves, so a pastor who posts someone else's sermon keeps their own post.
 *  3. The Speakers box on a sermon's edit screen. The Speaker part of the ordinary Categories box is
 *     hidden so there is one place to pick speakers, and Speaker Name becomes read-only once a main
 *     speaker is saved.
 *  4. The one-time fill-in from typed names, and Undo.
 *  5. The page Posts > Sermon speakers (status, preview, fill-in, sermons that need a look, Undo).
 *
 * How the website SHOWS the speakers is worked out in sermon-filters.php (tcc_sermons_speaker),
 * so it is the same whether this feature is on or off. This feature needs that one switched on.
 *
 * Part of the TCC Website Features plugin (added in 0.11.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Needs "Sermons page: search, filters and series" (sermon-filters.php). Without it, do nothing:
// the Features tab then shows this feature as needing a look.
if ( ! function_exists( 'tcc_sermons_speaker_root' ) ) {
	return;
}

/* ----------------------------------------------------------------------------------------------
 * 1. Helpers.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_norm' ) ) {

	/** A name made easy to compare: small letters, no accents, single spaces. */
	function tcc_speakers_norm( $name ) {
		$name = remove_accents( wp_specialchars_decode( (string) $name, ENT_QUOTES ) );
		$name = trim( (string) preg_replace( '/\s+/', ' ', $name ) );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
	}

	/** Every speaker (the categories filed straight under "Speaker"), A to Z: term id => name. */
	function tcc_speakers_all() {
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return array();
		}
		$terms = get_terms(
			array(
				'taxonomy'   => 'category',
				'parent'     => $root,
				'hide_empty' => false,
			)
		);
		$out = array();
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$out[ (int) $term->term_id ] = wp_specialchars_decode( $term->name, ENT_QUOTES );
		}
		uasort( $out, 'strnatcasecmp' );
		return $out;
	}

	/** The speaker with this name (ignoring capitals, accents and extra spaces), or 0. */
	function tcc_speakers_find( $name ) {
		$want = tcc_speakers_norm( $name );
		if ( '' === $want ) {
			return 0;
		}
		foreach ( tcc_speakers_all() as $id => $have ) {
			if ( tcc_speakers_norm( $have ) === $want ) {
				return (int) $id;
			}
		}
		return 0;
	}

	/**
	 * Adds a speaker under "Speaker", or finds the one already there with the same name.
	 * Returns array( 'id', 'name', 'existed' ), or a WP_Error with a message a volunteer can act on.
	 */
	function tcc_speakers_add( $name ) {
		$name = trim( (string) preg_replace( '/\s+/', ' ', (string) $name ) );
		if ( '' === $name ) {
			return new WP_Error( 'tcc_speakers_empty', 'Type the speaker\'s name first.' );
		}
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return new WP_Error( 'tcc_speakers_no_root', 'There is no "Speaker" category. Add one under Posts > Categories, with the slug "speaker".' );
		}
		$found = tcc_speakers_find( $name );
		if ( $found ) {
			$all = tcc_speakers_all();
			return array(
				'id'      => $found,
				'name'    => $all[ $found ],
				'existed' => true,
			);
		}
		$made = wp_insert_term( $name, 'category', array( 'parent' => $root ) );
		if ( is_wp_error( $made ) ) {
			return new WP_Error( 'tcc_speakers_add', 'The speaker could not be added: ' . $made->get_error_message() );
		}
		return array(
			'id'      => (int) $made['term_id'],
			'name'    => $name,
			'existed' => false,
		);
	}

	/** The login whose display name is this speaker's name, when exactly one matches; else 0. */
	function tcc_speakers_user_for( $name ) {
		$want = tcc_speakers_norm( $name );
		if ( '' === $want ) {
			return 0;
		}
		$users = get_users(
			array(
				'search'         => '*' . trim( (string) preg_replace( '/\s+/', ' ', (string) $name ) ) . '*',
				'search_columns' => array( 'display_name' ),
				'capability'     => 'edit_posts', // Only logins that can post, as in the Author dropdown.
				'fields'         => array( 'ID', 'display_name' ),
				'number'         => 20,
			)
		);
		$hits = array();
		foreach ( $users as $user ) {
			if ( tcc_speakers_norm( $user->display_name ) === $want ) {
				$hits[] = (int) $user->ID;
			}
		}
		return 1 === count( $hits ) ? $hits[0] : 0;
	}

	/** The main speaker among the ticked ones: the one asked for if it is ticked, else the first A to Z; 0 if none. */
	function tcc_speakers_pick_main( $ticked, $wanted ) {
		$all   = tcc_speakers_all();
		$names = array();
		foreach ( (array) $ticked as $id ) {
			$id = (int) $id;
			if ( isset( $all[ $id ] ) ) {
				$names[ $id ] = $all[ $id ];
			}
		}
		if ( ! $names ) {
			return 0;
		}
		$ordered = tcc_sermons_order_speakers( $names, (int) $wanted );
		return (int) key( $ordered );
	}

	/**
	 * Changes only a sermon's Author. wp_update_post would run the whole save again (re-cleaning the
	 * sermon text and firing every save hook), so the one column is changed directly.
	 */
	function tcc_speakers_set_author( $post_id, $user ) {
		global $wpdb;
		$wpdb->update( $wpdb->posts, array( 'post_author' => (int) $user ), array( 'ID' => (int) $post_id ) );
		clean_post_cache( (int) $post_id );
	}

	/** "Filled in": the sermon has a main speaker saved AND speakers ticked. The one rule used everywhere. */
	function tcc_speakers_is_filled( $post_id ) {
		return (bool) get_post_meta( (int) $post_id, '_tcc_main_speaker', true ) && (bool) tcc_speakers_of( $post_id );
	}

	/** The speaker ids ticked on a sermon. */
	function tcc_speakers_of( $post_id ) {
		$cats = array_map( 'intval', (array) wp_get_post_categories( (int) $post_id ) );
		return array_values( array_intersect( $cats, array_keys( tcc_speakers_all() ) ) );
	}
}

/* ----------------------------------------------------------------------------------------------
 * 2. Saving.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_apply' ) ) {

	/**
	 * Saves who spoke: the sermon's Speaker categories (its other categories are kept), the main
	 * speaker, and the Speaker Name field. With $author true the Author follows the main speaker
	 * when exactly one login has that name. Nothing ticked takes the speakers off and forgets the
	 * main speaker; the typed Speaker Name is then left as it was.
	 */
	function tcc_speakers_apply( $post_id, $ticked, $main, $author ) {
		$post_id = (int) $post_id;
		$all     = tcc_speakers_all();
		$ticked  = array_values( array_intersect( array_map( 'intval', (array) $ticked ), array_keys( $all ) ) );
		$keep    = array_diff( array_map( 'intval', (array) wp_get_post_categories( $post_id ) ), array_keys( $all ) );

		$GLOBALS['tcc_speakers_busy'] = true; // So the save hooks below leave our own saves alone.
		try {
			// The Categories box no longer shows speakers, so a speaker-only save sends no other
			// category and WordPress adds the default one ("Uncategorized"). Do not keep that.
			if ( $ticked && array( (int) get_option( 'default_category' ) ) === array_values( $keep ) ) {
				$keep = array();
			}
			wp_set_post_categories( $post_id, array_values( array_unique( array_merge( $keep, $ticked ) ) ) );
			if ( ! $ticked ) {
				delete_post_meta( $post_id, '_tcc_main_speaker' );
			} else {
				$main  = tcc_speakers_pick_main( $ticked, $main );
				$names = array_intersect_key( $all, array_flip( $ticked ) );
				update_post_meta( $post_id, '_tcc_main_speaker', $main );
				update_post_meta( $post_id, 'speaker_name', tcc_sermons_join_names( tcc_sermons_order_speakers( $names, $main ) ) );
				if ( $author ) {
					$user = tcc_speakers_user_for( $all[ $main ] );
					if ( $user && (int) get_post_field( 'post_author', $post_id ) !== $user ) {
						tcc_speakers_set_author( $post_id, $user );
					}
				}
			}
		} finally {
			$GLOBALS['tcc_speakers_busy'] = false; // Always put back, even if something above failed.
		}
		tcc_sermons_bump();
	}

	/** Did this save come from the Speakers box on THIS sermon's edit screen, with its security check? */
	function tcc_speakers_box_sent( $post_id ) {
		return isset( $_POST['tcc_speakers_nonce'], $_POST['post_ID'] )
			&& (int) wp_unslash( $_POST['post_ID'] ) === (int) $post_id
			&& wp_verify_nonce( sanitize_key( wp_unslash( $_POST['tcc_speakers_nonce'] ) ), 'tcc_speakers_save' );
	}

	/**
	 * Should this save use what the Speakers box sent? Yes when it came from this sermon's box, and
	 * either the sermon already has a main speaker, or someone ticked or unticked something in the box.
	 * A sermon that has not been filled in yet is left alone by an everyday save (fixing a typo), so
	 * its typed speakers are never replaced by whatever categories happened to be ticked.
	 */
	function tcc_speakers_box_applies( $post_id ) {
		if ( ! tcc_speakers_box_sent( $post_id ) ) {
			return false;
		}
		if ( tcc_speakers_is_filled( $post_id ) ) {
			return true;
		}
		$touched = isset( $_POST['tcc_speakers_touched'] ) ? wp_unslash( $_POST['tcc_speakers_touched'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput -- checked in tcc_speakers_box_sent(); only compared with "1".
		return is_string( $touched ) && '1' === $touched;
	}

	/** What the Speakers box sent: array( ticked speaker ids, the main speaker asked for ). */
	function tcc_speakers_box_values() {
		$ticked = isset( $_POST['tcc_speakers'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['tcc_speakers'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification -- checked in tcc_speakers_box_sent().
		$main   = isset( $_POST['tcc_main_speaker'] ) ? (int) wp_unslash( $_POST['tcc_main_speaker'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		return array( $ticked, $main );
	}

	// The Author is set here, before WordPress saves the sermon, so nothing is saved twice.
	// Only for an Editor or Administrator: someone with the Author role keeps their own post.
	add_filter(
		'wp_insert_post_data',
		function ( $data, $postarr = array() ) {
			// No post id given: leave the Author alone (the save_post step still saves the speakers).
			$id = (int) ( $postarr['ID'] ?? 0 );
			if ( ! empty( $GLOBALS['tcc_speakers_busy'] ) || 'post' !== $data['post_type'] || ! $id || ! tcc_speakers_box_applies( $id ) || ! current_user_can( 'edit_others_posts' ) ) {
				return $data;
			}
			list( $ticked, $wanted ) = tcc_speakers_box_values();
			$main = tcc_speakers_pick_main( $ticked, $wanted );
			if ( ! $main ) {
				return $data;
			}
			$all  = tcc_speakers_all();
			$user = tcc_speakers_user_for( $all[ $main ] );
			if ( $user ) {
				$data['post_author'] = $user;
			}
			return $data;
		},
		20,
		2
	);

	// The speakers, main speaker and Speaker Name. On save_post at 20, after ACF has saved its fields
	// (save_post at 10), so the filled-in Speaker Name is the one that stays.
	add_action(
		'save_post',
		function ( $post_id, $post ) {
			if ( ! empty( $GLOBALS['tcc_speakers_busy'] ) || ! ( $post instanceof WP_Post ) || 'post' !== $post->post_type ) {
				return;
			}
			if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! tcc_speakers_box_applies( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
			list( $ticked, $main ) = tcc_speakers_box_values();
			tcc_speakers_apply( $post_id, $ticked, $main, false );
		},
		20,
		2
	);
}

/* ----------------------------------------------------------------------------------------------
 * 3. The Speakers box on a sermon's edit screen.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_box' ) ) {

	add_action(
		'add_meta_boxes_post',
		function () {
			add_meta_box( 'tcc-speakers-box', 'Speakers', 'tcc_speakers_box', 'post', 'side', 'core' );
		}
	);

	// "+ Add New Category" in the ordinary Categories box must not offer Speaker (or a speaker) as the parent.
	add_filter(
		'post_edit_category_parent_dropdown_args',
		function ( $args ) {
			$root = tcc_sermons_speaker_root();
			if ( $root && ( empty( $args['post_type'] ) || 'post' === $args['post_type'] ) ) {
				$args['exclude_tree'] = $root;
			}
			return $args;
		}
	);

	/** One line of the box. The server also sends this markup for a speaker added on the page. */
	function tcc_speakers_row( $id, $name, $on, $main ) {
		return '<li class="tcc-spk-row' . ( $on ? ' is-on' : '' ) . '" data-name="' . esc_attr( tcc_speakers_norm( $name ) ) . '">'
			. '<label class="tcc-spk-tick"><input type="checkbox" name="tcc_speakers[]" value="' . (int) $id . '"' . checked( $on, true, false ) . '> ' . esc_html( $name ) . '</label>'
			. '<label class="tcc-spk-main"><input type="radio" name="tcc_main_speaker" value="' . (int) $id . '"' . checked( $main, true, false ) . '> Main speaker<span class="screen-reader-text"> (' . esc_html( $name ) . ')</span></label>'
			. '</li>';
	}

	/** The Speakers box: a tick for everyone under "Speaker", a Main speaker choice, and Add a new speaker. */
	function tcc_speakers_box( $post ) {
		if ( ! tcc_sermons_speaker_root() ) {
			echo '<p>There is no "Speaker" category yet. Add a category named Speaker (slug <code>speaker</code>) under Posts &rarr; Categories, then reload this page.</p>';
			return;
		}
		$all    = tcc_speakers_all();
		$ticked = tcc_speakers_of( $post->ID );
		$saved  = (int) get_post_meta( $post->ID, '_tcc_main_speaker', true );
		$main   = tcc_speakers_pick_main( $ticked, $saved );
		$typed  = trim( (string) get_post_meta( $post->ID, 'speaker_name', true ) );
		$note   = '';
		$use   = false;
		$first = '';
		if ( '' !== $typed && ! tcc_speakers_is_filled( $post->ID ) ) {
			// Not filled in yet: pre-tick what the typed name says, when that is clear. Nothing is saved
			// until someone ticks or unticks (see tcc_speakers_box_applies).
			$current = array_intersect_key( $all, array_flip( $ticked ) );
			$one     = tcc_speakers_plan_one( $typed, $current, $all );
			$note    = 'The website shows the typed name <strong>' . esc_html( $typed ) . '</strong> until this sermon is saved with its speakers ticked here. Nothing here changes until you tick or untick someone.';
			if ( '' === $one['look'] ) {
				$ids = array();
				foreach ( $one['names'] as $name ) {
					$found = tcc_speakers_find( $name );
					if ( $found ) {
						$ids[] = $found;
					}
				}
				if ( $ids ) {
					$ticked = $ids;
					$use    = true;
					// The first typed name is the main speaker, unless that person is not a speaker yet.
					$first_new = $one['create'] && tcc_speakers_norm( $one['create'][0] ) === tcc_speakers_norm( $one['names'][0] );
					$main      = $first_new ? 0 : $ids[0];
				}
				if ( $one['create'] ) {
					$note .= ' Not in the list yet: ' . esc_html( implode( ', ', $one['create'] ) ) . '. Add them below if they spoke, or they will be left out of Speaker Name when you save.';
					if ( ! empty( $first_new ) ) {
						$note .= ' The first name typed, ' . esc_html( $one['create'][0] ) . ', is not in the list yet: add them below and choose them as main speaker.';
						$first = tcc_speakers_norm( $one['create'][0] );
					}
				}
			} else {
				$note .= ' ' . esc_html( $one['look'] );
			}
		}

		wp_nonce_field( 'tcc_speakers_save', 'tcc_speakers_nonce' );
		echo '<input type="hidden" name="tcc_speakers_touched" value="0" id="tcc-spk-touched" autocomplete="off" data-first="' . esc_attr( $first ) . '">';
		echo '<p class="tcc-spk-help">Tick everyone who spoke, then choose the main speaker. The website shows the main speaker first.</p>';
		if ( '' !== $note ) {
			echo '<p class="tcc-spk-note">' . $note . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every part is escaped above.
		}
		if ( $use ) {
			echo '<p><button type="button" class="button" id="tcc-spk-use">Use these speakers</button> <span class="tcc-spk-use-status" id="tcc-spk-use-status" aria-live="polite"></span></p>';
		}
		if ( count( $all ) > 10 ) {
			echo '<p><label class="screen-reader-text" for="tcc-spk-search">Find a speaker</label><input type="search" id="tcc-spk-search" class="tcc-spk-search" placeholder="Find a speaker" autocomplete="off"></p>';
		}
		echo '<ul class="tcc-spk-list">';
		foreach ( $all as $id => $name ) {
			echo tcc_speakers_row( $id, $name, in_array( (int) $id, $ticked, true ), (int) $id === $main ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in tcc_speakers_row().
		}
		echo '</ul>';
		if ( ! $all ) {
			echo '<p class="tcc-spk-empty">No speakers yet. Add the first one below.</p>';
		}
		if ( current_user_can( 'manage_categories' ) ) {
			echo '<div class="tcc-spk-add"><label for="tcc-spk-new">Add a new speaker</label>'
				. '<div class="tcc-spk-add-row"><input type="text" id="tcc-spk-new" autocomplete="off" placeholder="First and last name">'
				. '<button type="button" class="button" id="tcc-spk-add-btn" data-nonce="' . esc_attr( wp_create_nonce( 'tcc_add_speaker' ) ) . '">Add</button></div>'
				. '<p class="tcc-spk-status" aria-live="polite"></p></div>';
		}
	}

	/** Is this the edit screen of a sermon (a Post)? */
	function tcc_speakers_on_edit_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && 'post' === $screen->base && 'post' === $screen->post_type;
	}

	/**
	 * CSS that hides the Speaker part of the ordinary Categories box, so speakers are picked in one place.
	 * Newer WordPress gives the rows ids like "in-category-2-1", older ones "category-2", so ids alone
	 * do not match. The value of the tick box is the category id WordPress saves, the same in every
	 * version, so each row is found by that (the old id selectors are kept as a fallback). WordPress
	 * also moves ticked categories to the top of the box, outside their parent, so every speaker is
	 * hidden by itself as well as the Speaker branch. The hidden ticks are still sent; the save
	 * replaces them with what the Speakers box says.
	 */
	function tcc_speakers_hide_css() {
		$root = tcc_sermons_speaker_root();
		if ( ! $root ) {
			return '';
		}
		$hide = array();
		$old  = array();
		foreach ( array_merge( array( (int) $root ), array_map( 'intval', array_keys( tcc_speakers_all() ) ) ) as $id ) {
			$hide[] = '#categorychecklist li:has(> label > input[value="' . $id . '"])';
			$hide[] = '#categorychecklist-pop li:has(input[value="' . $id . '"])';
			$old[]  = '#categorychecklist #category-' . $id;
			$old[]  = '#categorychecklist-pop #popular-category-' . $id;
		}
		// Two rules: a browser that does not know :has() drops only the first, not the old-id fallback.
		return implode( ',', $hide ) . '{display:none}' . implode( ',', $old ) . '{display:none}';
	}

	add_action(
		'admin_head',
		function () {
			if ( ! tcc_speakers_on_edit_screen() ) {
				return;
			}
			$css = '#tcc-speakers-box .tcc-spk-help{margin:0 0 10px;color:#50575e}'
				. '#tcc-speakers-box .tcc-spk-note{background:#fcf9e8;border-left:4px solid #dba617;padding:6px 10px;margin:0 0 10px}'
				. '#tcc-speakers-box .tcc-spk-search{width:100%;min-height:36px}'
				. '#tcc-speakers-box .tcc-spk-list{margin:0;max-height:320px;overflow:auto;border:1px solid #dcdcde;border-radius:4px;padding:2px 0}'
				. '#tcc-speakers-box .tcc-spk-row{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:2px 12px;margin:0;padding:4px 10px;border-bottom:1px solid #f0f0f1}'
				. '#tcc-speakers-box .tcc-spk-row:last-child{border-bottom:0}'
				. '#tcc-speakers-box .tcc-spk-row[hidden]{display:none}' // The search hides rows with the hidden attribute; display:flex above would otherwise win.
				. '#tcc-speakers-box .tcc-spk-row.is-on{background:#eef8fb}'
				. '#tcc-speakers-box .tcc-spk-row label{display:inline-flex;align-items:center;gap:8px;min-height:36px;cursor:pointer;font-size:14px}'
				. '#tcc-speakers-box .tcc-spk-row input{margin:0}'
				. '#tcc-speakers-box .tcc-spk-tick{flex:1}'
				. '#tcc-speakers-box .tcc-spk-main{color:#50575e;font-size:13px}'
				. '#tcc-speakers-box .tcc-spk-row:not(.is-on) .tcc-spk-main{display:none}'
				. '#tcc-speakers-box .tcc-spk-add{margin-top:12px}'
				. '#tcc-speakers-box .tcc-spk-add label{display:block;font-weight:600;margin-bottom:4px}'
				. '#tcc-speakers-box .tcc-spk-add-row{display:flex;gap:8px}'
				. '#tcc-speakers-box .tcc-spk-add-row input{flex:1;min-width:0;min-height:36px}'
				. '#tcc-speakers-box .tcc-spk-status{margin:6px 0 0;min-height:1em}';
			echo '<style id="tcc-speakers-css">' . tcc_speakers_hide_css() . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed CSS and integer ids.
		}
	);

	add_action(
		'admin_footer',
		function () {
			if ( ! tcc_speakers_on_edit_screen() ) {
				return;
			}
			?>
<script id="tcc-speakers-js">
(function () {
	/* The Speakers box: "Main speaker" beside each ticked name, the search line, and Add a new speaker. */
	var box = document.getElementById('tcc-speakers-box');
	if (!box) { return; }
	var list = box.querySelector('.tcc-spk-list');
	if (!list) { return; }
	/* Always sit straight under the Categories box, in whichever column that is (on the church's
	   site Categories is in the wide column), so speakers are picked next to the other categories. */
	var cats = document.getElementById('categorydiv');
	if (cats && cats.parentNode) { cats.parentNode.insertBefore(box, cats.nextSibling); }
	if (cats) {
		var inside = cats.querySelector('.inside');
		if (inside) {
			var note = document.createElement('p');
			note.className = 'description';
			note.textContent = 'Speakers are picked in the Speakers box.';
			inside.appendChild(note);
		}
	}
	function rows() { return Array.prototype.slice.call(list.querySelectorAll('.tcc-spk-row')); }
	function tick(row) { return row.querySelector('input[type=checkbox]'); }
	function radio(row) { return row.querySelector('input[type=radio]'); }
	/* Shows "Main speaker" beside each ticked name, and makes sure one of them is chosen (the first A to Z). */
	function sync() {
		var on = rows().filter(function (r) { return tick(r).checked; });
		rows().forEach(function (r) {
			r.classList.toggle('is-on', tick(r).checked);
			if (!tick(r).checked) { radio(r).checked = false; }
		});
		if (on.length && !on.some(function (r) { return radio(r).checked; })) { radio(on[0]).checked = true; }
	}
	var touched = document.getElementById('tcc-spk-touched');
	function touch() { if (touched) { touched.value = '1'; } }
	list.addEventListener('change', function () { touch(); sync(); });
	/* "Use these speakers": accepts what the box pre-ticked, so it is saved with the next Update. */
	var use = document.getElementById('tcc-spk-use');
	if (use) {
		use.addEventListener('click', function () {
			touch();
			var s = document.getElementById('tcc-spk-use-status');
			if (s) { s.textContent = 'These speakers will be saved when you press Update.'; }
			use.disabled = true;
		});
	}
	function norm(t) { return t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim(); }

	var search = box.querySelector('.tcc-spk-search');
	if (search) {
		search.addEventListener('input', function () {
			var q = search.value.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
			rows().forEach(function (r) {
				r.hidden = q !== '' && r.getAttribute('data-name').indexOf(q) === -1 && !tick(r).checked;
			});
		});
		search.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); } });
	}

	var input = document.getElementById('tcc-spk-new');
	var button = document.getElementById('tcc-spk-add-btn');
	var status = box.querySelector('.tcc-spk-status');
	function add() {
		var name = input.value.replace(/\s+/g, ' ').trim();
		if (!name) { status.textContent = 'Type the speaker’s name first.'; input.focus(); return; }
		button.disabled = true;
		status.textContent = 'Adding…';
		var body = new URLSearchParams({ action: 'tcc_add_speaker', name: name, _ajax_nonce: button.getAttribute('data-nonce') });
		fetch(window.ajaxurl, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (r) { return r.json(); })
			.then(function (res) {
				button.disabled = false;
				if (!res || !res.success) {
					status.textContent = (res && res.data && res.data.message) || 'The speaker could not be added. Reload the page and try again.';
					return;
				}
				var d = res.data;
				var found = list.querySelector('input[type=checkbox][value="' + d.id + '"]');
				var row;
				if (found) {
					row = found.closest('.tcc-spk-row');
				} else {
					var holder = document.createElement('ul');
					holder.innerHTML = d.row;
					row = holder.firstElementChild;
					var before = rows().filter(function (r) { return r.getAttribute('data-name') > row.getAttribute('data-name'); })[0];
					list.insertBefore(row, before || null);
				}
				tick(row).checked = true;
				row.hidden = false;
				/* The first typed name was not a speaker yet: make them the main speaker once added. */
				if (touched && touched.getAttribute('data-first') && norm(d.name) === touched.getAttribute('data-first')) { radio(row).checked = true; }
				touch();
				sync();
				var empty = box.querySelector('.tcc-spk-empty');
				if (empty) { empty.remove(); }
				input.value = '';
				input.focus();
				status.textContent = d.existed ? d.name + ' was already in the list and is now ticked.' : d.name + ' was added and ticked.';
				row.scrollIntoView({ block: 'nearest' });
			})
			.catch(function () {
				button.disabled = false;
				status.textContent = 'The speaker could not be added. Check the internet connection and try again.';
			});
	}
	if (button) {
		button.addEventListener('click', add);
		input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); add(); } });
	}
	sync();
})();
</script>
			<?php
		}
	);

	// "Add" in the Speakers box.
	add_action(
		'wp_ajax_tcc_add_speaker',
		function () {
			check_ajax_referer( 'tcc_add_speaker' );
			if ( ! current_user_can( 'manage_categories' ) ) {
				wp_send_json_error( array( 'message' => 'Only an Editor or Administrator can add a speaker. Ask one of them, or tick an existing speaker.' ), 403 );
			}
			$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
			$made = tcc_speakers_add( $name );
			if ( is_wp_error( $made ) ) {
				wp_send_json_error( array( 'message' => $made->get_error_message() ) );
			}
			$made['row'] = tcc_speakers_row( $made['id'], $made['name'], false, false );
			wp_send_json_success( $made );
		}
	);

	// Speaker Name (Sermon Info) is filled in for you once the sermon has a main speaker.
	add_filter(
		'acf/prepare_field/name=speaker_name',
		function ( $field ) {
			$post = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
			if ( is_array( $field ) && $post instanceof WP_Post && tcc_speakers_is_filled( $post->ID ) ) {
				$field['readonly']     = 1;
				$field['instructions'] = 'Filled in automatically from the Speakers box.';
			}
			return $field;
		}
	);
}

/* ----------------------------------------------------------------------------------------------
 * 4. The one-time fill-in from typed names, and Undo.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_plan_one' ) ) {

	/**
	 * What the fill-in would do for one sermon.
	 * $typed its Speaker Name; $current the speakers ticked on it (id => name); $all every speaker (id => name).
	 * Returns array(
	 *   'names'  => the people in order, the main speaker (the first typed name) first,
	 *   'create' => typed names that are not speakers yet,
	 *   'look'   => '' or why a person should look at this sermon instead,
	 * ).
	 */
	function tcc_speakers_plan_one( $typed, $current, $all ) {
		$typed = trim( html_entity_decode( (string) $typed, ENT_QUOTES, 'UTF-8' ) );
		$look  = function ( $why ) {
			return array(
				'names'  => array(),
				'create' => array(),
				'look'   => $why,
			);
		};
		if ( '' !== $typed && false !== stripos( $typed, 'trinity community' ) ) {
			return $look( 'The typed name is the church, not a person. Tick the speaker by hand.' );
		}
		if ( preg_match( '/\s[-\x{2013}\x{2014}]\s/u', $typed ) ) {
			return $look( 'The typed name uses a dash; it may be two people. Tick the speakers by hand.' );
		}
		$typed_names = '' === $typed ? array() : array_values( tcc_sermons_speaker_names( $typed ) );
		if ( ! $typed_names && ! $current ) {
			return $look( 'No speaker is typed or ticked.' );
		}
		$known = array();
		foreach ( (array) $all as $name ) {
			$known[ tcc_speakers_norm( $name ) ] = $name;
		}
		$ticked = array();
		foreach ( (array) $current as $name ) {
			$ticked[ tcc_speakers_norm( $name ) ] = $name;
		}
		$typed_keys = array_flip( array_map( 'tcc_speakers_norm', $typed_names ) );
		if ( $typed_names && $ticked && ! array_intersect_key( $typed_keys, $ticked ) ) {
			return $look( 'The typed name (' . $typed . ') and the ticked speaker (' . implode( ', ', $current ) . ') disagree.' );
		}
		$names  = array();
		$create = array();
		foreach ( $typed_names as $name ) {
			$key = tcc_speakers_norm( $name );
			if ( isset( $names[ $key ] ) ) {
				continue;
			}
			if ( isset( $known[ $key ] ) ) {
				$names[ $key ] = $known[ $key ];
			} else {
				if ( ! preg_match( '/\s/', $name ) || preg_match( '/\d/', $name ) || preg_match( '/[()]/', $name ) || preg_match( '/\b(?:guest|speakers?|team|various|panel|staff|worship)\b/i', $name ) || preg_match( '/^(?:pastor|pr|rev|reverend|dr|elder|bishop|brother|sister|mr|mrs|ms)\.?(?:\s|$)/i', $name ) ) {
					return $look( $name . ' looks like part of a name or has a title. Tick the speakers by hand.' );
				}
				$names[ $key ] = $name;
				$create[]      = $name;
			}
		}
		foreach ( $ticked as $key => $name ) {
			if ( ! isset( $names[ $key ] ) ) {
				$names[ $key ] = $name;
			}
		}
		return array(
			'names'  => array_values( $names ),
			'create' => $create,
			'look'   => '',
		);
	}

	/** Every sermon the fill-in looks at (any status but the bin), newest first. Their fields are loaded in one go. */
	function tcc_speakers_sermon_ids() {
		$ids = array_map(
			'intval',
			get_posts(
				array(
					'post_type'        => 'post',
					'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
					'posts_per_page'   => -1,
					'fields'           => 'ids',
					'orderby'          => 'date',
					'order'            => 'DESC',
					'no_found_rows'    => true,
					'suppress_filters' => true,
				)
			)
		);
		if ( $ids ) {
			update_postmeta_cache( $ids );
			update_object_term_cache( $ids, 'post' );
		}
		return $ids;
	}

	/**
	 * The fill-in, worked out but not done: one row per sermon with no main speaker saved yet.
	 * Each row: id, title, typed, current (names ticked now), names, create, look, author
	 * (the login the Author would change to, or 0).
	 */
	function tcc_speakers_plan() {
		$all   = tcc_speakers_all();
		$users = array();
		$rows  = array();
		foreach ( tcc_speakers_sermon_ids() as $id ) {
			if ( tcc_speakers_is_filled( $id ) ) {
				continue; // Done: a main speaker and speakers ticked.
			}
			$current = array_intersect_key( $all, array_flip( tcc_speakers_of( $id ) ) );
			$typed   = trim( (string) get_post_meta( $id, 'speaker_name', true ) );
			$one     = tcc_speakers_plan_one( $typed, $current, $all );
			$author  = 0;
			if ( '' === $one['look'] ) {
				$key = tcc_speakers_norm( $one['names'][0] );
				if ( ! isset( $users[ $key ] ) ) {
					$users[ $key ] = tcc_speakers_user_for( $one['names'][0] );
				}
				if ( $users[ $key ] && (int) get_post_field( 'post_author', $id ) !== $users[ $key ] ) {
					$author = $users[ $key ];
				}
			}
			$rows[] = array(
				'id'      => $id,
				'title'   => html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES, 'UTF-8' ),
				'typed'   => $typed,
				'current' => array_values( $current ),
				'names'   => $one['names'],
				'create'  => $one['create'],
				'look'    => $one['look'],
				'author'  => $author,
			);
		}
		return $rows;
	}
}

if ( ! function_exists( 'tcc_speakers_fill_in' ) ) {

	/**
	 * Does the fill-in. A copy of each sermon's speakers, main speaker, Speaker Name and Author is
	 * saved first in the option tcc_speakers_backup (added to, never replaced, if an earlier fill-in
	 * left one), so tcc_speakers_undo() can put everything back.
	 * Returns array(
	 *   'done'    => sermons filled in,
	 *   'created' => names of speakers added,
	 *   'look'    => sermons left for a person,
	 *   'failed'  => lines like "Sermon title: reason" for sermons left untouched because a name could not be added,
	 *   'error'   => a message when nothing was changed because the backup could not be saved, else '',
	 *   'running' => true when another fill-in is already running (nothing was done).
	 * )
	 */
	function tcc_speakers_fill_in() {
		$result = array(
			'done'    => 0,
			'created' => array(),
			'look'    => 0,
			'failed'  => array(),
			'error'   => '',
			'running' => false,
		);
		if ( get_transient( 'tcc_speakers_filling' ) ) { // Someone pressed the button twice, or two people did.
			$result['running'] = true;
			return $result;
		}
		set_transient( 'tcc_speakers_filling', 1, 5 * MINUTE_IN_SECONDS );
		try {
			$plan = tcc_speakers_plan();
			$todo = array_filter(
				$plan,
				function ( $row ) {
					return '' === $row['look'];
				}
			);
			$result['look'] = count( $plan ) - count( $todo );

			// A backup already there (an earlier run) is added to, never replaced: the oldest state wins.
			$backup = get_option( 'tcc_speakers_backup' );
			if ( ! is_array( $backup ) || empty( $backup['posts'] ) ) {
				$old    = is_array( $backup ) && ! empty( $backup['created'] ) ? (array) $backup['created'] : array(); // Speakers it added still count.
				$backup = array(
					'when'    => time(),
					'created' => $old,
					'posts'   => array(),
				);
			}
			$backup['last']    = time();
			$backup['created'] = array_values( array_unique( array_map( 'intval', (array) $backup['created'] ) ) );
			$added             = array();
			$default           = (int) get_option( 'default_category' );
			foreach ( $todo as $row ) {
				if ( isset( $backup['posts'][ $row['id'] ] ) ) {
					continue;
				}
				$cats                          = array_map( 'intval', (array) wp_get_post_categories( $row['id'] ) );
				$added[]                       = $row['id'];
				$backup['posts'][ $row['id'] ] = array(
					'cats'        => tcc_speakers_of( $row['id'] ),
					'name'        => $row['typed'],
					'author'      => (int) get_post_field( 'post_author', $row['id'] ),
					'had_default' => in_array( $default, $cats, true ),
					'main'        => (int) get_post_meta( $row['id'], '_tcc_main_speaker', true ),
				);
			}
			update_option( 'tcc_speakers_backup', $backup, false ); // Before anything changes.
			$stored = get_option( 'tcc_speakers_backup' );
			foreach ( $todo as $row ) {
				if ( ! is_array( $stored ) || ! isset( $stored['posts'][ $row['id'] ] ) ) {
					$result['error'] = 'The copy of how the sermons are now could not be saved, so nothing was changed.';
					return $result;
				}
			}

			$author = current_user_can( 'edit_others_posts' );
			wp_defer_term_counting( true );
			try {
				foreach ( $todo as $row ) {
					// Work out every person first. If anyone cannot be added, leave this sermon alone.
					$ids    = array();
					$why    = '';
					$fresh  = array();
					$made_n = array();
					foreach ( $row['names'] as $name ) {
						$found = tcc_speakers_add( $name );
						if ( is_wp_error( $found ) ) {
							$why = $found->get_error_message();
							break;
						}
						if ( ! $found['existed'] ) {
							$fresh[]  = $found['id'];
							$made_n[] = $found['name'];
						}
						$ids[] = $found['id'];
					}
					if ( $fresh ) {
						$backup['created'] = array_values( array_unique( array_merge( $backup['created'], $fresh ) ) );
						update_option( 'tcc_speakers_backup', $backup, false );
					}
					if ( '' !== $why || ! $ids ) {
						$result['failed'][] = ( '' !== $row['title'] ? $row['title'] : 'Sermon ' . $row['id'] ) . ': ' . ( '' !== $why ? $why : 'no speaker could be found for it.' );
						if ( in_array( $row['id'], $added, true ) ) {
							unset( $backup['posts'][ $row['id'] ] ); // Never changed, so nothing to put back.
							update_option( 'tcc_speakers_backup', $backup, false );
						}
						continue;
					}
					tcc_speakers_apply( $row['id'], $ids, $ids[0], $author );
					++$result['done'];
					$result['created'] = array_merge( $result['created'], $made_n );
				}
			} finally {
				wp_defer_term_counting( false );
			}
			if ( function_exists( 'tcc_search_content_changed' ) ) {
				tcc_search_content_changed(); // So the site search forgets what it remembered.
			}
			// tcc_sermons_bump() only acts once per request, and saving the first sermon already used
			// it up, so a page viewed mid-run could have been remembered half filled in. Move the
			// "generation" on directly now that everything is done.
			update_option( 'tcc_sermons_gen', (int) get_option( 'tcc_sermons_gen', 1 ) + 1, false );
		} finally {
			delete_transient( 'tcc_speakers_filling' );
		}
		return $result;
	}

	/**
	 * Puts back every sermon in the backup, which covers all fill-ins since the first one (and any
	 * speaker changes made to those sermons since). Returns how many sermons were put back; 0 when
	 * there is no backup or a fill-in is running.
	 */
	function tcc_speakers_undo() {
		$backup = get_option( 'tcc_speakers_backup' );
		if ( get_transient( 'tcc_speakers_filling' ) || ! is_array( $backup ) || empty( $backup['posts'] ) ) {
			return 0;
		}
		$speakers = array_keys( tcc_speakers_all() );
		$count    = 0;
		$GLOBALS['tcc_speakers_busy'] = true; // So the save hooks leave these saves alone.
		try {
			foreach ( $backup['posts'] as $id => $row ) {
				$id = (int) $id;
				if ( ! get_post( $id ) ) {
					continue;
				}
				$keep = array_diff( array_map( 'intval', (array) wp_get_post_categories( $id ) ), $speakers );
				$back = array_merge( $keep, array_map( 'intval', (array) $row['cats'] ) );
				if ( ! empty( $row['had_default'] ) ) {
					$back[] = (int) get_option( 'default_category' ); // It had "Uncategorized" before the fill-in dropped it.
				}
				wp_set_post_categories( $id, array_values( array_unique( $back ) ) );
				delete_post_meta( $id, '_tcc_main_speaker' );
				if ( ! empty( $row['main'] ) ) {
					update_post_meta( $id, '_tcc_main_speaker', (int) $row['main'] ); // It had one before the fill-in.
				}
				if ( '' === (string) $row['name'] ) {
					delete_post_meta( $id, 'speaker_name' );
				} else {
					update_post_meta( $id, 'speaker_name', (string) $row['name'] );
				}
				if ( (int) $row['author'] && (int) get_post_field( 'post_author', $id ) !== (int) $row['author'] ) {
					tcc_speakers_set_author( $id, (int) $row['author'] );
				}
				++$count;
			}
		} finally {
			$GLOBALS['tcc_speakers_busy'] = false; // Always put back.
		}
		foreach ( (array) $backup['created'] as $term_id ) {
			$used = get_objects_in_term( (int) $term_id, 'category' );
			if ( is_array( $used ) && ! $used ) {
				wp_delete_term( (int) $term_id, 'category' );
			}
		}
		delete_option( 'tcc_speakers_backup' );
		if ( function_exists( 'tcc_search_content_changed' ) ) {
			tcc_search_content_changed();
		}
		// As in the fill-in: move the generation on directly, because tcc_sermons_bump() acts once per request.
		update_option( 'tcc_sermons_gen', (int) get_option( 'tcc_sermons_gen', 1 ) + 1, false );
		return $count;
	}

	/**
	 * For the status panel: sermons with speakers ticked, sermons the fill-in would do (waiting), and
	 * sermons that need a person to look (including any with no speaker at all). Pass the plan if you
	 * already have it.
	 */
	function tcc_speakers_counts( $plan = null ) {
		$plan = null === $plan ? tcc_speakers_plan() : $plan;
		$look = 0;
		foreach ( $plan as $row ) {
			if ( '' !== $row['look'] ) {
				++$look;
			}
		}
		return array(
			'ticked'  => count( tcc_speakers_sermon_ids() ) - count( $plan ),
			'waiting' => count( $plan ) - $look,
			'look'    => $look,
		);
	}
}

/* ----------------------------------------------------------------------------------------------
 * 5. The page Posts > Sermon speakers (Administrators only).
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_speakers_page' ) ) {

	add_action(
		'admin_menu',
		function () {
			add_submenu_page( 'edit.php', 'Sermon speakers', 'Sermon speakers', 'manage_options', 'tcc-sermon-speakers', 'tcc_speakers_page' );
		}
	);

	/** "1 sermon" or "3 sermons". */
	function tcc_speakers_n( $n, $one, $many ) {
		return (int) $n . ' ' . ( 1 === (int) $n ? $one : $many );
	}

	/** The address of the page, with any extra bits. */
	function tcc_speakers_page_url( $extra = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'tcc-sermon-speakers' ), $extra ), admin_url( 'edit.php' ) );
	}

	add_action(
		'admin_post_tcc_speakers_fill',
		function () {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'Only an Administrator can fill in the speakers.' );
			}
			check_admin_referer( 'tcc_speakers_fill' );
			if ( function_exists( 'set_time_limit' ) ) {
				set_time_limit( 300 );
			}
			$result = tcc_speakers_fill_in();
			set_transient(
				'tcc_speakers_notes',
				array(
					'failed' => array_slice( (array) $result['failed'], 0, 30 ),
					'error'  => (string) $result['error'],
				),
				10 * MINUTE_IN_SECONDS
			);
			wp_safe_redirect(
				tcc_speakers_page_url(
					array(
						'filled'  => (int) $result['done'],
						'added'   => count( $result['created'] ),
						'failed'  => count( $result['failed'] ),
						'running' => $result['running'] ? 1 : 0,
					)
				)
			);
			exit;
		}
	);

	add_action(
		'admin_post_tcc_speakers_undo',
		function () {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'Only an Administrator can undo the fill-in.' );
			}
			check_admin_referer( 'tcc_speakers_undo' );
			if ( function_exists( 'set_time_limit' ) ) {
				set_time_limit( 300 );
			}
			if ( get_transient( 'tcc_speakers_filling' ) ) {
				wp_safe_redirect( tcc_speakers_page_url( array( 'running' => 1 ) ) );
				exit;
			}
			$count = tcc_speakers_undo();
			wp_safe_redirect( tcc_speakers_page_url( array( 'undone' => (int) $count ) ) );
			exit;
		}
	);

	/** A small form that posts to admin-post.php with one button. */
	function tcc_speakers_button_form( $action, $label, $confirm, $primary ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="if(!confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')){return false;} this.querySelector(\'button\').disabled=true; return true;">'
			. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">'
			. wp_nonce_field( $action, '_wpnonce', true, false )
			. '<button type="submit" class="button' . ( $primary ? ' button-primary' : '' ) . '">' . esc_html( $label ) . '</button></form>';
	}

	/** Posts > Sermon speakers: status, the fill-in with its preview, sermons that need a look, and Undo. */
	function tcc_speakers_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! tcc_sermons_speaker_root() ) {
			echo '<div class="wrap tcc-spk-page"><h1>Sermon speakers</h1><p>There is no Speaker category yet. Add a category named Speaker (slug <code>speaker</code>) under Posts &rarr; Categories, then reload this page.</p></div>';
			return;
		}
		$plan    = tcc_speakers_plan();
		$counts  = tcc_speakers_counts( $plan );
		$preview = isset( $_GET['preview'] ); // phpcs:ignore WordPress.Security.NonceVerification -- only shows a list.
		$todo    = array_filter(
			$plan,
			function ( $row ) {
				return '' === $row['look'];
			}
		);
		$look    = array_filter(
			$plan,
			function ( $row ) {
				return '' !== $row['look'];
			}
		);
		$backup  = get_option( 'tcc_speakers_backup' );
		$ok      = 0 === $counts['waiting'] && 0 === $counts['look'];

		echo '<div class="wrap tcc-spk-page"><h1>Sermon speakers</h1>';
		echo '<style>.tcc-spk-page .tcc-spk-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px 20px;margin:16px 0;max-width:1100px}'
			. '.tcc-spk-page .tcc-spk-card h2{margin-top:0}.tcc-spk-page .tcc-spk-pill{display:inline-block;padding:3px 10px;border-radius:999px;font-weight:600}'
			. '.tcc-spk-page .is-ok{background:#e7f6ec;color:#1e6b34}.tcc-spk-page .is-look{background:#fcf0e3;color:#8a4b00}'
			. '.tcc-spk-page table{border-collapse:collapse;width:100%}.tcc-spk-page th,.tcc-spk-page td{text-align:left;padding:8px;border-bottom:1px solid #f0f0f1;vertical-align:top}'
			. '.tcc-spk-page .tcc-spk-scroll{overflow-x:auto}@media (max-width:782px){.tcc-spk-page .tcc-spk-card{padding:12px}}</style>';

		// phpcs:disable WordPress.Security.NonceVerification -- these only read the result of a redirect.
		if ( ! empty( $_GET['running'] ) ) {
			echo '<div class="notice notice-warning"><p>A fill-in is already running (or ran a moment ago). Wait a minute, then reload this page.</p></div>';
		}
		$notes = ( isset( $_GET['filled'] ) || isset( $_GET['failed'] ) ) ? get_transient( 'tcc_speakers_notes' ) : false;
		if ( is_array( $notes ) && '' !== (string) $notes['error'] ) {
			echo '<div class="notice notice-error"><p>' . esc_html( (string) $notes['error'] ) . '</p></div>';
		}
		if ( isset( $_GET['filled'] ) && ! ( is_array( $notes ) && '' !== (string) $notes['error'] ) ) {
			echo '<div class="notice notice-success"><p><strong>Done.</strong> ' . esc_html( tcc_speakers_n( (int) $_GET['filled'], 'sermon', 'sermons' ) ) . ' filled in, ' . esc_html( tcc_speakers_n( (int) ( $_GET['added'] ?? 0 ), 'new speaker', 'new speakers' ) ) . ' added. Look at a few sermon pages, then clear WP Rocket (Settings &rarr; WP Rocket: Clear Used CSS, then Clear and Preload Cache).</p></div>';
		}
		if ( isset( $_GET['failed'] ) && (int) $_GET['failed'] > 0 ) {
			echo '<div class="notice notice-warning"><p><strong>' . esc_html( tcc_speakers_n( (int) $_GET['failed'], 'sermon', 'sermons' ) ) . ' could not be filled in</strong> and ' . ( 1 === (int) $_GET['failed'] ? 'was' : 'were' ) . ' left as ' . ( 1 === (int) $_GET['failed'] ? 'it was' : 'they were' ) . ':</p><ul style="list-style:disc;margin-left:20px">';
			foreach ( is_array( $notes ) ? (array) $notes['failed'] : array() as $line ) {
				echo '<li>' . esc_html( (string) $line ) . '</li>';
			}
			echo '</ul></div>';
		}
		if ( isset( $_GET['undone'] ) ) {
			echo '<div class="notice notice-success"><p><strong>Put back.</strong> ' . esc_html( tcc_speakers_n( (int) $_GET['undone'], 'sermon is', 'sermons are' ) ) . ' as ' . ( 1 === (int) $_GET['undone'] ? 'it was' : 'they were' ) . ' before the fill-in.</p></div>';
		}
		// phpcs:enable

		echo '<div class="tcc-spk-card"><h2>Status</h2><p><span class="tcc-spk-pill ' . ( $ok ? 'is-ok">All sermons have speakers' : 'is-look">Needs a look' ) . '</span></p><ul>';
		echo '<li><strong>' . (int) $counts['ticked'] . '</strong> ' . ( 1 === (int) $counts['ticked'] ? 'sermon has its' : 'sermons have their' ) . ' speakers ticked.</li>';
		echo '<li><strong>' . (int) $counts['waiting'] . '</strong> ' . ( 1 === (int) $counts['waiting'] ? 'is' : 'are' ) . ' waiting for the fill-in (only a typed name, or a speaker ticked but no main speaker).</li>';
		echo '<li><strong>' . (int) $counts['look'] . '</strong> ' . ( 1 === (int) $counts['look'] ? 'needs' : 'need' ) . ' a person to look (the typed name and the ticked speaker disagree, the name looks odd, or there is no speaker at all).</li></ul>';
		echo '<p>Speakers are picked in the <strong>Speakers</strong> box on each sermon\'s edit screen. The speakers themselves are the categories under Speaker (Posts &rarr; Categories).</p></div>';

		echo '<div class="tcc-spk-card"><h2>Fill in speakers from typed names</h2>';
		if ( ! $todo ) {
			echo '<p>Nothing to fill in. Every sermon has its speakers ticked or is in the list below for a person to look at.</p>';
		} else {
			echo '<p>This ticks the speakers on <strong>' . esc_html( tcc_speakers_n( count( $todo ), 'sermon', 'sermons' ) ) . '</strong> from their typed Speaker Name, adds anyone who is not a speaker yet, makes the first typed name the main speaker, and sets the Author to the main speaker when that person has a login. A copy of how things are now is kept first, so it can be undone.</p>';
			if ( ! $preview ) {
				echo '<p><a class="button button-primary" href="' . esc_url( tcc_speakers_page_url( array( 'preview' => 1 ) ) ) . '">Show what would change</a> <span class="description">Nothing is saved until you press the button under the list.</span></p>';
			} else {
				echo '<div class="tcc-spk-scroll"><table><thead><tr><th>Sermon</th><th>Typed now</th><th>Will tick (main speaker first)</th><th>New speakers</th><th>Author becomes</th></tr></thead><tbody>';
				foreach ( $todo as $row ) {
					$names = $row['names'];
					$first = array_shift( $names );
					$who   = '<strong>' . esc_html( $first ) . '</strong>' . ( $names ? ', ' . esc_html( implode( ', ', $names ) ) : '' );
					$user  = $row['author'] ? get_userdata( $row['author'] ) : null;
					echo '<tr><td><a href="' . esc_url( (string) get_edit_post_link( $row['id'] ) ) . '">' . esc_html( $row['title'] ) . '</a></td>'
						. '<td>' . esc_html( '' !== $row['typed'] ? $row['typed'] : '(nothing typed)' ) . '</td>'
						. '<td>' . $who . '</td>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
						. '<td>' . esc_html( $row['create'] ? implode( ', ', $row['create'] ) : '-' ) . '</td>'
						. '<td>' . esc_html( $user ? $user->display_name : 'stays the same' ) . '</td></tr>';
				}
				echo '</tbody></table></div>';
				$new_names = array();
				foreach ( $todo as $row ) {
					$new_names = array_merge( $new_names, $row['create'] );
				}
				$new_names = array_values( array_unique( $new_names ) );
				echo '<p><strong>' . ( $new_names ? esc_html( 'New speakers this will add: ' . implode( ', ', $new_names ) . '.' ) : 'No new speakers.' ) . '</strong></p>';
				echo '<p class="description">If a row is wrong, open that sermon, tick its speakers and press Update; it then leaves this list.</p><p>';
				echo tcc_speakers_button_form( 'tcc_speakers_fill', 'Fill in speakers from typed names', 'Fill in the speakers on ' . tcc_speakers_n( count( $todo ), 'sermon', 'sermons' ) . '? You can undo this afterwards.', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
				echo '</p>';
			}
		}
		echo '</div>';

		echo '<div class="tcc-spk-card"><h2>Sermons that need a person to look</h2>';
		if ( ! $look ) {
			echo '<p>None.</p>';
		} else {
			echo '<p>The fill-in does not guess on these. Open each one, tick its speakers in the Speakers box and press Update.</p><div class="tcc-spk-scroll"><table><thead><tr><th>Sermon</th><th>Why</th></tr></thead><tbody>';
			foreach ( $look as $row ) {
				echo '<tr><td><a href="' . esc_url( (string) get_edit_post_link( $row['id'] ) ) . '">' . esc_html( '' !== $row['title'] ? $row['title'] : 'Sermon ' . $row['id'] ) . '</a></td><td>' . esc_html( $row['look'] ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';

		if ( is_array( $backup ) && ! empty( $backup['posts'] ) ) {
			echo '<div class="tcc-spk-card"><h2>Undo the fill-in</h2>';
			echo '<p>The fill-in on ' . esc_html( wp_date( 'F j, Y \a\t g:i a', (int) $backup['when'] ) ) . ( ! empty( $backup['last'] ) && (int) $backup['last'] - (int) $backup['when'] > 60 ? ' (run again as late as ' . esc_html( wp_date( 'F j, Y \a\t g:i a', (int) $backup['last'] ) ) . ')' : '' ) . ' changed ' . esc_html( tcc_speakers_n( count( $backup['posts'] ), 'sermon', 'sermons' ) ) . '. Undo puts back how these sermons were before the first fill-in, and also undoes any speaker changes made to them since. It puts their speakers, Speaker Name and Author back, and removes any speaker it added that no sermon uses any more.</p>';
			echo tcc_speakers_button_form( 'tcc_speakers_undo', 'Undo the fill-in', 'Put ' . tcc_speakers_n( count( $backup['posts'] ), 'sermon', 'sermons' ) . ' back as they were before the fill-in?', false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		}
		echo '</div>';
	}
}
