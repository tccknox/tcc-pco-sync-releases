<?php
/**
 * TCC community groups filter bar.
 *
 * [tcc_group_filter]  prints the bar above the group cards on the Community Groups page:
 *                     who the group is for, the day it meets, how often, and a search box.
 * [tcc_group_data]    goes inside each group card; it prints a hidden tag with that group's
 *                     facts (who, days, how often) so the bar knows what to show, and the words
 *                     of its description and organizer so the search box finds them too.
 *
 * The cards themselves are plain Divi: a Divi loop over Community Groups draws every active
 * group. This feature only hides and shows the cards already on the page, in the visitor's
 * browser, so it is instant and asks nothing extra of the server.
 *
 * What it reads, all from the group's own fields (Community Groups Info):
 *   who        "Gender-Specific"            Group is Co-ed / Female Only / Male Only
 *   days       "Date And Meeting Time"      any day names in the words, e.g. "Mondays and Thursdays"
 *   how often  "How Often"                  Weekly; twice a month (1st and 3rd Weeks, 2nd and 4th
 *                                           Weeks, Every Other Week, Bi-Monthly); Monthly
 * A menu only lists choices that at least one group on the page has.
 *
 * What the page needs: the list of cards keeps the CSS ID tcc-groups, each card keeps the CSS
 * class tcc-group-card and holds a Text layer with [tcc_group_data]. A <span> with the class
 * tcc-group-count anywhere on the page is filled with the number of groups.
 *
 * With JavaScript off, or with fewer than two groups, the bar stays hidden and every group shows.
 * To remove the bar, switch this feature off on TCC Website > Features: the page simply shows
 * every group, and the two short codes print nothing.
 *
 * Part of the TCC Website Features plugin. Added 2026-11-21.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_group_facts' ) ) {
	/** The three facts the filter needs about one group, as short codes for the browser. */
	function tcc_group_facts( $id ) {
		$who_text = strtolower( (string) get_post_meta( $id, 'gender_specific', true ) );
		$who      = '';
		if ( false !== strpos( $who_text, 'female' ) ) {
			$who = 'f';
		} elseif ( false !== strpos( $who_text, 'male' ) ) {
			$who = 'm';
		} elseif ( '' !== trim( $who_text ) ) {
			$who = 'c';
		}

		$often_text = strtolower( trim( (string) get_post_meta( $id, 'how_often', true ) ) );
		$often      = '';
		if ( 'weekly' === $often_text ) {
			$often = 'w';
		} elseif ( 'monthly' === $often_text ) {
			$often = 'm';
		} elseif ( false !== strpos( $often_text, 'weeks' ) || false !== strpos( $often_text, 'every other' ) || false !== strpos( $often_text, 'bi-monthly' ) ) {
			$often = 't';
		}

		$days  = array();
		$names = array(
			'sun'  => 'sun',
			'mon'  => 'mon',
			'tue'  => 'tue',
			'tues' => 'tue',
			'wed'  => 'wed',
			'thu'  => 'thu',
			'thur' => 'thu',
			'thurs' => 'thu',
			'fri'  => 'fri',
			'sat'  => 'sat',
		);
		$when  = (string) get_post_meta( $id, 'date_and_meeting_time', true );
		if ( preg_match_all( '/\b(sun|mon|tues|tue|wednes|wed|thurs|thur|thu|fri|satur|sat)(?:days?|s)?\b/i', $when, $found ) ) {
			foreach ( $found[1] as $word ) {
				$word = strtolower( $word );
				if ( 'wednes' === $word ) {
					$word = 'wed';
				} elseif ( 'satur' === $word ) {
					$word = 'sat';
				}
				if ( isset( $names[ $word ] ) ) {
					$days[ $names[ $word ] ] = true;
				}
			}
		}

		return array(
			'who'   => $who,
			'often' => $often,
			'days'  => implode( ' ', array_keys( $days ) ),
		);
	}
}

if ( ! function_exists( 'tcc_group_data_shortcode' ) ) {
	function tcc_group_data_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || 'project' !== get_post_type( $id ) ) {
				return '';
			}
			$facts = tcc_group_facts( $id );
			// Words the search box should also find, though the card does not show them: the description and the organizer.
			$words = wp_strip_all_tags( (string) get_post_meta( $id, 'group_description', true ) . ' ' . (string) get_post_meta( $id, 'organizer_name', true ) );
			$words = strtolower( trim( (string) preg_replace( '/\s+/', ' ', $words ) ) );
			return '<span class="tcc-group-data" style="display:none" data-who="' . esc_attr( $facts['who'] ) . '" data-days="' . esc_attr( $facts['days'] ) . '" data-often="' . esc_attr( $facts['often'] ) . '" data-words="' . esc_attr( $words ) . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_group_data', 'tcc_group_data_shortcode' );
}

if ( ! function_exists( 'tcc_group_filter_shortcode' ) ) {
	function tcc_group_filter_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'target' => 'tcc-groups' ), $atts, 'tcc_group_filter' );
		try {
			// The bar starts hidden; the script shows it once it has found the cards.
			// (The Divi editor does not run the script; the style rules below show it there anyway.)
			$out  = '<div class="tcc-group-filter" data-target="' . esc_attr( $atts['target'] ) . '" role="search" aria-label="Find a group" hidden>';
			$out .= '<span class="tcc-gf-label">Find a group</span>';
			$out .= '<select data-f="who" aria-label="Who the group is for"><option value="">Anyone</option><option value="c">Co-ed</option><option value="f">Women</option><option value="m">Men</option></select>';
			$out .= '<select data-f="day" aria-label="Day it meets"><option value="">Any day</option><option value="sun">Sunday</option><option value="mon">Monday</option><option value="tue">Tuesday</option><option value="wed">Wednesday</option><option value="thu">Thursday</option><option value="fri">Friday</option><option value="sat">Saturday</option></select>';
			$out .= '<select data-f="often" aria-label="How often it meets"><option value="">Any schedule</option><option value="w">Weekly</option><option value="t">Twice a month</option><option value="m">Monthly</option></select>';
			$out .= '<input type="search" data-f="q" aria-label="Search groups" placeholder="Search groups" />';
			$out .= '<button type="button" class="tcc-gf-clear" hidden>Clear filters</button>';
			$out .= '<div class="tcc-gf-status" aria-live="polite" hidden></div>';
			$out .= '<div class="tcc-gf-none" hidden>No groups match those choices. Try removing one, or clear the filters to see every group.</div>';
			$out .= '</div>';

			static $printed = false;
			if ( ! $printed ) {
				$printed = true;
				$out    .= '<style>'
					. '.tcc-group-filter{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin:0 0 26px;padding:16px 18px;background:#f4f4f4;border-radius:15px;border:2px solid #f4f4f4;transition:border-color .25s ease}'
					. '.tcc-group-filter[hidden],.tcc-gf-clear[hidden],.tcc-gf-status[hidden],.tcc-gf-none[hidden]{display:none}'
					// Inside the Divi editor (its page has the class et-fb) the bar shows as a plain preview,
					// with menus instead of buttons, and a note under it saying so. Visitors never see this.
					. 'body.et-fb .tcc-group-filter[hidden]{display:flex!important}'
					. 'body.et-fb .tcc-group-filter:after{content:"Editor preview (automatic). On the website the first menu shows as buttons (Anyone, Co-ed, Women, Men), and the bar counts and filters the group cards below.";flex:1 1 100%;font-size:14px;line-height:1.4;color:#6b6b6c}'
					. '.tcc-group-filter.is-filtering{border-color:#00A4CF}'
					. '.tcc-gf-label{font:600 18px/1.2 "CMG Sans SemiBold",Helvetica,Arial,sans-serif;color:#404041;margin-right:4px}'
					. '.tcc-group-filter select,.tcc-group-filter input[type=search]{font:400 17px/1.2 "Open Sans",Helvetica,Arial,sans-serif;color:#404041;background-color:#fff;border:2px solid #d9d9da;border-radius:10px;padding:10px 14px;height:48px;box-sizing:border-box;max-width:100%;margin:0;outline:0;box-shadow:none;transition:border-color .2s ease,box-shadow .2s ease,color .2s ease}'
					. '.tcc-group-filter select{-webkit-appearance:none;appearance:none;cursor:pointer;padding-right:42px;background-image:url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 12 8%27%3E%3Cpath d=%27M1 1.5l5 5 5-5%27 fill=%27none%27 stroke=%27%23404041%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 15px center;background-size:13px auto}'
					. '.tcc-group-filter input[type=search]{flex:1 1 220px;min-width:0}'
					. '.tcc-group-filter select:hover,.tcc-group-filter input[type=search]:hover{border-color:#b5b5b6}'
					. '.tcc-group-filter select.is-active,.tcc-group-filter input[type=search].is-active{border-color:#00A4CF;color:#00637d;font-weight:600}'
					. '.tcc-group-filter select:focus,.tcc-group-filter input[type=search]:focus{border-color:#00A4CF!important;box-shadow:0 0 0 3px rgba(0,164,207,.25)!important;outline:0!important}'
					. '.tcc-gf-clear{font:600 17px/1.2 "CMG Sans SemiBold",Helvetica,Arial,sans-serif;color:#fff;background:#404041;border:0;border-radius:10px;padding:0 18px;height:48px;cursor:pointer;transition:background-color .2s ease}'
					. '.tcc-gf-clear:hover{background:#00A4CF}'
					. '.tcc-gf-clear:focus-visible{outline:3px solid #00A4CF;outline-offset:2px}'
					. '.tcc-gf-status{flex:1 1 100%;font:400 17px/1.3 "Open Sans",Helvetica,Arial,sans-serif;color:#404041}'
					. '.tcc-gf-none{flex:1 1 100%;font:400 18px/1.4 "Open Sans",Helvetica,Arial,sans-serif;color:#404041;background:#fff;border-radius:10px;padding:16px 18px}'
					// The press-buttons for who a group is for (Anyone / Co-ed / Women / Men). The script makes them from the menu's choices.
					. '.tcc-gf-seg{display:inline-flex;flex-wrap:wrap;gap:6px}'
					. '.tcc-gf-seg button{font:400 17px/1.2 "Open Sans",Helvetica,Arial,sans-serif;color:#404041;background:#fff;border:2px solid #d9d9da;border-radius:10px;padding:0 16px;height:48px;margin:0;cursor:pointer;transition:background-color .2s ease,border-color .2s ease,color .2s ease}'
					. '.tcc-gf-seg button:hover{border-color:#b5b5b6}'
					. '.tcc-gf-seg button[aria-pressed=true]{background:#00A4CF;border-color:#00A4CF;color:#fff;font-weight:600}'
					. '.tcc-gf-seg button:focus-visible{outline:3px solid rgba(0,164,207,.45);outline-offset:2px}'
					. '.tcc-group-count{font-size:.55em;color:#00A4CF;margin-left:8px;white-space:nowrap}'
					// "Show 12 more" under the cards, with "Showing 12 of 16" beside it (the same as the Sermons page).
					. '.tcc-gf-more{display:flex;flex-wrap:wrap;align-items:center;gap:12px 20px;margin:28px 0 0;font:400 17px/1.3 "Open Sans",Helvetica,Arial,sans-serif;color:#6b6b6c}'
					. '.tcc-gf-more[hidden]{display:none}'
					. '.tcc-gf-more button{display:inline-flex;align-items:center;min-height:48px;margin:0;padding:0 20px;font:500 16px "CMG Sans SemiBold","Montserrat",sans-serif;color:#00A4CF;background:#fff;border:2px solid #e3e7ea;border-radius:10px;cursor:pointer;transition:border-color .2s}'
					. '.tcc-gf-more button:hover,.tcc-gf-more button:focus-visible{border-color:#00A4CF}'
					. '@media (prefers-reduced-motion:reduce){.tcc-group-filter,.tcc-group-filter *{transition:none!important}}'
					// On phones the "who" buttons sit two to a row, all the same width, so no button ends up
					// alone on a stretched row. With an odd number, the last one spans the whole row.
					. '@media (max-width:767px){.tcc-gf-label{flex:1 1 100%}.tcc-group-filter select,.tcc-group-filter input[type=search],.tcc-gf-clear{flex:1 1 100%;width:100%}.tcc-gf-seg{display:grid;grid-template-columns:1fr 1fr;flex:1 1 100%}.tcc-gf-seg button{width:100%;padding:0 8px}.tcc-gf-seg button:last-child:nth-child(odd){grid-column:1/-1}}'
					. '</style>';
				$out    .= '<script>(function(){'
					. 'var KEYS=["who","day","often","q"];'
					. 'function init(bar){if(bar.__tcc){return;}var target=document.getElementById(bar.getAttribute("data-target"));if(!target){return;}'
					. 'var cards=[].slice.call(target.querySelectorAll(".tcc-group-card"));'
					. '[].forEach.call(document.querySelectorAll(".tcc-group-count"),function(el){el.textContent=cards.length?String(cards.length):"";});'
					. 'if(cards.length<2){return;}bar.__tcc=1;'
					. 'var ctl={};KEYS.forEach(function(k){ctl[k]=bar.querySelector("[data-f="+k+"]");});'
					. 'var status=bar.querySelector(".tcc-gf-status"),none=bar.querySelector(".tcc-gf-none"),clearBtn=bar.querySelector(".tcc-gf-clear");'
					. 'var facts=cards.map(function(card){var d=card.querySelector(".tcc-group-data");return{who:d?d.getAttribute("data-who")||"":"",days:d?(d.getAttribute("data-days")||"").split(" "):[],often:d?d.getAttribute("data-often")||"":"",text:(card.textContent+" "+(d?d.getAttribute("data-words")||"":"")).toLowerCase()};});'
					// A menu only keeps the choices that at least one group has; a menu with nothing to choose is hidden.
					. '[["who",function(f,v){return f.who===v;}],["day",function(f,v){return f.days.indexOf(v)>-1;}],["often",function(f,v){return f.often===v;}]].forEach(function(p){'
					. 'var sel=ctl[p[0]],left=0;[].slice.call(sel.options).forEach(function(o){if(!o.value){return;}if(facts.some(function(f){return p[1](f,o.value);})){left++;}else{sel.removeChild(o);}});'
					. 'if(left<2){sel.hidden=true;sel.style.display="none";}});'
					// Four or fewer choices read better as press-buttons than as a menu. The menu stays (hidden) and holds the choice.
					. 'var seg=null;if(!ctl.who.hidden){seg=document.createElement("div");seg.className="tcc-gf-seg";seg.setAttribute("role","group");seg.setAttribute("aria-label","Who the group is for");'
					. '[].slice.call(ctl.who.options).forEach(function(o){var b=document.createElement("button");b.type="button";b.textContent=o.textContent;b.setAttribute("data-v",o.value);b.addEventListener("click",function(){ctl.who.value=o.value;apply();});seg.appendChild(b);});'
					. 'ctl.who.parentNode.insertBefore(seg,ctl.who);ctl.who.style.display="none";}'
					// Twelve cards show at first; "Show 12 more" adds twelve. Choosing a filter shows every match.
					. 'var STEP=12,max=STEP,more=document.createElement("div");more.className="tcc-gf-more";more.hidden=true;more.innerHTML="<button type=\\"button\\"></button><span></span>";'
					. 'target.parentNode.insertBefore(more,target.nextSibling);var moreBtn=more.firstChild,moreNote=more.lastChild;'
					. 'moreBtn.addEventListener("click",function(){var first=cards[max];max+=STEP;apply();if(first){first.setAttribute("tabindex","-1");try{first.focus();}catch(e){}}});'
					. 'function apply(){var term=ctl.q.value.trim().toLowerCase(),shown=0,active=0;'
					. 'if(seg){[].forEach.call(seg.children,function(b){b.setAttribute("aria-pressed",b.getAttribute("data-v")===ctl.who.value?"true":"false");});}'
					. 'cards.forEach(function(card,i){var f=facts[i];'
					. 'var ok=(!ctl.who.value||f.who===ctl.who.value)&&(!ctl.day.value||f.days.indexOf(ctl.day.value)>-1)&&(!ctl.often.value||f.often===ctl.often.value)&&(!term||f.text.indexOf(term)>-1);'
					. 'card.style.display=ok?"":"none";if(ok){shown++;}});'
					. 'KEYS.forEach(function(k){var on=!!ctl[k].value.trim();ctl[k].classList.toggle("is-active",on);if(on){active++;}});'
					. 'bar.classList.toggle("is-filtering",active>0);clearBtn.hidden=!active;'
					. 'status.hidden=!active||shown===0;status.textContent="Showing "+shown+" of "+cards.length+" groups";none.hidden=!(active>0&&shown===0);'
					. 'if(!active){cards.forEach(function(card,i){card.style.display=i<max?"":"none";});}var left=cards.length-max;more.hidden=active>0||left<=0;'
					. 'moreBtn.textContent="Show "+Math.min(STEP,left)+" more";moreNote.textContent="Showing "+Math.min(max,cards.length)+" of "+cards.length;}'
					. '["who","day","often"].forEach(function(k){ctl[k].addEventListener("change",apply);});ctl.q.addEventListener("input",apply);'
					. 'clearBtn.addEventListener("click",function(){KEYS.forEach(function(k){ctl[k].value="";});apply();ctl.q.focus();});'
					. 'bar.hidden=false;apply();}'
					. 'function boot(){[].forEach.call(document.querySelectorAll(".tcc-group-filter"),init);}'
					. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",boot);}else{boot();}window.addEventListener("load",boot);'
					. '})();</script>';
			}
			return $out;
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_group_filter', 'tcc_group_filter_shortcode' );
}
