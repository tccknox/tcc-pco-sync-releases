<?php
/**
 * TCC community groups filter bar.
 *
 * [tcc_group_filter]  prints the bar above the group cards on the Community Groups page:
 *                     who the group is for, the day it meets, how often, and a search box.
 * [tcc_group_data]    goes inside each group card; it prints a hidden tag with that group's
 *                     facts (who, days, how often) so the bar knows what to show, and the words
 *                     of its description and organizer so the search box finds them too.
 *
 * The cards themselves are plain Divi: a Divi loop over Community Groups draws every active
 * group. This feature only hides and shows the cards already on the page, in the visitor's
 * browser, so it is instant and asks nothing extra of the server.
 *
 * What it reads, all from the group's own fields (Community Groups Info):
 *   who        "Gender-Specific"            Group is Co-ed / Female Only / Male Only
 *   days       "Date And Meeting Time"      any day names in the words, e.g. "Mondays and Thursdays"
 *   how often  "How Often"                  Weekly; twice a month (1st and 3rd Weeks, 2nd and 4th
 *                                           Weeks, Every Other Week, Bi-Monthly); Monthly
 * A menu only lists choices that at least one group on the page has. "Who" shows as press-buttons
 * (Anyone / Co-ed / Women / Men; two to a row on phones). Twelve cards show at first, with
 * "Show 12 more" under them; choosing a filter shows every match, with "Showing 3 of 8 groups".
 *
 * The look and the script are shared with the Events filter bar: they are in
 * features/filter-bar.css and features/filter-bar.js (a change there changes both pages).
 * This file prints the bar's parts and, on the bar, the settings that make it the Community
 * Groups bar (data-..., explained at the top of filter-bar.js). The bar has the classes
 * tcc-filter-bar and tcc-group-filter; its parts have tcc-fb-... and their older tcc-gf-... names.
 * In the Divi editor the bar shows as a plain preview with a grey note (see the end of filter-bar.css).
 *
 * What the page needs: the list of cards keeps the CSS ID tcc-groups, each card keeps the CSS
 * class tcc-group-card and holds a Text layer with [tcc_group_data]. A <span> with the class
 * tcc-group-count anywhere on the page is filled with the number of groups.
 *
 * With JavaScript off, or with fewer than two groups, the bar stays hidden and every group shows.
 * To remove the bar, switch this feature off on TCC Website > Features: the page simply shows
 * every group, and the two short codes print nothing.
 *
 * Part of the TCC Website Features plugin. Added 2026-11-21.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_group_facts' ) ) {
	/** The three facts the filter needs about one group, as short codes for the browser. */
	function tcc_group_facts( $id ) {
		$who_text = strtolower( (string) get_post_meta( $id, 'gender_specific', true ) );
		$who      = '';
		if ( false !== strpos( $who_text, 'female' ) ) {
			$who = 'f';
		} elseif ( false !== strpos( $who_text, 'male' ) ) {
			$who = 'm';
		} elseif ( '' !== trim( $who_text ) ) {
			$who = 'c';
		}

		$often_text = strtolower( trim( (string) get_post_meta( $id, 'how_often', true ) ) );
		$often      = '';
		if ( 'weekly' === $often_text ) {
			$often = 'w';
		} elseif ( 'monthly' === $often_text ) {
			$often = 'm';
		} elseif ( false !== strpos( $often_text, 'weeks' ) || false !== strpos( $often_text, 'every other' ) || false !== strpos( $often_text, 'bi-monthly' ) ) {
			$often = 't';
		}

		$days  = array();
		$names = array(
			'sun'  => 'sun',
			'mon'  => 'mon',
			'tue'  => 'tue',
			'tues' => 'tue',
			'wed'  => 'wed',
			'thu'  => 'thu',
			'thur' => 'thu',
			'thurs' => 'thu',
			'fri'  => 'fri',
			'sat'  => 'sat',
		);
		$when  = (string) get_post_meta( $id, 'date_and_meeting_time', true );
		if ( preg_match_all( '/\b(sun|mon|tues|tue|wednes|wed|thurs|thur|thu|fri|satur|sat)(?:days?|s)?\b/i', $when, $found ) ) {
			foreach ( $found[1] as $word ) {
				$word = strtolower( $word );
				if ( 'wednes' === $word ) {
					$word = 'wed';
				} elseif ( 'satur' === $word ) {
					$word = 'sat';
				}
				if ( isset( $names[ $word ] ) ) {
					$days[ $names[ $word ] ] = true;
				}
			}
		}

		return array(
			'who'   => $who,
			'often' => $often,
			'days'  => implode( ' ', array_keys( $days ) ),
		);
	}
}

if ( ! function_exists( 'tcc_group_data_shortcode' ) ) {
	function tcc_group_data_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || 'project' !== get_post_type( $id ) ) {
				return '';
			}
			$facts = tcc_group_facts( $id );
			// Words the search box should also find, though the card does not show them: the description and the organizer.
			$words = wp_strip_all_tags( (string) get_post_meta( $id, 'group_description', true ) . ' ' . (string) get_post_meta( $id, 'organizer_name', true ) );
			$words = strtolower( trim( (string) preg_replace( '/\s+/', ' ', $words ) ) );
			return '<span class="tcc-group-data" style="display:none" data-who="' . esc_attr( $facts['who'] ) . '" data-days="' . esc_attr( $facts['days'] ) . '" data-often="' . esc_attr( $facts['often'] ) . '" data-words="' . esc_attr( $words ) . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_group_data', 'tcc_group_data_shortcode' );
}

if ( ! function_exists( 'tcc_filter_bar_assets' ) ) {
	/**
	 * The filter bar's shared look and script (features/filter-bar.css and features/filter-bar.js),
	 * printed inside the page straight after the first filter bar, once per page.
	 * The same small function is in events-filter.php, so it is there whichever feature is switched on.
	 * (Tests can set $GLOBALS['tcc_filter_bar_printed'] back to false to print it again.)
	 */
	function tcc_filter_bar_assets() {
		if ( ! empty( $GLOBALS['tcc_filter_bar_printed'] ) ) {
			return '';
		}
		$GLOBALS['tcc_filter_bar_printed'] = true;
		$file = function ( $ext ) {
			if ( function_exists( 'tcc_site_asset' ) ) {
				return tcc_site_asset( 'features/filter-bar.' . $ext ); // An administrator's saved edit, if any.
			}
			$text = is_readable( __DIR__ . '/filter-bar.' . $ext ) ? (string) file_get_contents( __DIR__ . '/filter-bar.' . $ext ) : '';
			return (string) preg_replace( '/\n\z/', '', $text );
		};
		// Empty lines are left out: WordPress's paragraph tool could otherwise break the style or script apart.
		$css = (string) preg_replace( '/\n\s*\n/', "\n", $file( 'css' ) );
		$js  = (string) preg_replace( '/\n\s*\n/', "\n", $file( 'js' ) );
		return '<style id="tcc-filter-bar-css">' . $css . '</style><script>' . $js . '</script>';
	}
}

if ( ! function_exists( 'tcc_group_filter_shortcode' ) ) {
	function tcc_group_filter_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'target' => 'tcc-groups' ), $atts, 'tcc_group_filter' );
		try {
			// The bar starts hidden; the script shows it once it has found at least two cards.
			// (The Divi editor does not run the script; filter-bar.css shows it there anyway, as a preview.)
			// The settings on the bar (data-...) tell the shared script what to do; see filter-bar.js.
			$out  = '<div class="tcc-filter-bar tcc-group-filter" data-target="' . esc_attr( $atts['target'] ) . '"'
				. ' data-cards=".tcc-group-card" data-card-data=".tcc-group-data" data-count-into=".tcc-group-count"'
				. ' data-status-text="Showing {shown} of {total} groups" data-min-cards="2"'
				. ' data-hide-unused-choices data-buttons="who" data-hide-status-when-none data-focus-search-after-clear'
				. ' role="search" aria-label="Find a group" hidden>';
			$out .= '<span class="tcc-fb-label tcc-gf-label">Find a group</span>';
			$out .= '<select data-f="who" data-from="who" aria-label="Who the group is for"><option value="">Anyone</option><option value="c">Co-ed</option><option value="f">Women</option><option value="m">Men</option></select>';
			$out .= '<select data-f="day" data-from="days" aria-label="Day it meets"><option value="">Any day</option><option value="sun">Sunday</option><option value="mon">Monday</option><option value="tue">Tuesday</option><option value="wed">Wednesday</option><option value="thu">Thursday</option><option value="fri">Friday</option><option value="sat">Saturday</option></select>';
			$out .= '<select data-f="often" data-from="often" aria-label="How often it meets"><option value="">Any schedule</option><option value="w">Weekly</option><option value="t">Twice a month</option><option value="m">Monthly</option></select>';
			$out .= '<input type="search" data-f="q" aria-label="Search groups" placeholder="Search groups" />';
			$out .= '<button type="button" class="tcc-fb-clear tcc-gf-clear" data-clear="all" hidden>Clear filters</button>';
			$out .= '<div class="tcc-fb-status tcc-gf-status" aria-live="polite" hidden></div>';
			$out .= '<div class="tcc-fb-none tcc-gf-none" hidden>No groups match those choices. Try removing one, or clear the filters to see every group.</div>';
			$out .= '</div>';
			return $out . tcc_filter_bar_assets();
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_group_filter', 'tcc_group_filter_shortcode' );
}
