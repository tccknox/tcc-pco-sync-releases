(function () {
	var form = document.getElementById('tcc-sf');
	if (!form) { return; }
	var list = document.getElementById(form.getAttribute('data-target'));
	var rows = [], notes = {};
	try { rows = JSON.parse(document.getElementById('tcc-sf-cards').textContent) || []; } catch (e) {}
	try { notes = JSON.parse(document.getElementById('tcc-sf-series-data').textContent) || {}; } catch (e) {}
	if (!list || !rows.length) { form.hidden = true; return; }

	var PAGE = parseInt(form.getAttribute('data-first'), 10) || 12;
	var KEYS = ['q', 'series', 'speaker', 'book', 'topic'];
	var ctl = {};
	KEYS.forEach(function (k) { ctl[k] = form.querySelector('[data-key="' + k + '"]'); });
	var status = form.querySelector('.tcc-sf-status');
	var live = form.querySelector('[role="status"]');
	var note = document.querySelector('.tcc-sf-note');

	function el(tag, cls, text) { var n = document.createElement(tag); if (cls) { n.className = cls; } if (text != null) { n.textContent = text; } return n; }
	function plain(s) { s = (s || '').toLowerCase(); return s.normalize ? s.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : s; }
	function deepest(node) { while (node && node.firstElementChild) { node = node.firstElementChild; } return node; }

	/* The cards Divi drew, by sermon. */
	var drawn = {}, template = null;
	Array.prototype.forEach.call(list.querySelectorAll('.tcc-sermon-card'), function (card) {
		var d = card.querySelector('.tcc-sermon-data');
		if (!d) { return; }
		drawn[d.getAttribute('data-id')] = card;
		if (!template) { template = card; }
	});
	if (!template) { form.hidden = true; return; }

	/* Opens a copied card's sermon. Cards Divi drew are opened by Divi itself. */
	function go(url, e) {
		if (e && (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1)) { window.open(url, '_blank', 'noopener'); } else { window.location.href = url; }
	}
	function copyCard(row) {
		var card = template.cloneNode(true);
		card.removeAttribute('data-loop-item');
		card.classList.add('tcc-sermon-copy');
		card.setAttribute('role', 'link');
		card.setAttribute('tabindex', '0');
		var pic = card.querySelector('.tcc-sermon-pic') || card.firstElementChild;
		if (pic) { pic.style.backgroundImage = row.i ? 'url("' + row.i + '")' : 'none'; }
		var data = card.querySelector('.tcc-sermon-data');
		if (data && data.parentNode) {
			var holder = data.parentNode;
			holder.textContent = row.sp + (row.sp && row.d ? ' · ' : '') + row.d;
			var mark = el('span', 'tcc-sermon-data'); mark.hidden = true; mark.setAttribute('data-id', row.id); holder.appendChild(mark);
		}
		var title = card.querySelector('.tcc-sermon-title');
		title = title ? (title.querySelector('h1,h2,h3,h4,h5,h6') || deepest(title)) : card.querySelector('h3');
		if (title) { title.textContent = row.t; }
		var series = card.querySelector('.tcc-sermon-series');
		if (series) { deepest(series).textContent = row.sn || ''; }
		card.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); go(row.u, e); }, true);
		card.addEventListener('auxclick', function (e) { if (e.button === 1) { e.preventDefault(); e.stopPropagation(); go(row.u, e); } }, true);
		card.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); go(row.u, e); } }, true);
		return card;
	}

	/* One entry per sermon, newest first. Copies are made only when a card is first needed. */
	var speakers = {};
	var cards = rows.map(function (row) {
		/* A sermon with two speakers on one line counts under each of them. */
		var keys = [].concat(row.k || []), names = [].concat(row.kn || []);
		keys.forEach(function (k, i) { if (k && !speakers[k]) { speakers[k] = names[i] || row.sp; } });
		return { row: row, node: drawn[String(row.id)] || null, who: ' ' + keys.join(' ') + ' ', book: ' ' + (row.b || []).join(' ') + ' ', topic: ' ' + (row.tp || []).join(' ') + ' ' };
	});
	/* A card Divi drew for a sermon the list does not know (it should not happen) is left out of the way. */
	Object.keys(drawn).forEach(function (id) {
		if (!rows.some(function (r) { return String(r.id) === id; })) { drawn[id].style.display = 'none'; }
	});

	Object.keys(speakers).sort(function (a, b) { return speakers[a].localeCompare(speakers[b]); }).forEach(function (slug) {
		var o = el('option', '', speakers[slug]); o.value = slug; ctl.speaker.appendChild(o);
	});

	/* The pieces under the list: "nothing found" and "Show 12 more". */
	var none = el('div', 'tcc-sf-none');
	none.appendChild(el('h3', '', 'No sermons match that.'));
	none.appendChild(el('p', '', 'Try a shorter word, or clear a filter.'));
	none.hidden = true;
	var more = el('div', 'tcc-sf-more');
	/* et_pb_button gives it the site's own button look (Divi's site-wide button settings). */
	var moreBtn = el('button', 'tcc-sf-more-btn', 'Show more'); moreBtn.type = 'button'; // a quiet button, the same as "Show more" on the search and Trinity Talk pages
	var moreCount = el('span', 'tcc-sf-more-count');
	more.appendChild(moreBtn); more.appendChild(moreCount);
	list.parentNode.insertBefore(none, list.nextSibling);
	list.parentNode.insertBefore(more, none.nextSibling);

	var shown = PAGE;

	function writeUrl() {
		if (!window.history || !history.replaceState) { return; }
		try {
			var u = new URL(window.location.href);
			KEYS.forEach(function (k) {
				var v = ctl[k].value.trim();
				if (v) { u.searchParams.set('sermon_' + k, v); } else { u.searchParams.delete('sermon_' + k); }
			});
			history.replaceState(null, '', u.toString());
		} catch (e) {}
	}

	function apply(reset, focusFrom) {
		if (reset) { shown = PAGE; }
		var words = plain(ctl.q.value.trim()).split(/\s+/).filter(Boolean);
		var v = { series: ctl.series.value, speaker: ctl.speaker.value, book: ctl.book.value, topic: ctl.topic.value };
		var n = 0, active = 0, order = [], firstNew = null;
		cards.forEach(function (c) {
			var r = c.row;
			var ok = (!v.series || r.s === v.series) &&
				(!v.speaker || c.who.indexOf(' ' + v.speaker + ' ') > -1) &&
				(!v.book || c.book.indexOf(' ' + v.book + ' ') > -1) &&
				(!v.topic || c.topic.indexOf(' ' + v.topic + ' ') > -1) &&
				words.every(function (w) { return r.x.indexOf(w) > -1; });
			if (ok) { n++; }
			var vis = ok && n <= shown;
			if (vis && !c.node) { c.node = copyCard(r); }
			if (c.node) {
				c.node.style.display = vis ? '' : 'none';
				if (vis) { order.push(c.node); if (focusFrom && n === focusFrom) { firstNew = c.node; } }
			}
		});
		/* Put the showing cards in the page in date order (copies are added here the first time). */
		order.forEach(function (node) { list.appendChild(node); });

		status.innerHTML = '';
		KEYS.forEach(function (k) {
			var val = ctl[k].value.trim();
			ctl[k].classList.toggle('is-active', !!val);
			if (!val) { return; }
			active++;
			var label = k === 'q' ? 'Search: “' + val + '”' : ctl[k].getAttribute('data-name') + ': ' + ctl[k].options[ctl[k].selectedIndex].text;
			var chip = el('button', 'tcc-sf-chip'); chip.type = 'button';
			chip.appendChild(el('span', '', label));
			var x = el('i', '', '×'); x.setAttribute('aria-hidden', 'true'); chip.appendChild(x);
			chip.setAttribute('aria-label', 'Remove filter: ' + label);
			chip.addEventListener('click', function () { ctl[k].value = ''; apply(true); ctl[k].focus(); });
			status.appendChild(chip);
		});
		if (active) {
			var cnt = el('span', 'tcc-sf-count');
			cnt.appendChild(el('strong', '', 'Showing ' + n));
			cnt.appendChild(document.createTextNode(' of ' + cards.length + ' sermons'));
			status.insertBefore(cnt, status.firstChild);
			var clear = el('button', 'tcc-sf-clear', 'Clear all'); clear.type = 'button';
			clear.addEventListener('click', function () { KEYS.forEach(function (k) { ctl[k].value = ''; }); apply(true); ctl.q.focus(); });
			status.appendChild(clear);
		}
		status.hidden = !active;
		form.classList.toggle('is-filtering', active > 0);
		if (live) { live.textContent = active ? (n === 1 ? '1 sermon found' : n + ' sermons found') : ''; }

		none.hidden = n > 0;
		var left = n - Math.min(n, shown);
		more.hidden = left <= 0;
		moreBtn.textContent = 'Show ' + Math.min(PAGE, left) + ' more';
		moreCount.textContent = 'Showing ' + Math.min(n, shown) + ' of ' + n;

		/* When one series is chosen, a note about it appears with a link to its own page. */
		var g = notes[v.series];
		if (note) {
			note.hidden = !g;
			if (g) {
				note.innerHTML = '';
				note.href = g.u;
				if (g.i) { var pic = el('span', 'tcc-sf-note-pic'); pic.style.backgroundImage = 'url("' + g.i + '")'; note.appendChild(pic); }
				var box = el('span', 'tcc-sf-note-text');
				box.appendChild(el('strong', '', g.n));
				if (g.d) { box.appendChild(el('span', 'tcc-sf-note-desc', g.d)); }
				box.appendChild(el('span', 'tcc-sf-note-go', 'Open the series page, with every part in order ›'));
				note.appendChild(box);
			}
		}
		writeUrl();
		if (firstNew) { try { firstNew.focus({ preventScroll: true }); } catch (e) {} }
	}

	/* A link such as /sermons/?sermon_series=in-christ arrives already filtered. */
	try {
		var params = new URL(window.location.href).searchParams;
		KEYS.forEach(function (k) {
			var val = params.get('sermon_' + k);
			if (!val) { return; }
			if (k === 'q') { ctl.q.value = val; return; }
			var has = Array.prototype.some.call(ctl[k].options, function (o) { return o.value === val; });
			if (has) { ctl[k].value = val; }
		});
	} catch (e) {}

	KEYS.forEach(function (k) {
		ctl[k].addEventListener(k === 'q' ? 'input' : 'change', function () { apply(true); });
	});
	/* After "Show 12 more", the keyboard is placed on the first of the new cards. */
	moreBtn.addEventListener('click', function () { var from = shown + 1; shown += PAGE; apply(false, from); });
	apply(true);
})();
