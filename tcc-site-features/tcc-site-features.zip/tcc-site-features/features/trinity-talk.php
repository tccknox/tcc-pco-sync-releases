<?php
/**
 * TCC Trinity Talk pages: the automatic pieces of the three Trinity Talk pages.
 *
 * Trinity Talk is the church's chapter-by-chapter writing on the Bible. In WordPress each piece is an
 * "Article", and the book it belongs to (Matthew, Romans...) is a "Trinity Talk" category on it.
 *
 * The three pages are ordinary Divi layouts (Divi > Theme Builder):
 *   "Trinity Talk: one piece - NEW (shows automatically)"       the page of one piece
 *   "Trinity Talk: a book's page - NEW (shows automatically)"   every chapter of one book
 *   "Trinity Talk: home - NEW (shows automatically)"            all the books
 * Those templates are deliberately NOT assigned to anything. This file finds them (by the short code
 * each one holds) and shows them on the right pages. Switch this feature off and the website goes
 * straight back to the older Trinity Talk pages, which are still assigned in the Theme Builder.
 *
 * Divi draws the sections, headings, the words of the piece, the rows and the cards. This file adds
 * only what Divi cannot work out by itself:
 *
 *  1. Short lines of text: the title without its "Matthew 5 |" start, "Matthew - Chapter 5 of 28",
 *     the writer and how long the piece takes to read.
 *  2. Five lists Divi can loop over, so rows and cards stay ordinary Divi layers:
 *       "Trinity Talk: previous chapter (automatic)"            none or one piece
 *       "Trinity Talk: next chapter (automatic)"                none or one piece
 *       "Trinity Talk: more from this book (automatic)"         up to four pieces
 *       "Trinity Talk: every chapter of this book (automatic)"  the rows on a book's page
 *       "Trinity Talk: pieces in no book (automatic)"           the "More writing" cards on the home page
 *  3. The grey panels (a button for every chapter, the writers) and the book buttons.
 *  4. A few styles: the hover on rows and cards, the small arrows, the chapter buttons.
 *
 * Nothing is typed in twice. The book comes from the piece's Trinity Talk category; the chapter
 * number comes from the start of its title ("Matthew 5 | Choosing to Walk The Hard Path").
 * Chapters are put in order by that number, not by date.
 *
 * Short codes (each prints nothing when it is put on some other page):
 *   One piece
 *   [tcc_talk_title]        the title without "Matthew 5 |". Inside a row or card it is that piece's title.
 *   [tcc_talk_facts]        "Matthew - Chapter 5 of 28 - By Mark Medley - 3 minute read"
 *   [tcc_talk_panel]        the grey panel: Written by, a button for every chapter, Go further
 *   [tcc_talk_steps_title]  "Keep reading in Matthew" and "Chapter 5 of 28"
 *   [tcc_talk_book_link]    the "See all 28 chapters" link
 *   [tcc_talk_step]         inside a previous or next row: "Previous chapter" or "Next chapter"
 *   [tcc_talk_end]          which="first" or "last": the note shown in place of a missing row
 *   [tcc_talk_more_title]   "More from Matthew" or "More writing"
 *   [tcc_talk_home_link]    the "Back to Trinity Talk" link (label="..." changes the words)
 *   Inside any row or card
 *   [tcc_talk_tile]         the small white tile: "MATTHEW 4" (label="Chapter" prints "CHAPTER 4")
 *   [tcc_talk_card_meta]    "Matthew 7 - Mark Medley"
 *   [tcc_talk_row_meta]     "Mark Medley - 3 minute read"
 *   [tcc_talk_summary]      the first sentence or two of the piece (or its Yoast description, if one was typed)
 *   A book's page
 *   [tcc_talk_book_lead]    "28 chapters, each with a short reading, written by 11 of Trinity's pastors and members..."
 *   [tcc_talk_start]        the "Start with chapter 1" button
 *   [tcc_talk_book_panel]   the grey panel: Jump to a chapter, Written by, More
 *   [tcc_talk_books]        a button for every book (the "Other books" section)
 *   The home page
 *   [tcc_talk_shelf]        group="gospels", "paul" or "other": that group's book cards
 *   [tcc_talk_loose_count]  how many pieces are in no book
 *   [tcc_talk_show_all]     the "Show 12 more" button under the "More writing" cards, with "Showing 12 of 37"
 *
 * In the Divi editor there is no piece being viewed, so every part shows a real chapter from the
 * middle of the longest book as an example.
 *
 * Part of the TCC Website Features plugin (added in 0.6.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_talk_index' ) ) {

	/** The WordPress names this feature reads. */
	function tcc_talk_post_type() {
		return 'article';
	}
	function tcc_talk_taxonomy() {
		return 'trinity-talk';
	}

	/** The five lists Divi can loop over: name => label shown in Divi's loop settings. */
	function tcc_talk_sources() {
		return array(
			'tcc_talk_prev'  => 'Trinity Talk: previous chapter (automatic)',
			'tcc_talk_next'  => 'Trinity Talk: next chapter (automatic)',
			'tcc_talk_more'  => 'Trinity Talk: more from this book (automatic)',
			'tcc_talk_list'  => 'Trinity Talk: every chapter of this book (automatic)',
			'tcc_talk_loose' => 'Trinity Talk: pieces in no book (automatic)',
		);
	}

	/** The books of the Bible in their usual order, in the three groups the home page shows. */
	function tcc_talk_shelves() {
		return array(
			'gospels' => array( 'Matthew', 'Mark', 'Luke', 'John', 'Acts' ),
			'paul'    => array( 'Romans', '1 Corinthians', '2 Corinthians', 'Galatians', 'Ephesians', 'Philippians', 'Colossians', '1 Thessalonians', '2 Thessalonians', '1 Timothy', '2 Timothy', 'Titus', 'Philemon' ),
			'other'   => array( 'Hebrews', 'James', '1 Peter', '2 Peter', '1 John', '2 John', '3 John', 'Jude', 'Revelation' ),
		);
	}

	/** Letters and digits only, lower case: used to compare "1 Corinthians" with "1corinthians". */
	function tcc_talk_key( $text ) {
		return preg_replace( '/[^a-z0-9]+/', '', strtolower( (string) $text ) );
	}

	/**
	 * The first sentence or two of a piece, for rows and cards: about 100 to 200 letters, ending at
	 * the end of a sentence where it can.
	 */
	function tcc_talk_make_summary( $content ) {
		$text = html_entity_decode( wp_strip_all_tags( strip_shortcodes( (string) $content ) ), ENT_QUOTES, 'UTF-8' );
		$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
		if ( '' === $text ) {
			return '';
		}
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
		if ( $length <= 200 ) {
			return $text;
		}
		$out   = '';
		$parts = preg_split( '/(?<=[.!?])\s+/u', $text );
		foreach ( (array) $parts as $sentence ) {
			$try     = '' === $out ? $sentence : $out . ' ' . $sentence;
			$try_len = function_exists( 'mb_strlen' ) ? mb_strlen( $try ) : strlen( $try );
			if ( $try_len > 200 ) {
				break;
			}
			$out = $try;
			if ( $try_len >= 100 ) {
				break;
			}
		}
		if ( '' !== $out ) {
			return $out;
		}
		// The first sentence alone is too long: stop at a whole word and show that more follows.
		$cut   = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 180 ) : substr( $text, 0, 180 );
		$space = strrpos( $cut, ' ' );
		if ( false !== $space && $space > 80 ) {
			$cut = substr( $cut, 0, $space );
		}
		return rtrim( $cut, ' ,;:-' ) . '...';
	}

	/**
	 * Everything this feature knows, worked out once and remembered for 12 hours (and worked out
	 * again as soon as a piece or a Trinity Talk category is saved):
	 *   'posts' => piece id => array( t (short title), full, book (category id or 0), n (chapter or 0),
	 *                                 a (writer), m (minutes to read), x (summary), g (group, for pieces in no book) )
	 *   'books' => category id => array( name, slug, url, ids (in chapter order), max (highest chapter) )
	 *   'loose' => ids of the pieces in no book
	 *   'heads' => ids of the heading categories (New Testament, Old Testament)
	 */
	function tcc_talk_index() {
		static $index = null;
		if ( null !== $index ) {
			return $index;
		}
		// The "2" is the shape of what is remembered. Raise it when this function changes what it works
		// out, so an older remembered copy is not used.
		$key    = 'tcc_talk_index_2_' . tcc_site_gen( 'talk' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['posts'], $cached['books'], $cached['loose'], $cached['heads'] ) ) {
			$index = $cached;
			return $index;
		}
		$index = array(
			'posts' => array(),
			'books' => array(),
			'loose' => array(),
			'heads' => array(),
		);
		try {
			$terms = get_terms(
				array(
					'taxonomy'   => tcc_talk_taxonomy(),
					'hide_empty' => false,
				)
			);
			if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
				return $index;
			}
			// "New Testament" and "Old Testament" are headings; a book is a category filed under one of them.
			$heads = array();
			$names = array();
			foreach ( $terms as $term ) {
				$names[ (int) $term->term_id ] = (string) $term->name;
				if ( in_array( $term->slug, array( 'new-testament', 'old-testament' ), true ) ) {
					$heads[] = (int) $term->term_id;
				}
			}
			$index['heads'] = $heads;
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( in_array( $id, $heads, true ) || ! in_array( (int) $term->parent, $heads, true ) ) {
					continue;
				}
				$link                  = get_term_link( $term );
				$index['books'][ $id ] = array(
					'name' => html_entity_decode( (string) $term->name, ENT_QUOTES, 'UTF-8' ),
					'slug' => (string) $term->slug,
					'url'  => is_wp_error( $link ) ? '' : (string) $link,
					'ids'  => array(),
					'max'  => 0,
				);
			}

			$posts = get_posts(
				array(
					'post_type'        => tcc_talk_post_type(),
					'post_status'      => 'publish',
					'has_password'     => false, // A password-protected piece is never listed or summarised.
					'numberposts'      => -1,
					'orderby'          => 'date',
					'order'            => 'ASC',
					'suppress_filters' => true,
				)
			);
			$sort  = array();
			$loose = array();
			foreach ( (array) $posts as $post ) {
				if ( ! ( $post instanceof WP_Post ) ) {
					continue;
				}
				$id       = (int) $post->ID;
				$full     = trim( html_entity_decode( wp_strip_all_tags( (string) $post->post_title ), ENT_QUOTES, 'UTF-8' ) );
				$term_ids = wp_get_object_terms( $id, tcc_talk_taxonomy(), array( 'fields' => 'ids' ) );
				$term_ids = is_wp_error( $term_ids ) ? array() : array_map( 'intval', (array) $term_ids );
				$book     = 0;
				foreach ( $term_ids as $term_id ) {
					if ( isset( $index['books'][ $term_id ] ) ) {
						$book = $term_id;
						break;
					}
				}
				// "Matthew 5 | Choosing to Walk The Hard Path": the part before the bar names the book and chapter.
				$short   = $full;
				$chapter = 0;
				$bar     = strpos( $full, '|' );
				if ( $book && false !== $bar ) {
					$left  = trim( substr( $full, 0, $bar ) );
					$right = trim( substr( $full, $bar + 1 ) );
					// The book's name with any spacing ("1 Corinthians", "1Corinthians"), then the first number
					// after it. "John 2 & 3" is chapter 2.
					$words = array_map( 'preg_quote', preg_split( '/\s+/', trim( $index['books'][ $book ]['name'] ) ) );
					if ( '' !== $right && $words && preg_match( '/^' . implode( '\s*', $words ) . '(?![a-z])\s*(.*)$/iu', $left, $found ) ) {
						$short = $right;
						$rest  = trim( $found[1] );
						if ( preg_match( '/^(\d+)/', $rest, $number ) ) {
							$chapter = (int) $number[1];
						} elseif ( '' === $rest ) {
							$chapter = 1; // A book with one chapter (Jude, Philemon).
						}
					}
				}
				$typed = trim( (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ) );
				$words = str_word_count( wp_strip_all_tags( (string) $post->post_content ) );
				$group = '';
				if ( ! $book ) {
					foreach ( $term_ids as $term_id ) {
						if ( isset( $names[ $term_id ] ) && ( '' === $group || ! in_array( $term_id, $heads, true ) ) ) {
							$group = $names[ $term_id ];
						}
					}
					$loose[ $id ] = $post->post_date;
				}
				$index['posts'][ $id ] = array(
					't'    => $short,
					'full' => $full,
					'book' => $book,
					'n'    => $chapter,
					'a'    => (string) get_the_author_meta( 'display_name', (int) $post->post_author ),
					'm'    => max( 1, (int) round( $words / 220 ) ),
					'x'    => '' !== $typed ? $typed : tcc_talk_make_summary( $post->post_content ),
					'g'    => html_entity_decode( $group, ENT_QUOTES, 'UTF-8' ),
				);
				if ( $book ) {
					$sort[ $book ][ $id ] = sprintf( '%05d %s', $chapter ? $chapter : 99999, $post->post_date );
				}
			}
			foreach ( $sort as $book => $rows ) {
				asort( $rows, SORT_STRING );
				$index['books'][ $book ]['ids'] = array_map( 'intval', array_keys( $rows ) );
				foreach ( array_keys( $rows ) as $id ) {
					$index['books'][ $book ]['max'] = max( $index['books'][ $book ]['max'], $index['posts'][ $id ]['n'] );
				}
			}
			arsort( $loose, SORT_STRING ); // Newest first.
			$index['loose'] = array_map( 'intval', array_keys( $loose ) );
			set_transient( $key, $index, 12 * HOUR_IN_SECONDS );
		} catch ( \Throwable $e ) {
			return $index;
		}
		return $index;
	}

	/** Forget what was worked out, so the next page view works it out again. */
	function tcc_talk_forget() {
		tcc_site_new_gen( 'talk' );
	}
	add_action( 'save_post_article', 'tcc_talk_forget' );
	add_action(
		'deleted_post',
		function ( $post_id, $post = null ) {
			if ( $post instanceof WP_Post && tcc_talk_post_type() === $post->post_type ) {
				tcc_talk_forget();
			}
		},
		10,
		2
	);
	add_action(
		'set_object_terms',
		function ( $object_id, $terms, $tt_ids, $taxonomy ) {
			if ( tcc_talk_taxonomy() === $taxonomy ) {
				tcc_talk_forget();
			}
		},
		10,
		4
	);
	foreach ( array( 'created_trinity-talk', 'edited_trinity-talk', 'delete_trinity-talk' ) as $tcc_talk_hook ) {
		add_action( $tcc_talk_hook, 'tcc_talk_forget' );
	}
	unset( $tcc_talk_hook );

	/* ------------------------------------------------------------------------------------------
	 * Which page is this?
	 * ---------------------------------------------------------------------------------------- */

	/** Is a visitor looking at one Trinity Talk piece? */
	function tcc_talk_is_single() {
		return did_action( 'wp' ) && ! is_admin() && is_singular( tcc_talk_post_type() );
	}

	/** Is a visitor looking at the page of a Trinity Talk category (a book)? */
	function tcc_talk_is_term() {
		return did_action( 'wp' ) && ! is_admin() && is_tax( tcc_talk_taxonomy() );
	}

	/** Is a visitor looking at the Trinity Talk home page (the list of all pieces)? */
	function tcc_talk_is_archive() {
		return did_action( 'wp' ) && ! is_admin() && is_post_type_archive( tcc_talk_post_type() );
	}

	/**
	 * Which of the three new pages this page view should show: 'single', 'book', 'home' or ''.
	 * The heading categories (New Testament) have no chapters of their own, so they show the home page.
	 */
	function tcc_talk_page_kind() {
		if ( tcc_talk_is_single() ) {
			return 'single';
		}
		if ( tcc_talk_is_archive() ) {
			return 'home';
		}
		if ( tcc_talk_is_term() ) {
			$index = tcc_talk_index();
			return in_array( (int) get_queried_object_id(), $index['heads'], true ) ? 'home' : 'book';
		}
		return '';
	}

	/** True in the Divi editor, where there is no piece or book being viewed. */
	function tcc_talk_editing() {
		return tcc_site_divi_drawing(); // In the plugin's main file.
	}

	/** A real book to show in the Divi editor: the one with the most chapters. */
	function tcc_talk_example_book() {
		$index = tcc_talk_index();
		$best  = 0;
		$most  = 0;
		foreach ( $index['books'] as $id => $book ) {
			if ( count( $book['ids'] ) > $most ) {
				$most = count( $book['ids'] );
				$best = (int) $id;
			}
		}
		return $best;
	}

	/** The piece these parts are about: the one being viewed, or, in the Divi editor, an example. */
	function tcc_talk_post_id() {
		if ( tcc_talk_is_single() ) {
			return (int) get_queried_object_id();
		}
		if ( ! tcc_talk_editing() ) {
			return 0;
		}
		$index = tcc_talk_index();
		$book  = tcc_talk_example_book();
		if ( $book && $index['books'][ $book ]['ids'] ) {
			$ids = $index['books'][ $book ]['ids'];
			return (int) $ids[ (int) floor( count( $ids ) / 2 ) ];
		}
		return 0;
	}

	/** The category whose page is being viewed (a book, or a group such as Christian Living), or an example. */
	function tcc_talk_term_id() {
		if ( tcc_talk_is_term() ) {
			return (int) get_queried_object_id();
		}
		return tcc_talk_editing() ? tcc_talk_example_book() : 0;
	}

	/** The piece a short code inside a row or card is about; outside one, the piece being viewed. */
	function tcc_talk_item_id() {
		$id    = (int) get_the_ID();
		$index = tcc_talk_index();
		if ( $id && isset( $index['posts'][ $id ] ) ) {
			return $id;
		}
		return tcc_talk_post_id();
	}

	/** One piece's facts from the index, or null. */
	function tcc_talk_fact( $post_id ) {
		$index = tcc_talk_index();
		return isset( $index['posts'][ (int) $post_id ] ) ? $index['posts'][ (int) $post_id ] : null;
	}

	/** The book a piece belongs to (with 'id' and the piece's place 'at', from 0), or null. */
	function tcc_talk_book_of( $post_id ) {
		$fact  = tcc_talk_fact( $post_id );
		$index = tcc_talk_index();
		if ( ! $fact || ! $fact['book'] || ! isset( $index['books'][ $fact['book'] ] ) ) {
			return null;
		}
		$book       = $index['books'][ $fact['book'] ];
		$at         = array_search( (int) $post_id, $book['ids'], true );
		$book['id'] = (int) $fact['book'];
		$book['at'] = false === $at ? 0 : (int) $at;
		return $book;
	}

	/** The address of the Trinity Talk home page. */
	function tcc_talk_home_url() {
		$url = (string) get_post_type_archive_link( tcc_talk_post_type() );
		return '' !== $url ? $url : home_url( '/articles/' );
	}

	/** The pieces listed on a category's page, in order: a book's chapters, or a group's pieces. */
	function tcc_talk_term_ids( $term_id ) {
		$term_id = (int) $term_id;
		$index   = tcc_talk_index();
		if ( isset( $index['books'][ $term_id ] ) ) {
			return $index['books'][ $term_id ]['ids'];
		}
		if ( $term_id < 1 ) {
			return array();
		}
		static $memo = array();
		if ( ! isset( $memo[ $term_id ] ) ) {
			$ids              = get_posts(
				array(
					'post_type'        => tcc_talk_post_type(),
					'post_status'      => 'publish',
					'numberposts'      => 200,
					'fields'           => 'ids',
					'orderby'          => 'date',
					'order'            => 'DESC',
					'suppress_filters' => true,
					'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'taxonomy'         => tcc_talk_taxonomy(),
							'terms'            => array( $term_id ),
							'include_children' => false,
						),
					),
				)
			);
			$memo[ $term_id ] = array_map( 'intval', (array) $ids );
		}
		return $memo[ $term_id ];
	}

	/** The previous and next chapter of a piece: array( 'prev' => id or 0, 'next' => id or 0 ). */
	function tcc_talk_steps( $post_id ) {
		$out  = array(
			'prev' => 0,
			'next' => 0,
		);
		$book = tcc_talk_book_of( $post_id );
		if ( ! $book || count( $book['ids'] ) < 2 ) {
			return $out;
		}
		if ( $book['at'] > 0 ) {
			$out['prev'] = (int) $book['ids'][ $book['at'] - 1 ];
		}
		if ( $book['at'] < count( $book['ids'] ) - 1 ) {
			$out['next'] = (int) $book['ids'][ $book['at'] + 1 ];
		}
		return $out;
	}

	/**
	 * The cards at the foot of a piece: up to four.
	 * In a book: the chapters after the next one (going round to the start at the end of the book).
	 * In no book: other pieces that are in no book.
	 */
	function tcc_talk_more( $post_id ) {
		$post_id = (int) $post_id;
		$out     = array();
		$book    = tcc_talk_book_of( $post_id );
		$index   = tcc_talk_index();
		if ( $book ) {
			$ids   = $book['ids'];
			$count = count( $ids );
			$steps = tcc_talk_steps( $post_id );
			for ( $k = 2; $k < $count + 2 && count( $out ) < 4; $k++ ) {
				$id = (int) $ids[ ( $book['at'] + $k ) % $count ];
				if ( $id !== $post_id && $id !== $steps['prev'] && $id !== $steps['next'] && ! in_array( $id, $out, true ) ) {
					$out[] = $id;
				}
			}
			if ( ! $out ) {
				// A book with one or two pieces (Jude, Philemon) has no other chapters to offer:
				// show where the books that follow it begin.
				$order = tcc_talk_books_in_order();
				$place = array_search( (int) $book['id'], $order, true );
				$total = count( $order );
				for ( $k = 1; false !== $place && $k < $total && count( $out ) < 4; $k++ ) {
					$next = $index['books'][ $order[ ( $place + $k ) % $total ] ];
					if ( $next['ids'] ) {
						$out[] = (int) $next['ids'][0];
					}
				}
			}
			return $out;
		}
		$ids   = $index['loose'];
		$count = count( $ids );
		$at    = array_search( $post_id, $ids, true );
		$at    = false === $at ? -1 : (int) $at;
		for ( $k = 1; $k <= $count && count( $out ) < 4; $k++ ) {
			$id = (int) $ids[ ( $at + $k ) % $count ];
			if ( $id !== $post_id && ! in_array( $id, $out, true ) ) {
				$out[] = $id;
			}
		}
		return $out;
	}

	/* ------------------------------------------------------------------------------------------
	 * Showing the three new layouts.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The Theme Builder body layouts that hold the three pages: array( 'single' => id, 'book' => id, 'home' => id ),
	 * 0 for one that does not exist. Found by the short code each holds, not by name or number, so
	 * renaming a template does not break anything.
	 */
	function tcc_talk_layouts() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		return tcc_site_body_layouts(
			array(
				'single' => '[tcc_talk_panel]',
				'book'   => '[tcc_talk_book_panel]',
				'home'   => '[tcc_talk_shelf',
			)
		);
	}

	/** The new layout this page view shows ('single', 'book' or 'home'), or '' when it keeps the older page. */
	function tcc_talk_showing() {
		static $showing = null;
		if ( null !== $showing ) {
			return $showing;
		}
		if ( ! did_action( 'wp' ) ) {
			return '';
		}
		$showing = '';
		try {
			$kind = tcc_talk_page_kind();
			if ( '' === $kind ) {
				return $showing;
			}
			// For testing only, and only for a signed-in administrator: adding ?tcc_talk_test=old to the
			// address shows the older page, to compare the two.
			if ( isset( $_GET['tcc_talk_test'] ) && 'old' === $_GET['tcc_talk_test'] && current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return $showing;
			}
			$layouts = tcc_talk_layouts();
			if ( ! empty( $layouts[ $kind ] ) ) {
				$showing = $kind;
			}
		} catch ( \Throwable $e ) {
			$showing = '';
		}
		return $showing;
	}

	/** Shows the new layout on Trinity Talk pages, whatever is assigned to them in the Theme Builder. */
	function tcc_talk_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) ) {
				return $layouts;
			}
			$kind = tcc_talk_showing();
			if ( '' === $kind ) {
				return $layouts;
			}
			$ids = tcc_talk_layouts();
			return tcc_site_use_body_layout( $layouts, $ids[ $kind ] );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_talk_swap_layout', 20 );

	/** Used by the "Page trail" feature: the steps after Home on a Trinity Talk page, or null elsewhere. */
	function tcc_talk_trail_steps() {
		try {
			$kind = tcc_talk_page_kind();
			if ( '' === $kind ) {
				return null;
			}
			$steps = array();
			$home  = tcc_talk_home_url();
			if ( tcc_talk_is_archive() ) {
				$steps[] = array( 'Trinity Talk', '' );
				return $steps;
			}
			$steps[] = array( 'Trinity Talk', $home );
			if ( tcc_talk_is_term() ) {
				$term = get_queried_object();
				if ( $term instanceof WP_Term ) {
					// 'long' leaves this step off on phones, where the page title just below says the same.
					$steps[] = array(
						$term->name,
						'',
						'long' => true,
					);
				}
				return $steps;
			}
			$id   = (int) get_queried_object_id();
			$book = tcc_talk_book_of( $id );
			$fact = tcc_talk_fact( $id );
			if ( $book ) {
				$steps[] = array( $book['name'], $book['url'] );
			}
			$steps[] = array(
				$fact ? $fact['t'] : get_the_title( $id ),
				'',
				'long' => true,
			);
			return $steps;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/* ------------------------------------------------------------------------------------------
	 * The five lists Divi loops over.
	 * ---------------------------------------------------------------------------------------- */

	// Automatic lists for Divi loops (tcc_site_loop_source() is in the plugin's main file).
	add_action(
		'init',
		function () {
			foreach ( tcc_talk_sources() as $name => $label ) {
				tcc_site_loop_source( $name, $label, 'tcc_talk_answer', array( 'title' ) );
			}
		},
		30
	);

	/** The pieces a Divi loop gets for one of the five lists (cut to the loop's "posts per page"). */
	function tcc_talk_answer( $name, $query ) {
		if ( 'tcc_talk_loose' === $name ) {
			$index = tcc_talk_index();
			return $index['loose'];
		}
		if ( 'tcc_talk_list' === $name ) {
			return tcc_talk_term_ids( tcc_talk_term_id() );
		}
		$current = tcc_talk_post_id();
		if ( ! $current ) {
			return array();
		}
		if ( 'tcc_talk_more' === $name ) {
			return tcc_talk_more( $current );
		}
		$steps = tcc_talk_steps( $current );
		$one   = 'tcc_talk_prev' === $name ? $steps['prev'] : $steps['next'];
		return $one ? array( $one ) : array();
	}
}

/* ----------------------------------------------------------------------------------------------
 * Short codes.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_talk_title_shortcode' ) ) {

	/** "Chapter 5 of 28" for a piece, or '' when it has no chapter number. */
	function tcc_talk_chapter_words( $post_id ) {
		$fact = tcc_talk_fact( $post_id );
		$book = tcc_talk_book_of( $post_id );
		if ( ! $fact || ! $book || ! $fact['n'] ) {
			return '';
		}
		return 'Chapter ' . (int) $fact['n'] . ( $book['max'] > 1 ? ' of ' . (int) $book['max'] : '' );
	}

	/** The title without its "Matthew 5 |" start. */
	function tcc_talk_title_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			return $fact ? esc_html( $fact['t'] ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_title', 'tcc_talk_title_shortcode' );

	/** "Matthew - Chapter 5 of 28 - By Mark Medley - 3 minute read", under the title. */
	function tcc_talk_facts_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$dot  = '<span class="tcc-tt-dot" aria-hidden="true">&middot;</span>';
			$html = '';
			$book = tcc_talk_book_of( $id );
			if ( $book ) {
				$where   = '' !== $book['url'] ? '<a href="' . esc_url( $book['url'] ) . '">' . esc_html( $book['name'] ) . '</a>' : esc_html( $book['name'] );
				$chapter = tcc_talk_chapter_words( $id );
				$html   .= '<span class="tcc-tt-where">' . $where . ( '' !== $chapter ? ' &middot; ' . esc_html( $chapter ) : '' ) . '</span>' . $dot;
			}
			if ( '' !== $fact['a'] ) {
				$html .= 'By <b>' . esc_html( $fact['a'] ) . '</b>' . $dot;
			}
			return $html . (int) $fact['m'] . ' minute read';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_facts', 'tcc_talk_facts_shortcode' );

	/** One button for every chapter of a book. $here is the piece being read (0 for none). */
	function tcc_talk_chips( $book, $here ) {
		$index = tcc_talk_index();
		$html  = '<ul class="tcc-tt-chips">';
		foreach ( $book['ids'] as $id ) {
			$fact = $index['posts'][ $id ];
			$now  = (int) $id === (int) $here;
			$html .= '<li><a class="tcc-tt-chip' . ( $now ? ' is-here' : '' ) . '" href="' . esc_url( get_permalink( $id ) ) . '"'
				. ' aria-label="' . esc_attr( $book['name'] . ( $fact['n'] ? ' ' . $fact['n'] : '' ) . ': ' . $fact['t'] ) . '"'
				. ( $now ? ' aria-current="page"' : '' ) . '>' . ( $fact['n'] ? (int) $fact['n'] : '&bull;' ) . '</a></li>';
		}
		return $html . '</ul>';
	}

	/** True when a book's pieces carry chapter numbers and there is more than one. */
	function tcc_talk_has_chapters( $book ) {
		return is_array( $book ) && count( $book['ids'] ) > 1 && $book['max'] > 1;
	}

	/** The grey panel beside the words of a piece: Written by, a button for every chapter, Go further. */
	function tcc_talk_panel_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$book = tcc_talk_book_of( $id );
			$html = '';
			if ( '' !== $fact['a'] ) {
				$html .= '<h3>Written by</h3><p class="tcc-tt-who">' . esc_html( $fact['a'] ) . '</p>';
			}
			if ( tcc_talk_has_chapters( $book ) ) {
				$html .= '<h3>Chapters in ' . esc_html( $book['name'] ) . '</h3>' . tcc_talk_chips( $book, $id );
			}
			$html .= '<h3>Go further</h3>';
			if ( $book && $fact['n'] ) {
				// Opens the chapter itself on Bible Gateway, in a new tab, in the English Standard Version
				// (the owner's choice, 2026-11-21). To use another translation, change ESV below.
				$passage = $book['name'] . ( $book['max'] > 1 ? ' ' . (int) $fact['n'] : '' );
				$bible   = add_query_arg(
					array(
						'search'  => rawurlencode( $passage ),
						'version' => 'ESV',
					),
					'https://www.biblegateway.com/passage/'
				);
				$html   .= '<a class="tcc-tt-btn" href="' . esc_url( $bible ) . '" target="_blank" rel="noopener">Read ' . esc_html( $passage ) . ' in the Bible<span class="screen-reader-text"> (ESV, opens in a new tab)</span></a>';
			}
			$html .= '<a class="tcc-tt-btn" href="' . esc_url( tcc_talk_home_url() ) . '">Other books in Trinity Talk</a>';
			return '<div class="tcc-tt-panel">' . $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_panel', 'tcc_talk_panel_shortcode' );

	/** "Keep reading in Matthew" and "Chapter 5 of 28", for the heading above the previous and next rows. */
	function tcc_talk_steps_title_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book ) {
				return '';
			}
			$chapter = tcc_talk_chapter_words( $id );
			return 'Keep reading in ' . esc_html( $book['name'] ) . ( '' !== $chapter ? ' <span class="tcc-tt-count">' . esc_html( $chapter ) . '</span>' : '' );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_steps_title', 'tcc_talk_steps_title_shortcode' );

	/** The "See all 28 chapters" link. */
	function tcc_talk_book_link_shortcode() {
		try {
			$book = tcc_talk_book_of( tcc_talk_post_id() );
			if ( ! $book || '' === $book['url'] ) {
				return '';
			}
			$label = $book['max'] > 1 ? 'See all ' . (int) $book['max'] . ' chapters' : 'See all of ' . $book['name'];
			return '<a class="tcc-tt-link" href="' . esc_url( $book['url'] ) . '">' . esc_html( $label ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_link', 'tcc_talk_book_link_shortcode' );

	/** Inside a previous or next row: "Previous chapter" or "Next chapter". */
	function tcc_talk_step_shortcode() {
		try {
			$row_id = (int) get_the_ID();
			$steps  = tcc_talk_steps( tcc_talk_post_id() );
			// The small arrows only show when the two rows are stacked (tablets and phones).
			if ( $row_id && $row_id === $steps['prev'] ) {
				return '<b aria-hidden="true">&lsaquo; </b>Previous chapter';
			}
			if ( $row_id && $row_id === $steps['next'] ) {
				return 'Next chapter<b aria-hidden="true"> &rsaquo;</b>';
			}
			return '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_step', 'tcc_talk_step_shortcode' );

	/** The note shown where a row would be, on the first or the last chapter of a book. */
	function tcc_talk_end_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'which' => 'first' ), $atts, 'tcc_talk_end' );
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book || count( $book['ids'] ) < 2 ) {
				return '';
			}
			$steps = tcc_talk_steps( $id );
			if ( 'last' === $atts['which'] ) {
				return $steps['next'] ? '' : '<span class="tcc-tt-end">This is the last chapter of ' . esc_html( $book['name'] ) . '.</span>';
			}
			return $steps['prev'] ? '' : '<span class="tcc-tt-end">This is the first chapter of ' . esc_html( $book['name'] ) . '.</span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_end', 'tcc_talk_end_shortcode' );

	/** "More from Matthew", or "More writing" for a piece in no book. */
	function tcc_talk_more_title_shortcode() {
		try {
			$id   = tcc_talk_post_id();
			$book = tcc_talk_book_of( $id );
			if ( ! $book ) {
				return 'More writing';
			}
			// A book too short to have more chapters shows the start of other books instead.
			$more  = tcc_talk_more( $id );
			$first = $more ? tcc_talk_fact( $more[0] ) : null;
			if ( $first && (int) $first['book'] !== (int) $book['id'] ) {
				return 'More from Trinity Talk';
			}
			return 'More from ' . esc_html( $book['name'] );
		} catch ( \Throwable $e ) {
			return 'More writing';
		}
	}
	add_shortcode( 'tcc_talk_more_title', 'tcc_talk_more_title_shortcode' );

	/** The "Back to Trinity Talk" link. */
	function tcc_talk_home_link_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'Back to Trinity Talk' ), $atts, 'tcc_talk_home_link' );
		return '<a class="tcc-tt-link" href="' . esc_url( tcc_talk_home_url() ) . '">' . esc_html( $atts['label'] ) . '</a>';
	}
	add_shortcode( 'tcc_talk_home_link', 'tcc_talk_home_link_shortcode' );

	/** Inside a row or card: the small white tile, "MATTHEW 4" or (label="Chapter") "CHAPTER 4". */
	function tcc_talk_tile_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => '' ), $atts, 'tcc_talk_tile' );
		try {
			$id   = tcc_talk_item_id();
			$fact = tcc_talk_fact( $id );
			$book = tcc_talk_book_of( $id );
			if ( ! $fact || ! $book || ! $fact['n'] ) {
				return '';
			}
			$label = '' !== trim( (string) $atts['label'] ) ? (string) $atts['label'] : $book['name'];
			return '<span class="tcc-tt-tile-in"><small>' . esc_html( $label ) . '</small><b>' . (int) $fact['n'] . '</b></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_tile', 'tcc_talk_tile_shortcode' );

	/** Inside a card: "Matthew 7 - Mark Medley" (or the piece's group and writer). */
	function tcc_talk_card_meta_shortcode() {
		try {
			$id   = tcc_talk_item_id();
			$fact = tcc_talk_fact( $id );
			if ( ! $fact ) {
				return '';
			}
			$book = tcc_talk_book_of( $id );
			$lead = $book ? $book['name'] . ( $fact['n'] && $book['max'] > 1 ? ' ' . (int) $fact['n'] : '' ) : $fact['g'];
			return esc_html( $lead ) . ( '' !== $lead && '' !== $fact['a'] ? ' &middot; ' : '' ) . esc_html( $fact['a'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_card_meta', 'tcc_talk_card_meta_shortcode' );

	/** Inside a row on a book's page: "Mark Medley - 3 minute read". */
	function tcc_talk_row_meta_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			if ( ! $fact ) {
				return '';
			}
			return esc_html( $fact['a'] ) . '<i>' . ( '' !== $fact['a'] ? ' &middot; ' : '' ) . (int) $fact['m'] . ' minute read</i>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_row_meta', 'tcc_talk_row_meta_shortcode' );

	/** Inside a row or card: the first sentence or two of the piece. */
	function tcc_talk_summary_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			return $fact ? esc_html( $fact['x'] ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_summary', 'tcc_talk_summary_shortcode' );

	/** The writers of a list of pieces, most pieces first: name => how many. */
	function tcc_talk_writers( $ids ) {
		$index = tcc_talk_index();
		$names = array();
		foreach ( (array) $ids as $id ) {
			$name = isset( $index['posts'][ $id ] ) ? (string) $index['posts'][ $id ]['a'] : '';
			if ( '' !== $name ) {
				$names[ $name ] = isset( $names[ $name ] ) ? $names[ $name ] + 1 : 1;
			}
		}
		return $names;
	}

	/** The sentence under a book's name. */
	function tcc_talk_book_lead_shortcode() {
		try {
			$term_id = tcc_talk_term_id();
			$ids     = tcc_talk_term_ids( $term_id );
			$count   = count( $ids );
			if ( ! $count ) {
				return '';
			}
			$index   = tcc_talk_index();
			$book    = isset( $index['books'][ $term_id ] ) ? $index['books'][ $term_id ] : null;
			$writers = array_keys( tcc_talk_writers( $ids ) );
			if ( 1 === count( $writers ) ) {
				$by = ', written by ' . $writers[0];
			} elseif ( $writers ) {
				$by = ', written by ' . count( $writers ) . ' of Trinity&rsquo;s pastors and members';
			} else {
				$by = '';
			}
			if ( $book && $count > 1 && $count === (int) $book['max'] ) {
				return $count . ' chapters, each with a short reading' . ( 1 === count( $writers ) ? esc_html( $by ) : $by ) . '. Read them in order or pick a chapter.';
			}
			$lead = 1 === $count ? 'One short reading' : $count . ' short readings';
			return $lead . ( 1 === count( $writers ) ? esc_html( $by ) : $by ) . '.';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_lead', 'tcc_talk_book_lead_shortcode' );

	/** The "Start with chapter 1" button on a book's page. It follows the website's own button style. */
	function tcc_talk_start_shortcode() {
		try {
			$ids = tcc_talk_term_ids( tcc_talk_term_id() );
			if ( count( $ids ) < 2 ) {
				return '';
			}
			$fact  = tcc_talk_fact( $ids[0] );
			$label = ( $fact && 1 === (int) $fact['n'] ) ? 'Start with chapter 1' : 'Start reading';
			return '<a class="et_pb_button tcc-tt-start" href="' . esc_url( get_permalink( $ids[0] ) ) . '">' . esc_html( $label ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_start', 'tcc_talk_start_shortcode' );

	/** The grey panel on a book's page: Jump to a chapter, Written by, More. */
	function tcc_talk_book_panel_shortcode() {
		try {
			$term_id = tcc_talk_term_id();
			$ids     = tcc_talk_term_ids( $term_id );
			if ( ! $ids ) {
				return '';
			}
			$index = tcc_talk_index();
			$book  = isset( $index['books'][ $term_id ] ) ? $index['books'][ $term_id ] : null;
			$html  = '';
			$chips = tcc_talk_has_chapters( $book );
			if ( $chips ) {
				$html .= '<h3>Jump to a chapter</h3>' . tcc_talk_chips( $book, 0 );
			}
			$writers = array_keys( tcc_talk_writers( $ids ) );
			if ( $writers ) {
				$html .= '<h3 class="tcc-tt-opt">Written by</h3><p class="tcc-tt-names tcc-tt-opt">' . esc_html( implode( ', ', $writers ) ) . '</p>';
			}
			$html .= '<h3 class="tcc-tt-opt">More</h3><a class="tcc-tt-btn tcc-tt-opt" href="' . esc_url( tcc_talk_home_url() ) . '">Other books in Trinity Talk</a>';
			return '<div class="tcc-tt-panel' . ( $chips ? '' : ' tcc-tt-panel-plain' ) . '">' . $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_book_panel', 'tcc_talk_book_panel_shortcode' );

	/** The books in their usual order: array of category ids. Books not in the usual list go last, by name. */
	function tcc_talk_books_in_order( $group = '' ) {
		$index   = tcc_talk_index();
		$by_key  = array();
		foreach ( $index['books'] as $id => $book ) {
			if ( $book['ids'] ) {
				$by_key[ tcc_talk_key( $book['name'] ) ] = (int) $id;
			}
		}
		$out     = array();
		$shelves = tcc_talk_shelves();
		foreach ( $shelves as $name => $books ) {
			foreach ( $books as $book_name ) {
				$key = tcc_talk_key( $book_name );
				if ( isset( $by_key[ $key ] ) ) {
					if ( '' === $group || $group === $name ) {
						$out[] = $by_key[ $key ];
					}
					unset( $by_key[ $key ] );
				}
			}
		}
		if ( '' === $group || 'other' === $group ) {
			ksort( $by_key );
			$out = array_merge( $out, array_values( $by_key ) );
		}
		return $out;
	}

	/** A button for every book, with how many pieces it has. The book being viewed is filled in. */
	function tcc_talk_books_shortcode() {
		try {
			$index = tcc_talk_index();
			$here  = tcc_talk_term_id();
			$html  = '';
			foreach ( tcc_talk_books_in_order() as $id ) {
				$book  = $index['books'][ $id ];
				$now   = (int) $id === (int) $here;
				$html .= '<li><a class="tcc-tt-book' . ( $now ? ' is-here' : '' ) . '" href="' . esc_url( $book['url'] ) . '"' . ( $now ? ' aria-current="page"' : '' ) . '>' . esc_html( $book['name'] ) . ' <b>' . count( $book['ids'] ) . '</b></a></li>';
			}
			return '' === $html ? '' : '<ul class="tcc-tt-books">' . $html . '</ul>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_books', 'tcc_talk_books_shortcode' );

	/** The home page: one group's book cards. group="gospels", "paul" or "other". */
	function tcc_talk_shelf_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'group' => 'gospels' ), $atts, 'tcc_talk_shelf' );
		try {
			$index = tcc_talk_index();
			$html  = '';
			foreach ( tcc_talk_books_in_order( sanitize_key( $atts['group'] ) ) as $id ) {
				$book  = $index['books'][ $id ];
				$count = count( $book['ids'] );
				$html .= '<li><a class="tcc-tt-shelf-card" href="' . esc_url( $book['url'] ) . '"><span class="tcc-tt-shelf-txt"><span class="tcc-tt-shelf-name">' . esc_html( $book['name'] ) . '</span>'
					. '<span class="tcc-tt-shelf-count">' . $count . ( 1 === $count ? ' reading' : ' readings' ) . '</span></span></a></li>';
			}
			return '' === $html ? '' : '<ul class="tcc-tt-shelf">' . $html . '</ul>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_shelf', 'tcc_talk_shelf_shortcode' );

	/** How many pieces are in no book. */
	function tcc_talk_loose_count_shortcode() {
		try {
			$index = tcc_talk_index();
			return (string) count( $index['loose'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_loose_count', 'tcc_talk_loose_count_shortcode' );

	/**
	 * The "Show 12 more" button under the "More writing" cards, with "Showing 12 of 37" beside it.
	 * The page shows the first twelve cards and each press adds twelve (the same as the Sermons,
	 * Events and Community Groups pages). With JavaScript off every card simply shows.
	 */
	function tcc_talk_show_all_shortcode() {
		try {
			$index = tcc_talk_index();
			$count = count( $index['loose'] );
			if ( $count <= 12 ) {
				return '';
			}
			return '<div class="tcc-tt-more-row" hidden><button type="button" class="tcc-tt-btn tcc-tt-show-all">Show 12 more</button><span class="tcc-tt-more-note"></span></div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_show_all', 'tcc_talk_show_all_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * Looks.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_talk_css' ) ) {

	/**
	 * Tells the styles which page this is:
	 *   tcc-talk-page      one piece           tcc-talk-no-steps   a piece with no previous or next chapter
	 *   tcc-talk-book      a book's page       tcc-talk-plain      a page of pieces with no chapter numbers
	 *   tcc-talk-home      the home page
	 */
	add_filter(
		'body_class',
		function ( $classes ) {
			try {
				$kind = tcc_talk_showing();
				if ( 'single' === $kind ) {
					$classes[] = 'tcc-talk-page';
					$steps     = tcc_talk_steps( (int) get_queried_object_id() );
					if ( ! $steps['prev'] && ! $steps['next'] ) {
						$classes[] = 'tcc-talk-no-steps';
					}
				} elseif ( 'book' === $kind ) {
					$classes[] = 'tcc-talk-book';
					$index     = tcc_talk_index();
					$term_id   = (int) get_queried_object_id();
					if ( ! isset( $index['books'][ $term_id ] ) || ! tcc_talk_has_chapters( $index['books'][ $term_id ] ) ) {
						$classes[] = 'tcc-talk-plain';
					}
				} elseif ( 'home' === $kind ) {
					$classes[] = 'tcc-talk-home';
				}
			} catch ( \Throwable $e ) {
				return $classes;
			}
			return $classes;
		}
	);

	/**
	 * The styles for the three pages. Colours, corner size and fonts match the sermon and search pages:
	 * the one Trinity teal (#00A4CF), soft grey panels (#f4f4f4), 15px corners.
	 */
	function tcc_talk_css() {
		// Notes on the rules below:
		// - A previous or next row with no piece in it is hidden (Divi prints "No Results Found" there).
		// - ":not(#tcc-keep)" only makes one rule strong enough to win over the Events feature's rule that
		//   hides the whole box around an empty list. Here that box also holds the "This is the first
		//   chapter" note, so on computers it has to stay. No layer has that ID.
		// - A tile with no chapter number in it is hidden (pieces that are in no book).
		// - The grey panel stays in view while the page scrolls, but only on screens at least 760 tall, so
		//   its last button is never cut off on a short screen.
		// - On small laptops (981 to 1250 wide) the grey panel is narrower, so the words keep enough room.
		//   Those three widths are set in Divi for larger screens; this rule only steps in between.
		// - "#page-container" in front of a rule only makes it strong enough to win over the theme's own
		//   heading sizes, which are written with an ID in them. Each such rule is written twice,
		//   because the theme writes its own in two strengths.
		$css = <<<'CSS'
.tcc-talk-no-steps .tcc-tt-steps{display:none!important}
.tcc-tt-facts .et_pb_text_inner,.tcc-tt-facts p{font-size:17px;line-height:1.5;color:#6b6b6c}
.tcc-tt-where{font-family:"CMG Sans SemiBold","Montserrat",sans-serif;color:#00A4CF}
.tcc-tt-where a{color:#00A4CF}
.tcc-tt-where a:hover,.tcc-tt-link:hover{text-decoration:underline}
.tcc-tt-dot{margin:0 8px}
.tcc-tt-facts b{font-weight:600;color:#404041}
.tcc-tt-count{color:#00A4CF;font-size:22px;margin-left:6px;white-space:nowrap}
.tcc-tt-link{display:inline-block;padding:10px 0;font:500 16px "CMG Sans SemiBold","Montserrat",sans-serif;color:#00A4CF}
.tcc-tt-prose ol,.tcc-tt-prose ul{padding-left:28px}
.tcc-tt-prose li{margin-bottom:10px;padding-left:4px;line-height:1.6em}
.tcc-tt-prose li::marker{color:#00A4CF;font-family:"CMG Sans SemiBold","Montserrat",sans-serif}
.tcc-tt-prose sup{font-size:.65em;color:#6b6b6c}
.tcc-tt-prose p:last-child{padding-bottom:0}
@media (min-width:981px) and (min-height:760px){.tcc-tt-side{position:sticky;top:var(--tcc-tt-top,120px)}}
#page-container .tcc-tt-panel h3,#page-container #et-boc .et-l .tcc-tt-panel h3{font:500 14px/1.3 "CMG Sans SemiBold","Montserrat",sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#00A4CF;margin:24px 0 10px;padding:0}
#page-container .tcc-tt-panel h3:first-child,#page-container #et-boc .et-l .tcc-tt-panel h3:first-child{margin-top:0}
#page-container .tcc-tt-group-head h2,#page-container #et-boc .et-l .tcc-tt-group-head h2{font:500 14px/1.3 "CMG Sans SemiBold","Montserrat",sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#00A4CF;padding:0}
#page-container .tcc-tt-who,#page-container #et-boc .et-l .tcc-tt-who{font:500 20px/1.3 "CMG Sans SemiBold","Montserrat",sans-serif;color:#404041;margin:0;padding:0}
#page-container .tcc-tt-names,#page-container #et-boc .et-l .tcc-tt-names{margin:0;padding:0;font-size:16px;line-height:1.5;color:#404041}
.tcc-tt-chips{display:grid;grid-template-columns:repeat(auto-fill,minmax(44px,1fr));gap:8px;margin:0!important;padding:0!important;list-style:none!important}
.tcc-tt-chips li,.tcc-tt-books li,.tcc-tt-shelf li{margin:0;padding:0;list-style:none}
.tcc-tt-chip{display:flex;align-items:center;justify-content:center;height:44px;background:#fff;border:2px solid #e3e7ea;border-radius:10px;font:500 16px "CMG Sans SemiBold","Montserrat",sans-serif;color:#00A4CF;transition:border-color .2s}
.tcc-tt-chip:hover,.tcc-tt-chip:focus-visible{border-color:#00A4CF}
.tcc-tt-chip.is-here{background:#00A4CF;border-color:#00A4CF;color:#fff}
.tcc-tt-btn{display:flex;align-items:center;justify-content:center;width:100%;min-height:48px;margin:10px 0 0;padding:6px 20px;font:500 16px/1.25 "CMG Sans SemiBold","Montserrat",sans-serif;text-align:center;color:#00A4CF;background:#fff;border:2px solid #e3e7ea;border-radius:10px;cursor:pointer;transition:border-color .2s}
.tcc-tt-panel h3+.tcc-tt-btn{margin-top:0}
.tcc-tt-btn:hover,.tcc-tt-btn:focus-visible{border-color:#00A4CF}
.tcc-tt-btn[hidden]{display:none!important}
.tcc-tt-more-row{display:flex;flex-wrap:wrap;align-items:center;gap:12px 20px;margin:22px 0 0;font-size:17px;line-height:1.3;color:#6b6b6c}
.tcc-tt-more-row[hidden]{display:none!important}
.tcc-tt-show-all{width:auto;margin:0}
.tcc-tt-chip:focus-visible,.tcc-tt-btn:focus-visible,.tcc-tt-book:focus-visible,.tcc-tt-shelf-card:focus-visible,.tcc-tt-row:focus-visible,.tcc-tt-card:focus-visible{outline:3px solid rgba(0,164,207,.45);outline-offset:2px}
.tcc-tt-row,.tcc-tt-card{cursor:pointer;border:2px solid #f4f4f4;transition:border-color .2s,background-color .2s}
.tcc-tt-row:hover,.tcc-tt-row:focus-within,.tcc-tt-card:hover,.tcc-tt-card:focus-within{border-color:#00A4CF;background-color:#fff!important}
.tcc-tt-row:hover .tcc-tt-tile,.tcc-tt-row:focus-within .tcc-tt-tile{background-color:#f4f4f4!important}
.tcc-tt-tile{transition:background-color .2s}
.tcc-tt-tile:not(:has(b)){display:none!important}
.tcc-tt-tile-in{display:block;font-family:"CMG Sans SemiBold","Montserrat",sans-serif;line-height:1;text-align:center}
.tcc-tt-tile-in small{display:block;margin-bottom:4px;font-size:14px;letter-spacing:.06em;text-transform:uppercase;color:#00A4CF;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tcc-tt-tile-in b{display:block;font-weight:500;font-size:28px;color:#404041}
.tcc-tt-prev:before,.tcc-tt-next:after,.tcc-tt-list-row:after,.tcc-tt-shelf-card:after{content:"";flex:none;width:11px;height:11px;border-right:3px solid #00A4CF;border-top:3px solid #00A4CF;margin:0 4px;transition:transform .2s}
.tcc-tt-next:after,.tcc-tt-list-row:after,.tcc-tt-shelf-card:after{transform:rotate(45deg)}
.tcc-tt-next:hover:after,.tcc-tt-list-row:hover:after,.tcc-tt-shelf-card:hover:after{transform:translateX(4px) rotate(45deg)}
.tcc-tt-prev:before{transform:rotate(-135deg)}
.tcc-tt-prev:hover:before{transform:translateX(-4px) rotate(-135deg)}
.tcc-tt-list-row:after{align-self:center}
.tcc-tt-step b{display:none;font-weight:inherit}
.tcc-tt-end{display:flex;align-items:center;justify-content:center;min-height:84px;height:100%;padding:14px;border:2px dashed #e3e7ea;border-radius:15px;color:#6b6b6c;font-size:17px;line-height:1.3;text-align:center}
.tcc-tt-cell>.et_pb_text:has(.tcc-tt-end){height:100%}
.tcc-tt-cell>.et_pb_text:has(.tcc-tt-end) .et_pb_text_inner{height:100%}
@media (min-width:981px){.et_pb_group.tcc-tt-cell:not(#tcc-keep){display:flex!important}}
.tcc-tt-row>.entry,.tcc-tt-card>.entry{display:none!important}
.tcc-tt-row:has(>.entry>.not-found-title),.tcc-tt-card:has(>.entry>.not-found-title){display:none!important}
.tcc-tt-clamp .et_pb_text_inner,.tcc-tt-clamp p{display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden}
.tcc-tt-clamp-2 .et_pb_text_inner,.tcc-tt-clamp-2 p{-webkit-line-clamp:2}
.tcc-tt-clamp-3 .et_pb_text_inner,.tcc-tt-clamp-3 p{-webkit-line-clamp:3}
.tcc-tt-row-meta i{font-style:normal;font-weight:400;color:#6b6b6c}
.tcc-tt-books{display:flex;flex-wrap:wrap;gap:10px;margin:0!important;padding:0!important;list-style:none!important}
.tcc-tt-book{display:inline-flex;align-items:center;gap:10px;min-height:48px;padding:0 18px;border:2px solid #e3e7ea;border-radius:10px;font:500 16px "CMG Sans SemiBold","Montserrat",sans-serif;color:#404041;transition:border-color .2s,color .2s}
.tcc-tt-book b{font-weight:500;color:#00A4CF}
.tcc-tt-book:hover,.tcc-tt-book:focus-visible{border-color:#00A4CF;color:#00A4CF}
.tcc-tt-book.is-here{background:#00A4CF;border-color:#00A4CF;color:#fff}
.tcc-tt-book.is-here b{color:#fff}
.tcc-tt-shelf{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:0!important;padding:0!important;list-style:none!important}
.tcc-tt-shelf-card{display:flex;align-items:center;gap:10px;height:100%;min-height:84px;padding:14px 16px 14px 20px;background:#f4f4f4;border:2px solid #f4f4f4;border-radius:15px;transition:border-color .2s,background-color .2s}
.tcc-tt-shelf-card:hover,.tcc-tt-shelf-card:focus-visible{border-color:#00A4CF;background:#fff}
.tcc-tt-shelf-txt{flex:1;min-width:0}
.tcc-tt-shelf-name{display:block;font:500 22px/1.15 "CMG Sans SemiBold","Montserrat",sans-serif;color:#404041}
.tcc-tt-shelf-count{display:block;margin-top:4px;font-size:15px;font-weight:600;line-height:1.3;color:#00A4CF}
.tcc-tt-loose .tcc-tt-card.is-later{display:none!important}
.tcc-talk-plain .tcc-tt-start{display:none}
@media (min-width:1700px){.tcc-tt-shelf{grid-template-columns:repeat(5,minmax(0,1fr))}}
@media (min-width:981px) and (max-width:1250px){#page-container .et_pb_group.tcc-tt-side,#page-container #et-boc .et-l .et_pb_group.tcc-tt-side{width:290px!important}#page-container .et_pb_group:has(>.tcc-tt-side),#page-container #et-boc .et-l .et_pb_group:has(>.tcc-tt-side){column-gap:36px!important}#page-container .et_pb_group:has(>.tcc-tt-side)>.et_pb_group:not(.tcc-tt-side),#page-container #et-boc .et-l .et_pb_group:has(>.tcc-tt-side)>.et_pb_group:not(.tcc-tt-side){width:calc(100% - 326px)!important}}
@media (max-width:1100px){.tcc-tt-shelf{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:860px){.tcc-tt-shelf{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:980px){.tcc-tt-prev:before,.tcc-tt-next:after{display:none}.tcc-tt-step b{display:inline}.et_pb_group.tcc-tt-cell:has(.not-found-title){display:none!important}.tcc-tt-book-side .tcc-tt-opt{display:none!important}.tcc-tt-book-side:has(.tcc-tt-panel-plain){display:none!important}}
@media (max-width:767px){.tcc-tt-where{display:block;margin-bottom:4px}.tcc-tt-where+.tcc-tt-dot{display:none}.tcc-tt-book-side,.tcc-tt-row-meta i,.tcc-tt-list-row:after,.tcc-tt-shelf-card:after{display:none!important}.tcc-tt-shelf{gap:10px}.tcc-tt-count{display:block;margin:8px 0 0}.tcc-tt-shelf-card{min-height:72px;padding:12px 12px 12px 14px}.tcc-tt-shelf-name{font-size:18px}.tcc-tt-tile-in small{font-size:10.5px;letter-spacing:.05em}.tcc-tt-tile-in b{font-size:24px}.tcc-tt-book{padding:0 14px;font-size:15px}}
@media (prefers-reduced-motion:reduce){.tcc-tt-row,.tcc-tt-card,.tcc-tt-row:before,.tcc-tt-row:after,.tcc-tt-chip,.tcc-tt-btn,.tcc-tt-book,.tcc-tt-shelf-card,.tcc-tt-shelf-card:after,.tcc-tt-tile{transition:none!important}}
CSS;
		return $css;
	}

	/** The styles go in the head of the three pages, so nothing flashes unstyled. */
	add_action(
		'wp_head',
		function () {
			if ( '' !== tcc_talk_showing() ) {
				echo '<style id="tcc-talk-css">' . tcc_talk_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		},
		30
	);

	/**
	 * Two small jobs in the visitor's browser:
	 *  - the grey panel stays in view just below the menu bar, however tall that bar is;
	 *  - on the home page, "More writing" shows twelve cards; "Show 12 more" adds twelve at a time.
	 */
	add_action(
		'wp_footer',
		function () {
			if ( '' === tcc_talk_showing() ) {
				return;
			}
			?>
<script id="tcc-talk-js">
(function () {
	try {
		var bar = document.querySelector('header.et-l--header, .et-l--header');
		var fixed = bar && bar.querySelector('.et_pb_sticky, [class*="sticky"]');
		var h = fixed ? fixed.getBoundingClientRect().height : 0;
		if (h > 0 && h < 300) { document.documentElement.style.setProperty('--tcc-tt-top', Math.round(h + 40) + 'px'); }
	} catch (e) {}
	var list = document.querySelector('.tcc-tt-loose');
	var btn = document.querySelector('.tcc-tt-show-all');
	if (!list || !btn) { return; }
	var row = btn.parentNode, note = row.querySelector('.tcc-tt-more-note');
	var cards = [].slice.call(list.querySelectorAll('.tcc-tt-card')), STEP = 12, max = STEP;
	function paint() {
		cards.forEach(function (c, i) { c.classList.toggle('is-later', i >= max); });
		var left = cards.length - max;
		row.hidden = left <= 0;
		btn.textContent = 'Show ' + Math.min(STEP, left) + ' more';
		if (note) { note.textContent = 'Showing ' + Math.min(max, cards.length) + ' of ' + cards.length; }
	}
	paint();
	btn.addEventListener('click', function () {
		var next = cards[max];
		max += STEP;
		paint();
		if (next) { next.setAttribute('tabindex', '-1'); try { next.focus(); } catch (e) {} }
	});
})();
</script>
			<?php
		},
		51
	);
}
