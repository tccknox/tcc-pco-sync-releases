<?php
/**
 * TCC Trinity Talk pages: the automatic pieces of the three Trinity Talk pages.
 *
 * Trinity Talk is the church's chapter-by-chapter writing on the Bible. In WordPress each piece is an
 * "Article", and the book it belongs to (Matthew, Romans...) is a "Trinity Talk" category on it.
 *
 * The three pages are ordinary Divi layouts (Divi > Theme Builder):
 *   "Trinity Talk: one piece - NEW (shows automatically)"       the page of one piece
 *   "Trinity Talk: a book's page - NEW (shows automatically)"   every chapter of one book
 *   "Trinity Talk: home - NEW (shows automatically)"            all the books
 * Those templates are deliberately NOT assigned to anything. This feature finds them (by the short code
 * each one holds) and shows them on the right pages. Switch this feature off and the website goes
 * straight back to the older Trinity Talk pages, which are still assigned in the Theme Builder.
 *
 * Divi draws the sections, headings, the words of the piece, the rows and the cards. This feature
 * adds only what Divi cannot work out by itself:
 *
 *  1. Short lines of text: the title without its "Matthew 5 |" start, "Matthew - Chapter 5 of 28",
 *     the writer and how long the piece takes to read.
 *  2. Five lists Divi can loop over, so rows and cards stay ordinary Divi layers:
 *       "Trinity Talk: previous chapter (automatic)"            none or one piece
 *       "Trinity Talk: next chapter (automatic)"                none or one piece
 *       "Trinity Talk: more from this book (automatic)"         up to four pieces
 *       "Trinity Talk: every chapter of this book (automatic)"  the rows on a book's page
 *       "Trinity Talk: pieces in no book (automatic)"           the "More writing" cards on the home page
 *  3. The grey panels (a button for every chapter, the writers) and the book buttons.
 *  4. A few styles: the hover on rows and cards, the small arrows, the chapter buttons. They are in
 *     trinity-talk.css, beside this file.
 *  5. A small script, in trinity-talk.js beside this file: it keeps the grey panel just below the
 *     menu bar, and runs the "Show 12 more" button on the home page.
 *
 * Nothing is typed in twice. The book comes from the piece's Trinity Talk category; the chapter
 * number comes from the start of its title ("Matthew 5 | Choosing to Walk The Hard Path").
 * Chapters are put in order by that number, not by date.
 *
 * Where the code is. This file is short on purpose: it loads the three parts in the folder
 * trinity-talk/ beside it. Each part can be seen and edited on its own on TCC Website > Features
 * (the folded list "Parts of the larger features" at the bottom of that tab):
 *   trinity-talk/books-and-chapters.php  the index: every book and piece, the chapter numbers and their
 *                                        order, and looking things up in it (previous, next, more)
 *   trinity-talk/pages.php               which page this is, showing the three new layouts on it, the
 *                                        steps for the back link, and the five lists Divi loops over
 *   trinity-talk/short-codes.php         every short code below except [tcc_talk_title]
 * This file itself keeps [tcc_talk_title] (the Features tab looks for it to say the feature is
 * working) and, at the end, the looks: the page classes and the style and script blocks.
 *
 * Short codes (each prints nothing when it is put on some other page):
 *   One piece
 *   [tcc_talk_title]        the title without "Matthew 5 |". Inside a row or card it is that piece's title.
 *   [tcc_talk_facts]        "Matthew - Chapter 5 of 28 - By Mark Medley - 3 minute read"
 *   [tcc_talk_panel]        the grey panel: Written by, a button for every chapter, Go further
 *   [tcc_talk_steps_title]  "Keep reading in Matthew" and "Chapter 5 of 28"
 *   [tcc_talk_book_link]    the "See all 28 chapters" link
 *   [tcc_talk_step]         inside a previous or next row: "Previous chapter" or "Next chapter"
 *   [tcc_talk_end]          which="first" or "last": the note shown in place of a missing row
 *   [tcc_talk_more_title]   "More from Matthew" or "More writing"
 *   [tcc_talk_home_link]    the "Back to Trinity Talk" link (label="..." changes the words)
 *   Inside any row or card
 *   [tcc_talk_tile]         the small white tile: "MATTHEW 4" (label="Chapter" prints "CHAPTER 4")
 *   [tcc_talk_card_meta]    "Matthew 7 - Mark Medley"
 *   [tcc_talk_row_meta]     "Mark Medley - 3 minute read"
 *   [tcc_talk_summary]      the first sentence or two of the piece (or its Yoast description, if one was typed)
 *   A book's page
 *   [tcc_talk_book_lead]    "28 chapters, each with a short reading, written by 11 of Trinity's pastors and members..."
 *   [tcc_talk_start]        the "Start with chapter 1" button
 *   [tcc_talk_book_panel]   the grey panel: Jump to a chapter, Written by, More
 *   [tcc_talk_books]        a button for every book (the "Other books" section)
 *   The home page
 *   [tcc_talk_shelf]        group="gospels", "paul" or "other": that group's book cards
 *   [tcc_talk_loose_count]  how many pieces are in no book
 *   [tcc_talk_show_all]     the "Show 12 more" button under the "More writing" cards, with "Showing 12 of 37"
 *
 * In the Divi editor there is no piece being viewed, so every piece of the page shows a real chapter
 * from the middle of the longest book as an example.
 *
 * Part of the TCC Website Features plugin (added in 0.6.0, November 2026; split into parts in 0.14.4).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ----------------------------------------------------------------------------------------------
 * The title short code. It stays in this file because the Features tab looks for
 * tcc_talk_title_shortcode() to say this feature is working.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_talk_title_shortcode' ) ) {

	/** The title without its "Matthew 5 |" start. */
	function tcc_talk_title_shortcode() {
		try {
			$fact = tcc_talk_fact( tcc_talk_item_id() );
			return $fact ? esc_html( $fact['t'] ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_talk_title', 'tcc_talk_title_shortcode' );
}

/* ----------------------------------------------------------------------------------------------
 * The three parts, in this order (the later ones use what the first one works out).
 * Each runs the saved edit of its file if there is a healthy one, otherwise the original
 * (code-edits.php). They are loaded outside the "if" above on purpose: each part has its own
 * "if ( ! function_exists() )" line, and if a saved edit of this file stops part-way and the
 * original is loaded instead, the parts are still loaded.
 * -------------------------------------------------------------------------------------------- */

tcc_code_require( 'tcc-site-features', 'features/trinity-talk/books-and-chapters.php' );
tcc_code_require( 'tcc-site-features', 'features/trinity-talk/pages.php' );
tcc_code_require( 'tcc-site-features', 'features/trinity-talk/short-codes.php' );

/* ----------------------------------------------------------------------------------------------
 * Looks.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_talk_css' ) ) {

	/**
	 * Tells the styles which page this is:
	 *   tcc-talk-page      one piece           tcc-talk-no-steps   a piece with no previous or next chapter
	 *   tcc-talk-book      a book's page       tcc-talk-plain      a page of pieces with no chapter numbers
	 *   tcc-talk-home      the home page
	 */
	add_filter(
		'body_class',
		function ( $classes ) {
			try {
				$kind = tcc_talk_showing();
				if ( 'single' === $kind ) {
					$classes[] = 'tcc-talk-page';
					$steps     = tcc_talk_steps( (int) get_queried_object_id() );
					if ( ! $steps['prev'] && ! $steps['next'] ) {
						$classes[] = 'tcc-talk-no-steps';
					}
				} elseif ( 'book' === $kind ) {
					$classes[] = 'tcc-talk-book';
					$index     = tcc_talk_index();
					$term_id   = (int) get_queried_object_id();
					// tcc_talk_has_chapters() is in trinity-talk/short-codes.php.
					if ( ! isset( $index['books'][ $term_id ] ) || ! tcc_talk_has_chapters( $index['books'][ $term_id ] ) ) {
						$classes[] = 'tcc-talk-plain';
					}
				} elseif ( 'home' === $kind ) {
					$classes[] = 'tcc-talk-home';
				}
			} catch ( \Throwable $e ) {
				return $classes;
			}
			return $classes;
		}
	);

	/**
	 * The styles for the three pages. Colours, corner size and fonts match the sermon and search pages:
	 * the one Trinity teal (#00A4CF), soft grey panels (#f4f4f4), 15px corners.
	 */
	function tcc_talk_css() {
		// The styles themselves are in trinity-talk.css (beside this file). Notes on the rules there:
		// - A previous or next row with no piece in it is hidden (Divi prints "No Results Found" there).
		// - ":not(#tcc-keep)" only makes one rule strong enough to win over the Events feature's rule that
		//   hides the whole box around an empty list. Here that box also holds the "This is the first
		//   chapter" note, so on computers it has to stay. No layer has that ID.
		// - A tile with no chapter number in it is hidden (pieces that are in no book).
		// - The grey panel stays in view while the page scrolls, but only on screens at least 760 tall, so
		//   its last button is never cut off on a short screen.
		// - On small laptops (981 to 1250 wide) the grey panel is narrower, so the words keep enough room.
		//   Those three widths are set in Divi for larger screens; this rule only steps in between.
		// - "#page-container" in front of a rule only makes it strong enough to win over the theme's own
		//   heading sizes, which are written with an ID in them. Each such rule is written twice,
		//   because the theme writes its own in two strengths.
		return tcc_site_asset( 'features/trinity-talk.css' );
	}

	/** The styles go in the head of the three pages, so nothing flashes unstyled. */
	add_action(
		'wp_head',
		function () {
			if ( '' !== tcc_talk_showing() ) {
				echo '<style id="tcc-talk-css">' . tcc_talk_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		},
		30
	);

	/**
	 * Two small jobs in the visitor's browser:
	 *  - the grey panel stays in view just below the menu bar, however tall that bar is;
	 *  - on the home page, "More writing" shows twelve cards; "Show 12 more" adds twelve at a time.
	 * The script is in trinity-talk.js, beside this file.
	 */
	add_action(
		'wp_footer',
		function () {
			if ( '' === tcc_talk_showing() ) {
				return;
			}
			// The script itself is in trinity-talk.js (beside this file). Only the <script> tag is written here.
			?>
<script id="tcc-talk-js">
<?php echo tcc_site_asset( 'features/trinity-talk.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
			<?php
		},
		51
	);
}
