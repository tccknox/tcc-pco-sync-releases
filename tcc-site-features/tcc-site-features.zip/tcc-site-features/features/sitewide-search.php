<?php
/**
 * TCC sitewide search page.
 *
 * What a visitor sees after typing in the Search box in the main menu:
 *   - "Top results": the three best matches from everything (only when there are 7 or more results),
 *     favouring upcoming events, community groups and recent sermons.
 *   - then the results in groups: Pages, Upcoming events, Sermons, Trinity Talk, Community Groups.
 *   - spelling help: if nothing is found, the closest known word is tried instead
 *     ("baptizm" finds "baptism"), and a search of several words falls back to any of the words.
 *
 * It only takes over a SITEWIDE search. A search limited to one kind of content (for example a
 * sermon-only search, whose address has post_type=post in it) is left alone and keeps its own page.
 *
 * How it is put on the page (all in the Divi Theme Builder, in the template whose body holds the
 * short code [tcc_search_results]):
 *   [tcc_search_heading]   the words 'Results for "baptism"'
 *   [tcc_search_form]      the search-again box
 *   [tcc_search_results]   everything else
 * This feature finds that template by itself and shows it for sitewide searches, so the template does
 * NOT need to be assigned to "Search Results" in the Theme Builder. Switch this feature off and
 * searches go back to the template that IS assigned there (the old search page).
 *
 * Built to fail gently:
 *   - WordPress's own search still runs, so if a Divi update ever stops this feature from showing its
 *     template, visitors get the old results page, working, and the Features tab says so.
 *   - If someone assigns the new template to "Search Results" after all, it still behaves: a search
 *     limited to one kind of content shows only that kind.
 *   - Links to other pages are looked up by their address, so when a page has been moved, renamed
 *     or removed its link is left off (and the Features tab says so) instead of leading nowhere.
 *
 * What is searched: titles and page text (WordPress's own search), plus the fields and labels that
 * hold most of what a sermon or a community group says about itself: the sermon descriptions and
 * speaker name, the sermon categories (Bible book, topic, series, speaker), and a group's
 * description, leader, meeting time and place. See tcc_search_meta_keys() and tcc_search_taxonomies()
 * (in sitewide-search/finding.php).
 *
 * A group with more results than fit has a "See all 59 ..." link to a page of its own
 * (the address gains &tcc_kind=sermon), which shows them 30 at a time.
 *
 * Also: words that mean the same ("kids" also searches "children"), a list of searches that found
 * nothing, and both are looked after by volunteers under TCC Website > Search. A word is matched
 * where a word starts ("men" finds "Men's Ministry", not "moment"), and community groups marked
 * as not active are left out.
 *
 * Server load: a handful of small database lookups per search. Each word is looked up once per
 * search, however many wordings are tried (tcc_search_remember). A search is remembered for up to
 * 6 hours (10 minutes when it found nothing; less when an upcoming event is about to end) and
 * worked out afresh as soon as anything it reads is changed (tcc_search_start_afresh).
 * Nothing is fetched from outside the website.
 *
 * Where the code is. Since 0.14.4 this file is short: it holds the three things a volunteer may
 * want to change (the first three functions below: the groups, with their names, order and how many
 * show before "Show all"; the "nothing found" links; and the extra words the spelling help knows),
 * the short code [tcc_search_results], and the lines that load the rest. The rest is in the folder
 * sitewide-search/, beside this file, one part per job (each can be edited on its own from
 * TCC Website > Features, under "Parts of the larger features"):
 *   page.php         which searches it takes over and how it shows its page; the health check the
 *                    Features tab reads; the pieces of the results page; [tcc_search_heading],
 *                    [tcc_search_form] and the styles
 *   finding.php      finding the matches and scoring them (the database lookups)
 *   words.php        words that mean the same, the closest spelling, the list of searches that found
 *                    nothing, and the Search tab on the TCC Website screen
 *   remembering.php  working out a search (with the second tries), remembering it, the "busy" limit,
 *                    and starting the remembered searches afresh when content changes
 *
 * How the page looks (colours, sizes, spacing) is in sitewide-search.css, beside this file; see
 * tcc_search_css() in sitewide-search/page.php for how that file is laid out. The small script for
 * the "Show ..." buttons is in sitewide-search.js, beside this file; tcc_search_results_shortcode()
 * below prints it at the end of the results.
 *
 * Part of the TCC Website Features plugin (added 2026-11-20).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_kinds' ) ) {

	/**
	 * The groups, in the order they appear.
	 * kind => array( group heading, label on a Top results card, how many show before "Show all", "See all" link ('' for none), words on that link ).
	 */
	function tcc_search_kinds() {
		return array(
			'page'    => array( 'Pages', 'Page', 5, '', '' ),
			'event'   => array( 'Upcoming events', 'Upcoming event', 3, '/events/', 'See all events' ),
			'sermon'  => array( 'Sermons', 'Sermon', 5, '/sermons/', 'See all sermons' ),
			'article' => array( 'Trinity Talk', 'Trinity Talk', 4, '', '' ),
			'group'   => array( 'Community Groups', 'Community Group', 4, '/community-groups/', 'See all groups' ),
		);
	}

	/** Links offered when nothing is found: words => address. */
	function tcc_search_empty_links() {
		return array(
			'What to expect' => '/new/what-to-expect/',
			'Events'         => '/events/',
			'Sermons'        => '/sermons/',
			'Ministries'     => '/ministries/',
			'Contact us'     => '/contact-us/',
		);
	}

	/** Extra words the spelling help knows, on top of every word used in a title on the website. */
	function tcc_search_extra_words() {
		return array( 'baptism', 'baptized', 'communion', 'tithe', 'tithing', 'giving', 'donate', 'volunteer', 'serve', 'serving', 'nursery', 'children', 'kids', 'youth', 'students', 'worship', 'prayer', 'membership', 'partner', 'missions', 'counseling', 'pastor', 'pastors', 'elders', 'staff', 'directions', 'parking', 'address', 'service', 'services', 'times', 'livestream', 'online', 'podcast', 'bible', 'discipleship', 'marriage', 'wedding', 'funeral', 'benevolence', 'calendar', 'sermon', 'sermons', 'groups', 'community', 'women', 'events', 'classes', 'foundations', 'contact' );
	}

	/* ------------------------------------------------------------------
	 * The results. This stays in this file: the Features tab looks for
	 * tcc_search_results_shortcode() here to say the feature is working.
	 * The pieces it uses are in sitewide-search/page.php.
	 * ------------------------------------------------------------------ */

	/** [tcc_search_results]: the Top results cards, the jump buttons and the groups. */
	function tcc_search_results_shortcode() {
		try {
			$data  = tcc_search_data();
			$items = $data['items'];
			$kinds = tcc_search_kinds();
			$html  = tcc_search_css( true ) . '<div class="tcc-search tcc-s-results">';
			// Tells tcc_search_note_outcome() that the new page really was shown.
			$GLOBALS['tcc_search_drawn'] = true;

			if ( '' === $data['typed'] ) {
				return $html . '<p class="tcc-s-note">Type a word or two in the box above, for example &ldquo;baptism&rdquo; or &ldquo;youth&rdquo;.</p></div>';
			}

			if ( 'busy' === $data['note'] ) {
				return $html . '<div class="tcc-s-empty"><p class="tcc-s-empty-head">The search is busy right now.</p><p>Please wait a minute and press Search again.</p></div></div>';
			}

			if ( ! $items ) {
				$html .= '<div class="tcc-s-empty"><p class="tcc-s-empty-head">We could not find anything for that.</p>'
					. '<p>Check the spelling or try a shorter word, for example &ldquo;youth&rdquo; instead of &ldquo;youth group times&rdquo;. Or start from one of these:</p><ul class="tcc-s-jump">';
				foreach ( tcc_search_empty_links() as $words => $address ) {
					$link = tcc_search_link( $address );
					if ( '' !== $link ) {
						$html .= '<li><a href="' . esc_url( $link ) . '">' . esc_html( $words ) . '</a></li>';
					}
				}
				return $html . '</ul></div></div>';
			}

			if ( 'spelling' === $data['note'] ) {
				$html .= '<p class="tcc-s-note">We could not find &ldquo;' . esc_html( $data['typed'] ) . '&rdquo;, so here are the results for &ldquo;<strong>' . esc_html( $data['used'] ) . '</strong>&rdquo;.</p>';
			} elseif ( 'any' === $data['note'] ) {
				$html .= '<p class="tcc-s-note">Nothing has all of those words together, so here is everything that matches any of them.</p>';
			}
			if ( ! empty( $data['also'] ) ) {
				$said = array();
				foreach ( array_slice( (array) $data['also'], 0, 4 ) as $other ) {
					$said[] = '&ldquo;' . esc_html( $other ) . '&rdquo;';
				}
				$html .= '<p class="tcc-s-note tcc-s-also">Also showing results for ' . implode( ', ', $said ) . '.</p>';
			}

			// One kind on its own page ("See all 59"), or every kind with its first few.
			$one    = tcc_search_one_kind();
			$limit  = ( '' !== $one ) ? 300 : 30;
			$groups = array();
			$ids    = array();
			foreach ( $kinds as $kind => $setup ) {
				$group = tcc_search_group( $items, $kind );
				if ( $group ) {
					$groups[ $kind ] = $group;
					if ( '' === $one || $one === $kind ) {
						foreach ( array_slice( $group, 0, $limit ) as $item ) {
							$ids[] = $item[0];
						}
					}
				}
			}
			if ( '' !== $one && ! isset( $groups[ $one ] ) ) {
				$one   = '';
				$limit = 30;
			}
			if ( $ids && function_exists( '_prime_post_caches' ) ) {
				_prime_post_caches( $ids, true, true );
			}
			$search_url = add_query_arg( 's', rawurlencode( $data['typed'] ), home_url( '/' ) );

			if ( '' !== $one ) {
				$html  .= '<p class="tcc-s-back"><a href="' . esc_url( $search_url ) . '">All results for &ldquo;' . esc_html( $data['used'] ) . '&rdquo;</a></p>';
				$groups = array( $one => $groups[ $one ] );
			} else {
				$top = tcc_search_top( $items );
				if ( $top ) {
					$cards = '';
					foreach ( $top as $item ) {
						$view = tcc_search_view( $item );
						if ( $view ) {
							$cards .= '<li>' . tcc_search_card_html( $view, $kinds[ $item[1] ][1] ) . '</li>';
						}
					}
					if ( '' !== $cards ) {
						$html .= '<section class="tcc-s-top" aria-label="Top results"><h2 class="tcc-s-top-head">Top results</h2><ul class="tcc-s-cards' . ( 2 === count( $top ) ? ' tcc-s-cards-2' : '' ) . '">' . $cards . '</ul></section>';
					}
				}

				if ( count( $groups ) > 1 ) {
					$html .= '<ul class="tcc-s-jump" aria-label="Jump to a kind of result">';
					foreach ( $groups as $kind => $group ) {
						$html .= '<li><a href="#tcc-s-' . esc_attr( $kind ) . '">' . esc_html( $kinds[ $kind ][0] ) . ' <b>' . count( $group ) . '</b></a></li>';
					}
					$html .= '</ul>';
				}
			}

			foreach ( $groups as $kind => $group ) {
				$setup = $kinds[ $kind ];
				$first = ( '' !== $one ) ? 30 : $setup[2];
				$html .= '<section class="tcc-s-group" id="tcc-s-' . esc_attr( $kind ) . '"><div class="tcc-s-group-head"><h2>' . esc_html( $setup[0] ) . ' <span>' . count( $group ) . '</span></h2>';
				$see_all = ( '' !== $setup[3] ) ? tcc_search_link( $setup[3] ) : '';
				if ( '' !== $see_all ) {
					$html .= '<a href="' . esc_url( $see_all ) . '">' . esc_html( $setup[4] ) . '</a>';
				}
				$html .= '</div><ul class="tcc-s-rows">';
				$drawn = 0;
				foreach ( array_slice( $group, 0, $limit ) as $item ) {
					$view = tcc_search_view( $item );
					if ( ! $view ) {
						continue;
					}
					$html .= '<li' . ( $drawn >= $first ? ' class="tcc-s-extra"' : '' ) . '>' . tcc_search_row_html( $view ) . '</li>';
					$drawn++;
				}
				$html .= '</ul>';
				$more  = '';
				if ( '' !== $one ) {
					// On a kind's own page the rest come 30 at a time.
					if ( $drawn > $first ) {
						$more .= '<button type="button" data-step="30">Show 30 more</button>';
					}
				} else {
					if ( $drawn > $first ) {
						$more .= '<button type="button">Show ' . ( count( $group ) > $drawn ? 'the first ' : 'all ' ) . (int) $drawn . '</button>';
					}
					// More than fit here: a page of their own with every one.
					if ( count( $group ) > $drawn ) {
						$more .= '<a class="tcc-s-all" href="' . esc_url( add_query_arg( 'tcc_kind', $kind, $search_url ) ) . '" aria-label="' . esc_attr( 'See all ' . count( $group ) . ' results in ' . $setup[0] ) . '">See all ' . count( $group ) . '</a>';
					}
				}
				if ( '' !== $more ) {
					$html .= '<p class="tcc-s-more">' . $more . '</p>';
				}
				$html .= '</section>';
			}

			// The "Show ..." buttons. Without JavaScript every result simply shows. The script is in
			// sitewide-search.js, beside this file; the line breaks around it are only for reading.
			$html .= '<script>' . "\n" . tcc_site_asset( 'features/sitewide-search.js' ) . "\n" . '</script>';

			return $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_search_results', 'tcc_search_results_shortcode' );
}

// The rest of the feature, one part per job (see the list at the top of this file). Each line runs the
// saved edit of that part if there is a healthy one, otherwise the original (code-edits.php). They are
// loaded here, outside the block above, so that if a saved edit of this file fails part-way and the
// original is loaded instead, the parts still load. No part calls another while it is being loaded, so
// their order does not matter.
tcc_code_require( 'tcc-site-features', 'features/sitewide-search/page.php' );
tcc_code_require( 'tcc-site-features', 'features/sitewide-search/finding.php' );
tcc_code_require( 'tcc-site-features', 'features/sitewide-search/words.php' );
tcc_code_require( 'tcc-site-features', 'features/sitewide-search/remembering.php' );
