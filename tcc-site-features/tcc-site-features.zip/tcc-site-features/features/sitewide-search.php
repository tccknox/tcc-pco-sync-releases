<?php
/**
 * TCC sitewide search page.
 *
 * What a visitor sees after typing in the Search box in the main menu:
 *   - "Top results": the three best matches from everything (only when there are 7 or more results),
 *     favouring upcoming events, community groups and recent sermons.
 *   - then the results in groups: Pages, Upcoming events, Sermons, Trinity Talk, Community Groups.
 *   - spelling help: if nothing is found, the closest known word is tried instead
 *     ("baptizm" finds "baptism"), and a search of several words falls back to any of the words.
 *
 * It only takes over a SITEWIDE search. A search limited to one kind of content (for example a
 * sermon-only search, whose address has post_type=post in it) is left alone and keeps its own page.
 *
 * How it is put on the page (all in the Divi Theme Builder, in the template whose body holds the
 * short code [tcc_search_results]):
 *   [tcc_search_heading]   the words 'Results for "baptism"'
 *   [tcc_search_form]      the search-again box
 *   [tcc_search_results]   everything else
 * This file finds that template by itself and shows it for sitewide searches, so the template does
 * NOT need to be assigned to "Search Results" in the Theme Builder. Switch this feature off and
 * searches go back to the template that IS assigned there (the old search page).
 *
 * Built to fail gently:
 *   - WordPress's own search still runs, so if a Divi update ever stops this file from showing its
 *     template, visitors get the old results page, working, and the Features tab says so.
 *   - If someone assigns the new template to "Search Results" after all, it still behaves: a search
 *     limited to one kind of content shows only that kind.
 *   - Links to other pages are looked up by their address, so when a page has been moved, renamed
 *     or removed its link is left off (and the Features tab says so) instead of leading nowhere.
 *
 * What is searched: titles and page text (WordPress's own search), plus the fields and labels that
 * hold most of what a sermon or a community group says about itself: the sermon descriptions and
 * speaker name, the sermon categories (Bible book, topic, series, speaker), and a group's
 * description, leader, meeting time and place. See tcc_search_meta_keys() and tcc_search_taxonomies().
 *
 * A group with more results than fit has a "See all 59 ..." link to a page of its own
 * (the address gains &tcc_kind=sermon), which shows them 30 at a time.
 *
 * Also: words that mean the same ("kids" also searches "children"), a list of searches that found
 * nothing, and both are looked after by volunteers under TCC Website > Search. A word is matched
 * where a word starts ("men" finds "Men's Ministry", not "moment"), and community groups marked
 * as not active are left out.
 *
 * Server load: a handful of small database lookups per search, remembered for 10 minutes. Nothing
 * is fetched from outside the website.
 *
 * Things a volunteer may want to change are in the first three functions below:
 * the groups (names, order, how many show before "Show all"), the "nothing found" links,
 * and the extra words the spelling help knows.
 *
 * How the page looks (colours, sizes, spacing) is in sitewide-search.css, beside this file; see
 * tcc_search_css() below for how that file is laid out. The small script for the "Show ..."
 * buttons is in sitewide-search.js, beside this file; tcc_search_results_shortcode() below prints it
 * at the end of the results.
 *
 * Part of the TCC Website Features plugin (added 2026-11-20).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_search_kinds' ) ) {

	/**
	 * The groups, in the order they appear.
	 * kind => array( group heading, label on a Top results card, how many show before "Show all", "See all" link ('' for none), words on that link ).
	 */
	function tcc_search_kinds() {
		return array(
			'page'    => array( 'Pages', 'Page', 5, '', '' ),
			'event'   => array( 'Upcoming events', 'Upcoming event', 3, '/events/', 'See all events' ),
			'sermon'  => array( 'Sermons', 'Sermon', 5, '/sermons/', 'See all sermons' ),
			'article' => array( 'Trinity Talk', 'Trinity Talk', 4, '', '' ),
			'group'   => array( 'Community Groups', 'Community Group', 4, '/community-groups/', 'See all groups' ),
		);
	}

	/** Links offered when nothing is found: words => address. */
	function tcc_search_empty_links() {
		return array(
			'What to expect' => '/new/what-to-expect/',
			'Events'         => '/events/',
			'Sermons'        => '/sermons/',
			'Ministries'     => '/ministries/',
			'Contact us'     => '/contact-us/',
		);
	}

	/** Extra words the spelling help knows, on top of every word used in a title on the website. */
	function tcc_search_extra_words() {
		return array( 'baptism', 'baptized', 'communion', 'tithe', 'tithing', 'giving', 'donate', 'volunteer', 'serve', 'serving', 'nursery', 'children', 'kids', 'youth', 'students', 'worship', 'prayer', 'membership', 'partner', 'missions', 'counseling', 'pastor', 'pastors', 'elders', 'staff', 'directions', 'parking', 'address', 'service', 'services', 'times', 'livestream', 'online', 'podcast', 'bible', 'discipleship', 'marriage', 'wedding', 'funeral', 'benevolence', 'calendar', 'sermon', 'sermons', 'groups', 'community', 'women', 'events', 'classes', 'foundations', 'contact' );
	}

	/**
	 * Which kind of content goes in which group.
	 * When the search is limited to one kind (see tcc_search_only_type) only that kind is returned,
	 * unless $all is true.
	 */
	function tcc_search_type_map( $all = false ) {
		$map = array(
			'page'    => 'page',
			'post'    => 'sermon',
			'article' => 'article',
			'project' => 'group',
		);
		$only = $all ? '' : tcc_search_only_type();
		if ( isset( $map[ $only ] ) ) {
			return array( $only => $map[ $only ] );
		}
		if ( 'tribe_events' === $only ) {
			return array();
		}
		return $map;
	}

	/**
	 * Looks a page up by its address and returns its link, or '' when there is no such published
	 * page. So a renamed or removed page never leaves a dead link on the search page.
	 */
	function tcc_search_link( $path ) {
		$path = trim( (string) $path, '/' );
		if ( '' === $path ) {
			return '';
		}
		$page = get_page_by_path( $path );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			return (string) get_permalink( $page );
		}
		if ( 'events' === $path && post_type_exists( 'tribe_events' ) ) {
			return (string) get_post_type_archive_link( 'tribe_events' );
		}
		return '';
	}

	function tcc_search_lower( $text ) {
		$text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	}

	/** The words typed into the search box, tidied. */
	function tcc_search_term() {
		if ( ! isset( $_GET['s'] ) || is_array( $_GET['s'] ) ) {
			return '';
		}
		$term = trim( preg_replace( '/\s+/', ' ', sanitize_text_field( wp_unslash( $_GET['s'] ) ) ) );
		return (string) substr( $term, 0, 80 );
	}

	/**
	 * True for a search of the whole website. False when the address limits the search to one
	 * kind of content (post_type=post, or a Divi Search box set to one kind), so that a
	 * sermon-only search can have its own page.
	 */
	function tcc_search_is_sitewide() {
		return ! is_admin() && isset( $_GET['s'] ) && '' === tcc_search_only_type();
	}

	/**
	 * The one kind of content the address limits the search to ('post' for a sermon-only search),
	 * or '' for a search of the whole website.
	 */
	function tcc_search_only_type() {
		$type = '';
		if ( isset( $_GET['post_type'] ) ) {
			$type = wp_unslash( $_GET['post_type'] );
			if ( is_array( $type ) ) {
				$type = ( 1 === count( $type ) ) ? reset( $type ) : '';
			}
			$type = is_string( $type ) ? sanitize_key( $type ) : '';
			if ( 'any' === $type ) {
				$type = '';
			}
		}
		if ( '' === $type && isset( $_GET['search_post_types'] ) && ! is_array( $_GET['search_post_types'] ) ) {
			$list = array_values( array_filter( array_map( 'trim', explode( ',', (string) wp_unslash( $_GET['search_post_types'] ) ) ) ) );
			if ( 1 === count( $list ) ) {
				$type = sanitize_key( $list[0] );
			}
		}
		return $type;
	}

	/**
	 * The Theme Builder body layout that holds [tcc_search_results], or 0 when there is none.
	 * Found by looking, not by name or number, so renaming the template does not break anything.
	 */
	function tcc_search_layout_id() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		$found = tcc_site_body_layouts( array( 'search' => 'tcc_search_results' ) );
		return (int) $found['search'];
	}

	/** True when this page view is a sitewide search AND the new search page exists to show it. */
	function tcc_search_active() {
		static $active = null;
		if ( null === $active ) {
			$active = tcc_search_is_sitewide() && tcc_search_layout_id() > 0;
		}
		return $active;
	}

	/** Shows the new search page for sitewide searches, whatever is assigned to "Search Results". */
	function tcc_search_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) || ! is_search() || ! tcc_search_active() ) {
				return $layouts;
			}
			return tcc_site_use_body_layout( $layouts, tcc_search_layout_id() );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_search_swap_layout', 20 );

	/*
	 * WordPress's own ordinary search for the page is deliberately left running, although the new
	 * page does not use it. It is one small query, and it means that if Divi ever stops showing
	 * our template the old results page underneath still has its results.
	 */

	/**
	 * Keeps a note when a sitewide search did NOT end up showing the new page (for example after a
	 * Divi update changed how templates are chosen), and clears the note once it shows again.
	 * The Features tab reads the note.
	 */
	function tcc_search_note_outcome() {
		try {
			if ( ! tcc_search_active() || ! is_search() ) {
				return;
			}
			$noted = (int) get_option( 'tcc_search_not_shown', 0 );
			if ( ! empty( $GLOBALS['tcc_search_drawn'] ) ) {
				if ( $noted ) {
					delete_option( 'tcc_search_not_shown' );
				}
			} elseif ( ! $noted ) {
				update_option( 'tcc_search_not_shown', time(), false );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}
	add_action( 'wp_footer', 'tcc_search_note_outcome', 99 );

	/** True when the template that holds the search page is assigned to "Search Results" in the Theme Builder. */
	function tcc_search_template_assigned() {
		$layout_id = tcc_search_layout_id();
		if ( $layout_id < 1 ) {
			return false;
		}
		$templates = get_posts(
			array(
				'post_type'        => 'et_template',
				'post_status'      => 'publish',
				'numberposts'      => 100,
				'fields'           => 'ids',
				'suppress_filters' => true,
			)
		);
		foreach ( (array) $templates as $template_id ) {
			if ( (int) get_post_meta( $template_id, '_et_body_layout_id', true ) === $layout_id && in_array( 'search', (array) get_post_meta( $template_id, '_et_use_on', false ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Things that would quietly make the search page worse, in plain words, for the Features tab.
	 * An empty list means all is well.
	 */
	function tcc_search_health() {
		$problems = array();
		try {
			if ( tcc_search_layout_id() < 1 ) {
				$problems[] = 'Its page cannot be found, so searches are using the older results page. In Divi > Theme Builder there should be a template called "Search results - SITEWIDE (new)" whose body holds a layer with [tcc_search_results] in it.';
			}
			$noted = (int) get_option( 'tcc_search_not_shown', 0 );
			if ( $noted ) {
				$problems[] = 'Divi did not show the new search page when someone searched on ' . wp_date( 'F j', $noted ) . ', so visitors are getting the older results page (it still works). This usually follows a Divi update. Try a search yourself: if the new page shows, this message clears itself; if not, tell whoever looks after the website\'s code.';
			}
			if ( tcc_search_template_assigned() ) {
				$problems[] = 'The template "Search results - SITEWIDE (new)" has been assigned to Search Results in the Theme Builder. It still works, but it is meant to be left unassigned, with the OLD search template assigned instead, so that switching this feature off has a working page to fall back to.';
			}
			if ( ! post_type_exists( 'project' ) ) {
				$problems[] = 'The Community Groups content type cannot be found, so groups are missing from search.';
			}
			if ( ! post_type_exists( 'article' ) ) {
				$problems[] = 'The Articles (Trinity Talk) content type cannot be found, so articles are missing from search.';
			}
			if ( ! function_exists( 'tcc_upcoming_ids_for' ) ) {
				$problems[] = 'The "Event feeds" feature is switched off, so upcoming events are missing from search.';
			} elseif ( ! function_exists( 'tribe_get_events' ) ) {
				$problems[] = 'The Events Calendar plugin is switched off, so upcoming events are missing from search.';
			}
			foreach ( tcc_search_kinds() as $setup ) {
				if ( '' !== $setup[3] && '' === tcc_search_link( $setup[3] ) ) {
					$problems[] = 'The page ' . $setup[3] . ' cannot be found, so the "' . $setup[4] . '" link is left off the search page.';
				}
			}
		} catch ( \Throwable $e ) {
			return $problems;
		}
		return $problems;
	}

	/** Divi's Search box rewrites every search on the page to its own settings. Put ours back. */
	function tcc_search_keep_our_query( $query ) {
		if ( $query instanceof WP_Query && $query->get( 'tcc_search' ) ) {
			$query->set( 'post_type', array_keys( tcc_search_type_map() ) );
			$query->set( 'posts_per_page', (int) $query->get( 'tcc_search' ) );
			$query->set( 'orderby', 'relevance' );
			$query->set( 'paged', 1 );
			$query->set( 'offset', 0 );
		}
	}
	add_action( 'pre_get_posts', 'tcc_search_keep_our_query', 9999 );

	/** Marks the page so styles (and anyone curious) can tell which search page this is. */
	function tcc_search_body_class( $classes ) {
		if ( tcc_search_active() ) {
			$classes[] = 'tcc-search-page';
		}
		return $classes;
	}
	add_filter( 'body_class', 'tcc_search_body_class' );

	/* ------------------------------------------------------------------
	 * Finding and ranking
	 * ------------------------------------------------------------------ */

	/** The useful words of a search, lower case, without little joining words. */
	function tcc_search_words( $term ) {
		$skip  = array( 'the', 'and', 'for', 'with', 'what', 'when', 'where', 'how', 'are', 'is', 'to', 'of', 'in', 'at', 'on', 'a', 'an', 'do', 'does', 'can', 'i', 'my', 'we', 'you', 'your', 'our' );
		$words = array();
		foreach ( preg_split( '/[^a-z0-9\']+/', tcc_search_lower( $term ) ) as $word ) {
			$word = trim( $word, "'" );
			if ( strlen( $word ) > 1 && ! in_array( $word, $skip, true ) && ! in_array( $word, $words, true ) ) {
				$words[] = $word;
			}
		}
		return array_slice( $words, 0, 6 );
	}

	/**
	 * True when the text has a word that starts with $word: "men" is in "Men's Ministry"
	 * but not in "judgement".
	 */
	function tcc_search_has_word( $text, $word ) {
		return 1 === preg_match( '/(?<![a-z0-9])' . preg_quote( $word, '/' ) . '/', $text );
	}

	/**
	 * Words that ask for a whole kind of thing. Searching "groups" lists the community groups,
	 * "sermons" the latest sermons and "events" what is coming up, even though those words are
	 * not in their titles.
	 */
	function tcc_search_kind_words() {
		return array(
			'group'  => array( 'group', 'groups' ),
			'sermon' => array( 'sermon', 'sermons', 'message', 'messages', 'preaching' ),
			'event'  => array( 'event', 'events', 'calendar', 'happening' ),
		);
	}

	/**
	 * How good a match one item is. Higher is better.
	 * The title counts most; then the kind of thing it is (events coming up, groups and recent
	 * sermons are what people are usually after).
	 */
	function tcc_search_score( $title, $kind, $timestamp, $phrase, $words ) {
		$title = tcc_search_lower( $title );
		$score = 10;
		if ( '' !== $phrase && $title === $phrase ) {
			$score = 100;
		} elseif ( '' !== $phrase && tcc_search_has_word( $title, $phrase ) ) {
			$score = 70;
		} elseif ( $words ) {
			$hits = 0;
			foreach ( $words as $word ) {
				if ( tcc_search_has_word( $title, $word ) ) {
					$hits++;
				}
			}
			if ( $hits === count( $words ) ) {
				$score = 55;
			} elseif ( $hits > 0 ) {
				$score = 10 + (int) round( 25 * $hits / count( $words ) );
			}
		}
		$age_days = max( 0, ( time() - (int) $timestamp ) / DAY_IN_SECONDS );
		if ( 'event' === $kind ) {
			$score += 30;
		} elseif ( 'group' === $kind ) {
			$score += 22;
		} elseif ( 'page' === $kind ) {
			$score += 20;
		} elseif ( 'sermon' === $kind ) {
			$score += ( $age_days <= 183 ) ? 28 : ( ( $age_days <= 548 ) ? 18 : ( ( $age_days <= 1096 ) ? 8 : 0 ) );
		} elseif ( 'article' === $kind && $age_days <= 365 ) {
			$score += 5;
		}
		return $score;
	}

	/**
	 * The extra places searched besides a title and the page text. On this website most of what a
	 * sermon or a community group says about itself is in these fields, not in the page text.
	 * Add a field's name here to make it searchable.
	 */
	function tcc_search_meta_keys() {
		return array(
			'sermon_description_short',
			'sermon_description_long',
			'speaker_name',
			'group_description',
			'organizer_name',
			'date_and_meeting_time',
			'group_location',
			'ages',
			'_yoast_wpseo_metadesc',
		);
	}

	/**
	 * Accounts whose name is not searched, because they are not a person who wrote something:
	 * the church's own account, the sermon upload app, and the web support accounts.
	 * Write the account's name exactly as Users shows it ("Name" column). Add one here if a search
	 * for an everyday word starts bringing back everything that account saved.
	 */
	function tcc_search_author_skip() {
		return array( 'Trinity Community Church', 'Sermon-Publisher app', 'TCC Media', 'Divi Admin', 'USCNi Staff', 'BIC Web Support' );
	}

	/** The kinds of label searched: sermon categories (Bible book, topic, series, speaker), tags, Trinity Talk books. */
	function tcc_search_taxonomies() {
		return array_values( array_filter( array( 'category', 'post_tag', 'trinity-talk', 'project_category', 'project_tag' ), 'taxonomy_exists' ) );
	}

	/**
	 * A pattern the database uses to find a word only where a word STARTS: "men" is found in
	 * "Men's Ministry" and "mentor" but not in "moment" or "commandment".
	 * ("u003e" is how Divi stores the end of a tag, so a word straight after a tag still counts.)
	 */
	function tcc_search_word_pattern( $word ) {
		return '(^|[^[:alnum:]]|u003e)' . preg_replace( '/[^a-z0-9\']/', '', strtolower( (string) $word ) );
	}

	/**
	 * Of these ids (found by WordPress's own search, which matches letters anywhere), keeps the
	 * ones that really have the words as words, in the title, the page text, the excerpt or the
	 * author's name. If the database cannot do it, every id is kept.
	 */
	function tcc_search_whole_word_ids( $ids, $words, $any = false ) {
		global $wpdb;
		$ids   = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		$words = array_slice( array_values( (array) $words ), 0, 6 );
		if ( ! $ids || ! $words ) {
			return $ids;
		}
		$parts = array();
		$args  = array();
		foreach ( $words as $word ) {
			$pattern = tcc_search_word_pattern( $word );
			$parts[] = '( p.post_title REGEXP %s OR p.post_content REGEXP %s OR p.post_excerpt REGEXP %s OR u.display_name REGEXP %s )';
			array_push( $args, $pattern, $pattern, $pattern, $pattern );
		}
		$id_list = implode( ',', $ids );
		$sql     = "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->users} u ON u.ID = p.post_author WHERE p.ID IN ($id_list) AND ( " . implode( $any ? ' OR ' : ' AND ', $parts ) . ' )';
		$before  = $wpdb->suppress_errors( true );
		$kept    = $wpdb->get_col( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- built from fixed text and whole numbers above.
		$failed  = '' !== (string) $wpdb->last_error;
		$wpdb->suppress_errors( $before );
		if ( $failed || ! is_array( $kept ) ) {
			return $ids;
		}
		$kept = array_flip( array_map( 'intval', $kept ) );
		return array_values(
			array_filter(
				$ids,
				function ( $id ) use ( $kept ) {
					return isset( $kept[ $id ] );
				}
			)
		);
	}

	/**
	 * Ids of items that have this word in one of the extra fields or in the name of one of their
	 * labels: array( 'meta' => ids, 'label' => ids ). Two small database lookups.
	 */
	function tcc_search_extra_ids( $word ) {
		global $wpdb;
		$out  = array(
			'meta'  => array(),
			'label' => array(),
		);
		$like = tcc_search_word_pattern( $word );
		$keys = tcc_search_meta_keys();
		if ( $keys ) {
			$marks       = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
			$out['meta'] = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ($marks) AND meta_value REGEXP %s LIMIT 600", array_merge( $keys, array( $like ) ) ) ) );
		}
		// The name of the person who wrote it (a Trinity Talk piece is saved under its writer's account).
		// This used to come from the WP Extended Search plugin; it is done here since 0.10.0.
		// Accounts that are not a person (see tcc_search_author_skip) are left out, so a search for
		// "church" or "sermon" does not bring back everything those accounts ever saved.
		$skip  = tcc_search_author_skip();
		$names = $skip ? ' AND u.display_name NOT IN (' . implode( ',', array_fill( 0, count( $skip ), '%s' ) ) . ')' : '';
		$by    = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->users} u ON u.ID = p.post_author WHERE p.post_status = 'publish' AND u.display_name REGEXP %s" . $names . ' LIMIT 600', array_merge( array( $like ), $skip ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders only.
		$out['meta'] = array_values( array_unique( array_merge( $out['meta'], array_map( 'intval', (array) $by ) ) ) );

		$taxonomies = tcc_search_taxonomies();
		if ( $taxonomies ) {
			$marks        = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );
			$out['label'] = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT tr.object_id FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id JOIN {$wpdb->terms} t ON t.term_id = tt.term_id WHERE tt.taxonomy IN ($marks) AND t.name REGEXP %s LIMIT 600", array_merge( $taxonomies, array( $like ) ) ) ) );
		}
		return $out;
	}

	/** Ids from WordPress's ordinary search (titles and page text) for these words, best first. */
	function tcc_search_core_ids( $lookup, $types ) {
		if ( ! $types ) {
			return array();
		}
		$query = new WP_Query(
			array(
				's'                      => $lookup,
				'post_type'              => $types,
				'post_status'            => 'publish',
				'has_password'           => false,
				'posts_per_page'         => 400,
				'orderby'                => 'relevance',
				'fields'                 => 'ids',
				'ignore_sticky_posts'    => true,
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'tcc_search'             => 400,
			)
		);
		return array_map( 'intval', (array) $query->posts );
	}

	/**
	 * Every match for these words: array of array( id, kind, score, time, strong ).
	 * $any = false: all the words must be there. $any = true: any one of them.
	 */
	function tcc_search_collect( $term, $any = false ) {
		global $wpdb;
		$phrase = tcc_search_lower( $term );
		$words  = tcc_search_words( $term );
		if ( '' === $phrase ) {
			return array();
		}
		$map   = tcc_search_type_map();
		$types = array_keys( $map );
		$only  = tcc_search_only_type();
		$items = array();
		$long  = array_values(
			array_filter(
				$words,
				function ( $word ) {
					return strlen( $word ) > 2;
				}
			)
		);

		// 1. Titles and page text.
		$found = array(); // id => how it was found: 1 = title or page text, 2 = an extra field, 3 = a label.
		if ( $any ) {
			foreach ( array_slice( $long, 0, 4 ) as $word ) {
				foreach ( tcc_search_core_ids( $word, $types ) as $id ) {
					$found[ $id ] = 1;
				}
			}
		} else {
			foreach ( tcc_search_core_ids( $term, $types ) as $id ) {
				$found[ $id ] = 1;
			}
		}
		// WordPress matches letters anywhere ("men" in "moment"). Keep only real word matches.
		if ( $found ) {
			$found = array_fill_keys( tcc_search_whole_word_ids( array_keys( $found ), $any ? array_slice( $long, 0, 4 ) : $words, $any ), 1 );
		}

		// 2. The extra fields and labels (sermon descriptions, speaker, Bible book, group details...).
		if ( $types && $long ) {
			$extra = array();
			foreach ( array_slice( $long, 0, 4 ) as $word ) {
				$extra[ $word ] = tcc_search_extra_ids( $word );
			}
			if ( $any || 1 === count( $long ) ) {
				foreach ( $extra as $sets ) {
					foreach ( $sets['meta'] as $id ) {
						$found[ $id ] = max( 2, isset( $found[ $id ] ) ? $found[ $id ] : 0 );
					}
					foreach ( $sets['label'] as $id ) {
						$found[ $id ] = 3;
					}
				}
			} else {
				// Several words: each one must be somewhere on the item, in any mix of places
				// ("tyler" as the speaker and "baptism" in the title).
				$has_extra = false;
				foreach ( $extra as $sets ) {
					if ( $sets['meta'] || $sets['label'] ) {
						$has_extra = true;
					}
				}
				if ( $has_extra ) {
					$all = null;
					foreach ( $extra as $word => $sets ) {
						$here = array_fill_keys( array_merge( $sets['meta'], $sets['label'], tcc_search_whole_word_ids( tcc_search_core_ids( $word, $types ), array( $word ) ) ), true );
						$all  = ( null === $all ) ? $here : array_intersect_key( $all, $here );
					}
					foreach ( array_keys( (array) $all ) as $id ) {
						$found[ $id ] = max( 2, isset( $found[ $id ] ) ? $found[ $id ] : 0 );
					}
				}
			}
		}

		// 3. Look the found items up lightly (no page text), and leave out what should not show.
		$ids = array_slice( array_keys( $found ), 0, 900 );
		if ( $ids && $types ) {
			$id_list   = implode( ',', array_map( 'intval', $ids ) );
			$type_mark = implode( ',', array_fill( 0, count( $types ), '%s' ) );
			$rows      = (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_date_gmt FROM {$wpdb->posts} WHERE ID IN ($id_list) AND post_status = 'publish' AND post_password = '' AND post_type IN ($type_mark)", $types ) );
			// Pages the church has asked search engines to leave out (thank-you pages and the like) stay out here too.
			$hidden = array_fill_keys( array_map( 'intval', (array) $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_yoast_wpseo_meta-robots-noindex' AND meta_value = '1' AND post_id IN ($id_list)" ) ), true );
			// Community groups marked as not active (Community Groups Info > "Is This Group Active?" unticked) stay out too.
			foreach ( (array) $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'is_this_group_active' AND meta_value = '0' AND post_id IN ($id_list)" ) as $inactive_id ) {
				$hidden[ (int) $inactive_id ] = true;
			}
			foreach ( $rows as $row ) {
				$id = (int) $row->ID;
				if ( isset( $hidden[ $id ] ) || ! isset( $map[ $row->post_type ] ) ) {
					continue;
				}
				$kind  = $map[ $row->post_type ];
				$time  = (int) strtotime( $row->post_date_gmt . ' UTC' );
				$plain = tcc_search_score( '', $kind, $time, '', array() ); // what its kind and age alone are worth
				$score = tcc_search_score( $row->post_title, $kind, $time, $phrase, $words );
				// "Strong" = the words are in its title, or it is filed under a label with this name
				// (the book of Ephesians, the speaker). Only strong matches can be a Top result.
				// The words in its description alone is a fair match, not a strong one.
				$strong = ( $score - $plain ) >= 30 ? 1 : 0;
				if ( 3 === $found[ $id ] ) {
					$score  = max( $score, 35 + $plain );
					$strong = 1;
				} elseif ( 2 === $found[ $id ] ) {
					$score += 12;
				}
				$items[ $id ] = array( $id, $kind, $score, $time, $strong );
			}
		}

		// Upcoming events come from the same list the event cards use, so past dates never show
		// and a repeating event shows once.
		if ( function_exists( 'tcc_upcoming_ids_for' ) && ( '' === $only || 'tribe_events' === $only ) ) {
			$event_ids = array_map( 'intval', (array) tcc_upcoming_ids_for( 'series', 0 ) );
			if ( $event_ids && function_exists( '_prime_post_caches' ) ) {
				_prime_post_caches( $event_ids, true, false );
			}
			foreach ( $event_ids as $event_id ) {
				$event = get_post( $event_id );
				// A password-protected event is left out, like every other protected page above, so its words cannot be found by searching.
				if ( ! ( $event instanceof WP_Post ) || isset( $items[ $event_id ] ) || '' !== (string) $event->post_password ) {
					continue;
				}
				$labels = '';
				$terms  = taxonomy_exists( 'tribe_events_cat' ) ? get_the_terms( $event_id, 'tribe_events_cat' ) : false;
				if ( is_array( $terms ) ) {
					$labels = implode( ' ', wp_list_pluck( $terms, 'name' ) );
				}
				if ( function_exists( 'tribe_get_venue' ) ) {
					$labels .= ' ' . (string) tribe_get_venue( $event_id );
				}
				$text = tcc_search_lower( $event->post_title . ' ' . preg_replace( '/<!--.*?-->/s', ' ', $event->post_content ) . ' ' . $labels );
				$hits = 0;
				foreach ( $words as $word ) {
					if ( false !== strpos( $text, $word ) ) {
						$hits++;
					}
				}
				$match = $any ? ( $hits > 0 ) : ( false !== strpos( $text, $phrase ) || ( $words && $hits === count( $words ) ) );
				if ( ! $match ) {
					continue;
				}
				$start  = function_exists( 'tribe_get_start_date' ) ? (int) tribe_get_start_date( $event_id, true, 'U' ) : 0;
				$score  = tcc_search_score( $event->post_title, 'event', time(), $phrase, $words );
				$strong = ( $score - tcc_search_score( '', 'event', time(), '', array() ) ) >= 30 ? 1 : 0;
				$items[ $event_id ] = array( $event_id, 'event', $score, $start, $strong );
			}
		}

		// A search that names a kind of thing ("groups", "sermons", "events") lists that kind.
		// Only when the search is about nothing else: "groups" or "community groups" lists the groups,
		// but "youth group times" is a search for something specific and does not.
		$filler = array( 'community', 'small', 'church', 'tcc', 'trinity', 'latest', 'recent', 'new', 'upcoming', 'next', 'all', 'list' );
		foreach ( tcc_search_kind_words() as $kind => $names ) {
			if ( '' !== $only || ! array_intersect( $words, $names ) || array_diff( $words, $names, $filler ) ) {
				continue;
			}
			if ( 'event' === $kind ) {
				$extra = function_exists( 'tcc_upcoming_ids_for' ) ? array_slice( array_map( 'intval', (array) tcc_upcoming_ids_for( 'series', 0 ) ), 0, 6 ) : array();
			} else {
				$extra = get_posts(
					array(
						'post_type'        => ( 'group' === $kind ) ? 'project' : 'post',
						'post_status'      => 'publish',
						'has_password'     => false,
						'numberposts'      => ( 'group' === $kind ) ? 30 : 5,
						'orderby'          => ( 'group' === $kind ) ? 'title' : 'date',
						'order'            => ( 'group' === $kind ) ? 'ASC' : 'DESC',
						'fields'           => 'ids',
						'suppress_filters' => true,
						// Leave out community groups marked as not active.
						'meta_query'       => ( 'group' === $kind ) ? array(
							'relation' => 'OR',
							array(
								'key'     => 'is_this_group_active',
								'compare' => 'NOT EXISTS',
							),
							array(
								'key'     => 'is_this_group_active',
								'value'   => '0',
								'compare' => '!=',
							),
						) : array(),
					)
				);
			}
			$place = 0;
			foreach ( (array) $extra as $extra_id ) {
				$extra_id = (int) $extra_id;
				if ( $extra_id > 0 && ! isset( $items[ $extra_id ] ) ) {
					// The time is only used to keep them in this order within their group.
					$time               = ( 'event' === $kind && function_exists( 'tribe_get_start_date' ) ) ? (int) tribe_get_start_date( $extra_id, true, 'U' ) : ( time() - $place );
					$items[ $extra_id ] = array( $extra_id, $kind, 45, $time, 1 );
					$place++;
				}
			}
		}

		return array_values( $items );
	}

	/* ------------------------------------------------------------------
	 * Words that mean the same, and searches that found nothing
	 * ------------------------------------------------------------------ */

	/**
	 * The starting list of words that mean the same thing on this website: one group per line,
	 * words separated by commas. Volunteers change the list under TCC Website > Search; this is
	 * what they get back when they press "Put the starting list back".
	 */
	function tcc_search_default_synonyms() {
		return implode(
			"\n",
			array(
				'kids, children, child, nursery',
				'youth, students, teens, teenagers',
				'giving, give, tithe, tithing, donate, offering',
				'small group, small groups, community group, community groups, life group, life groups',
				'volunteer, volunteering, serve, serving',
				'sermon, sermons, message, messages',
				'pastor, pastors, elders, leadership, staff',
				'membership, member, partner, partnership',
				'women, ladies',
				'baptism, baptized, baptize',
				'livestream, live stream, watch online',
				'jobs, job, employment, careers',
				'directions, address, location',
			)
		);
	}

	/** The list as volunteers last saved it, or the starting list. Text, one group per line. */
	function tcc_search_synonym_text() {
		$saved = get_option( 'tcc_search_synonyms', null );
		return ( is_string( $saved ) && '' !== trim( $saved ) ) ? $saved : tcc_search_default_synonyms();
	}

	/** The list as groups of lower-case words: array( array( 'kids', 'children' ), ... ). */
	function tcc_search_synonym_groups() {
		static $groups = null;
		if ( null !== $groups ) {
			return $groups;
		}
		$groups = array();
		foreach ( preg_split( '/[\r\n]+/', tcc_search_synonym_text() ) as $line ) {
			$entries = array();
			foreach ( explode( ',', $line ) as $entry ) {
				$entry = trim( preg_replace( '/\s+/', ' ', preg_replace( '/[^a-z0-9\' ]+/', ' ', tcc_search_lower( $entry ) ) ) );
				if ( strlen( $entry ) > 1 && ! in_array( $entry, $entries, true ) ) {
					$entries[] = $entry;
				}
			}
			if ( count( $entries ) > 1 ) {
				$groups[] = $entries;
			}
			if ( count( $groups ) >= 80 ) {
				break;
			}
		}
		return $groups;
	}

	/**
	 * Other ways of saying the same search: "kids ministry" gives "children ministry",
	 * "nursery ministry"... At most four, so a search never turns into dozens.
	 */
	function tcc_search_variants( $term ) {
		$term     = trim( preg_replace( '/\s+/', ' ', tcc_search_lower( $term ) ) );
		$variants = array();
		foreach ( tcc_search_synonym_groups() as $group ) {
			// Longest first, so "community groups" is tried before "community group".
			$by_length = $group;
			usort(
				$by_length,
				function ( $a, $b ) {
					return strlen( $b ) <=> strlen( $a );
				}
			);
			foreach ( $by_length as $entry ) {
				$pattern = '/(?<![a-z0-9])' . preg_quote( $entry, '/' ) . '(?![a-z0-9])/';
				if ( 1 !== preg_match( $pattern, $term ) ) {
					continue;
				}
				foreach ( $group as $other ) {
					if ( $other === $entry ) {
						continue;
					}
					$variant = trim( preg_replace( $pattern, $other, $term, 1 ) );
					if ( '' !== $variant && $variant !== $term && ! in_array( $variant, $variants, true ) ) {
						$variants[] = $variant;
					}
				}
				break; // one entry per group is enough
			}
		}
		return array_slice( $variants, 0, 4 );
	}

	/**
	 * tcc_search_collect(), plus the same search in other words.
	 * $also is filled with the other wordings that added something.
	 */
	function tcc_search_collect_wide( $term, $any, &$also, $with_variants = true ) {
		$items = array();
		foreach ( tcc_search_collect( $term, $any ) as $item ) {
			$items[ $item[0] ] = $item;
		}
		foreach ( ( $with_variants ? tcc_search_variants( $term ) : array() ) as $variant ) {
			$added = false;
			foreach ( tcc_search_collect( $variant, $any ) as $item ) {
				if ( ! isset( $items[ $item[0] ] ) ) {
					// Found by another word for it: a touch below the same match on the word typed.
					$item[2]           = max( 1, $item[2] - 6 );
					$items[ $item[0] ] = $item;
					$added             = true;
				} elseif ( $item[2] - 6 > $items[ $item[0] ][2] ) {
					$item[2]           = $item[2] - 6;
					$items[ $item[0] ] = $item;
				}
			}
			if ( $added && ! in_array( $variant, (array) $also, true ) ) {
				$also[] = $variant;
			}
		}
		return array_values( $items );
	}

	/**
	 * Is the search too busy to start a fresh search for this visitor? Counts fresh searches per
	 * minute: 15 for one visitor (known only by a scrambled form of their internet address, which
	 * is not kept) and 90 for the whole website. Searches remembered from the last 10 minutes do
	 * not count. Signed-in editors are never held back. The counts sit in the server's memory
	 * cache (or as short-lived WordPress settings) and are forgotten after two minutes.
	 */
	/**
	 * The visitor's internet address, for counting searches per visitor. Normally the address the
	 * request came from. Only when that is a private or local address (a proxy at the host, in front
	 * of the website) is the address the proxy passed on used instead: the last one in X-Forwarded-For,
	 * else X-Real-IP. A visitor cannot fool this by sending those headers, because they are only read
	 * when the request really came through such a proxy.
	 * Returns array( 'address' => ..., 'via' => 'direct' | 'proxy' | 'proxy, no visitor address' ).
	 */
	function tcc_search_client_address() {
		$public = function ( $ip ) {
			return false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		};
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? trim( (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked as an IP address.
		if ( '' === $remote || $public( $remote ) ) {
			return array( 'address' => $remote, 'via' => 'direct' );
		}
		$passed = array();
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$passed = array_reverse( array_map( 'trim', explode( ',', (string) wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		if ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
			$passed[] = trim( (string) wp_unslash( $_SERVER['HTTP_X_REAL_IP'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		foreach ( $passed as $ip ) {
			if ( $public( $ip ) ) {
				return array( 'address' => $ip, 'via' => 'proxy' );
			}
		}
		return array( 'address' => $remote, 'via' => 'proxy, no visitor address' );
	}

	function tcc_search_too_busy() {
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return false;
		}
		$minute  = (int) floor( time() / 60 );
		$client  = tcc_search_client_address();
		$address = $client['address'];
		$limits  = array(
			'tcc_sq_' . substr( md5( $address . wp_salt( 'nonce' ) ), 0, 12 ) . '_' . $minute => 15,
			'tcc_sq_all_' . $minute => 90,
		);
		foreach ( $limits as $key => $most ) {
			$count = (int) get_transient( $key );
			if ( $count >= $most ) {
				return true;
			}
		}
		foreach ( array_keys( $limits ) as $key ) {
			set_transient( $key, (int) get_transient( $key ) + 1, 2 * MINUTE_IN_SECONDS );
		}
		return false;
	}

	/**
	 * Remembers a search that found nothing, for TCC Website > Search, so the church can see what
	 * people look for and cannot find. Only the words are kept: no names, no addresses, nothing
	 * about who searched. Searches that do not come from a page of this website (mostly robots)
	 * and anything that looks like an email address, a link or a long number are not kept.
	 */
	function tcc_search_log_miss( $term ) {
		try {
			$term = trim( preg_replace( '/\s+/', ' ', tcc_search_lower( $term ) ) );
			$len  = strlen( $term );
			if ( $len < 3 || $len > 40 || false !== strpos( $term, '@' ) || false !== strpos( $term, 'http' ) || false !== strpos( $term, '://' ) || preg_match( '/\d{4,}|[<>{}\[\]=;]/', $term ) ) {
				return;
			}
			$from = isset( $_SERVER['HTTP_REFERER'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['HTTP_REFERER'] ), PHP_URL_HOST ) : '';
			if ( '' === $from || strtolower( $from ) !== strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ) {
				return;
			}
			$misses = get_option( 'tcc_search_misses', array() );
			$misses = is_array( $misses ) ? $misses : array();
			$count  = isset( $misses[ $term ][0] ) ? (int) $misses[ $term ][0] : 0;
			// A word goes on the list the second time it is searched (within a day), so one robot
			// or one stray search cannot fill the list with nonsense.
			if ( 0 === $count ) {
				$seen = get_option( 'tcc_search_misses_once', array() );
				$seen = is_array( $seen ) ? array_filter(
					$seen,
					function ( $when ) {
						return (int) $when > time() - DAY_IN_SECONDS;
					}
				) : array();
				if ( ! isset( $seen[ $term ] ) ) {
					$seen[ $term ] = time();
					update_option( 'tcc_search_misses_once', array_slice( $seen, -100, null, true ), false );
					return;
				}
				unset( $seen[ $term ] );
				update_option( 'tcc_search_misses_once', $seen, false );
				$count = 1; // The first time counts too.
			}
			$misses[ $term ] = array( $count + 1, time() );
			if ( count( $misses ) > 150 ) {
				// Full: drop the ones searched longest ago.
				uasort(
					$misses,
					function ( $a, $b ) {
						return $b[1] <=> $a[1];
					}
				);
				$misses = array_slice( $misses, 0, 150, true );
			}
			update_option( 'tcc_search_misses', $misses, false );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/** Every word the website uses in a title, with how often: the spelling help's dictionary. */
	function tcc_search_vocabulary() {
		$key    = 'tcc_search_vocab_' . tcc_site_gen( 'search' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		$types  = array_merge( array_keys( tcc_search_type_map( true ) ), array( 'tribe_events' ) );
		$marks  = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$titles = (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_title FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($marks)", $types ) );
		foreach ( array( 'category', 'trinity-talk', 'tribe_events_cat' ) as $taxonomy ) {
			if ( taxonomy_exists( $taxonomy ) ) {
				$names = get_terms(
					array(
						'taxonomy'   => $taxonomy,
						'fields'     => 'names',
						'hide_empty' => true,
					)
				);
				if ( is_array( $names ) ) {
					$titles = array_merge( $titles, $names );
				}
			}
		}
		$vocab = array();
		foreach ( $titles as $title ) {
			foreach ( preg_split( '/[^a-z]+/', tcc_search_lower( $title ) ) as $word ) {
				if ( strlen( $word ) >= 4 ) {
					$vocab[ $word ] = isset( $vocab[ $word ] ) ? $vocab[ $word ] + 1 : 1;
				}
			}
		}
		foreach ( tcc_search_extra_words() as $word ) {
			$vocab[ $word ] = isset( $vocab[ $word ] ) ? $vocab[ $word ] + 5 : 5;
		}
		set_transient( $key, $vocab, 12 * HOUR_IN_SECONDS );
		return $vocab;
	}

	/**
	 * Swaps each misspelt word for the closest word the website knows.
	 * Returns the corrected search, or '' when there is nothing to correct.
	 */
	function tcc_search_fix_spelling( $term ) {
		$vocab   = tcc_search_vocabulary();
		$changed = false;
		$out     = array();
		foreach ( preg_split( '/\s+/', tcc_search_lower( $term ) ) as $word ) {
			$plain = preg_replace( '/[^a-z]/', '', $word );
			$len   = strlen( $plain );
			if ( $len < 4 || $len > 24 || isset( $vocab[ $plain ] ) ) {
				$out[] = $word;
				continue;
			}
			$allowed = ( $len <= 5 ) ? 1 : ( ( $len <= 8 ) ? 2 : 3 );
			$best    = '';
			$best_d  = 99;
			foreach ( $vocab as $known => $count ) {
				$known = (string) $known;
				if ( abs( strlen( $known ) - $len ) > $allowed ) {
					continue;
				}
				$distance = levenshtein( $plain, $known );
				if ( $distance > $allowed ) {
					continue;
				}
				// A different first letter is a less likely slip; a common word is a likelier target.
				$rank = $distance + ( ( $known[0] !== $plain[0] ) ? 0.6 : 0 ) - min( 0.4, $count / 100 );
				if ( $rank < $best_d ) {
					$best_d = $rank;
					$best   = $known;
				}
			}
			if ( '' !== $best ) {
				$out[]   = $best;
				$changed = true;
			} else {
				$out[] = $word;
			}
		}
		return $changed ? implode( ' ', $out ) : '';
	}

	/** Start the dictionary and the remembered searches afresh whenever content changes. */
	function tcc_search_content_changed( $post_id = 0 ) {
		if ( $post_id && ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) ) {
			return;
		}
		static $done = false;
		if ( ! $done ) {
			$done = true;
			tcc_site_new_gen( 'search' );
		}
	}
	foreach ( array( 'page', 'post', 'article', 'project', 'tribe_events' ) as $tcc_search_type ) {
		add_action( 'save_post_' . $tcc_search_type, 'tcc_search_content_changed' );
	}
	unset( $tcc_search_type );
	add_action( 'trashed_post', 'tcc_search_content_changed' );

	/**
	 * Everything the page needs for the current search:
	 * array( 'typed', 'used', 'note' ('' | 'spelling' | 'any' | 'busy'), 'items' ).
	 */
	function tcc_search_data() {
		static $data = null;
		if ( null !== $data ) {
			return $data;
		}
		$typed = tcc_search_term();
		$data  = array(
			'typed' => $typed,
			'used'  => $typed,
			'note'  => '',
			'also'  => array(),
			'items' => array(),
		);
		if ( '' === $typed ) {
			return $data;
		}
		$key    = 'tcc_search5_' . tcc_site_gen( 'search' ) . '_' . tcc_site_gen( 'upcoming' ) . '_' . md5( tcc_search_lower( $typed ) . '|' . tcc_search_only_type() );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['items'], $cached['also'] ) ) {
			$cached['typed'] = $typed;
			$data            = $cached;
			return $data;
		}
		// A fresh search (not remembered from the last 10 minutes) is real work for the server.
		// One visitor, or a robot, sending many different searches a minute is told to wait.
		if ( tcc_search_too_busy() ) {
			$data['note'] = 'busy';
			return $data;
		}
		try {
			$also  = array();
			$items = tcc_search_collect_wide( $typed, false, $also );
			if ( ! $items ) {
				// The second tries (closest spelling, then any of the words) skip the other wordings,
				// so a search that finds nothing costs a few lookups, not dozens.
				$fixed = tcc_search_fix_spelling( $typed );
				if ( '' !== $fixed ) {
					$items = tcc_search_collect_wide( $fixed, false, $also, false );
					if ( $items ) {
						$data['used'] = $fixed;
						$data['note'] = 'spelling';
					}
				}
				if ( ! $items && count( tcc_search_words( $typed ) ) > 1 ) {
					$loose = ( '' !== $fixed ) ? $fixed : $typed;
					$items = tcc_search_collect_wide( $loose, true, $also, false );
					if ( $items ) {
						$data['used'] = $loose;
						$data['note'] = 'any';
					}
				}
			}
			$data['items'] = $items;
			$data['also']  = $also;
			if ( ! $items ) {
				tcc_search_log_miss( $typed );
			}
		} catch ( \Throwable $e ) {
			$data['items'] = array();
		}
		set_transient( $key, $data, 10 * MINUTE_IN_SECONDS );
		return $data;
	}

	/**
	 * The one group being looked at on its own page (the address ends in &tcc_kind=sermon after
	 * someone pressed "See all 59 Sermons"), or '' for the ordinary page with every group.
	 */
	function tcc_search_one_kind() {
		$kind  = isset( $_GET['tcc_kind'] ) && ! is_array( $_GET['tcc_kind'] ) ? sanitize_key( wp_unslash( $_GET['tcc_kind'] ) ) : '';
		$kinds = tcc_search_kinds();
		return isset( $kinds[ $kind ] ) ? $kind : '';
	}

	/** The items of one kind, best first (events: soonest first). */
	function tcc_search_group( $items, $kind ) {
		$group = array();
		foreach ( $items as $item ) {
			if ( $item[1] === $kind ) {
				$group[] = $item;
			}
		}
		usort(
			$group,
			function ( $a, $b ) use ( $kind ) {
				if ( 'event' === $kind ) {
					return $a[3] <=> $b[3];
				}
				return ( $b[2] <=> $a[2] ) ? ( $b[2] <=> $a[2] ) : ( $b[3] <=> $a[3] );
			}
		);
		return $group;
	}

	/** The three best matches overall, one of each kind where possible. Empty when there are few results. */
	function tcc_search_top( $items ) {
		if ( count( $items ) < 7 ) {
			return array();
		}
		$sorted = $items;
		usort(
			$sorted,
			function ( $a, $b ) {
				return ( $b[2] <=> $a[2] ) ? ( $b[2] <=> $a[2] ) : ( $b[3] <=> $a[3] );
			}
		);
		$top   = array();
		$kinds = array();
		foreach ( $sorted as $item ) {
			// Only strong matches (see tcc_search_collect) lead the page.
			if ( count( $top ) < 3 && ! empty( $item[4] ) && ! isset( $kinds[ $item[1] ] ) ) {
				$top[ $item[0] ]   = $item;
				$kinds[ $item[1] ] = true;
			}
		}
		foreach ( $sorted as $item ) {
			if ( count( $top ) < 3 && ! empty( $item[4] ) && ! isset( $top[ $item[0] ] ) ) {
				$top[ $item[0] ] = $item;
			}
		}
		return ( count( $top ) >= 2 ) ? array_values( $top ) : array();
	}

	/* ------------------------------------------------------------------
	 * Drawing the page
	 * ------------------------------------------------------------------ */

	/** A short plain description of a page, article or group, or ''. */
	function tcc_search_blurb( $post ) {
		$text = (string) get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true );
		if ( '' === trim( $text ) || false !== strpos( $text, '%%' ) ) {
			$text = ( '' !== trim( $post->post_excerpt ) ) ? $post->post_excerpt : $post->post_content;
			$text = preg_replace( '/<!--.*?-->/s', ' ', $text );
			$text = preg_replace( '/\[\/?[a-zA-Z_][^\]]*\]/', ' ', $text );
			$text = preg_replace( '/<(script|style)\b.*?<\/\1>/is', ' ', $text );
		}
		$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) );
		if ( strlen( $text ) < 25 ) {
			return '';
		}
		return wp_trim_words( $text, 26, '…' );
	}

	/** The pieces shown for one result: title, link, small line, description, picture, date tile. */
	function tcc_search_view( $item ) {
		$post = get_post( $item[0] );
		if ( ! ( $post instanceof WP_Post ) ) {
			return null;
		}
		$kind = $item[1];
		$view = array(
			'kind'  => $kind,
			'title' => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'url'   => (string) get_permalink( $post ),
			'meta'  => '',
			'blurb' => '',
			'image' => (string) get_the_post_thumbnail_url( $post, 'medium_large' ),
			'month' => '',
			'day'   => '',
		);
		if ( 'event' === $kind && function_exists( 'tribe_get_start_date' ) ) {
			$view['month'] = (string) tribe_get_start_date( $post->ID, false, 'M' );
			$view['day']   = (string) tribe_get_start_date( $post->ID, false, 'j' );
			$when          = (string) tribe_get_start_date( $post->ID, false, 'l, F j' );
			if ( function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $post->ID ) ) {
				$time = 'All Day';
			} else {
				$start = (string) tribe_get_start_date( $post->ID, false, 'g:i A' );
				$end   = function_exists( 'tribe_get_end_date' ) ? (string) tribe_get_end_date( $post->ID, false, 'g:i A' ) : '';
				$time  = ( '' !== $end && $end !== $start ) ? $start . ' - ' . $end : $start;
			}
			$view['meta'] = trim( $when . ' · ' . $time, ' ·' );
		} elseif ( 'sermon' === $kind ) {
			// The same speaker line as the Sermons page ("Tyler Lynde & Amy Lynde"). Without that
			// feature: the typed Speaker Name, or failing that the sermon's author.
			if ( function_exists( 'tcc_sermons_speaker' ) ) {
				$speaker = (string) tcc_sermons_speaker( $post->ID );
			} else {
				$speaker = trim( (string) get_post_meta( $post->ID, 'speaker_name', true ) );
				if ( '' === $speaker ) {
					$speaker = (string) get_the_author_meta( 'display_name', (int) $post->post_author );
				}
			}
			if ( false !== stripos( $speaker, 'Trinity Community' ) ) {
				$speaker = '';
			}
			$view['meta'] = trim( $speaker . ' · ' . get_the_date( 'F j, Y', $post ), ' ·' );
			$short        = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) get_post_meta( $post->ID, 'sermon_description_short', true ) ) ) );
			if ( strlen( $short ) >= 25 ) {
				$view['blurb'] = wp_trim_words( $short, 26, '…' );
			}
		} elseif ( 'group' === $kind ) {
			// Community groups keep their words in their own fields (Community Groups Info).
			$about = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) get_post_meta( $post->ID, 'group_description', true ) ) ) );
			$when  = trim( (string) get_post_meta( $post->ID, 'date_and_meeting_time', true ) );
			$view['blurb'] = ( strlen( $about ) >= 25 ) ? wp_trim_words( $about, 26, '…' ) : tcc_search_blurb( $post );
			if ( '' !== $when ) {
				$view['blurb'] = trim( $when . ' · ' . $view['blurb'], ' ·' );
			}
		} else {
			$view['blurb'] = tcc_search_blurb( $post );
		}
		return $view;
	}

	function tcc_search_row_html( $view ) {
		$html = '<a class="tcc-s-row" href="' . esc_url( $view['url'] ) . '">';
		if ( 'event' === $view['kind'] && '' !== $view['day'] ) {
			$html .= '<span class="tcc-s-date"><small>' . esc_html( $view['month'] ) . '</small><b>' . esc_html( $view['day'] ) . '</b></span>';
		} elseif ( 'sermon' === $view['kind'] ) {
			// A real picture that the browser only fetches when its row is about to be seen.
			$html .= '<span class="tcc-s-thumb">' . ( '' !== $view['image'] ? '<img src="' . esc_url( $view['image'] ) . '" alt="" loading="lazy" decoding="async">' : '' ) . '</span>';
		}
		$html .= '<span class="tcc-s-text">';
		if ( 'sermon' === $view['kind'] && '' !== $view['meta'] ) {
			$html .= '<span class="tcc-s-meta">' . esc_html( $view['meta'] ) . '</span>';
		}
		$html .= '<span class="tcc-s-title">' . esc_html( $view['title'] ) . '</span>';
		if ( 'event' === $view['kind'] && '' !== $view['meta'] ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $view['meta'] ) . '</span>';
		} elseif ( '' !== $view['blurb'] ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $view['blurb'] ) . '</span>';
		}
		return $html . '</span></a>';
	}

	function tcc_search_card_html( $view, $label ) {
		$html  = '<a class="tcc-s-card" href="' . esc_url( $view['url'] ) . '">';
		$html .= '<span class="tcc-s-card-img"' . ( '' !== $view['image'] ? ' style="background-image:url(&quot;' . esc_url( $view['image'] ) . '&quot;)"' : '' ) . '></span>';
		$html .= '<span class="tcc-s-card-text"><span class="tcc-s-kind">' . esc_html( $label ) . '</span>';
		$html .= '<span class="tcc-s-title">' . esc_html( $view['title'] ) . '</span>';
		$line  = ( '' !== $view['meta'] ) ? $view['meta'] : wp_trim_words( $view['blurb'], 14, '…' );
		if ( '' !== $line ) {
			$html .= '<span class="tcc-s-blurb">' . esc_html( $line ) . '</span>';
		}
		return $html . '</span></a>';
	}

	/** [tcc_search_heading]: Results for "baptism". */
	function tcc_search_heading_shortcode() {
		try {
			$data = tcc_search_data();
			if ( '' === $data['typed'] ) {
				return 'Search the website';
			}
			if ( 'busy' === $data['note'] ) {
				return 'Search the website';
			}
			if ( ! $data['items'] ) {
				return 'No results for &ldquo;' . esc_html( $data['typed'] ) . '&rdquo;';
			}
			return 'Results for &ldquo;' . esc_html( $data['used'] ) . '&rdquo;';
		} catch ( \Throwable $e ) {
			return 'Search results';
		}
	}
	add_shortcode( 'tcc_search_heading', 'tcc_search_heading_shortcode' );

	/** [tcc_search_form]: the search-again box. It searches the whole website, unless this search was limited to one kind. */
	function tcc_search_form_shortcode() {
		$data = tcc_search_data();
		$only = tcc_search_only_type();
		return tcc_search_css( true ) . '<div class="tcc-search"><form class="tcc-s-form" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '">'
			. ( '' !== $only ? '<input type="hidden" name="post_type" value="' . esc_attr( $only ) . '">' : '' )
			. '<label class="screen-reader-text" for="tcc-s-box">Search the website</label>'
			. '<input id="tcc-s-box" type="search" name="s" value="' . esc_attr( $data['typed'] ) . '" placeholder="Search the website" autocomplete="off">'
			. '<button type="submit">Search</button></form></div>';
	}
	add_shortcode( 'tcc_search_form', 'tcc_search_form_shortcode' );

	/** [tcc_search_results]: the Top results cards, the jump buttons and the groups. */
	function tcc_search_results_shortcode() {
		try {
			$data  = tcc_search_data();
			$items = $data['items'];
			$kinds = tcc_search_kinds();
			$html  = tcc_search_css( true ) . '<div class="tcc-search tcc-s-results">';
			// Tells tcc_search_note_outcome() that the new page really was shown.
			$GLOBALS['tcc_search_drawn'] = true;

			if ( '' === $data['typed'] ) {
				return $html . '<p class="tcc-s-note">Type a word or two in the box above, for example &ldquo;baptism&rdquo; or &ldquo;youth&rdquo;.</p></div>';
			}

			if ( 'busy' === $data['note'] ) {
				return $html . '<div class="tcc-s-empty"><p class="tcc-s-empty-head">The search is busy right now.</p><p>Please wait a minute and press Search again.</p></div></div>';
			}

			if ( ! $items ) {
				$html .= '<div class="tcc-s-empty"><p class="tcc-s-empty-head">We could not find anything for that.</p>'
					. '<p>Check the spelling or try a shorter word, for example &ldquo;youth&rdquo; instead of &ldquo;youth group times&rdquo;. Or start from one of these:</p><ul class="tcc-s-jump">';
				foreach ( tcc_search_empty_links() as $words => $address ) {
					$link = tcc_search_link( $address );
					if ( '' !== $link ) {
						$html .= '<li><a href="' . esc_url( $link ) . '">' . esc_html( $words ) . '</a></li>';
					}
				}
				return $html . '</ul></div></div>';
			}

			if ( 'spelling' === $data['note'] ) {
				$html .= '<p class="tcc-s-note">We could not find &ldquo;' . esc_html( $data['typed'] ) . '&rdquo;, so here are the results for &ldquo;<strong>' . esc_html( $data['used'] ) . '</strong>&rdquo;.</p>';
			} elseif ( 'any' === $data['note'] ) {
				$html .= '<p class="tcc-s-note">Nothing has all of those words together, so here is everything that matches any of them.</p>';
			}
			if ( ! empty( $data['also'] ) ) {
				$said = array();
				foreach ( array_slice( (array) $data['also'], 0, 4 ) as $other ) {
					$said[] = '&ldquo;' . esc_html( $other ) . '&rdquo;';
				}
				$html .= '<p class="tcc-s-note tcc-s-also">Also showing results for ' . implode( ', ', $said ) . '.</p>';
			}

			// One kind on its own page ("See all 59"), or every kind with its first few.
			$one    = tcc_search_one_kind();
			$limit  = ( '' !== $one ) ? 300 : 30;
			$groups = array();
			$ids    = array();
			foreach ( $kinds as $kind => $setup ) {
				$group = tcc_search_group( $items, $kind );
				if ( $group ) {
					$groups[ $kind ] = $group;
					if ( '' === $one || $one === $kind ) {
						foreach ( array_slice( $group, 0, $limit ) as $item ) {
							$ids[] = $item[0];
						}
					}
				}
			}
			if ( '' !== $one && ! isset( $groups[ $one ] ) ) {
				$one   = '';
				$limit = 30;
			}
			if ( $ids && function_exists( '_prime_post_caches' ) ) {
				_prime_post_caches( $ids, true, true );
			}
			$search_url = add_query_arg( 's', rawurlencode( $data['typed'] ), home_url( '/' ) );

			if ( '' !== $one ) {
				$html  .= '<p class="tcc-s-back"><a href="' . esc_url( $search_url ) . '">All results for &ldquo;' . esc_html( $data['used'] ) . '&rdquo;</a></p>';
				$groups = array( $one => $groups[ $one ] );
			} else {
				$top = tcc_search_top( $items );
				if ( $top ) {
					$cards = '';
					foreach ( $top as $item ) {
						$view = tcc_search_view( $item );
						if ( $view ) {
							$cards .= '<li>' . tcc_search_card_html( $view, $kinds[ $item[1] ][1] ) . '</li>';
						}
					}
					if ( '' !== $cards ) {
						$html .= '<section class="tcc-s-top" aria-label="Top results"><h2 class="tcc-s-top-head">Top results</h2><ul class="tcc-s-cards' . ( 2 === count( $top ) ? ' tcc-s-cards-2' : '' ) . '">' . $cards . '</ul></section>';
					}
				}

				if ( count( $groups ) > 1 ) {
					$html .= '<ul class="tcc-s-jump" aria-label="Jump to a kind of result">';
					foreach ( $groups as $kind => $group ) {
						$html .= '<li><a href="#tcc-s-' . esc_attr( $kind ) . '">' . esc_html( $kinds[ $kind ][0] ) . ' <b>' . count( $group ) . '</b></a></li>';
					}
					$html .= '</ul>';
				}
			}

			foreach ( $groups as $kind => $group ) {
				$setup = $kinds[ $kind ];
				$first = ( '' !== $one ) ? 30 : $setup[2];
				$html .= '<section class="tcc-s-group" id="tcc-s-' . esc_attr( $kind ) . '"><div class="tcc-s-group-head"><h2>' . esc_html( $setup[0] ) . ' <span>' . count( $group ) . '</span></h2>';
				$see_all = ( '' !== $setup[3] ) ? tcc_search_link( $setup[3] ) : '';
				if ( '' !== $see_all ) {
					$html .= '<a href="' . esc_url( $see_all ) . '">' . esc_html( $setup[4] ) . '</a>';
				}
				$html .= '</div><ul class="tcc-s-rows">';
				$drawn = 0;
				foreach ( array_slice( $group, 0, $limit ) as $item ) {
					$view = tcc_search_view( $item );
					if ( ! $view ) {
						continue;
					}
					$html .= '<li' . ( $drawn >= $first ? ' class="tcc-s-extra"' : '' ) . '>' . tcc_search_row_html( $view ) . '</li>';
					$drawn++;
				}
				$html .= '</ul>';
				$more  = '';
				if ( '' !== $one ) {
					// On a kind's own page the rest come 30 at a time.
					if ( $drawn > $first ) {
						$more .= '<button type="button" data-step="30">Show 30 more</button>';
					}
				} else {
					if ( $drawn > $first ) {
						$more .= '<button type="button">Show ' . ( count( $group ) > $drawn ? 'the first ' : 'all ' ) . (int) $drawn . '</button>';
					}
					// More than fit here: a page of their own with every one.
					if ( count( $group ) > $drawn ) {
						$more .= '<a class="tcc-s-all" href="' . esc_url( add_query_arg( 'tcc_kind', $kind, $search_url ) ) . '" aria-label="' . esc_attr( 'See all ' . count( $group ) . ' results in ' . $setup[0] ) . '">See all ' . count( $group ) . '</a>';
					}
				}
				if ( '' !== $more ) {
					$html .= '<p class="tcc-s-more">' . $more . '</p>';
				}
				$html .= '</section>';
			}

			// The "Show ..." buttons. Without JavaScript every result simply shows. The script is in
			// sitewide-search.js, beside this file; the line breaks around it are only for reading.
			$html .= '<script>' . "\n" . tcc_site_asset( 'features/sitewide-search.js' ) . "\n" . '</script>';

			return $html . '</div>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_search_results', 'tcc_search_results_shortcode' );

	/**
	 * The look of the search page. Colours: teal #00A4CF (outlines, arrows), teal again for words (a darker teal, 007DA1, was used for words until 0.9.0; it is not one of the church's brand colours, so it was retired)
	 * (buttons, small labels), grey #f4f4f4 (rows), text #404041.
	 *
	 * The rules are in sitewide-search.css. Every rule is written twice: first starting with plain
	 * "body", so the page keeps its look even if a Divi update renames Divi's page ids, then (from the
	 * line starting "#page-container #et-boc .tcc-search{") again starting with Divi's two page ids, so
	 * Divi's own rules do not override it. A change to one copy needs making in the other copy too.
	 * Each copy runs in this order: the general rules, the search-again box and notes, Top results, the jump buttons, the
	 * groups and rows, the "nothing found" box, the narrower screens, then the two Divi text layers
	 * above the results (.tcc-search-eyebrow and .tcc-search-heading, which are outside .tcc-search).
	 * On tablets and phones (800 wide or less) the three Top results cards become rows with the
	 * picture on the left.
	 *
	 * It is printed in the page head for a sitewide search. A short code that finds it has not
	 * been printed (the template is being shown some other way) prints it itself: $inline = true.
	 */
	function tcc_search_css( $inline = false ) {
		static $printed = false;
		if ( $printed || ( ! $inline && ! tcc_search_active() ) ) {
			return '';
		}
		$printed = true;
		// The rules are in sitewide-search.css (beside this file), one rule to a line. The line break
		// after each closing } is only there to make the file easy to read: it is taken out here, so the
		// page gets the rules run together on one line, as it always has.
		$out = '<style id="tcc-sitewide-search">' . str_replace( "}\n", '}', tcc_site_asset( 'features/sitewide-search.css' ) ) . '</style>' . "\n";
		if ( $inline ) {
			return $out;
		}
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own styles file.
		return '';
	}
	add_action( 'wp_head', 'tcc_search_css', 30 );

	// WP Rocket is told to leave these styles alone (id tcc-sitewide-search) by the plugin's main file,
	// which keeps every style block whose id starts "tcc-".

	/* ------------------------------------------------------------------
	 * The Search tab on the TCC Website screen (drawn from admin.php)
	 * ------------------------------------------------------------------ */

	/** Saves or resets the list of words that mean the same, or clears the "found nothing" list. */
	function tcc_search_admin_save( $op ) {
		if ( 'search_synonyms' === $op ) {
			$text = isset( $_POST['tcc_search_synonyms'] ) ? sanitize_textarea_field( wp_unslash( $_POST['tcc_search_synonyms'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked by tcc_site_handle_post.
			update_option( 'tcc_search_synonyms', substr( $text, 0, 6000 ), false );
			$done = 'saved';
		} elseif ( 'search_synonyms_reset' === $op ) {
			delete_option( 'tcc_search_synonyms' );
			$done = 'reset';
		} elseif ( 'search_misses_clear' === $op ) {
			delete_option( 'tcc_search_misses' );
			delete_option( 'tcc_search_misses_once' );
			return 'cleared';
		} else {
			return '';
		}
		// Remembered searches were made with the old list: start them afresh.
		tcc_site_new_gen( 'search' );
		return $done;
	}

	function tcc_search_admin_tab() {
		$done = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only chooses a message.
		$said = array(
			'saved'   => 'Saved. Searches use the new list straight away.',
			'reset'   => 'The starting list is back.',
			'cleared' => 'The list of searches that found nothing has been emptied.',
		);
		if ( isset( $said[ $done ] ) ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html( $said[ $done ] ) . '</p></div>';
		}

		// 1. Searches that found nothing.
		$misses = get_option( 'tcc_search_misses', array() );
		$misses = is_array( $misses ) ? $misses : array();
		uasort(
			$misses,
			function ( $a, $b ) {
				return ( $b[0] <=> $a[0] ) ? ( $b[0] <=> $a[0] ) : ( $b[1] <=> $a[1] );
			}
		);
		echo '<div class="tcc-card"><h2>Searches that found nothing</h2>';
		echo '<p class="tcc-muted">What visitors typed into the website search and got no results for. Use it to spot a page that is missing, or a word to add to the list below. Only the words are kept, nothing about who searched. A search is counted at most once every 10 minutes, a word only shows here once it has been searched twice within a day (so one robot or one stray search cannot fill the list), and the list holds the 150 most recent.</p>';
		if ( ! $misses ) {
			echo '<p><span class="tcc-pill tcc-pill--ok">Nothing yet</span> No search has come up empty since this list was last emptied.</p>';
		} else {
			// A plain list, most-searched first: it reads the same on a phone as on a computer.
			echo '<ul style="margin:12px 0;padding:0;list-style:none">';
			foreach ( array_slice( $misses, 0, 150, true ) as $term => $miss ) {
				$times = (int) $miss[0];
				echo '<li style="margin:0;padding:8px 0;border-top:1px solid #f0f0f1"><strong>' . esc_html( (string) $term ) . '</strong> <span class="tcc-muted">&nbsp;' . $times . ( 1 === $times ? ' time' : ' times' ) . ', last ' . esc_html( human_time_diff( (int) $miss[1] ) ) . ' ago</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a whole number.
			}
			echo '</ul><p>' . tcc_site_button( 'search_misses_clear', 'Empty this list', array(), 'button', 'Empty the list of searches that found nothing? This cannot be undone.' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped by tcc_site_button.
		}
		echo '</div>';

		// 1b. How visitors are told apart, so one busy visitor cannot use up search for everyone.
		$client = tcc_search_client_address();
		$alone  = 'proxy, no visitor address' !== $client['via'] && '' !== $client['address'];
		echo '<div class="tcc-card"><h2>How visitors are counted</h2>';
		echo '<p>' . ( $alone ? '<span class="tcc-pill tcc-pill--ok">Each visitor on their own</span> ' : '<span class="tcc-pill tcc-pill--warn">Needs a look</span> ' );
		echo 'To keep the website fast, one visitor can start at most 15 new searches a minute, and the whole website 90 a minute (signed-in editors are never held back). Visitors are told apart by their internet address. ';
		if ( $alone ) {
			echo 'This website sees yours as <code>' . esc_html( $client['address'] ) . '</code>' . ( 'proxy' === $client['via'] ? ', passed on by the host\'s proxy' : '' ) . '. If that is your own address (searching "what is my IP" shows it), every visitor is counted on their own.</p>';
		} else {
			echo 'This website only sees the host\'s own address (<code>' . esc_html( $client['address'] ) . '</code>), so every visitor may share one count and search may say it is busy too soon. Ask whoever looks after the website\'s code.</p>';
		}
		echo '</div>';

		// 2. Words that mean the same.
		$custom = is_string( get_option( 'tcc_search_synonyms', null ) ) && '' !== trim( (string) get_option( 'tcc_search_synonyms', '' ) );
		echo '<div class="tcc-card"><h2>Words that mean the same</h2>';
		echo '<p class="tcc-muted">When a visitor searches for one of these words, the website also searches for the others on the same line. One group per line, words separated by commas. Example: <code>kids, children, nursery</code> means a search for "kids" also finds pages that only say "children".</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="tcc_site_do"><input type="hidden" name="op" value="search_synonyms">';
		wp_nonce_field( 'tcc_site_do', '_tcc_site_nonce' );
		echo '<label class="screen-reader-text" for="tcc-search-synonyms">Words that mean the same, one group per line</label>';
		echo '<textarea id="tcc-search-synonyms" name="tcc_search_synonyms" rows="14" style="width:100%;max-width:760px;font-family:inherit;font-size:14px;line-height:1.6" spellcheck="false">' . esc_textarea( tcc_search_synonym_text() ) . '</textarea>';
		echo '<p><button type="submit" class="button button-primary">Save the list</button> <span class="tcc-muted">' . count( tcc_search_synonym_groups() ) . ' groups in use. ' . ( $custom ? 'This is your own list.' : 'This is the starting list.' ) . '</span></p></form>';
		if ( $custom ) {
			echo tcc_site_button( 'search_synonyms_reset', 'Put the starting list back', array(), 'button', 'Replace your list with the starting list? Your changes to it will be lost.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<p class="tcc-muted" style="margin-bottom:0">Tips: keep groups small and truly alike, or searches get noisy. A word can be two words ("small group"). Lines with only one word are ignored. Only the first four other words on a line are tried for any one search.</p></div>';

		// 3. What search reads.
		echo '<div class="tcc-card"><h2>What the search reads</h2><ul style="list-style:disc;margin-left:20px">';
		echo '<li><strong>Pages and Trinity Talk articles:</strong> the title and the words on the page.</li>';
		echo '<li><strong>Sermons:</strong> the title, both descriptions, the Speaker Name, and the categories (Bible book, topic, series, speaker).</li>';
		echo '<li><strong>Community groups:</strong> the title, description, organizer, meeting time, location and ages. A group with "Is This Group Active?" unticked is left out.</li>';
		echo '<li><strong>Events:</strong> only ones still to come: the title, description, category and venue.</li>';
		echo '</ul><p class="tcc-muted" style="margin-bottom:0">A word is matched where a word starts, so "men" finds "Men\'s Ministry" but not "moment". A page set to "do not show in search results" in Yoast is left out. Results are remembered for 10 minutes and start afresh when something is saved.</p></div>';
	}
}
