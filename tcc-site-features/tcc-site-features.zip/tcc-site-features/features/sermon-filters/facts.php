<?php
/**
 * TCC Sermons page: the facts about every sermon.
 *
 * Part: the facts about every sermon (series, speakers, books and topics)
 *
 * What is in this part:
 *  - the four parent categories (Series, Speaker, Topics, Bible) and the books of the Bible in order;
 *  - tcc_sermons_index(): every category sorted into series, speaker, topic or book by the parent it
 *    is filed under, every published sermon and its series, and every series with its number of
 *    sermons, its dates, its picture and its description. Worked out once and remembered for 12
 *    hours; worked out again whenever a sermon or a category is saved (tcc_sermons_bump);
 *  - which page this is (the Sermons page, a category page, a series page, the Divi editor asking
 *    for a preview);
 *  - the speaker line of a sermon ("Tyler Lynde & Amy Lynde") and one sermon's facts, by group.
 * The "Sermon page" and "Sermon speakers" features use these too.
 *
 * Part of the "Sermons page: search, filters and series" feature (features/sermon-filters.php loads
 * it first). The other parts, series.php and filter-bar.php in this folder, use what it works out.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermons_index' ) ) {

	/** The name of the list Divi loops over for series cards. */
	function tcc_sermons_series_source() {
		return 'tcc_sermon_series';
	}

	/** The four parent categories, by their slug (the last part of their address). */
	function tcc_sermons_parent_slugs() {
		return apply_filters(
			'tcc_sermons_parent_slugs',
			array(
				'series'  => 'sermons-series',
				'speaker' => 'speaker',
				'topic'   => 'topics',
				'book'    => 'bible',
			)
		);
	}

	/** Books of the Bible in their usual order, so the Book menu reads Genesis to Revelation. */
	function tcc_sermons_bible_order() {
		static $order = null;
		if ( null === $order ) {
			$books = 'Genesis,Exodus,Leviticus,Numbers,Deuteronomy,Joshua,Judges,Ruth,1 Samuel,2 Samuel,1 Kings,2 Kings,1 Chronicles,2 Chronicles,Ezra,Nehemiah,Esther,Job,Psalms,Proverbs,Ecclesiastes,Song of Solomon,Isaiah,Jeremiah,Lamentations,Ezekiel,Daniel,Hosea,Joel,Amos,Obadiah,Jonah,Micah,Nahum,Habakkuk,Zephaniah,Haggai,Zechariah,Malachi,Matthew,Mark,Luke,John,Acts,Romans,1 Corinthians,2 Corinthians,Galatians,Ephesians,Philippians,Colossians,1 Thessalonians,2 Thessalonians,1 Timothy,2 Timothy,Titus,Philemon,Hebrews,James,1 Peter,2 Peter,1 John,2 John,3 John,Jude,Revelation';
			$order = array_flip( array_map( 'strtolower', explode( ',', $books ) ) );
			$order['psalm']           = $order['psalms'];
			$order['song of songs']   = $order['song of solomon'];
			$order['revelations']     = $order['revelation'];
		}
		return $order;
	}

	/**
	 * Everything these pages need to know, worked out once and remembered.
	 *
	 * 'cats'   category id => array( group, name, slug, testament )   group is series, speaker, topic or book
	 * 'series' series category id => array( name, slug, url, count, first, last, first_post, img, img_id, desc ),
	 *          newest series first; only series with at least one sermon
	 * 'posts'  sermon id => series category id (0 when it is in no series)
	 * 'used'   category id => how many sermons carry it
	 * 'total'  number of published sermons
	 */
	function tcc_sermons_index() {
		// Remembered per "generation", so a change to the sermons (which starts a new generation) is never hidden by an old copy.
		static $memo = array();
		$gen = tcc_site_gen( 'sermons' );
		if ( isset( $memo[ $gen ] ) ) {
			return $memo[ $gen ];
		}
		$key    = 'tcc_sermons_idx_' . $gen;
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['series'], $cached['cats'] ) ) {
			$memo[ $gen ] = $cached;
			return $memo[ $gen ];
		}

		$index = array(
			'cats'   => array(),
			'series' => array(),
			'posts'  => array(),
			'used'   => array(),
			'total'  => 0,
		);
		$GLOBALS['tcc_sermons_building'] = true;
		try {
			// 1. Sort every category into series, speaker, topic or book by the parent it sits under.
			$terms = get_terms(
				array(
					'taxonomy'   => 'category',
					'hide_empty' => false,
				)
			);
			$terms  = is_array( $terms ) ? $terms : array();
			$by_id  = array();
			$groups = array();
			foreach ( $terms as $term ) {
				$by_id[ (int) $term->term_id ] = $term;
			}
			foreach ( tcc_sermons_parent_slugs() as $group => $slug ) {
				foreach ( $terms as $term ) {
					if ( $term->slug === $slug && 0 === (int) $term->parent ) {
						$groups[ (int) $term->term_id ] = $group;
					}
				}
			}
			foreach ( $terms as $term ) {
				$id        = (int) $term->term_id;
				$walk      = $term;
				$testament = '';
				$group     = '';
				$steps     = 0;
				while ( $walk && $steps < 6 ) {
					$parent = (int) $walk->parent;
					if ( ! $parent || ! isset( $by_id[ $parent ] ) ) {
						break;
					}
					if ( isset( $groups[ $parent ] ) ) {
						$group = $groups[ $parent ];
						break;
					}
					if ( 'old-testament' === $by_id[ $parent ]->slug ) {
						$testament = 'ot';
					} elseif ( 'new-testament' === $by_id[ $parent ]->slug ) {
						$testament = 'nt';
					}
					$walk = $by_id[ $parent ];
					++$steps;
				}
				if ( '' === $group ) {
					continue;
				}
				// "Old Testament" and "New Testament" are headings in the Book menu, not books.
				if ( 'book' === $group && in_array( $term->slug, array( 'old-testament', 'new-testament' ), true ) ) {
					continue;
				}
				$index['cats'][ $id ] = array(
					'group'     => $group,
					'name'      => wp_specialchars_decode( $term->name, ENT_QUOTES ),
					'slug'      => $term->slug,
					'testament' => $testament,
				);
			}

			// 2. Every published sermon, oldest first, and the categories each one carries.
			$ids = get_posts(
				array(
					'post_type'              => 'post',
					'post_status'            => 'publish',
					'has_password'           => false, // A password-protected sermon is never listed or summarised.
					'posts_per_page'         => 2000,
					'orderby'                => 'date',
					'order'                  => 'ASC',
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'suppress_filters'       => true,
				)
			);
			$ids            = array_map( 'intval', is_array( $ids ) ? $ids : array() );
			$index['total'] = count( $ids );
			$series         = array();
			if ( $ids ) {
				_prime_post_caches( $ids, false, true );
				$links = wp_get_object_terms( $ids, 'category', array( 'fields' => 'all_with_object_id' ) );
				$links = is_array( $links ) ? $links : array();
				foreach ( $ids as $id ) {
					$index['posts'][ $id ] = 0;
				}
				foreach ( $links as $link ) {
					$term_id = (int) $link->term_id;
					$post_id = (int) $link->object_id;
					if ( ! isset( $index['cats'][ $term_id ] ) ) {
						continue;
					}
					$index['used'][ $term_id ] = isset( $index['used'][ $term_id ] ) ? $index['used'][ $term_id ] + 1 : 1;
					if ( 'series' === $index['cats'][ $term_id ]['group'] && ! $index['posts'][ $post_id ] ) {
						$index['posts'][ $post_id ] = $term_id;
					}
				}
				foreach ( $ids as $id ) {
					$term_id = $index['posts'][ $id ];
					if ( ! $term_id ) {
						continue;
					}
					$time  = (int) get_post_time( 'U', false, $id );
					$thumb = (int) get_post_meta( $id, '_thumbnail_id', true );
					if ( ! isset( $series[ $term_id ] ) ) {
						$term               = $by_id[ $term_id ];
						$link               = get_term_link( $term );
						$series[ $term_id ] = array(
							'name'       => $index['cats'][ $term_id ]['name'],
							'slug'       => $term->slug,
							'url'        => is_wp_error( $link ) ? '' : $link,
							'count'      => 0,
							'first'      => $time,
							'last'       => $time,
							'first_post' => $id,
							'img'        => '',
							'img_id'     => 0,
							'desc'       => trim( wp_strip_all_tags( (string) $term->description ) ),
						);
					}
					++$series[ $term_id ]['count'];
					$series[ $term_id ]['last'] = max( $series[ $term_id ]['last'], $time );
					// Stand-in graphic: the first sermon in the series that has one.
					if ( $thumb && ! $series[ $term_id ]['img_id'] ) {
						$series[ $term_id ]['img_id'] = $thumb;
					}
				}
			}
			foreach ( $series as $term_id => $row ) {
				// A graphic chosen on the category itself always wins.
				$own = (int) get_term_meta( $term_id, 'series_graphic', true );
				if ( $own && wp_attachment_is_image( $own ) ) {
					$row['img_id'] = $own;
				}
				if ( $row['img_id'] ) {
					$url        = wp_get_attachment_image_url( $row['img_id'], 'medium_large' );
					$row['img'] = $url ? $url : (string) wp_get_attachment_url( $row['img_id'] );
				}
				$series[ $term_id ] = $row;
			}
			uasort(
				$series,
				function ( $a, $b ) {
					return $b['last'] <=> $a['last'];
				}
			);
			$index['series'] = $series;
		} catch ( \Throwable $e ) {
			$index['error'] = $e->getMessage();
		}
		unset( $GLOBALS['tcc_sermons_building'] );

		if ( empty( $index['error'] ) ) {
			set_transient( $key, $index, 12 * HOUR_IN_SECONDS );
		}
		$memo[ $gen ] = $index;
		return $memo[ $gen ];
	}

	/** Forget the remembered facts, so they are worked out again on the next visit. */
	function tcc_sermons_bump() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		tcc_site_new_gen( 'sermons' );
	}
	add_action(
		'save_post_post',
		function ( $post_id ) {
			if ( ! wp_is_post_revision( $post_id ) && ! wp_is_post_autosave( $post_id ) ) {
				tcc_sermons_bump();
			}
		}
	);
	add_action( 'deleted_post', 'tcc_sermons_bump' );
	add_action( 'created_category', 'tcc_sermons_bump' );
	add_action( 'edited_category', 'tcc_sermons_bump' );
	add_action( 'delete_category', 'tcc_sermons_bump' );
	add_action(
		'set_object_terms',
		function ( $object_id, $terms, $tt_ids, $taxonomy ) {
			if ( 'category' === $taxonomy ) {
				tcc_sermons_bump();
			}
		},
		10,
		4
	);

	/** Is this the Sermons page (the list of posts) or a category page? Only true once WordPress knows. */
	function tcc_sermons_is_list_page() {
		return did_action( 'wp' ) && ! is_admin() && ( is_home() || is_category() );
	}

	/** Is the Divi editor asking for a list to preview? (So its preview can match the website.) */
	function tcc_sermons_is_divi_preview() {
		if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
			return false;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return false !== strpos( $uri, 'divi/v1/loop/' ) || false !== strpos( rawurldecode( $uri ), 'divi/v1/loop/' );
	}

	/** The series category id of the page being shown, or 0 when it is not a series page. */
	function tcc_sermons_current_series() {
		if ( ! did_action( 'wp' ) || ! is_category() ) {
			return 0;
		}
		$term  = get_queried_object();
		$index = tcc_sermons_index();
		$id    = ( $term instanceof WP_Term ) ? (int) $term->term_id : 0;
		return ( $id && isset( $index['cats'][ $id ] ) && 'series' === $index['cats'][ $id ]['group'] ) ? $id : 0;
	}

	/** The id of the "Speaker" category (the parent every speaker is filed under), or 0 if there is none. */
	function tcc_sermons_speaker_root() {
		static $root = 0;
		if ( $root ) {
			return $root;
		}
		$slugs = tcc_sermons_parent_slugs();
		$term  = get_term_by( 'slug', $slugs['speaker'], 'category' );
		$root  = ( $term && 0 === (int) $term->parent ) ? (int) $term->term_id : 0;
		return $root;
	}

	/** Speakers (id => name) with the main speaker first and the rest A to Z. A main speaker not among them is ignored. */
	function tcc_sermons_order_speakers( $names, $main ) {
		$names = (array) $names;
		uasort( $names, 'strnatcasecmp' );
		$main = (int) $main;
		if ( ! isset( $names[ $main ] ) ) {
			return $names;
		}
		return array( $main => $names[ $main ] ) + $names;
	}

	/** "A", "A & B", "A, B & C". $and is " &amp; " when the names are already HTML. */
	function tcc_sermons_join_names( $names, $and = ' & ' ) {
		$names = array_values(
			array_filter(
				array_map( 'strval', (array) $names ),
				function ( $name ) {
					return '' !== trim( $name );
				}
			)
		);
		$last = array_pop( $names );
		if ( null === $last ) {
			return '';
		}
		return $names ? implode( ', ', $names ) . $and . $last : $last;
	}

	/**
	 * The speakers ticked on a sermon, main speaker first: term id => name.
	 * Empty until the sermon has a main speaker saved (the Speakers box or the fill-in does that),
	 * so older sermons keep showing their typed Speaker Name until they are filled in.
	 * Only speakers filed straight under Speaker count (that is how every speaker is filed).
	 */
	function tcc_sermons_speaker_list( $post_id ) {
		$main = (int) get_post_meta( $post_id, '_tcc_main_speaker', true );
		$root = tcc_sermons_speaker_root();
		if ( ! $main || ! $root ) {
			return array();
		}
		$names = array();
		$terms = get_the_terms( $post_id, 'category' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( (int) $term->parent === $root ) {
					$names[ (int) $term->term_id ] = wp_specialchars_decode( $term->name, ENT_QUOTES );
				}
			}
		}
		return $names ? tcc_sermons_order_speakers( $names, $main ) : array();
	}

	/**
	 * The speaker line of one sermon, for example "Tyler Lynde & Amy Lynde":
	 * the speakers ticked in the Speakers box (main speaker first), else the Speaker Name field,
	 * else the Speaker category, else the author.
	 */
	function tcc_sermons_speaker( $post_id ) {
		$list = tcc_sermons_speaker_list( $post_id );
		if ( $list ) {
			return tcc_sermons_join_names( $list );
		}
		$name = trim( (string) get_post_meta( $post_id, 'speaker_name', true ) );
		if ( '' !== $name ) {
			return $name;
		}
		$index = tcc_sermons_index();
		$terms = get_the_terms( $post_id, 'category' );
		$names = array();
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( isset( $index['cats'][ $id ] ) && 'speaker' === $index['cats'][ $id ]['group'] ) {
					$names[] = $index['cats'][ $id ]['name'];
				}
			}
		}
		if ( $names ) {
			// Every Speaker category, so the card names everyone the Speaker filter finds it under (since 0.14.4).
			return tcc_sermons_join_names( $names );
		}
		$post = get_post( $post_id );
		return $post ? trim( (string) get_the_author_meta( 'display_name', (int) $post->post_author ) ) : '';
	}

	/** One sermon's facts, grouped: array( series => [slug => name], speaker => ..., book => ..., topic => ... ). */
	function tcc_sermons_facts( $post_id ) {
		$facts = array(
			'series'  => array(),
			'speaker' => array(),
			'book'    => array(),
			'topic'   => array(),
		);
		$index = tcc_sermons_index();
		$terms = get_the_terms( $post_id, 'category' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$id = (int) $term->term_id;
				if ( isset( $index['cats'][ $id ] ) ) {
					$facts[ $index['cats'][ $id ]['group'] ][ $index['cats'][ $id ]['slug'] ] = $index['cats'][ $id ]['name'];
				}
			}
		}
		// Keep to the one series the rest of the page uses for this sermon.
		$series_id = isset( $index['posts'][ $post_id ] ) ? (int) $index['posts'][ $post_id ] : 0;
		if ( $series_id && isset( $index['cats'][ $series_id ] ) ) {
			$facts['series'] = array( $index['cats'][ $series_id ]['slug'] => $index['cats'][ $series_id ]['name'] );
		}
		return $facts;
	}
}
