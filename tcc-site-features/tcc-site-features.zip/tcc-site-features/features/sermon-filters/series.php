<?php
/**
 * TCC Sermons page: the series lists, the series pictures and the series pages.
 *
 * Part: the series lists, series pictures and series pages
 *
 * What is in this part:
 *  - "Sermon series - newest first (automatic)", the list Divi loops over for the series cards, and
 *    what Divi can read on a series category (its picture, and "27 sermons - 2025 to 2026");
 *  - the smaller copy of a series graphic on the Sermons page and category pages;
 *  - a sermon with no graphic borrows its series graphic, or else the church's default graphic;
 *  - "Sermons in this series - oldest first (automatic)", the list on a series page;
 *  - the "Sermon series page" layout, shown on every series page without anyone assigning it;
 *  - the short codes at the top of a series page: [tcc_series_graphic], [tcc_series_facts] and
 *    [tcc_series_start].
 *
 * Part of the "Sermons page: search, filters and series" feature (features/sermon-filters.php loads
 * it, after facts.php in this folder, whose facts it reads).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_sermons_series_terms' ) ) {

	/* ------------------------------------------------------------------------------------------
	 * The list Divi loops over for series cards.
	 * ---------------------------------------------------------------------------------------- */

	function tcc_sermons_register_source() {
		register_taxonomy(
			tcc_sermons_series_source(),
			'post',
			array(
				'labels'             => array(
					'name'          => 'Sermon series - newest first (automatic)',
					'singular_name' => 'Sermon series - newest first (automatic)',
				),
				'public'             => true,
				'publicly_queryable' => true,
				'hierarchical'       => false,
				'show_ui'            => false,
				'show_in_menu'       => false,
				'show_in_nav_menus'  => false,
				'show_tagcloud'      => false,
				'show_in_quick_edit' => false,
				'show_admin_column'  => false,
				'show_in_rest'       => false,
				'rewrite'            => false,
				'query_var'          => false,
			)
		);
	}
	add_action( 'init', 'tcc_sermons_register_source', 30 );

	add_filter(
		'wpseo_sitemap_exclude_taxonomy',
		function ( $excluded, $taxonomy ) {
			return tcc_sermons_series_source() === $taxonomy ? true : $excluded;
		},
		10,
		2
	);

	/**
	 * Answers Divi's request for the "Sermon series" list with the real series categories.
	 * On a series page the series being shown is left out, so "More series" never repeats it.
	 */
	function tcc_sermons_series_terms( $terms, $query ) {
		try {
			if ( ! ( $query instanceof WP_Term_Query ) ) {
				return $terms;
			}
			$vars = $query->query_vars;
			$tax  = isset( $vars['taxonomy'] ) ? array_values( (array) $vars['taxonomy'] ) : array();
			if ( array( tcc_sermons_series_source() ) !== $tax ) {
				return $terms;
			}
			// A question about one sermon's terms is not a request for the list.
			if ( ! empty( $vars['object_ids'] ) ) {
				return 'count' === ( isset( $vars['fields'] ) ? $vars['fields'] : '' ) ? 0 : array();
			}
			$index = tcc_sermons_index();
			$ids   = array_keys( $index['series'] );
			$skip  = tcc_sermons_current_series();
			if ( $skip ) {
				$ids = array_values( array_diff( $ids, array( $skip ) ) );
			}
			if ( ! empty( $vars['include'] ) ) {
				$ids = array_values( array_intersect( $ids, array_map( 'intval', (array) $vars['include'] ) ) );
			}
			if ( ! empty( $vars['exclude'] ) ) {
				$ids = array_values( array_diff( $ids, array_map( 'intval', (array) $vars['exclude'] ) ) );
			}
			$fields = isset( $vars['fields'] ) ? $vars['fields'] : 'all';
			if ( 'count' === $fields ) {
				return count( $ids );
			}
			$offset = isset( $vars['offset'] ) ? max( 0, (int) $vars['offset'] ) : 0;
			$number = isset( $vars['number'] ) ? (int) $vars['number'] : 0;
			if ( $offset || $number > 0 ) {
				$ids = array_slice( $ids, $offset, $number > 0 ? $number : null );
			}
			if ( 'ids' === $fields ) {
				return $ids;
			}
			$out = array();
			foreach ( $ids as $id ) {
				$term = get_term( $id, 'category' );
				if ( ! ( $term instanceof WP_Term ) ) {
					continue;
				}
				if ( 'names' === $fields ) {
					$out[] = $term->name;
				} elseif ( 'id=>name' === $fields ) {
					$out[ $id ] = $term->name;
				} elseif ( 'id=>slug' === $fields ) {
					$out[ $id ] = $term->slug;
				} elseif ( 'slugs' === $fields ) {
					$out[] = $term->slug;
				} else {
					$out[] = $term;
				}
			}
			return $out;
		} catch ( \Throwable $e ) {
			return $terms;
		}
	}
	add_filter( 'terms_pre_query', 'tcc_sermons_series_terms', 10, 2 );

	/**
	 * What Divi can read on a series category:
	 *   "Category Image"     the series graphic (its own, or the stand-in). This is what the cards use.
	 *   and two made-up fields for "Loop Term Custom Field":
	 *   tcc_series_summary  "27 sermons - 2025 to 2026"
	 *   tcc_series_image    the address of the series graphic (not used by the cards any more; kept for other layouts)
	 */
	function tcc_sermons_term_fields( $value, $term_id, $meta_key ) {
		if ( 'tcc_series_image' !== $meta_key && 'tcc_series_summary' !== $meta_key && 'thumbnail_id' !== $meta_key ) {
			return $value;
		}
		if ( ! empty( $GLOBALS['tcc_sermons_building'] ) ) {
			return $value;
		}
		$index = tcc_sermons_index();
		$row   = isset( $index['series'][ (int) $term_id ] ) ? $index['series'][ (int) $term_id ] : null;
		if ( 'thumbnail_id' === $meta_key ) {
			// Divi's "Category Image" reads this. Only series categories are given one.
			return ( $row && $row['img_id'] ) ? array( (int) $row['img_id'] ) : $value;
		}
		if ( ! $row ) {
			return array( '' );
		}
		return array( 'tcc_series_image' === $meta_key ? $row['img'] : tcc_sermons_series_summary( $row, false ) );
	}
	add_filter( 'get_term_metadata', 'tcc_sermons_term_fields', 10, 3 );

	/**
	 * The series cards use Divi's own "Category Image" for their picture, because that is the one
	 * picture setting the Divi editor can preview card by card. Divi always uses the full-size
	 * file, though (a series graphic can be several hundred kB, or more if a large PNG is uploaded),
	 * and a card is never wider than about 430 pixels. So on the Sermons page and category pages,
	 * when the address of a series graphic's full-size file is asked for, the 768-pixel-wide copy
	 * is given instead. Nothing else on those pages uses the full-size file of a series graphic:
	 * the large picture at the top of a series page and the sermon cards ask for a named size, and
	 * those requests are left alone (see tcc_sermons_sized_request below).
	 */
	/** True for a series graphic on the Sermons page or a category page (where the swap applies). */
	function tcc_sermons_is_series_graphic_here( $attachment_id ) {
		static $ids = null;
		if ( ! empty( $GLOBALS['tcc_sermons_building'] ) || ! tcc_sermons_is_list_page() ) {
			return false;
		}
		if ( null === $ids ) {
			$ids   = array();
			$index = tcc_sermons_index();
			foreach ( $index['series'] as $row ) {
				if ( ! empty( $row['img_id'] ) ) {
					$ids[ (int) $row['img_id'] ] = true;
				}
			}
		}
		return ! empty( $ids[ (int) $attachment_id ] );
	}

	function tcc_sermons_smaller_series_image( $url, $attachment_id ) {
		// While WordPress works out a named size (see below) it needs the real full-size address.
		if ( ! empty( $GLOBALS['tcc_sermons_real_sizes'] ) || ! tcc_sermons_is_series_graphic_here( $attachment_id ) ) {
			return $url;
		}
		$GLOBALS['tcc_sermons_real_sizes'] = true; // The smaller copy is itself a named size.
		$small                             = wp_get_attachment_image_url( (int) $attachment_id, 'medium_large' );
		$GLOBALS['tcc_sermons_real_sizes'] = false;
		return $small ? $small : $url;
	}
	add_filter( 'wp_get_attachment_url', 'tcc_sermons_smaller_series_image', 10, 2 );

	/**
	 * A named size (thumbnail, large and so on) of a series graphic is worked out from the real file.
	 * WordPress does that by first asking for the full-size address, so for exactly as long as it takes,
	 * the swap above is paused: this works out the size itself with the swap off, and hands back the
	 * answer. Nothing is left behind for a later request (until 0.14.2 a flag was set here and cleared by
	 * whichever full-size request came next).
	 */
	function tcc_sermons_sized_request( $out, $attachment_id, $size ) {
		if ( false !== $out || ! empty( $GLOBALS['tcc_sermons_real_sizes'] ) || ! tcc_sermons_is_series_graphic_here( $attachment_id ) ) {
			return $out;
		}
		$GLOBALS['tcc_sermons_real_sizes'] = true;
		$out                               = image_downsize( (int) $attachment_id, $size );
		$GLOBALS['tcc_sermons_real_sizes'] = false;
		return $out;
	}
	add_filter( 'image_downsize', 'tcc_sermons_sized_request', 9999, 3 );

	/** "27 sermons - 2025 to 2026", or with full dates when $long is true. */
	function tcc_sermons_series_summary( $row, $long ) {
		$count = (int) $row['count'];
		$text  = $count . ( 1 === $count ? ' sermon' : ' sermons' );
		if ( $long ) {
			$from = wp_date( 'F j, Y', $row['first'] );
			$to   = wp_date( 'F j, Y', $row['last'] );
		} else {
			$from = wp_date( 'Y', $row['first'] );
			$to   = wp_date( 'Y', $row['last'] );
		}
		// A real middle dot, not "&middot;": Divi prints custom fields as plain text.
		return $text . " \xC2\xB7 " . ( $from === $to ? $from : $from . ' to ' . $to );
	}

	/* ------------------------------------------------------------------------------------------
	 * A sermon with no graphic borrows its series graphic (Sermons page, category pages and the Divi editor's preview of them).
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The stand-in picture for a sermon that has no graphic and is in no series with one.
	 * It is the default event graphic chosen under Planning Center > Settings > Graphics (the church
	 * logo on soft grey). To use another picture, choose it there.
	 */
	function tcc_sermons_default_graphic() {
		static $id = null;
		if ( null === $id ) {
			$id = tcc_site_default_graphic(); // In the plugin's main file.
		}
		return $id;
	}

	/** The picture to show for a sermon that has none of its own: its series graphic, else the stand-in. 0 for none. */
	function tcc_sermons_stand_in_graphic( $post_id ) {
		$index     = tcc_sermons_index();
		$series_id = isset( $index['posts'][ (int) $post_id ] ) ? (int) $index['posts'][ (int) $post_id ] : 0;
		if ( $series_id && ! empty( $index['series'][ $series_id ]['img_id'] ) ) {
			return (int) $index['series'][ $series_id ]['img_id'];
		}
		return tcc_sermons_default_graphic();
	}

	function tcc_sermons_borrowed_graphic( $value, $post_id, $meta_key ) {
		if ( '_thumbnail_id' !== $meta_key || ! empty( $GLOBALS['tcc_sermons_building'] ) ) {
			return $value;
		}
		// On the Sermons page and category pages, and in the Divi editor's preview of those lists.
		if ( ! tcc_sermons_is_list_page() && ! tcc_sermons_is_divi_preview() ) {
			return $value;
		}
		static $busy = false;
		if ( $busy || 'post' !== get_post_type( $post_id ) ) {
			return $value;
		}
		$busy = true;
		$own  = (int) get_post_meta( $post_id, '_thumbnail_id', true );
		$busy = false;
		if ( $own ) {
			return $value;
		}
		$stand_in = tcc_sermons_stand_in_graphic( $post_id );
		return $stand_in ? array( $stand_in ) : $value;
	}
	add_filter( 'get_post_metadata', 'tcc_sermons_borrowed_graphic', 10, 3 );

	/* ------------------------------------------------------------------------------------------
	 * The list Divi loops over on a series page: that series' sermons, oldest first.
	 * ---------------------------------------------------------------------------------------- */

	function tcc_sermons_parts_source() {
		return 'tcc_series_parts';
	}

	// An automatic list for Divi loops (tcc_site_loop_source() is in the plugin's main file).
	add_action(
		'init',
		function () {
			tcc_site_loop_source( tcc_sermons_parts_source(), 'Sermons in this series - oldest first (automatic)', 'tcc_sermons_parts_answer' );
		},
		30
	);

	/** The sermons of one series, oldest first. */
	function tcc_sermons_series_post_ids( $series_id ) {
		$index = tcc_sermons_index();
		$ids   = array();
		foreach ( $index['posts'] as $post_id => $term_id ) {
			if ( (int) $term_id === (int) $series_id ) {
				$ids[] = (int) $post_id;
			}
		}
		return $ids;
	}

	/**
	 * Answers Divi's request for "Sermons in this series" with the sermons of the series being shown.
	 * Anywhere else (the Divi editor, for one) it answers with the newest series, as an example.
	 */
	function tcc_sermons_parts_answer( $name, $query ) {
		$series_id = tcc_sermons_current_series();
		if ( ! $series_id ) {
			$index     = tcc_sermons_index();
			$series_id = (int) key( $index['series'] );
		}
		$all   = $series_id ? tcc_sermons_series_post_ids( $series_id ) : array();
		$count = (int) $query->get( 'posts_per_page' );
		if ( $count < 1 ) {
			$count = 200;
		}
		$offset = max( 0, (int) $query->get( 'offset' ) );
		return array(
			'ids'   => array_slice( $all, $offset, $count ),
			'found' => count( $all ),
			'pages' => (int) ceil( count( $all ) / $count ),
		);
	}

	/* ------------------------------------------------------------------------------------------
	 * Every series page uses the "Sermon series page" layout, without anyone assigning it.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * The Theme Builder body layout that holds [tcc_series_facts], or 0 when there is none.
	 * Found by looking, not by name or number, so renaming the template does not break anything.
	 */
	function tcc_sermons_series_layout_id() {
		// tcc_site_body_layouts() is in the plugin's main file; it remembers the answer for an hour.
		$found = tcc_site_body_layouts( array( 'series' => 'tcc_series_facts' ) );
		return (int) $found['series'];
	}

	/** Shows the series layout on the page of any category filed under "Series". */
	function tcc_sermons_swap_layout( $layouts ) {
		try {
			if ( ! is_array( $layouts ) || ! tcc_sermons_current_series() ) {
				return $layouts;
			}
			return tcc_site_use_body_layout( $layouts, tcc_sermons_series_layout_id() );
		} catch ( \Throwable $e ) {
			return $layouts;
		}
	}
	add_filter( 'et_theme_builder_template_layouts', 'tcc_sermons_swap_layout', 20 );

	/* ------------------------------------------------------------------------------------------
	 * Short codes for the top of a series page.
	 * ---------------------------------------------------------------------------------------- */

	function tcc_series_row() {
		$series_id = tcc_sermons_current_series();
		$index     = tcc_sermons_index();
		return ( $series_id && isset( $index['series'][ $series_id ] ) ) ? $index['series'][ $series_id ] : null;
	}

	function tcc_series_graphic_shortcode() {
		try {
			$row = tcc_series_row();
			if ( ! $row || ! $row['img_id'] ) {
				return '';
			}
			return wp_get_attachment_image(
				$row['img_id'],
				'large',
				false,
				array(
					'class'   => 'tcc-series-graphic',
					'alt'     => $row['name'] . ' sermon series',
					'loading' => 'eager',
					'sizes'   => '(max-width: 980px) 90vw, 600px',
				)
			);
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_graphic', 'tcc_series_graphic_shortcode' );

	function tcc_series_facts_shortcode() {
		try {
			$row = tcc_series_row();
			return $row ? esc_html( tcc_sermons_series_summary( $row, true ) ) : '';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_facts', 'tcc_series_facts_shortcode' );

	function tcc_series_start_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'label' => 'Start with part 1' ), $atts, 'tcc_series_start' );
		try {
			$row = tcc_series_row();
			if ( ! $row || ! $row['first_post'] ) {
				return '';
			}
			return '<a class="et_pb_button et_pb_bg_layout_light tcc-series-start" href="' . esc_url( get_permalink( $row['first_post'] ) ) . '">' . esc_html( $atts['label'] ) . '</a>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_start', 'tcc_series_start_shortcode' );
}
