<?php
/**
 * TCC Sermons page: the pieces of the filter bar, and the short codes inside the cards.
 *
 * Part: the filter bar's pieces and the short codes inside the cards
 *
 * What is in this part:
 *  - "Sermon from August 16, 2026" for a sermon with no title;
 *  - tcc_sermons_cards(): one short row per sermon, which the filter bar's script copies the cards
 *    from (remembered with the other facts, and worked out again when a sermon is saved);
 *  - the short codes inside the cards: [tcc_sermon_meta], [tcc_sermon_series], [tcc_sermon_count]
 *    and [tcc_series_toggle];
 *  - the pieces the filter bar is built from: the choices in its menus, the plain list for a browser
 *    with JavaScript switched off, and the script (from features/sermon-filters.js).
 * The [tcc_sermon_filter] short code, which puts the bar together, is in features/sermon-filters.php.
 *
 * Part of the "Sermons page: search, filters and series" feature (features/sermon-filters.php loads
 * it last; it reads the facts in facts.php and the stand-in pictures in series.php, in this folder).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ----------------------------------------------------------------------------------------------
 * The facts about every sermon, for the filter bar.
 * -------------------------------------------------------------------------------------------- */

if ( ! function_exists( 'tcc_sermons_cards' ) ) {

	/** A sermon with no title is shown as "Sermon from August 16, 2026" instead of a blank. */
	function tcc_sermons_title_fallback( $title, $post_id = 0 ) {
		if ( '' !== trim( (string) $title ) || is_admin() || ! $post_id || 'post' !== get_post_type( $post_id ) ) {
			return $title;
		}
		$date = get_the_date( 'F j, Y', $post_id );
		return $date ? 'Sermon from ' . $date : 'Sermon';
	}
	add_filter( 'the_title', 'tcc_sermons_title_fallback', 10, 2 );

	/**
	 * The people named in a Speaker Name field, as key => name. Two or more people typed on one line
	 * ("Tyler Lynde / Amy Lynde", "A | B", "A, B and C") become separate speakers, so the Speaker
	 * menu lists each person once instead of listing the pair as one more "speaker".
	 */
	function tcc_sermons_speaker_names( $speaker ) {
		$out   = array();
		$parts = preg_split( '#\s*(?:/|\||,|&|\band\b)\s*#i', (string) $speaker );
		foreach ( (array) $parts as $part ) {
			$name = trim( (string) $part );
			$key  = sanitize_title( $name );
			if ( '' !== $name && '' !== $key ) {
				$out[ (string) $key ] = $name;
			}
		}
		return $out;
	}

	/**
	 * The people who spoke, as key => name (key = sanitize_title of the name, as the Speaker filter and
	 * links use). Ticked speakers are taken as they are, so a name like "Martin Luther King, Jr." is
	 * never cut into pieces; only a typed line (the Speaker Name field) is split into people.
	 * Since 0.14.4 the same goes for Speaker categories on a sermon with no main speaker chosen, and for
	 * the author's name: each is one person, whatever punctuation it has.
	 */
	function tcc_sermons_speaker_people( $post_id ) {
		$list = tcc_sermons_speaker_list( $post_id );
		if ( ! $list && '' === trim( (string) get_post_meta( $post_id, 'speaker_name', true ) ) ) {
			// No main speaker and nothing typed: the Speaker categories, each a whole name.
			$index = tcc_sermons_index();
			$terms = get_the_terms( $post_id, 'category' );
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$id = (int) $term->term_id;
				if ( isset( $index['cats'][ $id ] ) && 'speaker' === $index['cats'][ $id ]['group'] ) {
					$list[] = $index['cats'][ $id ]['name'];
				}
			}
			if ( ! $list ) {
				$author = tcc_sermons_speaker( $post_id ); // The author's name (nothing else is left).
				$list   = '' !== $author ? array( $author ) : array();
			}
		}
		if ( $list ) {
			$out = array();
			foreach ( $list as $name ) {
				$key = sanitize_title( $name );
				if ( '' !== $key ) {
					$out[ (string) $key ] = $name;
				}
			}
			return $out;
		}
		return tcc_sermons_speaker_names( tcc_sermons_speaker( $post_id ) );
	}

	/**
	 * One short row per published sermon, newest first, remembered with the other facts:
	 *   id, t title, u address, d date as shown, sp speaker line, k speaker keys, kn speaker names, s series key, sn series name,
	 *   b book keys, tp topic keys, i picture address, x the words the search box looks through.
	 * Divi draws only the newest cards itself. The filter bar's script copies that card for every
	 * other sermon from these rows, so the page stays quick to build however many sermons there are.
	 */
	function tcc_sermons_cards() {
		$key    = 'tcc_sermons_cards2_' . tcc_site_gen( 'sermons' );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$index = tcc_sermons_index();
		$ids   = array_reverse( array_keys( $index['posts'] ) );
		$rows  = array();
		$GLOBALS['tcc_sermons_building'] = true;
		try {
			_prime_post_caches( $ids, true, true );
			$thumbs = array();
			foreach ( $ids as $id ) {
				$thumb = (int) get_post_meta( $id, '_thumbnail_id', true );
				if ( ! $thumb ) {
					$thumb = tcc_sermons_stand_in_graphic( $id );
				}
				$thumbs[ $id ] = $thumb;
			}
			$need = array_values( array_unique( array_filter( $thumbs ) ) );
			if ( $need ) {
				_prime_post_caches( $need, false, true );
			}
			foreach ( $ids as $id ) {
				$speaker = tcc_sermons_speaker( $id );
				$who     = tcc_sermons_speaker_people( $id );
				$facts   = tcc_sermons_facts( $id );
				$title   = html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES, 'UTF-8' );
				$words   = array( $title, $speaker, get_post_meta( $id, 'sermon_description_short', true ) );
				foreach ( $facts as $group ) {
					foreach ( $group as $name ) {
						$words[] = $name;
					}
				}
				$text  = strtolower( remove_accents( wp_strip_all_tags( html_entity_decode( implode( ' ', array_filter( array_map( 'strval', $words ) ) ), ENT_QUOTES, 'UTF-8' ) ) ) );
				$text  = trim( preg_replace( '/\s+/', ' ', $text ) );
				$image = '';
				if ( $thumbs[ $id ] ) {
					$image = (string) wp_get_attachment_image_url( $thumbs[ $id ], 'medium_large' );
					if ( '' === $image ) {
						$image = (string) wp_get_attachment_url( $thumbs[ $id ] );
					}
				}
				$rows[] = array(
					'id' => (int) $id,
					't'  => $title,
					'u'  => (string) get_permalink( $id ),
					'd'  => (string) get_the_date( 'M j, Y', $id ),
					'sp' => $speaker,
					'k'  => array_map( 'strval', array_keys( $who ) ),
					'kn' => array_values( $who ),
					's'  => (string) key( $facts['series'] ),
					'sn' => (string) reset( $facts['series'] ),
					'b'  => array_keys( $facts['book'] ),
					'tp' => array_keys( $facts['topic'] ),
					'i'  => $image,
					'x'  => $text,
				);
			}
		} catch ( \Throwable $e ) {
			unset( $GLOBALS['tcc_sermons_building'] );
			return array();
		}
		unset( $GLOBALS['tcc_sermons_building'] );
		set_transient( $key, $rows, 12 * HOUR_IN_SECONDS );
		return $rows;
	}

	/* ------------------------------------------------------------------------------------------
	 * Short codes for the cards.
	 * ---------------------------------------------------------------------------------------- */

	/** "Speaker name - Nov 1, 2026", plus a hidden marker that tells the filter bar which sermon the card is. */
	function tcc_sermon_meta_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id || 'post' !== get_post_type( $id ) ) {
				return '';
			}
			$speaker = tcc_sermons_speaker( $id );
			$date    = get_the_date( 'M j, Y', $id );
			$line    = esc_html( $speaker ) . ( '' !== $speaker && $date ? ' &middot; ' : '' ) . esc_html( (string) $date );
			return $line . '<span class="tcc-sermon-data" hidden data-id="' . (int) $id . '"></span>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_meta', 'tcc_sermon_meta_shortcode' );

	/** The name of the sermon's series, or nothing when it is in no series. */
	function tcc_sermon_series_shortcode() {
		try {
			$id = get_the_ID();
			if ( ! $id ) {
				return '';
			}
			$facts = tcc_sermons_facts( $id );
			return esc_html( (string) reset( $facts['series'] ) );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_series', 'tcc_sermon_series_shortcode' );

	/** How many sermons (or series) there are. */
	function tcc_sermon_count_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'what' => 'sermons' ), $atts, 'tcc_sermon_count' );
		try {
			$index = tcc_sermons_index();
			if ( 'series' === $atts['what'] ) {
				return (string) count( $index['series'] );
			}
			$series_id = tcc_sermons_current_series();
			return (string) ( $series_id ? (int) $index['series'][ $series_id ]['count'] : (int) $index['total'] );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_sermon_count', 'tcc_sermon_count_shortcode' );

	/** The "See all 19 series" button. The script that makes it work is at the end of features/sermon-filters.php. */
	function tcc_series_toggle_shortcode() {
		try {
			$index = tcc_sermons_index();
			$count = count( $index['series'] );
			if ( $count <= 4 ) {
				return '';
			}
			return '<button type="button" class="tcc-series-toggle" aria-expanded="false" data-more="See all ' . (int) $count . ' series" data-less="Show fewer series">See all ' . (int) $count . ' series</button>';
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_series_toggle', 'tcc_series_toggle_shortcode' );

	/* ------------------------------------------------------------------------------------------
	 * The pieces of the search and filter bar. The bar itself is [tcc_sermon_filter], in
	 * features/sermon-filters.php.
	 * ---------------------------------------------------------------------------------------- */

	/** The choices for the Speaker, Book and Topic menus: only ones that at least one sermon carries. */
	function tcc_sermon_filter_choices() {
		$index   = tcc_sermons_index();
		$choices = array(
			'speaker' => array(),
			'topic'   => array(),
			'ot'      => array(),
			'nt'      => array(),
			'book'    => array(),
		);
		foreach ( $index['cats'] as $id => $cat ) {
			if ( empty( $index['used'][ $id ] ) || 'series' === $cat['group'] ) {
				continue;
			}
			if ( 'book' === $cat['group'] ) {
				$choices[ $cat['testament'] ? $cat['testament'] : 'book' ][ $cat['slug'] ] = $cat['name'];
			} else {
				$choices[ $cat['group'] ][ $cat['slug'] ] = $cat['name'];
			}
		}
		// Speakers named only in the Speaker Name field or as the author are found from the cards by the script.
		natcasesort( $choices['speaker'] );
		natcasesort( $choices['topic'] );
		$order = tcc_sermons_bible_order();
		foreach ( array( 'ot', 'nt', 'book' ) as $part ) {
			uasort(
				$choices[ $part ],
				function ( $a, $b ) use ( $order ) {
					$x = isset( $order[ strtolower( $a ) ] ) ? $order[ strtolower( $a ) ] : 999;
					$y = isset( $order[ strtolower( $b ) ] ) ? $order[ strtolower( $b ) ] : 999;
					return $x === $y ? strcasecmp( $a, $b ) : $x <=> $y;
				}
			);
		}
		return $choices;
	}

	function tcc_sermon_filter_options( $list ) {
		$html = '';
		foreach ( $list as $slug => $name ) {
			$html .= '<option value="' . esc_attr( $slug ) . '">' . esc_html( $name ) . '</option>';
		}
		return $html;
	}

	/**
	 * For a visitor whose browser has JavaScript switched off: a note, and a plain list of every sermon
	 * that opens with one press. Browsers with JavaScript on never show it.
	 */
	function tcc_sermons_plain_list() {
		$rows = tcc_sermons_cards();
		$html = '<div class="tcc-sf-nojs"><p>The cards below are the newest sermons. Searching and filtering need JavaScript, which is switched off in this browser. Every sermon is in the list here, newest first, and each series above has its own page.</p>';
		if ( $rows ) {
			$html .= '<details><summary>See all ' . count( $rows ) . ' sermons as a plain list</summary><ul>';
			foreach ( $rows as $row ) {
				$line  = $row['sp'] . ( '' !== $row['sp'] && '' !== $row['d'] ? " \xC2\xB7 " : '' ) . $row['d'];
				$html .= '<li><a href="' . esc_url( $row['u'] ) . '">' . esc_html( $row['t'] ) . '</a> <span>' . esc_html( $line ) . '</span></li>';
			}
			$html .= '</ul></details>';
		}
		return $html . '</div>';
	}

	/**
	 * The filter bar's script.
	 *
	 * Divi draws the newest cards. For every other sermon this script makes a copy of the first card
	 * and fills in that sermon's picture, speaker, date, title and series, so a change to the card in
	 * Divi is picked up by every card. Then it only shows and hides cards; nothing is asked of the server.
	 *
	 * The script itself is in features/sermon-filters.js. It reads the sermons from the two data
	 * blocks the filter bar prints (tcc-sf-cards and tcc-sf-series-data), so it needs nothing from PHP.
	 * The "\n" after it is the line break the file's last line had.
	 */
	function tcc_sermon_filter_script() {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;
		?>
<script id="tcc-sermon-filter-js">
<?php echo tcc_site_asset( 'features/sermon-filters.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
		<?php
	}
}
