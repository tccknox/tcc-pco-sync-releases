(function () {
	try {
		if (window.ET_Builder || !window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) { return; }
		var IDLE_MS = 200;   // mouse paused on the way to the panel (450 until 0.14.0)
		var TRAIL_MS = 150;  // how far back to look when working out which way the mouse is moving
		var SIDE_MIN = 5;    // the mouse must have moved at least this far sideways (px) in that time to count as moving along the menu
		var SIDE_SLOPE = 0.18; // ...and no more than this much downward for each pixel sideways (about 10 degrees); steeper counts as heading for the panel. Raise it and more sloping moves between buttons switch at once, but long diagonals to a far card start switching panels too (at 0.25 that happened at 1920 wide)
		var GRACE_MS = 150;  // mouse wandered away from the menu (500 until 0.14.0)
		var MARGIN = 20;     // forgiving border (px) beside and above the button and panel where the menu simply stays open (70 until 0.14.0)
		var MARGIN_BELOW = 8; // much smaller border under the panel, so moving down off the cards closes the menu (16 until 0.14.0)
		var SYN = '__tccMenuSynthetic';
		var aim = null;
		var last = { x: 0, y: 0 };
		var seen = false;
		var trail = [];      // where the mouse has been in the last TRAIL_MS

		function header() { return document.querySelector('.et-l--header'); }

		function dropOf(t) {
			if (!t || !t.children) { return null; }
			for (var i = 0; i < t.children.length; i++) {
				var c = t.children[i];
				if (c.classList && c.classList.contains('et_pb_dropdown') && c.getAttribute('data-show-dropdown-on') === 'hover') { return c; }
			}
			return null;
		}

		function trigOf(el) {
			var h = header();
			if (!h) { return null; }
			for (var n = el; n && n.nodeType === 1; n = n.parentNode) {
				if (dropOf(n) && h.contains(n)) { return n; }
			}
			return null;
		}

		function isOpen(t) {
			var d = dropOf(t);
			return !!d && !d.classList.contains('et_pb_dropdown_hidden');
		}

		function fire(t, type) {
			var e = new MouseEvent(type, { bubbles: false, cancelable: false, relatedTarget: document.body, clientX: last.x, clientY: last.y });
			e[SYN] = true;
			t.dispatchEvent(e);
		}

		function clearAim() {
			if (!aim) { return; }
			clearTimeout(aim.idle);
			clearTimeout(aim.grace);
			aim = null;
		}

		// Is the mouse inside the cone that runs from where it left the button to the top edge of the panel?
		function heading(p, a, d) {
			var r = d.getBoundingClientRect();
			if (a.y >= r.top || p.y >= r.top || p.y < a.y - 3) { return false; }
			var t = (p.y - a.y) / (r.top - a.y);
			var lx = a.x + (r.left - 20 - a.x) * t - 14;
			var rx = a.x + (r.right + 20 - a.x) * t + 14;
			return p.x >= lx && p.x <= rx;
		}

		// Is the mouse moving along the menu (sideways or upward) rather than down toward the panel?
		function sideways() {
			if (!trail.length) { return false; }
			var dx = Math.abs(last.x - trail[0].x);
			var dy = last.y - trail[0].y;
			return dx >= SIDE_MIN && dy <= dx * SIDE_SLOPE;
		}

		// Is the mouse within the forgiving border around the button and its panel?
		function nearby(p, t1, d) {
			var a = t1.getBoundingClientRect();
			var b = d.getBoundingClientRect();
			return p.x >= Math.min(a.left, b.left) - MARGIN && p.x <= Math.max(a.right, b.right) + MARGIN &&
				p.y >= Math.min(a.top, b.top) - MARGIN && p.y <= Math.max(a.bottom, b.bottom) + MARGIN_BELOW;
		}

		function finish() {
			if (!aim) { return; }
			var t1 = aim.t;
			var el = document.elementFromPoint(last.x, last.y);
			var t2 = el ? trigOf(el) : null;
			var d = dropOf(t1);
			if (el && t1.contains(el)) { clearAim(); return; }
			if (!(t2 && t2 !== t1) && d && isOpen(t1) && nearby(last, t1, d)) {
				clearTimeout(aim.idle); clearTimeout(aim.grace); aim.idle = 0; aim.grace = 0;
				return;
			}
			clearAim();
			fire(t1, 'mouseleave');
			if (t2 && t2 !== t1) { fire(t2, 'mouseenter'); }
		}

		function evaluate() {
			if (!aim) { return; }
			var t1 = aim.t;
			var el = document.elementFromPoint(last.x, last.y);
			if (el && t1.contains(el)) { clearAim(); return; }
			var d = dropOf(t1);
			if (!d || !isOpen(t1)) { clearAim(); return; }
			if (heading(last, aim.apex, d)) {
				// On another menu button and moving along the menu: switch to that button's panel at once.
				var over = el ? trigOf(el) : null;
				if (over && over !== t1 && sideways()) { finish(); return; }
				clearTimeout(aim.idle);
				aim.idle = setTimeout(finish, IDLE_MS);
				return;
			}
			var t2 = el ? trigOf(el) : null;
			if (t2 && t2 !== t1) { finish(); return; }
			clearTimeout(aim.idle);
			if (nearby(last, t1, d)) { clearTimeout(aim.grace); aim.grace = 0; return; }
			if (!aim.grace) { aim.grace = setTimeout(finish, GRACE_MS); }
		}

		document.addEventListener('mouseleave', function (e) {
			if (e[SYN] || !e.relatedTarget || !e.target || e.target.nodeType !== 1) { return; }
			var t = trigOf(e.target);
			if (!t || t.contains(e.relatedTarget)) { return; }
			if (e.target !== t && e.target.parentNode !== t) { return; }
			if (!isOpen(t)) { return; }
			e.stopImmediatePropagation();
			// The cone starts at the last spot the mouse was seen inside the menu item.
			var from = seen ? { x: last.x, y: last.y } : { x: e.clientX, y: e.clientY };
			last = { x: e.clientX, y: e.clientY };
			if (!aim || aim.t !== t) {
				clearAim();
				aim = { t: t, apex: from, idle: 0, grace: 0 };
			}
			evaluate();
		}, true);

		document.addEventListener('mouseenter', function (e) {
			if (e[SYN] || !aim || !e.target || e.target.nodeType !== 1) { return; }
			if (dropOf(e.target) && e.target !== aim.t && trigOf(e.target) === e.target) {
				e.stopImmediatePropagation();
				last = { x: e.clientX, y: e.clientY };
				evaluate();
			}
		}, true);

		document.addEventListener('mousemove', function (e) {
			last = { x: e.clientX, y: e.clientY };
			seen = true;
			var now = Date.now();
			trail.push({ x: last.x, y: last.y, t: now });
			while (trail.length > 1 && now - trail[0].t > TRAIL_MS) { trail.shift(); }
			if (aim) { evaluate(); }
		}, { passive: true, capture: true });
	} catch (err) {}
})();
