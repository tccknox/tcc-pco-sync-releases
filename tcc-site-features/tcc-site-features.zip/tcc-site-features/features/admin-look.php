<?php
/**
 * Feature: the church's logo on the sign-in page and in the admin menu, and a tidier Dashboard.
 *
 * Until November 2026 the plugin "AGCA - Custom Dashboard & Login Page" did these jobs. It was set
 * to do only the handful of things below, so they were moved here and AGCA was switched off.
 *
 *  1. Sign-in page (wp-login.php): the church logo instead of the WordPress logo, linked to the
 *     website's home page; rounded corners on the sign-in box; no "Register" link.
 *  2. Admin menu: the church logo at the top of the left-hand menu (it opens the website in a new
 *     tab), and rounded corners on the small menus that pop out when you point at a menu item.
 *  3. Dashboard: hides the Welcome, Activity, Quick Draft and "WordPress Events and News" boxes,
 *     and the grey "Help" tab at the top right of admin screens.
 *
 * Visitors never see any of this. Switching it off brings back WordPress's own look for these screens.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_admin_look_login_css' ) ) {

	/**
	 * The church logo picture (it has its own white background). It is in the Media Library;
	 * to use another picture, change this address.
	 */
	function tcc_admin_look_logo_url() {
		return content_url( '/uploads/2022/05/Trinity-Community-Church-Logo-with-white-background-1.svg' );
	}

	/** 1. The sign-in page: the logo, and rounded corners on the box. */
	function tcc_admin_look_login_css() {
		$logo = esc_url( tcc_admin_look_logo_url() );
		echo '<style id="tcc-admin-look-login">'
			. '#login h1 a,.login h1 a{background-image:url("' . $logo . '");background-size:300px 113px;background-position:center;width:300px;height:113px;margin:0 auto 24px;}'
			. '.login form{border-radius:20px;}'
			. '</style>';
	}
	add_action( 'login_enqueue_scripts', 'tcc_admin_look_login_css' );

	/** The logo on the sign-in page goes to the website, and its hidden text says the church's name. */
	add_filter(
		'login_headerurl',
		function () {
			return home_url( '/' );
		}
	);
	add_filter(
		'login_headertext',
		function () {
			return get_bloginfo( 'name' );
		}
	);

	/** No "Register" link under the sign-in box (only shown at all when anyone can register). */
	add_filter( 'register', '__return_empty_string' );

	/** 2. and 3. Styles for the admin screens: the menu logo, the pop-out menus and the Help tab. */
	function tcc_admin_look_admin_css() {
		echo '<style id="tcc-admin-look">'
			// The logo at the top of the left-hand menu. Hidden when the menu is folded to icons, and on
			// phones, where the menu slides out under the black bar at the top and the logo would be cut off.
			. '#tcc-admin-logo{display:block;margin:0 0 -4px;line-height:0;}'
			. '#tcc-admin-logo img{width:160px;height:auto;display:block;}'
			. '.folded #tcc-admin-logo{display:none;}'
			. '@media (max-width:960px){.auto-fold #tcc-admin-logo{display:none;}}'
			// The small menus that pop out when you point at a menu item.
			. '#adminmenu .wp-submenu{border-radius:15px;}'
			. '#adminmenu .wp-has-current-submenu .wp-submenu,#adminmenu .wp-menu-open .wp-submenu{border-radius:0;}'
			. '.folded #adminmenu .wp-has-current-submenu .wp-submenu{border-radius:15px;}'
			// The grey "Help" tab at the top right.
			. '#contextual-help-link-wrap{display:none !important;}'
			. '</style>';
	}
	add_action( 'admin_head', 'tcc_admin_look_admin_css' );

	/** Puts the logo at the top of the left-hand menu. WordPress has no place for it, so a few lines of script add it. */
	function tcc_admin_look_menu_logo() {
		$link = wp_json_encode( esc_url( home_url( '/' ) ) );
		$logo = wp_json_encode( esc_url( tcc_admin_look_logo_url() ) );
		$name = wp_json_encode( get_bloginfo( 'name' ) );
		echo '<script id="tcc-admin-look-logo">(function(){var wrap=document.getElementById("adminmenuwrap");if(!wrap||document.getElementById("tcc-admin-logo")){return;}'
			. 'var a=document.createElement("a");a.id="tcc-admin-logo";a.href=' . $link . ';a.target="_blank";a.rel="noopener";a.title="Open the website in a new tab";'
			. 'var i=document.createElement("img");i.src=' . $logo . ';i.alt=' . $name . ';i.width=160;a.appendChild(i);wrap.insertBefore(a,wrap.firstChild);})();</script>';
	}
	add_action( 'admin_footer', 'tcc_admin_look_menu_logo' );

	/** 3. The Dashboard boxes nobody here uses. The other boxes can still be hidden or shown under Screen Options. */
	function tcc_admin_look_dashboard() {
		remove_meta_box( 'dashboard_activity', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
		remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
		remove_action( 'welcome_panel', 'wp_welcome_panel' );
	}
	add_action( 'wp_dashboard_setup', 'tcc_admin_look_dashboard', 99 );
}
