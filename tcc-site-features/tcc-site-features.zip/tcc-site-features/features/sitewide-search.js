/* TCC Website Features: the "Show ..." buttons on the search page (sitewide-search.php prints this
   at the end of [tcc_search_results]). Results past the first few of a group are marked
   tcc-s-extra and hidden by the styles while this script runs (class tcc-s-js); without
   JavaScript every result simply shows. A button with data-step="30" shows 30 more at a time;
   any other shows all the rest of its group. */
(function () {
	var w = document.querySelector(".tcc-s-results");
	if (!w) {
		return;
	}
	w.classList.add("tcc-s-js");
	w.addEventListener("click", function (e) {
		var b = e.target.closest ? e.target.closest(".tcc-s-more button") : null;
		if (!b) {
			return;
		}
		var g = b.closest(".tcc-s-group"),
			h = g.querySelectorAll(".tcc-s-extra"),
			n = parseInt(b.getAttribute("data-step"), 10) || h.length,
			f = null;
		/* Show the next results, and remember the first link among them. */
		for (var i = 0; i < h.length && i < n; i++) {
			h[i].classList.remove("tcc-s-extra");
			if (!f) {
				f = h[i].querySelector("a");
			}
		}
		/* Nothing left to show: the button goes. */
		if (h.length <= n) {
			b.remove();
		}
		/* Move to the first newly shown result, for keyboard and screen-reader users. */
		if (f) {
			f.focus();
		}
	});
})();
