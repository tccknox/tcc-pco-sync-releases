<?php
/**
 * TCC: keep commas in a new category's name.
 *
 * The problem this solves: on the edit screen of a sermon (a Post), the Categories box has a
 * "+ Add New Category" link. WordPress treats a comma typed there as "and another one", so
 * typing the series name "Faith, Hope, Love" quietly made three categories called "Faith",
 * "Hope" and "Love" instead of one. That happened in August 2026 and left six stray categories.
 *
 * What this does: when a name typed into that box has a comma in it, the whole name is kept
 * as ONE category, commas included. Nothing else about the box changes: the Parent choice
 * still works, and a name without a comma is handled by WordPress exactly as before.
 *
 * What it gives up: adding several categories at once by separating them with commas. Add
 * them one at a time instead.
 *
 * How: WordPress splits the typed text at commas before it makes the categories. Just before
 * that, the commas are swapped for a stand-in mark, so there is nothing to split on. When the
 * category is about to be saved, the mark is turned back into a comma. If this feature is off
 * or fails, WordPress simply behaves as it always did.
 *
 * It only runs for a signed-in editor pressing "Add New Category". Visitors never touch it.
 *
 * Part of the TCC Website Features plugin. Added 2026-11-21.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_category_commas_hold' ) ) {

	/** The stand-in for a comma. It has no comma in it, and nobody would type it. */
	function tcc_category_commas_mark() {
		return '[[tcc-comma]]';
	}

	/**
	 * Runs just before WordPress handles "Add New Category" on a post's edit screen.
	 * Swaps the commas in the typed name for the stand-in mark.
	 */
	function tcc_category_commas_hold() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WordPress checks the nonce itself straight after this.
		if ( ! isset( $_POST['newcategory'] ) || ! is_string( $_POST['newcategory'] ) ) {
			return;
		}
		if ( false === strpos( $_POST['newcategory'], ',' ) ) {
			return;
		}
		$_POST['newcategory'] = str_replace( ',', tcc_category_commas_mark(), $_POST['newcategory'] );
		// phpcs:enable
		add_filter( 'pre_insert_term', 'tcc_category_commas_restore', 1 );
	}
	add_action( 'wp_ajax_add-category', 'tcc_category_commas_hold', 0 );

	/** Runs as the category is about to be saved: turns the stand-in mark back into a comma. */
	function tcc_category_commas_restore( $name ) {
		if ( is_string( $name ) && false !== strpos( $name, tcc_category_commas_mark() ) ) {
			$name = str_replace( tcc_category_commas_mark(), ',', $name );
			$name = trim( (string) preg_replace( '/\s+/', ' ', $name ) );
		}
		return $name;
	}
}
