<?php
/**
 * TCC page landmarks: tells screen readers where the main part of each page is.
 *
 * The problem this solves: people who cannot see the screen often use a screen reader, which reads
 * the page aloud. It lets them jump straight past the header and menu to the "main" part of the
 * page, but only if the page says which part that is. Divi puts each page's own content in a box
 * called main-content and does not mark it, so there was nothing to jump to. Google's PageSpeed
 * report counts this against the accessibility score ("Document does not have a main landmark").
 *
 * What this does: it adds role="main" to that box (<div id="main-content">) on every page a visitor
 * sees, just before the page is sent. Nothing on the page looks any different. The header and the
 * footer stay outside the box, which is where they belong.
 *
 * It changes nothing when the page already has a main part of its own (a <main> tag or a
 * role="main"), because a page should have only one. It never runs in the admin screens, in the
 * Divi editor, or for feeds and background requests. WP Rocket's saved copies of pages include the
 * change, so signed-out visitors get it too.
 *
 * Part of the TCC Website Features plugin. Added in 0.14.8, November 2026.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_page_landmarks_start' ) ) {

	/**
	 * Given the finished page, adds role="main" to Divi's main-content box.
	 * Only the first such box is changed, and a page that already has a main part is left alone.
	 */
	function tcc_page_landmarks_mark( $html ) {
		if ( ! is_string( $html ) || false === strpos( $html, 'id="main-content"' ) ) {
			return $html;
		}
		if ( preg_match( '/<main[\s>]|\brole=["\']main["\']/i', $html ) ) {
			return $html;
		}
		$marked = preg_replace( '/<div id="main-content"(?=[\s>])/', '<div id="main-content" role="main"', $html, 1 );
		return is_string( $marked ) ? $marked : $html;
	}

	/** Starts watching the page as it is built, on ordinary visitor pages only. */
	function tcc_page_landmarks_start() {
		if ( is_admin() || is_feed() || is_robots() || is_trackback() || wp_doing_ajax() || isset( $_GET['et_fb'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only reads whether the Divi editor is open.
			return;
		}
		if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) ) {
			return;
		}
		ob_start( 'tcc_page_landmarks_mark' );
	}
	add_action( 'template_redirect', 'tcc_page_landmarks_start', 1 );
}
