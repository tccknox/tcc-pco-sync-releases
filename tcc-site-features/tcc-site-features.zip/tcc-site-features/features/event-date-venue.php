<?php
/**
 * TCC event shortcodes for the native Divi event page.
 *
 * [tcc_event_date]                   One line, e.g. "November 29, 2026 10:00 AM - 11:45 AM"
 * [tcc_event_date layout="stacked"]  Date on one line, time on the next
 * [tcc_event_venue]                  Venue name, then its address on the next line
 *
 * Handles normal, recurring, multi-day and all-day events by asking
 * The Events Calendar for the real dates. If The Events Calendar is switched
 * off, or the page is not an event, each shortcode prints nothing instead of
 * causing an error.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 8, "TCC event date and venue shortcodes".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_event_current_id' ) ) {
	/**
	 * The event being viewed (for a recurring event, the occurrence being viewed).
	 */
	function tcc_event_current_id() {
		$id = get_the_ID();
		if ( ! $id ) {
			$id = get_queried_object_id();
		}
		if ( ! $id || ! function_exists( 'tribe_is_event' ) || ! tribe_is_event( $id ) ) {
			return 0;
		}
		return (int) $id;
	}
}

if ( ! function_exists( 'tcc_event_placeholder' ) ) {
	/**
	 * Text shown to editors when there is no event to read from,
	 * such as while editing the template itself. Visitors never see it.
	 */
	function tcc_event_placeholder( $text ) {
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return esc_html( $text );
		}
		return '';
	}
}

if ( ! function_exists( 'tcc_event_date_shortcode' ) ) {
	function tcc_event_date_shortcode( $atts ) {
		$atts = shortcode_atts( array( 'layout' => 'line' ), $atts, 'tcc_event_date' );

		try {
			$id = tcc_event_current_id();
			if ( ! $id || ! function_exists( 'tribe_get_start_date' ) || ! function_exists( 'tribe_get_end_date' ) ) {
				return tcc_event_placeholder( 'Event date and time (filled in automatically)' );
			}

			$date_format = 'F j, Y';
			$time_format = 'g:i A';

			$start_day = (string) tribe_get_start_date( $id, false, $date_format );
			$end_day   = (string) tribe_get_end_date( $id, false, $date_format );
			if ( '' === $start_day ) {
				return '';
			}

			// One day: "November 29, 2026". Several days: "June 23, 2026 - June 25, 2026".
			$days = ( '' !== $end_day && $end_day !== $start_day ) ? $start_day . ' - ' . $end_day : $start_day;

			// All-day events show no times.
			$times   = '';
			$all_day = function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $id );
			if ( ! $all_day ) {
				$start_time = (string) tribe_get_start_date( $id, false, $time_format );
				$end_time   = (string) tribe_get_end_date( $id, false, $time_format );
				$times      = ( '' !== $end_time && $end_time !== $start_time ) ? $start_time . ' - ' . $end_time : $start_time;
			}

			$separator = ( 'stacked' === $atts['layout'] ) ? '<br />' : ' ';

			return esc_html( $days ) . ( '' !== $times ? $separator . esc_html( $times ) : '' );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_date', 'tcc_event_date_shortcode' );
}

if ( ! function_exists( 'tcc_event_venue_shortcode' ) ) {
	function tcc_event_venue_shortcode() {
		try {
			$id = tcc_event_current_id();
			if ( ! $id || ! function_exists( 'tribe_get_venue' ) ) {
				return tcc_event_placeholder( 'Event location (filled in automatically)' );
			}

			$name = trim( (string) tribe_get_venue( $id ) );

			// Street, city, state/province, zip: whichever of these the venue has.
			$parts = array();
			foreach ( array( 'tribe_get_address', 'tribe_get_city' ) as $getter ) {
				if ( function_exists( $getter ) ) {
					$value = trim( (string) call_user_func( $getter, $id ) );
					if ( '' !== $value ) {
						$parts[] = $value;
					}
				}
			}

			$region = function_exists( 'tribe_get_province' ) ? trim( (string) tribe_get_province( $id ) ) : '';
			if ( '' === $region && function_exists( 'tribe_get_stateprovince' ) ) {
				$region = trim( (string) tribe_get_stateprovince( $id ) );
			}
			if ( '' !== $region ) {
				$parts[] = $region;
			}

			if ( function_exists( 'tribe_get_zip' ) ) {
				$zip = trim( (string) tribe_get_zip( $id ) );
				if ( '' !== $zip ) {
					$parts[] = $zip;
				}
			}

			$lines = array();
			if ( '' !== $name ) {
				$lines[] = esc_html( $name );
			}
			if ( ! empty( $parts ) ) {
				$lines[] = esc_html( implode( ', ', $parts ) );
			}

			return implode( '<br />', $lines );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
	add_shortcode( 'tcc_event_venue', 'tcc_event_venue_shortcode' );
}
