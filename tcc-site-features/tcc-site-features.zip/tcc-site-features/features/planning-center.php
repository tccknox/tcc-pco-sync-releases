<?php
/**
 * TCC Website: Planning Center events.
 *
 * Brings events that are published to Church Center in Planning Center Calendar onto the website,
 * after someone approves them. One-way: Planning Center is only ever read, never changed.
 *
 * How it works, in short:
 *  1. Every hour (or when someone presses "Check Planning Center now") it asks Planning Center for upcoming
 *     events that are published to Church Center.
 *  2. New events wait on TCC Website > Planning Center > Waiting for approval. Nothing appears on the
 *     website until someone approves it.
 *  3. Approved events become normal website events. Planning Center owns the title, dates, graphic,
 *     description, registration link, location and rooms. The page body and extra buttons belong to the website.
 *  4. If a Planning Center-owned detail was changed on the website AND in Planning Center, nothing is
 *     overwritten: it goes on the Conflicts tab for a person to decide.
 *
 * The code is in the folder planning-center/:
 *   sync.php     the sync itself (talking to Planning Center, making and updating events, the short codes)
 *   options.php  choices for one event, the default graphic, the Dashboard box
 *   admin.php    the Planning Center screen and the box on each event's edit screen (loaded only in the admin)
 * Its help is the Planning Center group on TCC Website > Features, with the words in help.php.
 *
 * Switching this feature off stops the hourly check (tcc-site-features.php clears it) and hides the
 * Planning Center screen, the Dashboard box and the event box. Events already on the website stay, but
 * their pages lose what Planning Center fills in (description, rooms, Register button), because the short
 * codes below live in sync.php. tcc-site-features.php then registers stand-ins so no short code is ever
 * printed as plain text, and a Register button typed on the event itself still shows. Switching it back on
 * brings everything back.
 *
 * Part of the TCC Website plugin (added in 0.12.0, November 2026).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_planning_center_loaded' ) ) {

	// Another copy of this code (for example an older plugin that was left switched on) would make PHP stop with
	// "Cannot redeclare", which cannot be caught and would take the website down. Refuse to start instead: the loader
	// turns this into "Needs a look" on TCC Website > Features.
	if ( function_exists( 'tcc_pco_settings' ) ) {
		throw new RuntimeException( 'Another copy of the Planning Center code is already running, probably an older plugin. Deactivate and delete it under Plugins; then Planning Center events starts by itself.' );
	}

	if ( ! defined( 'TCC_PCO_VERSION' ) ) {
		define( 'TCC_PCO_VERSION', TCC_SITE_VERSION );
	}
	if ( ! defined( 'TCC_PCO_API' ) ) {
		define( 'TCC_PCO_API', 'https://api.planningcenteronline.com/calendar/v2' );
	}

	/** The Features tab looks for this function to say the feature is working. */
	function tcc_planning_center_loaded() {
		return true;
	}

	// Each runs the saved edit of the file if there is a healthy one, otherwise the original (code-edits.php).
	tcc_code_require( 'tcc-site-features', 'planning-center/options.php' );
	// The screens are only needed inside the admin (their buttons go through admin-post.php, which is the
	// admin too). Visitors, the hourly check and the Divi editor's previews never use them, so since 0.14.1
	// they are not loaded for those: one large file less to read on every page view.
	if ( is_admin() ) {
		tcc_code_require( 'tcc-site-features', 'planning-center/admin.php' );
	}
	tcc_code_require( 'tcc-site-features', 'planning-center/sync.php' );
}
