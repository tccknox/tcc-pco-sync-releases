<?php
/**
 * TCC mega menu: forgiving hover.
 *
 * Divi's dropdown closes (or switches tab) the instant the mouse leaves the
 * menu button. On wide screens the dropdown panel is centred in the window,
 * not under the button, so the mouse has to cross other buttons to reach it.
 *
 * This script keeps the open panel open while the mouse is travelling down
 * toward it. Moving along the menu from one button to the next switches the
 * panel straight away, with no wait (since 0.7.2: before that, a move that
 * drifted a little downward waited about half a second). A panel only waits
 * before switching when the mouse stops on another button on its way down to
 * the panel. It also stays open while the
 * mouse is within a narrow border beside and above the button and the panel
 * (a thinner one underneath), and closes a moment (0.15 seconds) after the mouse
 * moves away. It only affects hover dropdowns in
 * the header, only for mouse users, and never runs inside the Divi builder.
 *
 * The script itself is in menu-hover.js, beside this file. The waits and
 * borders (IDLE_MS, GRACE_MS, MARGIN and the rest) are at its top. In 0.14.0, after
 * the main menu was rebuilt, they were cut to about a third (the menu felt better
 * with this feature off), keeping only the help with reaching a panel that is
 * not under its button, which matters at 1920 wide.
 *
 * To switch it off, use TCC Website > Features: the menu goes back to Divi's
 * normal behaviour.
 *
 * Part of the TCC Website Features plugin. Until 2026-11-20 this was Code Snippets
 * snippet 10, "TCC mega menu forgiving hover".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_mega_menu_hover_script' ) ) {
	function tcc_mega_menu_hover_script() {
		if ( is_admin() || isset( $_GET['et_fb'] ) ) {
			return;
		}
		// The script itself is in menu-hover.js (beside this file). Only the <script> tag is written here.
		?>
<script id="tcc-mega-menu-hover">
<?php echo tcc_site_asset( 'features/menu-hover.js' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the plugin's own script file. ?>
</script>
		<?php
	}
	add_action( 'wp_footer', 'tcc_mega_menu_hover_script', 99 );
}
