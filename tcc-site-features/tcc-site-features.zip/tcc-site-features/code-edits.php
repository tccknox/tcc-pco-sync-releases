<?php
/**
 * TCC code edits: change a plugin's code from the WordPress admin, safely, and put it back.
 *
 * This same file ships in both of the church's plugins (TCC Website Features and TCC Planning
 * Center Sync). The two copies must stay word-for-word identical; whichever plugin loads first
 * sets it up and the other one's copy steps aside.
 *
 * The idea, in short:
 *  1. The code that comes with a plugin (the "original") is never changed from the admin.
 *  2. When someone saves an edit on a plugin's screen in WordPress, the edit is written as a SEPARATE copy in
 *     wp-content/tcc-code-edits/<plugin>/<file>. The plugin then runs that copy instead of its original.
 *  3. "Put the original back" deletes the copy. The plugin runs its original again. Nothing is lost
 *     because the original was never touched.
 *  4. Safety nets:
 *       - an edit with a typing mistake in it (a syntax error) is refused when it is saved;
 *       - an edit that saves but then crashes is switched off by itself on the next page view, and
 *         the file's page says why;
 *       - deleting the folder wp-content/tcc-code-edits puts every original back;
 *       - adding  define( 'TCC_CODE_EDITS_OFF', true );  to wp-config.php ignores every edit.
 *  5. A plugin update replaces the originals, not the edits. An edited file keeps running the
 *     edit, so it does not get that update until the original is put back. The file's page says so.
 *
 * It also builds the "AI prompts": ready-made briefings that explain the website, the plugin and
 * one file to an AI assistant, so someone without access to the church's GitHub can still get
 * good help. Each plugin supplies its own wording (see ai-prompts.php in each plugin).
 *
 * Who can use it: only people who can manage the website's settings (administrators), the same
 * people who can already install plugins and edit snippets.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tcc_code_register' ) ) {

	define( 'TCC_CODE_EDITS_VERSION', '1.0.0' );

	/* -----------------------------------------------------------------------
	 * Where things are kept
	 * --------------------------------------------------------------------- */

	/** The folder that holds every saved edit. It is outside the plugins, so plugin updates leave it alone. */
	function tcc_code_dir() {
		return wp_normalize_path( WP_CONTENT_DIR . '/tcc-code-edits' );
	}

	/** True when wp-config.php says to ignore every edit. */
	function tcc_code_off() {
		return defined( 'TCC_CODE_EDITS_OFF' ) && TCC_CODE_EDITS_OFF;
	}

	/**
	 * The record of saved edits: plugin => file => array( user, time, base_version, base_hash, broken, broken_time ).
	 * WordPress loads this with its other settings, so checking it costs nothing extra per page.
	 */
	function tcc_code_meta() {
		$meta = get_option( 'tcc_code_edits', array() );
		return is_array( $meta ) ? $meta : array();
	}

	function tcc_code_save_meta( $meta ) {
		foreach ( $meta as $slug => $files ) {
			if ( ! $files ) {
				unset( $meta[ $slug ] );
			}
		}
		update_option( 'tcc_code_edits', $meta, true );
	}

	/** The plugins that have signed up, or one of them. */
	function tcc_code_plugins( $slug = null ) {
		$all = isset( $GLOBALS['tcc_code_plugins'] ) && is_array( $GLOBALS['tcc_code_plugins'] ) ? $GLOBALS['tcc_code_plugins'] : array();
		if ( null === $slug ) {
			return $all;
		}
		return isset( $all[ $slug ] ) ? $all[ $slug ] : null;
	}

	/**
	 * A plugin signs up here.
	 *
	 * $args: 'name'    the plugin's name as volunteers know it,
	 *        'menu'    what its screen is called in the left menu,
	 *        'dir'     the plugin's own folder,
	 *        'version' its version,
	 *        'page'    the "page" part of its admin address,
	 *        'tab'     which tab of its screen the code is shown on, and 'tab_label' that tab's name,
	 *        'place'   where that is, in words (for example "TCC Website > Features"),
	 *        'find'    one sentence on how to find a file there,
	 *        'files'   a function that returns file => array( 'label', 'what', 'group' ) for every file that may be edited,
	 *        'extra'   a function that returns file => label for files that are shown to an AI but may not be edited,
	 *        'ai'      a function that returns array( 'plugin' => text, 'files' => array( file => text ) ).
	 */
	function tcc_code_register( $slug, $args ) {
		static $hooked = false;
		$GLOBALS['tcc_code_plugins'][ $slug ] = array_merge(
			array( 'name' => $slug, 'menu' => $slug, 'dir' => '', 'version' => '', 'page' => '', 'tab' => '', 'tab_label' => '', 'place' => '', 'find' => '', 'files' => '', 'extra' => '', 'ai' => '' ),
			(array) $args
		);
		if ( ! $hooked ) {
			$hooked = true;
			register_shutdown_function( 'tcc_code_shutdown' );
		}
	}

	/** The files of a plugin that may be edited: file => array( 'label', 'what', 'group' ). */
	function tcc_code_files( $slug ) {
		$plugin = tcc_code_plugins( $slug );
		if ( ! $plugin || ! is_callable( $plugin['files'] ) ) {
			return array();
		}
		$files = call_user_func( $plugin['files'] );
		return is_array( $files ) ? $files : array();
	}

	function tcc_code_original_path( $slug, $rel ) {
		$plugin = tcc_code_plugins( $slug );
		return $plugin ? wp_normalize_path( trailingslashit( $plugin['dir'] ) . $rel ) : '';
	}

	function tcc_code_edit_path( $slug, $rel ) {
		return tcc_code_dir() . '/' . $slug . '/' . $rel;
	}

	/** Is this file one of the saved edits of this plugin? */
	function tcc_code_is_edit_file( $file, $slug ) {
		return 0 === strpos( wp_normalize_path( (string) $file ), tcc_code_dir() . '/' . $slug . '/' );
	}

	/**
	 * What state a file is in:
	 *   'original'  no edit is saved,
	 *   'edited'    an edit is saved and running,
	 *   'broken'    an edit is saved but was switched off because it caused an error (the original is running),
	 *   'ignored'   an edit is saved but every edit is being ignored (TCC_CODE_EDITS_OFF) or its copy is missing.
	 */
	function tcc_code_state( $slug, $rel ) {
		$meta = tcc_code_meta();
		if ( empty( $meta[ $slug ][ $rel ] ) ) {
			return 'original';
		}
		if ( ! empty( $meta[ $slug ][ $rel ]['broken'] ) ) {
			return 'broken';
		}
		if ( tcc_code_off() || ! is_readable( tcc_code_edit_path( $slug, $rel ) ) ) {
			return 'ignored';
		}
		return 'edited';
	}

	/* -----------------------------------------------------------------------
	 * Loading a file: the edit if there is a healthy one, otherwise the original
	 * --------------------------------------------------------------------- */

	/** The path to load for a file. */
	function tcc_code_path( $slug, $rel ) {
		return 'edited' === tcc_code_state( $slug, $rel ) ? tcc_code_edit_path( $slug, $rel ) : tcc_code_original_path( $slug, $rel );
	}

	/**
	 * Loads a file. If its edit cannot even be read by PHP, the edit is switched off there and then
	 * and the original is loaded instead, so the website carries on.
	 * Returns 'edit' or 'original'. A mistake in the ORIGINAL is passed on to whoever called this.
	 */
	function tcc_code_require( $slug, $rel ) {
		$original = tcc_code_original_path( $slug, $rel );
		$path     = tcc_code_path( $slug, $rel );
		if ( $path !== $original ) {
			try {
				require_once $path;
				return 'edit';
			} catch ( \Throwable $e ) {
				tcc_code_mark_broken( $slug, $rel, $e->getMessage() . ' (line ' . $e->getLine() . ')' );
			}
		}
		require_once $original;
		return 'original';
	}

	/** Switches an edit off and remembers why. The edit itself is kept so it can be looked at and fixed. */
	function tcc_code_mark_broken( $slug, $rel, $message ) {
		$meta = tcc_code_meta();
		if ( empty( $meta[ $slug ][ $rel ] ) || ! empty( $meta[ $slug ][ $rel ]['broken'] ) ) {
			return;
		}
		$message = trim( (string) strtok( (string) $message, "\n" ) );
		$message = str_replace( array( tcc_code_dir() . '/', wp_normalize_path( ABSPATH ) ), '', wp_normalize_path( $message ) );
		$meta[ $slug ][ $rel ]['broken']      = function_exists( 'mb_substr' ) ? mb_substr( $message, 0, 400 ) : substr( $message, 0, 400 );
		$meta[ $slug ][ $rel ]['broken_time'] = time();
		tcc_code_save_meta( $meta );
	}

	/**
	 * Runs as every page view ends. If the page view died of an error that happened inside a saved
	 * edit, that edit is switched off, so the very next page view runs the original again.
	 */
	function tcc_code_shutdown() {
		$error = error_get_last();
		if ( ! is_array( $error ) || empty( $error['type'] ) ) {
			return;
		}
		$fatal = E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR | E_RECOVERABLE_ERROR;
		if ( ! ( (int) $error['type'] & $fatal ) ) {
			return;
		}
		$dir     = tcc_code_dir() . '/';
		$file    = wp_normalize_path( isset( $error['file'] ) ? (string) $error['file'] : '' );
		$message = isset( $error['message'] ) ? (string) $error['message'] : '';
		$trace   = wp_normalize_path( $message );
		if ( 0 !== strpos( $file, $dir ) && false === strpos( $trace, $dir ) ) {
			return;
		}
		try {
			foreach ( tcc_code_meta() as $slug => $files ) {
				foreach ( array_keys( (array) $files ) as $rel ) {
					$edit = tcc_code_edit_path( $slug, $rel );
					if ( $file === $edit || false !== strpos( $trace, $edit ) ) {
						tcc_code_mark_broken( $slug, $rel, $message . ( $file === $edit && ! empty( $error['line'] ) ? ' (line ' . (int) $error['line'] . ')' : '' ) );
					}
				}
			}
		} catch ( \Throwable $e ) {
			// Nothing more can be done from here; the folder can still be deleted by hand.
			return;
		}
	}

	/* -----------------------------------------------------------------------
	 * Saving an edit and putting an original back
	 * --------------------------------------------------------------------- */

	/** A typing mistake that would stop PHP reading the code, in plain words, or '' when there is none. */
	function tcc_code_syntax_error( $code ) {
		if ( ! function_exists( 'token_get_all' ) || ! defined( 'TOKEN_PARSE' ) ) {
			return '';
		}
		try {
			token_get_all( $code, TOKEN_PARSE );
		} catch ( \Throwable $e ) {
			return 'Line ' . $e->getLine() . ': ' . $e->getMessage();
		}
		return '';
	}

	function tcc_code_forget_compiled( $path ) {
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- some hosts restrict this call; the file is still picked up a moment later.
		}
	}

	/** Clears saved copies of whole pages, so a change shows for visitors straight away. */
	function tcc_code_clear_page_caches() {
		try {
			if ( function_exists( 'rocket_clean_domain' ) ) {
				rocket_clean_domain();
			}
			if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
				sg_cachepress_purge_cache();
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Saves an edit. Returns array( 'saved' | 'same' | 'error', message ).
	 * 'same' means the text is identical to the original, so no edit is kept.
	 */
	function tcc_code_save( $slug, $rel, $code ) {
		$files = tcc_code_files( $slug );
		if ( ! isset( $files[ $rel ] ) ) {
			return array( 'error', 'That file cannot be edited here.' );
		}
		$original = @file_get_contents( tcc_code_original_path( $slug, $rel ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $original ) {
			return array( 'error', 'The original file could not be read, so nothing was saved.' );
		}
		$code     = str_replace( array( "\r\n", "\r" ), "\n", (string) $code );
		$original = str_replace( array( "\r\n", "\r" ), "\n", $original );
		if ( '' === trim( $code ) ) {
			return array( 'error', 'The box was empty, so nothing was saved. To go back to the original, press "Put the original back".' );
		}
		if ( strlen( $code ) > 1024 * 1024 ) {
			return array( 'error', 'That is too much text for one file (more than 1 MB), so nothing was saved.' );
		}
		if ( rtrim( $code ) === rtrim( $original ) ) {
			tcc_code_reset( $slug, $rel );
			return array( 'same', '' );
		}
		if ( 0 !== strpos( ltrim( $code ), '<?php' ) ) {
			return array( 'error', 'The code has to start with <?php on its first line, exactly as the original does. Nothing was saved.' );
		}
		if ( ! preg_match( '/defined\s*\(\s*[\'"]ABSPATH[\'"]\s*\)/', $code ) ) {
			return array( 'error', 'The safety lines near the top are missing (the three lines that begin  if ( ! defined( \'ABSPATH\' ) ) ). Copy them from the original and try again. Nothing was saved.' );
		}
		$mistake = tcc_code_syntax_error( $code );
		if ( '' !== $mistake ) {
			return array( 'error', 'There is a typing mistake in the code, so it was not saved and the website is unchanged. ' . $mistake );
		}

		$path = tcc_code_edit_path( $slug, $rel );
		$root = tcc_code_dir();
		if ( ! wp_mkdir_p( dirname( $path ) ) ) {
			return array( 'error', 'The folder for saved edits (wp-content/tcc-code-edits) could not be made. Whoever manages the hosting can check that wp-content can be written to.' );
		}
		// Nobody should be able to open these copies straight from a browser.
		if ( ! file_exists( $root . '/.htaccess' ) ) {
			@file_put_contents( $root . '/.htaccess', "# Saved code edits. Not for visitors.\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $root . '/index.php' ) ) {
			@file_put_contents( $root . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $root . '/READ-ME.txt' ) ) {
			@file_put_contents( $root . '/READ-ME.txt', "This folder holds edits of the church's plugins made inside WordPress (TCC Website > Features, and Planning Center > Settings).\nEach file here is run INSTEAD of the plugin's own file of the same name.\nTo put every original back, delete this whole folder. Nothing else is needed.\n" ); // phpcs:ignore
		}
		if ( false === @file_put_contents( $path, $code, LOCK_EX ) ) { // phpcs:ignore
			return array( 'error', 'The edit could not be written to wp-content/tcc-code-edits. Nothing was changed.' );
		}
		tcc_code_forget_compiled( $path );

		$plugin = tcc_code_plugins( $slug );
		$user   = wp_get_current_user();
		$meta   = tcc_code_meta();
		$meta[ $slug ][ $rel ] = array(
			'user'         => $user && $user->exists() ? $user->display_name : '',
			'time'         => time(),
			'base_version' => (string) $plugin['version'],
			'base_hash'    => md5( $original ),
		);
		tcc_code_save_meta( $meta );
		tcc_code_clear_page_caches();
		return array( 'saved', '' );
	}

	/** Puts one original back: the saved edit is deleted. */
	function tcc_code_reset( $slug, $rel ) {
		$meta = tcc_code_meta();
		$path = tcc_code_edit_path( $slug, $rel );
		if ( isset( $meta[ $slug ][ $rel ] ) || file_exists( $path ) ) {
			if ( file_exists( $path ) ) {
				@unlink( $path ); // phpcs:ignore
				tcc_code_forget_compiled( $path );
			}
			unset( $meta[ $slug ][ $rel ] );
			tcc_code_save_meta( $meta );
			tcc_code_clear_page_caches();
		}
	}

	/** Lets a switched-off edit run again (after its cause was fixed some other way). */
	function tcc_code_retry( $slug, $rel ) {
		$meta = tcc_code_meta();
		if ( isset( $meta[ $slug ][ $rel ] ) ) {
			unset( $meta[ $slug ][ $rel ]['broken'], $meta[ $slug ][ $rel ]['broken_time'] );
			tcc_code_save_meta( $meta );
		}
	}

	/** The text of a file: 'original', 'edit' (or '' when there is none), or 'running' (whichever is in use). */
	function tcc_code_text( $slug, $rel, $which = 'running' ) {
		if ( 'running' === $which ) {
			$path = tcc_code_path( $slug, $rel );
		} elseif ( 'edit' === $which ) {
			$path = tcc_code_edit_path( $slug, $rel );
		} else {
			$path = tcc_code_original_path( $slug, $rel );
		}
		if ( '' === $path || ! is_readable( $path ) ) {
			return '';
		}
		$text = @file_get_contents( $path ); // phpcs:ignore
		return false === $text ? '' : str_replace( array( "\r\n", "\r" ), "\n", $text );
	}

	/* -----------------------------------------------------------------------
	 * The AI prompts
	 * --------------------------------------------------------------------- */

	/** What every AI assistant needs to know about this website before it touches anything. */
	function tcc_code_site_context() {
		$host    = wp_parse_url( home_url(), PHP_URL_HOST );
		$staging = false !== strpos( (string) $host, 'staging' );
		$places  = array();
		foreach ( tcc_code_plugins() as $one ) {
			$places[] = $one['name'] . ': ' . $one['place'] . '. ' . $one['find'];
		}
		$lines   = array(
			'ABOUT THIS WEBSITE',
			'You are helping someone at Trinity Community Church (TCC) in Knoxville, Tennessee look after the church\'s website. The person you are talking to is probably a volunteer and may not be a programmer. Explain things in plain English, say what a visitor would notice, and give exact steps.',
			'',
			'- The live website is https://tccknox.com. The practice copy ("staging") is https://staging13.tccknox.com. This prompt was copied from ' . home_url() . ( $staging ? ' (the staging copy).' : '. If that is the live website, changes are seen by visitors straight away.' ),
			'- It is a WordPress website. Pages and layouts are built in the Divi 5 theme (the Divi builder and Divi > Theme Builder). Events are kept in The Events Calendar plugin. Sermons are ordinary WordPress posts with custom fields and categories. Yoast SEO writes the titles and descriptions search engines see. WP Rocket and the host (SiteGround) keep saved copies of pages to make them fast. Termly shows the cookie banner. The Code Snippets plugin ("Snippets" in the menu) still runs a few older pieces of code.',
			'- The church has two plugins of its own: "TCC Website Features" (menu: TCC Website) holds the small features Divi cannot do by itself; "TCC Planning Center Sync" (menu: Planning Center) copies events from Planning Center Calendar onto the website after someone approves them.',
			'- You are running on PHP ' . PHP_VERSION . ' and WordPress ' . get_bloginfo( 'version' ) . ' here.',
			'',
			'THE CHURCH\'S RULES FOR CHANGES',
			'1. Try every change on the staging copy first. Do not change the live website unless the person says the website owner has agreed.',
			'2. Volunteers maintain this website. Prefer a native Divi setting over code whenever Divi can do the job. If the real fix is a setting, say so and give the clicks, and do not change any code.',
			'3. Keep the church\'s look: flat style, teal #00A4CF accents, neutral greys, subtle motion. Do not restyle things nobody asked about.',
			'4. Older visitors are a real audience: generous click and hover targets, readable text, nothing that needs precise mouse work.',
			'5. Be careful with server load: no call to an outside service for each visitor, no heavy database queries on every page. Remember results (WordPress transients) and filter in the visitor\'s browser where possible.',
			'6. Never ask for, print or store passwords, keys or tokens. The Planning Center Application ID and Secret must never be pasted into a chat.',
			'7. Do not lose work. Say how to undo every change you suggest.',
			'',
			'HOW CODE IS CHANGED ON THIS WEBSITE',
			'- Each plugin shows its own code inside WordPress. ' . implode( ' ', $places ) . ' Opening a file shows its code in a box.',
			'- Saving there does NOT change the plugin\'s own file. The edit is saved as a separate copy (in wp-content/tcc-code-edits) and the plugin runs that copy instead. "Put the original back" deletes the copy, and the plugin runs its own file again.',
			'- Safety nets: an edit with a PHP syntax error is refused when saved. An edit that saves but then causes a fatal error is switched off automatically on the next page view, and the file\'s page shows the error message. Deleting the folder wp-content/tcc-code-edits puts every original back.',
			'- The person will paste your answer over the whole file. So ALWAYS give back the COMPLETE file, from the first line (<?php) to the last, with your change in it. Never give a fragment, never write "the rest stays the same", and never leave anything out.',
			'- An edited file stops receiving plugin updates until its original is put back. So after a change that should be permanent, tell the person to pass the edited file to whoever looks after the church\'s code (the GitHub repository tccknox/tcc-website), so it can be made part of the plugin properly, and then press "Put the original back" once an update includes it.',
			'',
			'HOW THE CODE IS WRITTEN (keep to this)',
			'- Plain PHP in the WordPress style, no build step, no outside libraries. It must run on PHP 7.4 and on PHP 8.',
			'- Keep the lines near the top that begin  if ( ! defined( \'ABSPATH\' ) )  exactly as they are. WordPress refuses to save a file without them.',
			'- Every function name starts with tcc_. In TCC Website Features each feature file wraps its code in  if ( ! function_exists( \'...\' ) ) { ... }  so that two copies can never clash. Keep that wrapper and keep the name of the function it tests.',
			'- Escape everything printed (esc_html, esc_attr, esc_url, wp_kses). Check permissions and nonces on anything that saves.',
			'- A short code or feature that has nothing to show prints nothing. It never prints an error to visitors and never stops the page.',
			'- Comments are written in plain English for volunteers. Keep the big comment at the top of the file true: if you change what the file does, change that comment to match.',
			'- CSS and JavaScript are printed by the PHP file itself (small inline blocks). Keep the class names starting with tcc-.',
			'',
			'THINGS THAT HAVE CAUSED TROUBLE BEFORE',
			'- Divi 5 strips <script> tags out of custom fields shown through Dynamic Content. Use a short code instead.',
			'- A Divi Image module bound to the featured image inside a Divi loop crashes the page (HTTP 500). Use a block with the picture as its background.',
			'- Changes made in the Divi builder only stick when a person really clicks Save. A scripted save does not persist.',
			'- Divi asks for the 1920-pixel-wide file on wide screens however small the picture is shown. Pick a smaller file for small pictures.',
			'- Event pages and other plugin-made pages get extra margins from Divi, so set margins explicitly there.',
			'- The cookie banner (Termly) blocks outside players until a visitor agrees. youtube.com and buzzsprout.com are marked Essential in Termly.',
			'- Divi layers that a feature fills in are labelled "(automatic)" in the builder. Features find layers by CSS ID or class (for example tcc-events, tcc-sermon-card). Renaming or removing one in Divi breaks the feature without any error.',
			'',
			'HOW TO ANSWER',
			'1. First say, in two or three plain sentences, what you think is going on and what you would change. If you are not sure, ask for what you need (a screenshot, the page address, the error message shown on the file\'s page) before writing code.',
			'2. If code has to change, give the complete file as described above, and list in plain words what you changed and why.',
			'3. Give the steps to put it in: open the file in WordPress (where is described above), select everything in the box, paste, press "Save my edit".',
			'4. Give the steps to check it: which pages to open, what should be seen, at a wide screen (1920 and 1440), a tablet (768) and a phone (375). Event pages should be checked as well as ordinary pages. If lists of events changed, check the home page, /events/, a ministry page and the Events menu.',
			'5. Say how to undo it: open the file again and press "Put the original back".',
			'6. Say plainly what you could not check yourself.',
		);
		return implode( "\n", $lines );
	}

	/** The wording a plugin supplies for its prompts: array( 'plugin' => text, 'files' => array( file => text ) ). */
	function tcc_code_ai_notes( $slug ) {
		$plugin = tcc_code_plugins( $slug );
		$notes  = $plugin && is_callable( $plugin['ai'] ) ? call_user_func( $plugin['ai'] ) : array();
		return array(
			'plugin' => isset( $notes['plugin'] ) ? (string) $notes['plugin'] : '',
			'files'  => isset( $notes['files'] ) && is_array( $notes['files'] ) ? $notes['files'] : array(),
		);
	}

	/**
	 * The prompt for a whole plugin ($rel = '') or for one file of it.
	 * It does not include the code itself; the buttons on the screen add that.
	 */
	function tcc_code_prompt( $slug, $rel = '' ) {
		$plugin = tcc_code_plugins( $slug );
		if ( ! $plugin ) {
			return '';
		}
		$notes = tcc_code_ai_notes( $slug );
		$files = tcc_code_files( $slug );
		$out   = array( tcc_code_site_context(), '', 'THE PLUGIN: ' . strtoupper( $plugin['name'] ) . ' (version ' . $plugin['version'] . ', menu: ' . $plugin['menu'] . ')', $notes['plugin'] );

		if ( '' === $rel ) {
			$out[] = '';
			$out[] = 'MY QUESTION';
			$out[] = '(Type here what you want to change or what looks wrong. Say which page, what you expected and what you see. If you can, paste the code of the file it concerns underneath: ' . $plugin['place'] . ', open the file, then "Copy the prompt and the code".)';
			return implode( "\n", $out );
		}

		$label = isset( $files[ $rel ]['label'] ) ? $files[ $rel ]['label'] : $rel;
		$state = tcc_code_state( $slug, $rel );
		$out[] = '';
		$out[] = 'THE FILE THIS IS ABOUT: ' . $rel . ' ("' . $label . '")';
		if ( isset( $notes['files'][ $rel ] ) ) {
			$out[] = (string) $notes['files'][ $rel ];
		}
		if ( 'edited' === $state ) {
			$out[] = 'Note: this file is running an EDITED copy at the moment, not the original that came with the plugin. The code below is the edited copy.';
		} elseif ( 'broken' === $state ) {
			$meta  = tcc_code_meta();
			$out[] = 'Note: an edit of this file was switched off automatically because it caused this error: ' . $meta[ $slug ][ $rel ]['broken'] . ' The original is running in its place. The code below is that switched-off edit, which needs fixing.';
		}
		$out[] = '';
		$out[] = 'MY QUESTION';
		$out[] = '(Type here what you want to change or what looks wrong. Say which page, what you expected and what you see.)';
		return implode( "\n", $out );
	}

	/** Everything in one text file, to attach to an AI chat: the plugin prompt, then every file's code. */
	function tcc_code_pack( $slug ) {
		$plugin = tcc_code_plugins( $slug );
		$out    = tcc_code_prompt( $slug ) . "\n\n" . str_repeat( '=', 78 ) . "\nALL THE CODE OF THIS PLUGIN FOLLOWS, ONE FILE AFTER ANOTHER.\nFiles marked (can be edited in WordPress) are the only ones that can be changed from the WordPress admin.\nThe others are shown so you understand how it fits together; changing those needs the church's GitHub repository.\n" . str_repeat( '=', 78 ) . "\n";
		$notes  = tcc_code_ai_notes( $slug );
		foreach ( tcc_code_files( $slug ) as $rel => $file ) {
			$state = tcc_code_state( $slug, $rel );
			$out  .= "\n\n" . str_repeat( '=', 78 ) . "\nFILE: " . $rel . '  "' . $file['label'] . '"  (can be edited in WordPress' . ( 'edited' === $state ? '; this is an EDITED copy, not the original' : '' ) . ")\n";
			if ( isset( $notes['files'][ $rel ] ) ) {
				$out .= $notes['files'][ $rel ] . "\n";
			}
			$out .= str_repeat( '=', 78 ) . "\n\n" . tcc_code_text( $slug, $rel, 'running' );
		}
		$extra = $plugin && is_callable( $plugin['extra'] ) ? (array) call_user_func( $plugin['extra'] ) : array();
		foreach ( $extra as $rel => $label ) {
			$path = tcc_code_original_path( $slug, $rel );
			if ( is_readable( $path ) ) {
				$out .= "\n\n" . str_repeat( '=', 78 ) . "\nFILE: " . $rel . '  "' . $label . "\"  (shown for understanding; cannot be edited in WordPress)\n" . str_repeat( '=', 78 ) . "\n\n" . str_replace( array( "\r\n", "\r" ), "\n", (string) @file_get_contents( $path ) ); // phpcs:ignore
			}
		}
		return $out;
	}

	/* -----------------------------------------------------------------------
	 * Drawing the code on a plugin's screen
	 * --------------------------------------------------------------------- */

	/** The address of the tab that shows a plugin's code (with a file open when $extra names one). */
	function tcc_code_url( $slug, $extra = array() ) {
		$plugin = tcc_code_plugins( $slug );
		$url = add_query_arg( array_merge( array( 'page' => $plugin ? $plugin['page'] : '', 'tab' => $plugin ? $plugin['tab'] : '' ), $extra ), admin_url( 'admin.php' ) );
		// With no file open, jump down to the panel that lists the code.
		return isset( $extra['file'] ) ? $url : $url . '#tcc-code';
	}

	/** Which plugin's code is on screen: array( slug, file ), or null. */
	function tcc_code_on_screen() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- only chooses what to show.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
		$file = isset( $_GET['file'] ) ? sanitize_text_field( wp_unslash( $_GET['file'] ) ) : '';
		// phpcs:enable
		if ( '' === $page ) {
			return null;
		}
		foreach ( tcc_code_plugins() as $slug => $plugin ) {
			if ( $plugin['page'] === $page && $plugin['tab'] === $tab ) {
				$files = tcc_code_files( $slug );
				return array( $slug, isset( $files[ $file ] ) ? $file : '' );
			}
		}
		return null;
	}

	/** Loads WordPress's own code box (colours and line numbers) when a file is open. */
	function tcc_code_enqueue() {
		$screen = tcc_code_on_screen();
		if ( ! $screen || '' === $screen[1] || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$GLOBALS['tcc_code_editor_settings'] = wp_enqueue_code_editor( array( 'type' => 'application/x-httpd-php' ) );
	}
	add_action( 'admin_enqueue_scripts', 'tcc_code_enqueue' );

	/** Every button to do with code posts here. */
	function tcc_code_handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'You are not allowed to change this.' );
		}
		check_admin_referer( 'tcc_code_do', '_tcc_code_nonce' );
		$op    = isset( $_REQUEST['op'] ) ? sanitize_key( wp_unslash( $_REQUEST['op'] ) ) : '';
		$slug  = isset( $_REQUEST['plugin'] ) ? sanitize_key( wp_unslash( $_REQUEST['plugin'] ) ) : '';
		$rel   = isset( $_REQUEST['file'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['file'] ) ) : '';
		$files = tcc_code_files( $slug );
		if ( ! tcc_code_plugins( $slug ) ) {
			wp_die( 'That plugin is not known.' );
		}

		// One text file with the prompt and all the code, to attach to an AI chat.
		if ( 'pack' === $op ) {
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename="' . $slug . '-for-ai.txt"' );
			echo tcc_code_pack( $slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a plain text download.
			exit;
		}

		if ( 'reset_all' === $op ) {
			$meta = tcc_code_meta();
			foreach ( array_keys( isset( $meta[ $slug ] ) ? (array) $meta[ $slug ] : array() ) as $one ) {
				tcc_code_reset( $slug, $one );
			}
			wp_safe_redirect( tcc_code_url( $slug, array( 'tcc_code_msg' => 'reset_all' ) ) );
			exit;
		}

		if ( ! isset( $files[ $rel ] ) ) {
			wp_safe_redirect( tcc_code_url( $slug ) );
			exit;
		}
		$back = array( 'file' => rawurlencode( $rel ) );

		if ( 'reset' === $op ) {
			tcc_code_reset( $slug, $rel );
			delete_transient( 'tcc_code_draft_' . get_current_user_id() );
			$back['tcc_code_msg'] = 'reset';
		} elseif ( 'retry' === $op ) {
			tcc_code_retry( $slug, $rel );
			$back['tcc_code_msg'] = 'retry';
		} elseif ( 'save' === $op ) {
			// The code is sent in a wrapped form (base64) so that the host's firewall does not mistake it for an attack.
			if ( isset( $_POST['code_b64'] ) && '' !== $_POST['code_b64'] ) {
				$code = base64_decode( preg_replace( '/[^A-Za-z0-9+\/=]/', '', (string) wp_unslash( $_POST['code_b64'] ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$code = false === $code ? '' : $code;
			} else {
				$code = isset( $_POST['code'] ) ? (string) wp_unslash( $_POST['code'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- this is code, checked in tcc_code_save().
			}
			$result = tcc_code_save( $slug, $rel, $code );
			if ( 'error' === $result[0] ) {
				// Keep what was typed, so it is not lost, and show it again with the reason.
				set_transient( 'tcc_code_draft_' . get_current_user_id(), array( 'plugin' => $slug, 'file' => $rel, 'code' => $code, 'error' => $result[1] ), HOUR_IN_SECONDS );
				$back['tcc_code_msg'] = 'error';
			} else {
				delete_transient( 'tcc_code_draft_' . get_current_user_id() );
				$back['tcc_code_msg'] = $result[0];
			}
		}
		wp_safe_redirect( tcc_code_url( $slug, $back ) );
		exit;
	}
	add_action( 'admin_post_tcc_code_do', 'tcc_code_handle' );

	/** A small form with one button. */
	function tcc_code_button( $slug, $op, $label, $rel = '', $class = 'button', $confirm = '' ) {
		$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
		$html .= '<input type="hidden" name="action" value="tcc_code_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '"><input type="hidden" name="plugin" value="' . esc_attr( $slug ) . '"><input type="hidden" name="file" value="' . esc_attr( $rel ) . '">';
		$html .= wp_nonce_field( 'tcc_code_do', '_tcc_code_nonce', true, false );
		$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
		return $html;
	}

	/** The small coloured label for a file's state. */
	function tcc_code_pill( $state ) {
		$map = array(
			'original' => array( 'muted', 'Original' ),
			'edited'   => array( 'warn', 'Edited' ),
			'broken'   => array( 'bad', 'Edit switched off' ),
			'ignored'  => array( 'muted', 'Edit not in use' ),
		);
		$one = isset( $map[ $state ] ) ? $map[ $state ] : $map['original'];
		return '<span class="tcc-pill tcc-pill--' . esc_attr( $one[0] ) . '">' . esc_html( $one[1] ) . '</span>';
	}

	function tcc_code_css() {
		echo '<style>'
			. '.tcc-code-row{display:flex;flex-wrap:wrap;gap:10px 24px;align-items:center}'
			. '.tcc-code-row__text{flex:1 1 380px;min-width:0}'
			. '.tcc-code-row__text p{margin:0 0 4px}'
			. '.tcc-code-row__title{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:0 0 4px}'
			. '.tcc-code-row__title h3{margin:0;font-size:14px}'
			. '.tcc-code-row__do{flex:0 0 190px}'
			. '.tcc-code-row__do .button{width:100%;text-align:center;min-height:38px;line-height:36px}'
			. '.tcc-code-group{font-size:14px;margin:22px 0 10px}'
			. '.tcc-code-box{width:100%;min-height:420px;font-family:Menlo,Consolas,monospace;font-size:13px;line-height:1.5;white-space:pre;overflow:auto;tab-size:4}'
			. '.tcc-code .CodeMirror{height:62vh;min-height:360px;border:1px solid #dcdcde;border-radius:6px;font-size:13px}'
			. '.tcc-code-prompt{width:100%;height:220px;font-size:13px;line-height:1.5;background:#f6f7f7}'
			. '.tcc-code-bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:12px 0 0}'
			. '.tcc-code-bar .button{min-height:38px;line-height:36px}'
			. '.tcc-code-copied{color:#0a6b25;font-weight:600}'
			. '.tcc-code-steps{margin:8px 0 0 20px}.tcc-code-steps li{margin-bottom:6px}'
			. '.tcc-code-note{background:#f6f7f7;border-radius:6px;padding:8px 12px;margin:8px 0 0}'
			. '.tcc-code-note--bad{background:#fbe9e9;color:#8a1f1f}.tcc-code-note--warn{background:#fcf3d7;color:#5c3d00}'
			. '@media(max-width:600px){.tcc-code-row__do{flex:1 1 100%}.tcc-code-bar .button,.tcc-code-bar form{width:100%;text-align:center}.tcc-code-bar form .button{width:100%}}'
			. '</style>';
	}

	/** The copy buttons, and the wrapping of the code before it is sent. Printed once per screen. */
	function tcc_code_js() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done     = true;
		$settings = isset( $GLOBALS['tcc_code_editor_settings'] ) ? $GLOBALS['tcc_code_editor_settings'] : false;
		?>
<script>
(function () {
	var settings = <?php echo wp_json_encode( $settings ); ?>;
	var cm = null, dirty = false, sending = false;
	function box() { return document.getElementById('tcc-code-editor'); }
	function value(id) {
		var el = document.getElementById(id);
		if (!el) { return ''; }
		if (id === 'tcc-code-editor' && cm) { return cm.getValue(); }
		return el.value !== undefined ? el.value : el.textContent;
	}
	function copy(text, button) {
		function done(ok) {
			var note = button.parentNode.querySelector('.tcc-code-copied');
			if (!note) { note = document.createElement('span'); note.className = 'tcc-code-copied'; note.setAttribute('role', 'status'); button.parentNode.appendChild(note); }
			note.textContent = ok ? 'Copied. Now paste it into your AI chat.' : 'Could not copy. Click in the box, select all, and copy by hand.';
			setTimeout(function () { note.textContent = ''; }, 6000);
		}
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); });
			return;
		}
		var ta = document.createElement('textarea');
		ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
		document.body.appendChild(ta); ta.select();
		var ok = false;
		try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
		document.body.removeChild(ta); done(ok);
	}
	document.addEventListener('click', function (e) {
		var b = e.target.closest ? e.target.closest('[data-tcc-copy]') : null;
		if (!b) { return; }
		e.preventDefault();
		var parts = b.getAttribute('data-tcc-copy').split(',');
		var text = value(parts[0]);
		if (parts[1]) {
			text += '\n\n' + new Array(79).join('=') + '\nTHE CODE OF ' + (b.getAttribute('data-tcc-file') || 'THE FILE') + ' AS IT IS NOW\n' + new Array(79).join('=') + '\n\n' + value(parts[1]);
		}
		copy(text, b);
	});
	function wrap(text) {
		var bytes = new TextEncoder().encode(text), out = '', i;
		for (i = 0; i < bytes.length; i += 0x8000) { out += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); }
		return btoa(out);
	}
	window.addEventListener('load', function () {
		var ta = box(), form = document.getElementById('tcc-code-form');
		if (!ta || !form) { return; }
		if (settings && window.wp && wp.codeEditor) {
			try { cm = wp.codeEditor.initialize(ta, settings).codemirror; cm.on('change', function () { dirty = true; }); } catch (e) { cm = null; }
		}
		ta.addEventListener('input', function () { dirty = true; });
		form.addEventListener('submit', function (e) {
			if (!window.confirm('Save this edit? The website starts using it straight away. If it causes an error, it is switched off by itself and the original runs again.')) { e.preventDefault(); return; }
			if (cm) { cm.save(); }
			try {
				form.querySelector('[name=code_b64]').value = wrap(ta.value);
				ta.removeAttribute('name');
			} catch (err) { /* the plain text is sent instead */ }
			sending = true;
		});
		window.addEventListener('beforeunload', function (e) {
			if (dirty && !sending) { e.preventDefault(); e.returnValue = ''; }
		});
	});
})();
</script>
		<?php
	}

	/** The panel that hands the plugin's overall AI prompt to the person. Used under the list of files and on the Help tab. */
	function tcc_code_ai_card( $slug, $heading = 'Ask an AI assistant about this plugin' ) {
		$plugin = tcc_code_plugins( $slug );
		if ( ! $plugin ) {
			return;
		}
		tcc_code_css();
		tcc_code_js();
		$pack = wp_nonce_url( add_query_arg( array( 'action' => 'tcc_code_do', 'op' => 'pack', 'plugin' => $slug ), admin_url( 'admin-post.php' ) ), 'tcc_code_do', '_tcc_code_nonce' );
		echo '<div class="tcc-card" id="tcc-ai"><h2>' . esc_html( $heading ) . '</h2>';
		echo '<p>An AI assistant (Claude, ChatGPT and the like) can explain what this plugin does or help change it, but only if it is told how this website is set up. The box below is that briefing, written for it. It holds no passwords.</p>';
		echo '<ol class="tcc-code-steps">';
		echo '<li>Press <strong>Copy the prompt</strong> and paste it into a new chat with the AI assistant.</li>';
		echo '<li>Under "MY QUESTION" at the end, type what you want to know or change, in your own words.</li>';
		echo '<li>For a question about one feature or file, use the prompt on that file\'s own page instead (<a href="' . esc_url( tcc_code_url( $slug ) ) . '">' . esc_html( $plugin['place'] ) . '</a>, then <em>See or edit the code</em> beside it). It adds what the AI needs to know about that file, and its code.</li>';
		echo '<li>If the AI wants to see everything, press <strong>Download everything for an AI</strong> and attach that file to the chat. It is the prompt plus all of this plugin\'s code in one text file.</li>';
		echo '</ol>';
		echo '<textarea class="tcc-code-prompt" id="tcc-ai-prompt-' . esc_attr( $slug ) . '" readonly aria-label="The prompt for an AI assistant">' . esc_textarea( tcc_code_prompt( $slug ) ) . '</textarea>';
		echo '<div class="tcc-code-bar"><button type="button" class="button button-primary" data-tcc-copy="tcc-ai-prompt-' . esc_attr( $slug ) . '">Copy the prompt</button>';
		echo '<a class="button" href="' . esc_url( $pack ) . '">Download everything for an AI</a></div>';
		echo '<p class="tcc-muted" style="margin-bottom:0">Never paste a password, the Planning Center Application ID or Secret, or anyone\'s personal details into an AI chat. Treat what an AI says as advice: try it on the staging website first.</p>';
		echo '</div>';
	}

	/** The Help tab's panel about changing the code. The same words in both plugins. */
	function tcc_code_help_card( $slug ) {
		$plugin = tcc_code_plugins( $slug );
		if ( ! $plugin ) {
			return;
		}
		$link = '<a href="' . esc_url( tcc_code_url( $slug ) ) . '">' . esc_html( $plugin['place'] ) . '</a>';
		$meta = tcc_code_meta();
		$mine = isset( $meta[ $slug ] ) ? count( (array) $meta[ $slug ] ) : 0;
		echo '<div class="tcc-card" id="tcc-help-code"><h2>Changing the code (when the steps above are not enough)</h2>';
		echo '<p>' . ( $mine ? '<span class="tcc-pill tcc-pill--warn">' . (int) $mine . ' ' . ( 1 === $mine ? 'file is' : 'files are' ) . ' edited</span> ' : '<span class="tcc-pill tcc-pill--ok">Every file is the original</span> ' ) . 'An administrator can see the code behind each piece of this plugin and change it. It is built so that a mistake is easy to undo: the code that came with the plugin (the <strong>original</strong>) is never changed.</p><ol>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<li>Open ' . $link . '. ' . esc_html( $plugin['find'] ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<li>Press <strong>See or edit the code</strong> beside the piece you need. Its page says whether it is the <em>Original</em> or <em>Edited</em>.</li>';
		echo '<li>Change the code in the box, or paste a complete new version over it, and press <strong>Save my edit</strong>. Do this on the staging website first.</li>';
		echo '<li>Open the website and check the pages that use it.</li>';
		echo '<li>To undo it, open the file again and press <strong>Put the original back</strong>.</li>';
		echo '</ol><table>';
		echo '<tr><th>Your edit is a separate copy</th><td>Saving does not touch the plugin\'s own file. Your edit is kept beside it and the website uses your copy instead. Putting the original back simply removes your copy.</td></tr>';
		echo '<tr><th>If an edit has a mistake in it</th><td>A typing mistake is caught when you press Save, and nothing changes. An edit that saves but then causes an error is <strong>switched off by itself</strong> the next time a page opens; the original runs again and the file\'s page shows the error message so it can be fixed.</td></tr>';
		echo '<tr><th>Plugin updates</th><td>An update brings new originals. A file you have edited keeps running your edit, so it misses that update until you put its original back. The file\'s page warns you when that has happened. Tell whoever looks after the church\'s code about any edit that should stay, so it can be made part of the plugin.</td></tr>';
		echo '<tr><th>If the admin screens will not open at all</th><td>Ask whoever manages the hosting to delete the folder <code>wp-content/tcc-code-edits</code> (SiteGround: Site Tools &rarr; Site &rarr; File Manager). That puts every original back. Nothing else is stored there.</td></tr>';
		echo '<tr><th>Who can do this</th><td>Administrators only, the same people who can install plugins.</td></tr>';
		echo '</table></div>';
	}

	/** What just happened (saved, original put back, and so on). Printed once per screen. */
	function tcc_code_notices( $slug ) {
		static $done = array();
		if ( isset( $done[ $slug ] ) ) {
			return;
		}
		$done[ $slug ] = true;
		$msg     = isset( $_GET['tcc_code_msg'] ) ? sanitize_key( wp_unslash( $_GET['tcc_code_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$notices = array(
			'saved'     => array( 'success', 'Your edit is saved and the website is using it now. Open the website and check the pages that use it. If anything looks wrong, press "Put the original back".' ),
			'same'      => array( 'info', 'That is the same as the original, so no edit is kept. The original is running.' ),
			'reset'     => array( 'success', 'The original is back. The edit has been removed.' ),
			'reset_all' => array( 'success', 'Every original is back. All edits of this plugin have been removed.' ),
			'retry'     => array( 'info', 'The edit has been switched back on. Open the website and check it. If it causes the same error it will switch itself off again.' ),
		);
		if ( isset( $notices[ $msg ] ) ) {
			echo '<div class="notice notice-' . esc_attr( $notices[ $msg ][0] ) . ' inline"><p>' . esc_html( $notices[ $msg ][1] ) . '</p></div>';
		}
		if ( tcc_code_off() ) {
			echo '<div class="notice notice-warning inline"><p>Every saved edit is being ignored, because the line <code>define( \'TCC_CODE_EDITS_OFF\', true );</code> is in the website\'s wp-config.php. All originals are running. Remove that line to use edits again.</p></div>';
		}
	}

	/** The file that is open on screen for this plugin, or '' when none is. */
	function tcc_code_open_file( $slug ) {
		$screen = tcc_code_on_screen();
		return $screen && $screen[0] === $slug && current_user_can( 'manage_options' ) ? $screen[1] : '';
	}

	/**
	 * A small link to one file's code, for putting beside the thing the file runs
	 * (TCC Website Features puts one under each feature's switch).
	 */
	function tcc_code_file_link( $slug, $rel, $class = '' ) {
		$state = tcc_code_state( $slug, $rel );
		$label = 'original' === $state ? 'See or edit the code' : ( 'broken' === $state ? 'Fix or remove my edit' : 'Open my edit' );
		return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( tcc_code_url( $slug, array( 'file' => rawurlencode( $rel ) ) ) ) . '">' . esc_html( $label ) . '</a>';
	}

	/**
	 * A plugin's code, drawn inside one of its tabs: one file open, or the panel that lists the files.
	 * $skip_group leaves a group of files out of the list (TCC Website Features lists its features
	 * itself, each with its own link, so only the rest are listed here).
	 */
	function tcc_code_tab( $slug, $skip_group = '' ) {
		$plugin = tcc_code_plugins( $slug );
		if ( ! $plugin || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$files = tcc_code_files( $slug );
		$rel   = tcc_code_open_file( $slug );
		$meta  = tcc_code_meta();
		$mine  = isset( $meta[ $slug ] ) ? (array) $meta[ $slug ] : array();
		$msg   = isset( $_GET['tcc_code_msg'] ) ? sanitize_key( wp_unslash( $_GET['tcc_code_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		tcc_code_css();
		tcc_code_js();
		echo '<div class="tcc-code">';
		tcc_code_notices( $slug );
		if ( '' === $rel ) {
			tcc_code_tab_list( $slug, $plugin, $files, $mine, $skip_group );
		} else {
			tcc_code_tab_file( $slug, $plugin, $files, $rel, isset( $mine[ $rel ] ) ? $mine[ $rel ] : array(), $msg );
		}
		echo '</div>';
	}

	/** The list of files. */
	function tcc_code_tab_list( $slug, $plugin, $files, $mine, $skip_group = '' ) {
		$broken = 0;
		foreach ( $mine as $one ) {
			$broken += empty( $one['broken'] ) ? 0 : 1;
		}
		echo '<div class="tcc-card" id="tcc-code"><h2>The code behind this plugin</h2>';
		echo '<p>Most problems are solved without touching the code: follow the <a href="' . esc_url( add_query_arg( array( 'page' => $plugin['page'], 'tab' => 'help' ), admin_url( 'admin.php' ) ) ) . '">Help</a> tab first. This is the next step, for someone who needs to look at or change how a piece works.</p><ul style="list-style:disc;margin-left:20px">';
		echo '<li><strong>The original code is never changed.</strong> When you save, your edit is kept as a separate copy and the website uses that copy instead.</li>';
		echo '<li><strong>"Put the original back"</strong> removes your copy. The website then runs the original again, exactly as it came with the plugin.</li>';
		echo '<li><strong>A mistake cannot take the website down for long.</strong> An edit with a typing mistake is refused. An edit that saves but then causes an error is switched off by itself, and its page says why.</li>';
		echo '<li><strong>An edited file does not get plugin updates</strong> until its original is put back. Tell whoever looks after the church\'s code about any edit that should stay.</li>';
		echo '<li><strong>Try it on the staging website first</strong> (staging13.tccknox.com). An edit saved on the live website is seen by visitors straight away.</li>';
		echo '</ul>';
		echo '<p style="margin-bottom:0">';
		if ( ! $mine ) {
			echo '<span class="tcc-pill tcc-pill--ok">Every file is the original</span>';
		} else {
			echo '<span class="tcc-pill tcc-pill--' . ( $broken ? 'bad' : 'warn' ) . '">' . count( $mine ) . ' ' . ( 1 === count( $mine ) ? 'file has' : 'files have' ) . ' an edit' . ( $broken ? ', ' . (int) $broken . ' switched off after an error' : '' ) . '</span> ';
			echo tcc_code_button( $slug, 'reset_all', 'Put every original back', '', 'button', 'Put every original back? All ' . count( $mine ) . ' saved edits of this plugin will be removed. This cannot be undone.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</p></div>';

		$group = null;
		foreach ( $files as $rel => $file ) {
			$this_group = isset( $file['group'] ) ? (string) $file['group'] : '';
			if ( '' !== $skip_group && $this_group === $skip_group ) {
				continue;
			}
			if ( $this_group !== $group && '' !== $this_group ) {
				echo '<h3 class="tcc-code-group">' . esc_html( $this_group ) . '</h3>';
			}
			$group = $this_group;
			$state = tcc_code_state( $slug, $rel );
			$one   = isset( $mine[ $rel ] ) ? $mine[ $rel ] : array();
			echo '<div class="tcc-card tcc-code-row"><div class="tcc-code-row__text">';
			echo '<div class="tcc-code-row__title"><h3>' . esc_html( $file['label'] ) . '</h3>' . tcc_code_pill( $state ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( ! empty( $file['what'] ) ) {
				echo '<p>' . esc_html( $file['what'] ) . '</p>';
			}
			echo '<p class="tcc-muted">File: <code>' . esc_html( $rel ) . '</code>';
			if ( $one ) {
				echo ' &middot; edited' . ( ! empty( $one['user'] ) ? ' by ' . esc_html( $one['user'] ) : '' ) . ' ' . esc_html( human_time_diff( (int) $one['time'] ) ) . ' ago';
			}
			echo '</p>';
			if ( 'broken' === $state ) {
				echo '<p class="tcc-code-note tcc-code-note--bad">This edit caused an error and was switched off. The original is running. Open the file to see the message.</p>';
			}
			echo '</div><div class="tcc-code-row__do"><a class="button' . ( 'broken' === $state ? ' button-primary' : '' ) . '" href="' . esc_url( tcc_code_url( $slug, array( 'file' => rawurlencode( $rel ) ) ) ) . '">' . ( $one ? 'Open my edit' : 'See or edit the code' ) . '</a></div></div>';
		}

		tcc_code_ai_card( $slug );
	}

	/** One file open. */
	function tcc_code_tab_file( $slug, $plugin, $files, $rel, $one, $msg ) {
		$file     = $files[ $rel ];
		$state    = tcc_code_state( $slug, $rel );
		$original = tcc_code_text( $slug, $rel, 'original' );
		$edit     = $one ? tcc_code_text( $slug, $rel, 'edit' ) : '';
		$shown    = '' !== $edit ? $edit : $original;
		$draft    = get_transient( 'tcc_code_draft_' . get_current_user_id() );
		$error    = '';
		if ( 'error' === $msg && is_array( $draft ) && isset( $draft['plugin'], $draft['file'] ) && $draft['plugin'] === $slug && $draft['file'] === $rel ) {
			$shown = (string) $draft['code'];
			$error = (string) $draft['error'];
		}

		echo '<p><a href="' . esc_url( tcc_code_url( $slug ) ) . '">&larr; Back to ' . esc_html( $plugin['tab_label'] ) . '</a></p>';
		echo '<div class="tcc-card"><div class="tcc-code-row__title"><h2 style="margin:0">' . esc_html( $file['label'] ) . '</h2>' . tcc_code_pill( $state ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $file['what'] ) ) {
			echo '<p>' . esc_html( $file['what'] ) . '</p>';
		}
		echo '<p class="tcc-muted">File: <code>' . esc_html( $rel ) . '</code> in ' . esc_html( $plugin['name'] ) . ' ' . esc_html( $plugin['version'] ) . '. ';
		if ( 'original' === $state ) {
			echo 'This is the original code. Nothing has been edited.';
		} elseif ( $one ) {
			echo 'Edited' . ( ! empty( $one['user'] ) ? ' by ' . esc_html( $one['user'] ) : '' ) . ' on ' . esc_html( wp_date( 'F j, Y \a\t g:i a', (int) $one['time'] ) ) . ', starting from version ' . esc_html( $one['base_version'] ) . '.';
		}
		echo '</p>';

		if ( '' !== $error ) {
			echo '<p class="tcc-code-note tcc-code-note--bad"><strong>Not saved.</strong> ' . esc_html( $error ) . ' What you typed is still in the box below, so you can fix it and save again. The website has not changed.</p>';
		}
		if ( 'broken' === $state ) {
			echo '<p class="tcc-code-note tcc-code-note--bad"><strong>This edit was switched off ' . esc_html( human_time_diff( (int) $one['broken_time'] ) ) . ' ago because it caused an error.</strong> The original is running, so the website is working. The message was: <code style="white-space:normal">' . esc_html( $one['broken'] ) . '</code><br>Fix the edit in the box and save it again, or put the original back. Copying this message to an AI assistant with the prompt below is a good way to find the mistake.</p>';
		} elseif ( 'ignored' === $state && ! tcc_code_off() ) {
			echo '<p class="tcc-code-note tcc-code-note--warn">An edit was saved for this file, but its copy is no longer in wp-content/tcc-code-edits, so the original is running. Press "Put the original back" to clear this message.</p>';
		}
		if ( $one && ! empty( $one['base_hash'] ) && md5( $original ) !== $one['base_hash'] ) {
			echo '<p class="tcc-code-note tcc-code-note--warn"><strong>The original has changed since this edit was made</strong> (a plugin update replaced it; the plugin is now version ' . esc_html( $plugin['version'] ) . '). The website is still running the edit, so it is missing whatever that update changed in this file. Compare the two below, then either put the original back or make the same change again on top of the new original.</p>';
		} elseif ( 'edited' === $state ) {
			echo '<p class="tcc-code-note tcc-code-note--warn">The website is running this edit instead of the original. This file will not change with plugin updates until the original is put back.</p>';
		}
		echo '</div>';

		// The code box.
		echo '<div class="tcc-card"><h2>' . ( $one ? 'The code (your edit)' : 'The code' ) . '</h2>';
		echo '<p class="tcc-muted">Change it here, or select everything in the box and paste a complete new version over it. Then press Save my edit. The original stays safe either way.</p>';
		echo '<form method="post" id="tcc-code-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="tcc_code_do"><input type="hidden" name="op" value="save"><input type="hidden" name="plugin" value="' . esc_attr( $slug ) . '"><input type="hidden" name="file" value="' . esc_attr( $rel ) . '"><input type="hidden" name="code_b64" value="">';
		wp_nonce_field( 'tcc_code_do', '_tcc_code_nonce' );
		echo '<label class="screen-reader-text" for="tcc-code-editor">The code of ' . esc_html( $rel ) . '</label>';
		echo '<textarea id="tcc-code-editor" name="code" class="tcc-code-box" spellcheck="false" autocomplete="off" autocapitalize="off">' . esc_textarea( $shown ) . '</textarea>';
		echo '<div class="tcc-code-bar"><button type="submit" class="button button-primary">Save my edit</button>';
		echo '<button type="button" class="button" data-tcc-copy="tcc-code-editor">Copy the code</button></div>';
		echo '</form>';
		if ( $one ) {
			echo '<div class="tcc-code-bar">' . tcc_code_button( $slug, 'reset', 'Put the original back', $rel, 'button', 'Put the original back? Your edit of this file will be removed and the website will run the original again. This cannot be undone.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( 'broken' === $state ) {
				echo tcc_code_button( $slug, 'retry', 'Switch my edit back on without changing it', $rel, 'button', 'Switch the edit back on as it is? Only do this if the cause of the error was fixed somewhere else. If it causes the same error it switches itself off again.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
			echo '<details style="margin-top:14px"><summary style="cursor:pointer;color:#2271b1">Show the original, to compare (it cannot be changed)</summary>';
			echo '<textarea id="tcc-code-original" class="tcc-code-box" readonly aria-label="The original code" style="margin-top:8px;background:#f6f7f7">' . esc_textarea( $original ) . '</textarea>';
			echo '<div class="tcc-code-bar"><button type="button" class="button" data-tcc-copy="tcc-code-original">Copy the original</button></div></details>';
		}
		echo '</div>';

		// The prompt for this file.
		echo '<div class="tcc-card" id="tcc-ai"><h2>Ask an AI assistant about this file</h2>';
		echo '<p>The box below is a briefing written for an AI assistant (Claude, ChatGPT and the like). It explains this website, this plugin and this file, and how the AI should hand a change back to you. It holds no passwords.</p>';
		echo '<ol class="tcc-code-steps">';
		echo '<li>Press <strong>Copy the prompt and the code</strong> and paste it into a new chat with the AI assistant.</li>';
		echo '<li>Find "MY QUESTION" in what you pasted and type what you want changed or what looks wrong.</li>';
		echo '<li>The AI gives back the whole file. Select everything in the code box above, paste the new version over it, and press <strong>Save my edit</strong>.</li>';
		echo '<li>Check the website. If it is not right, press <strong>Put the original back</strong>.</li>';
		echo '</ol>';
		echo '<textarea class="tcc-code-prompt" id="tcc-code-prompt" readonly aria-label="The prompt for an AI assistant">' . esc_textarea( tcc_code_prompt( $slug, $rel ) ) . '</textarea>';
		echo '<div class="tcc-code-bar"><button type="button" class="button button-primary" data-tcc-copy="tcc-code-prompt,tcc-code-editor" data-tcc-file="' . esc_attr( $rel ) . '">Copy the prompt and the code</button>';
		echo '<button type="button" class="button" data-tcc-copy="tcc-code-prompt">Copy the prompt only</button></div>';
		echo '<p class="tcc-muted" style="margin-bottom:0">Never paste a password, the Planning Center Application ID or Secret, or anyone\'s personal details into an AI chat.</p>';
		echo '</div>';
	}
}
