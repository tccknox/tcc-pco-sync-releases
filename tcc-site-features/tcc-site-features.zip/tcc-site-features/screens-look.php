<?php
/**
 * TCC Website: the look of every TCC Website screen (Features, Search, Help, and Planning Center).
 *
 * Look B, "Calm and plain", chosen by the owner on 24 November 2026 from three looks in
 * docs/mockups/plugin-screens-directions.html. In short: a charcoal title with a small teal line
 * above it, teal underline tabs, groups as rows in one white panel, real on/off switches, teal
 * outline icons. Brand colours only: Trinity Teal #00A4CF, Indigo #1962A8 on pointer-over,
 * Charcoal #404041, neutral greys. Never #007DA1.
 *
 * Every style rule starts with .tcc-site, the class on the outside of these screens, so nothing
 * else in WordPress changes. WordPress's own menu, top bar and notices are left as they are.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A small outline icon, drawn inline so nothing is fetched from another website.
 * The drawings are Tabler Icons 3.19.0 (tabler.io, MIT licence), copied unchanged.
 * Returns '' for a name that is not here.
 */
function tcc_site_icon( $name, $size = 22, $class = '' ) {
	$paths = array(
		'calendar-event' => '<path d="M4 5m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z"/><path d="M16 3l0 4"/><path d="M8 3l0 4"/><path d="M4 11l16 0"/><path d="M8 15h2v2h-2z"/>',
		'refresh'        => '<path d="M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4"/><path d="M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4"/>',
		'microphone'     => '<path d="M9 2m0 3a3 3 0 0 1 3 -3h0a3 3 0 0 1 3 3v5a3 3 0 0 1 -3 3h0a3 3 0 0 1 -3 -3z"/><path d="M5 10a7 7 0 0 0 14 0"/><path d="M8 21l8 0"/><path d="M12 17l0 4"/>',
		'book'           => '<path d="M3 19a9 9 0 0 1 9 0a9 9 0 0 1 9 0"/><path d="M3 6a9 9 0 0 1 9 0a9 9 0 0 1 9 0"/><path d="M3 6l0 13"/><path d="M12 6l0 13"/><path d="M21 6l0 13"/>',
		'users-group'    => '<path d="M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"/><path d="M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1"/><path d="M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"/><path d="M17 10h2a2 2 0 0 1 2 2v1"/><path d="M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"/><path d="M3 13v-1a2 2 0 0 1 2 -2h2"/>',
		'search'         => '<path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"/><path d="M21 21l-6 -6"/>',
		'layout'         => '<path d="M4 4m0 2a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v1a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2z"/><path d="M4 13m0 2a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v3a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2z"/><path d="M14 4m0 2a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2z"/>',
		'login-2'        => '<path d="M9 8v-2a2 2 0 0 1 2 -2h7a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-7a2 2 0 0 1 -2 -2v-2"/><path d="M3 12h13l-3 -3"/><path d="M13 15l3 -3"/>',
		'puzzle'         => '<path d="M4 7h3a1 1 0 0 0 1 -1v-1a2 2 0 0 1 4 0v1a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h1a2 2 0 0 1 0 4h-1a1 1 0 0 0 -1 1v3a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-1a2 2 0 0 0 -4 0v1a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h1a2 2 0 0 0 0 -4h-1a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1"/>',
		'help-circle'    => '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"/><path d="M12 16v.01"/><path d="M12 13a2 2 0 0 0 .914 -3.782a1.98 1.98 0 0 0 -2.414 .483"/>',
		'chevron-down'   => '<path d="M6 9l6 6l6 -6"/>',
		'calendar-plus'  => '<path d="M12.5 21h-6.5a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v5"/><path d="M16 3v4"/><path d="M8 3v4"/><path d="M4 11h16"/><path d="M16 19h6"/><path d="M19 16v6"/>',
		'circle-check'   => '<path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"/><path d="M9 12l2 2l4 -4"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg class="tcc-icon' . ( '' !== $class ? ' ' . esc_attr( $class ) : '' ) . '" xmlns="http://www.w3.org/2000/svg" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

/** A small rounded status label with a coloured dot: ok (green), warn (amber), bad (red) or muted (grey). */
function tcc_site_pill( $level, $label, $title = '' ) {
	$level = in_array( $level, array( 'ok', 'warn', 'bad', 'muted' ), true ) ? $level : 'muted';
	return '<span class="tcc-pill tcc-pill--' . $level . '"' . ( '' !== $title ? ' title="' . esc_attr( $title ) . '"' : '' ) . '>' . esc_html( $label ) . '</span>';
}

/**
 * The top of every TCC Website screen: the small teal line, the title, one sentence, the status on
 * the right, then the tabs. $sentence_html and $status_html are built by the caller from fixed words
 * and escaped values. $tabs is key => array( 'label' => ..., 'url' => ... ).
 */
function tcc_site_screen_header( $title, $sentence_html, $status_html, $tabs, $current ) {
	tcc_site_screen_assets();
	echo '<header class="tcc-head"><div class="tcc-head__top"><div class="tcc-head__text">';
	echo '<p class="tcc-kicker">The church\'s own website features</p>';
	echo '<h1>' . esc_html( $title ) . '</h1>';
	echo '<p class="tcc-head__sentence">' . wp_kses_post( $sentence_html ) . '</p>';
	echo '</div><div class="tcc-head__status">' . $status_html . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from tcc_site_pill() and buttons by the caller.
	echo '<nav class="tcc-tabs" aria-label="' . esc_attr( $title ) . '">';
	foreach ( $tabs as $key => $tab ) {
		echo '<a class="tcc-tab" href="' . esc_url( $tab['url'] ) . '"' . ( $key === $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $tab['label'] ) . '</a>';
	}
	echo '</nav></header><hr class="wp-header-end">';
}

/**
 * The on/off switch for one feature. It posts the same "switch" action as the old buttons did, so
 * tcc_site_handle_post() in admin.php is unchanged. $confirm is the question asked before switching
 * off ('' asks nothing).
 */
function tcc_site_switch( $key, $is_on, $label, $confirm = '' ) {
	$html  = '<form class="tcc-switch-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( '' !== $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
	$html .= '<input type="hidden" name="action" value="tcc_site_do"><input type="hidden" name="op" value="switch">';
	$html .= wp_nonce_field( 'tcc_site_do', '_tcc_site_nonce', true, false );
	$html .= '<input type="hidden" name="feature" value="' . esc_attr( $key ) . '"><input type="hidden" name="to" value="' . ( $is_on ? '0' : '1' ) . '">';
	$html .= '<button type="submit" class="tcc-switch" role="switch" aria-checked="' . ( $is_on ? 'true' : 'false' ) . '" title="' . ( $is_on ? 'Switch off' : 'Switch on' ) . '" aria-label="' . esc_attr( $label ) . '">';
	$html .= '<span class="tcc-switch__state">' . ( $is_on ? 'On' : 'Off' ) . '</span><span class="tcc-switch__track" aria-hidden="true"></span></button></form>';
	return $html;
}

/**
 * A folding box: a press-to-open line and what it hides. Closed unless $open. Returns '' when there
 * is nothing inside. $inner_html is fixed help wording (see help.php) or escaped values.
 */
function tcc_site_fold( $label, $inner_html, $class = '', $open = false, $id = '' ) {
	if ( '' === trim( (string) $inner_html ) ) {
		return '';
	}
	return '<details class="tcc-fold' . ( '' !== $class ? ' ' . esc_attr( $class ) : '' ) . '"' . ( '' !== $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ( $open ? ' open' : '' ) . '>'
		. '<summary>' . tcc_site_icon( 'help-circle', 18 ) . '<span>' . esc_html( $label ) . '</span>' . tcc_site_icon( 'chevron-down', 18, 'tcc-chev' ) . '</summary>'
		. '<div class="tcc-fold__body">' . $inner_html . '</div></details>';
}

/** The styles and the small script for these screens, printed once per screen. */
function tcc_site_screen_assets() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	echo '<style>' . tcc_site_screen_css() . '</style><script>' . tcc_site_screen_script() . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed rules and script written in this file.
}

/** The style rules of these screens (without the <style> tag). Every rule starts with .tcc-site. */
function tcc_site_screen_css() {
	$font = content_url( 'uploads/et-fonts/cmgsans-semibold-webfont.ttf' );
	$head = '"CMG Sans SemiBold","Montserrat",Helvetica,Arial,sans-serif';
	return '@font-face{font-family:"CMG Sans SemiBold";font-display:swap;src:url("' . esc_url( $font ) . '") format("truetype")}'
		// The page.
		. '.tcc-site{max-width:1100px;color:#404041}'
		. '.tcc-site a{color:#00a4cf}.tcc-site a:hover,.tcc-site a:focus{color:#1962a8}'
		. '.tcc-site h1,.tcc-site h2,.tcc-site h3,.tcc-site .tcc-area__name{font-family:' . $head . ';font-weight:400;color:#404041}'
		. '.tcc-site .tcc-muted{color:#64646a}'
		. '.tcc-site code{white-space:normal;word-break:break-word}'
		. '.tcc-site summary{list-style:none;cursor:pointer}.tcc-site summary::-webkit-details-marker{display:none}'
		. '.tcc-site summary:focus-visible,.tcc-site .tcc-tab:focus-visible,.tcc-site .tcc-linkbutton:focus-visible,.tcc-site .tcc-job:focus-visible{outline:2px solid #00a4cf;outline-offset:2px;border-radius:6px}'
		. '.tcc-site .tcc-switch:focus-visible{outline:2px solid #00a4cf;outline-offset:2px}'
		. '.tcc-site .tcc-chev{transition:transform .15s;flex:0 0 auto}.tcc-site details[open]>summary .tcc-chev{transform:rotate(180deg)}'
		// The header and the tabs.
		. '.tcc-site .tcc-head{margin:6px 0 0}'
		. '.tcc-site .tcc-head__top{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:10px 20px}'
		. '.tcc-site .tcc-kicker{font-family:' . $head . ';text-transform:uppercase;letter-spacing:.1em;color:#00a4cf;font-size:12px;margin:0 0 2px}'
		. '.tcc-site .tcc-head h1{font-size:32px;line-height:1.2;margin:0;padding:0}'
		. '.tcc-site .tcc-head__sentence{color:#64646a;margin:4px 0 0;max-width:640px;font-size:14px}'
		. '.tcc-site .tcc-head__status{display:flex;flex-wrap:wrap;align-items:center;gap:10px}.tcc-site .tcc-head__status form{margin:0}'
		. '.tcc-site .tcc-tabs{display:flex;flex-wrap:wrap;gap:4px 22px;margin:18px 0 20px;border-bottom:1px solid #d6d9dd}'
		. '.tcc-site .tcc-tab{padding:12px 2px;color:#64646a;font-weight:600;font-size:14px;text-decoration:none;border-bottom:3px solid transparent;margin-bottom:-1px}'
		. '.tcc-site .tcc-tab:hover,.tcc-site .tcc-tab:focus{color:#1962a8}'
		. '.tcc-site .tcc-tab[aria-current]{color:#404041;border-bottom-color:#00a4cf}'
		. '.tcc-site .wp-header-end{margin:0;border:0}'
		// Status labels.
		. '.tcc-site .tcc-pill{display:inline-flex;align-items:center;gap:7px;border-radius:999px;padding:3px 11px;font-size:13px;font-weight:600;line-height:1.6;white-space:nowrap;vertical-align:middle}'
		. '.tcc-site .tcc-pill::before{content:"";width:9px;height:9px;border-radius:50%;background:currentColor}'
		. '.tcc-site .tcc-pill--ok{background:#ecf7e8;color:#2f6b1f}.tcc-site .tcc-pill--warn{background:#fdf3d6;color:#7a5200}.tcc-site .tcc-pill--bad{background:#fbe9e9;color:#8a1f1f}.tcc-site .tcc-pill--muted{background:#f0f0f1;color:#50575e}'
		// Panels.
		. '.tcc-site .tcc-card{background:#fff;border:1px solid #dcdfe3;border-radius:12px;padding:18px 22px;margin:0 0 14px}'
		. '.tcc-site .tcc-card>h2:first-child{margin-top:0}.tcc-site .tcc-card h2{font-size:20px;margin:0 0 8px;padding:0}'
		. '.tcc-site .tcc-tools{display:flex;justify-content:flex-end;gap:16px;margin:0 0 10px}'
		. '.tcc-site .tcc-linkbutton{border:0;background:none;color:#00a4cf;cursor:pointer;padding:8px 2px;min-height:44px;font-family:inherit;font-size:14px;text-decoration:underline;text-underline-offset:3px}'
		. '.tcc-site .tcc-linkbutton:hover,.tcc-site .tcc-linkbutton:focus{color:#1962a8}'
		// Groups.
		. '.tcc-site .tcc-areas{background:#fff;border:1px solid #dcdfe3;border-radius:12px;padding:0 22px;margin:0 0 18px}'
		. '.tcc-site .tcc-area+.tcc-area{border-top:1px solid #e3e7ea}'
		. '.tcc-site .tcc-area>summary{display:flex;align-items:center;gap:14px;min-height:64px}'
		. '.tcc-site .tcc-area__icon{color:#00a4cf;display:inline-flex}'
		. '.tcc-site .tcc-area__name{font-size:18px;flex:1 1 auto}'
		. '.tcc-site .tcc-area__count{color:#64646a;font-size:14px}'
		. '.tcc-site .tcc-area>summary .tcc-chev{color:#64646a}'
		. '.tcc-site .tcc-area__body{padding:0 0 14px}'
		. '.tcc-site .tcc-area__about{color:#64646a;margin:0 0 10px 36px}'
		. '.tcc-site .tcc-area__help{margin:0 0 6px 36px}'
		// One feature.
		. '.tcc-site .tcc-feature{display:grid;grid-template-columns:minmax(0,1fr) 190px;gap:8px 24px;align-items:start;padding:14px 0 4px 36px;border-top:1px dashed #e3e7ea}'
		. '.tcc-site .tcc-feature h3{font-size:17px;margin:0;display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center}'
		. '.tcc-site .tcc-feature--warn h3::before,.tcc-site .tcc-feature--bad h3::before{content:"";width:10px;height:10px;border-radius:50%;background:#dba617;margin-left:-20px}'
		. '.tcc-site .tcc-feature--bad h3::before{background:#d63638}'
		. '.tcc-site .tcc-feature__short{margin:4px 0 0}'
		. '.tcc-site .tcc-feature__note{margin:10px 0 0;border-left:4px solid #dba617;background:#fffaf0;padding:8px 12px}'
		. '.tcc-site .tcc-feature--bad .tcc-feature__note{border-left-color:#d63638;background:#fdf2f2}'
		. '.tcc-site .tcc-feature__do{display:flex;flex-direction:column;align-items:stretch;gap:4px}'
		. '.tcc-site .tcc-feature__code{display:block;text-align:center;font-size:14px;padding:12px 0}'
		. '.tcc-site .tcc-feature>.tcc-fold{grid-column:1/-1}'
		// The switch.
		. '.tcc-site .tcc-switch-form{margin:0}'
		. '.tcc-site .tcc-switch{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;min-height:48px;border:1px solid #e3e7ea;background:#fff;border-radius:12px;padding:6px 12px 6px 14px;cursor:pointer;color:#404041;font-family:inherit;font-weight:600;font-size:14px}'
		. '.tcc-site .tcc-switch:hover{border-color:#00a4cf}'
		. '.tcc-site .tcc-switch__track{position:relative;width:52px;height:30px;border-radius:999px;background:#c9ccd1;flex:0 0 auto;transition:background .15s}'
		. '.tcc-site .tcc-switch__track::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:left .15s}'
		. '.tcc-site .tcc-switch[aria-checked="true"] .tcc-switch__track{background:#00a4cf}'
		. '.tcc-site .tcc-switch[aria-checked="true"] .tcc-switch__track::after{left:25px}'
		// Folding boxes and help.
		. '.tcc-site .tcc-fold>summary{display:inline-flex;align-items:center;gap:6px;color:#00a4cf;font-weight:600;font-size:14px;min-height:44px;padding:4px 0}'
		. '.tcc-site .tcc-fold>summary:hover{color:#1962a8}'
		. '.tcc-site .tcc-fold__body ul{list-style:disc;margin:0 0 6px 20px}.tcc-site .tcc-fold__body ol{margin:0 0 6px 20px}.tcc-site .tcc-fold__body li{margin-bottom:6px}'
		// The Updates panel on the Features tab.
		. '.tcc-site .tcc-updates{display:flex;flex-wrap:wrap;align-items:center;gap:10px 16px}.tcc-site .tcc-updates p{flex:1 1 320px;margin:0}.tcc-site .tcc-updates form{margin:0}'
		. '.tcc-site .tcc-tabhelp{background:#fff;border:1px solid #dcdfe3;border-radius:12px;padding:4px 18px;margin:0 0 16px}'
		. '.tcc-site .tcc-tabhelp[open]{padding-bottom:14px}'
		. '.tcc-site .tcc-help-body{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px 28px;padding:14px 18px 16px;border-radius:12px;background:#f7f8f9;margin:2px 0 8px;font-size:14px}'
		. '.tcc-site .tcc-help-part h4{font-family:' . $head . ';font-weight:400;text-transform:uppercase;letter-spacing:.08em;font-size:12px;color:#00a4cf;margin:0 0 6px}'
		. '.tcc-site .tcc-help-part--wide{grid-column:1/-1}'
		. '.tcc-site .tcc-help-part p{margin:0 0 6px}'
		. '.tcc-site .tcc-help li{margin-bottom:6px}.tcc-site .tcc-help ol,.tcc-site .tcc-help ul{margin:0 0 6px 20px}.tcc-site .tcc-help ul{list-style:disc}'
		. '.tcc-site .tcc-help table{border-collapse:collapse;width:100%}'
		. '.tcc-site .tcc-help td,.tcc-site .tcc-help th{padding:8px 12px 8px 0;text-align:left;vertical-align:top;border-top:1px solid #e3e7ea}'
		. '.tcc-site .tcc-help th{width:210px}'
		. '.tcc-site .tcc-help h3{font-size:16px;margin:16px 0 6px}'
		. '.tcc-site .tcc-jobs{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:14px}'
		. '.tcc-site .tcc-job{display:flex;gap:12px;align-items:center;border:1px solid #e3e7ea;border-radius:12px;padding:14px 16px;text-decoration:none;color:#404041;font-weight:600;min-height:64px}'
		. '.tcc-site .tcc-job .tcc-icon{color:#00a4cf}.tcc-site .tcc-job:hover,.tcc-site .tcc-job:focus{color:#1962a8;border-color:#00a4cf}'
		. '.tcc-site [id]{scroll-margin-top:46px}'
		// A phone, or a narrow window.
		. '@media(max-width:600px){'
		. '.tcc-site .tcc-head h1{font-size:26px}'
		. '.tcc-site .tcc-areas{padding:0 12px}'
		. '.tcc-site .tcc-area__count{display:none}'
		. '.tcc-site .tcc-area__about,.tcc-site .tcc-area__help{margin-left:0}'
		. '.tcc-site .tcc-feature{grid-template-columns:1fr;padding-left:0}'
		. '.tcc-site .tcc-feature--warn h3::before,.tcc-site .tcc-feature--bad h3::before{margin-left:0}'
		. '.tcc-site .tcc-help-body{grid-template-columns:1fr;padding:12px 14px}'
		. '.tcc-site .tcc-help table,.tcc-site .tcc-help tbody,.tcc-site .tcc-help tr,.tcc-site .tcc-help th,.tcc-site .tcc-help td{display:block;width:auto}'
		. '.tcc-site .tcc-help th{padding-bottom:0}.tcc-site .tcc-help td{border-top:0;padding-top:2px}'
		. '}';
}

/**
 * The small script of these screens (without the <script> tag). It opens the folded sections around
 * the spot a link points to (on load, when the address changes, and on a click on a link to this same
 * page), and works the "Open everything" / "Close everything" buttons.
 */
function tcc_site_screen_script() {
	return '(function(){'
		. 'function dec(s){try{return decodeURIComponent(s);}catch(e){return s;}}'
		. 'function openTo(id){if(!id){return;}var el=document.getElementById(id);if(!el){return;}'
		. 'for(var d=el;d;d=d.parentElement){if(d.tagName==="DETAILS"){d.open=true;}}'
		. 'if(el.classList.contains("tcc-feature")){var f=el.querySelector(".tcc-fold");if(f){f.open=true;}}'
		. 'el.scrollIntoView({block:"start"});}'
		. 'function fromHash(){openTo(dec(location.hash.slice(1)));}'
		. 'window.addEventListener("hashchange",fromHash);'
		. 'document.addEventListener("DOMContentLoaded",function(){fromHash();'
		. 'document.querySelectorAll(".tcc-site [data-tcc-open]").forEach(function(b){b.addEventListener("click",function(){var open=b.getAttribute("data-tcc-open")==="all";document.querySelectorAll(".tcc-site details").forEach(function(d){d.open=open;});});});'
		. 'document.querySelectorAll(".tcc-site a[href^=\'#\']").forEach(function(a){a.addEventListener("click",function(){var id=a.getAttribute("href").slice(1);if(id===dec(location.hash.slice(1))){openTo(id);}});});'
		. '});})();';
}
