<?php
/**
 * TCC Website: the tidy-up when the plugin is DELETED.
 *
 * WordPress runs this file only when someone presses Delete for TCC Website on the Plugins screen (after
 * deactivating it). It does not run when the plugin is deactivated, switched off feature by feature, or updated:
 * those keep every setting. WordPress runs this file itself, so it cannot be edited from TCC Website > Features.
 *
 * What is removed:
 *  - The Planning Center sign-in: the Application ID and the Secret inside tcc_pco_settings. Nothing that could
 *    reach Planning Center is left behind. Every other choice in that setting stays (see below).
 *  - Everything only remembered for a while, which the plugin works out again by itself: WordPress transients whose
 *    names start with tcc_ (the event and sermon lists, search answers, the update check, the "a check is running"
 *    lock, button messages), the "generation" numbers of those lists (any option named tcc_<word>_gen),
 *    tcc_pco_last_run (the last check's result), tcc_site_update_status (the last update check) and tcc_site_lists_version.
 *  - The words visitors searched for that found nothing (tcc_search_misses and tcc_search_misses_once): a log of
 *    what people typed, not a setting.
 *  - The hourly Planning Center check (the scheduled task tcc_pco_sync_cron).
 *
 * What is NOT removed, on purpose:
 *  - The choices people made, so that deleting the plugin and installing it again (which volunteers sometimes do to
 *    fix a problem) loses no work: which events were approved or hidden (tcc_pco_items, tcc_pco_pruned), the
 *    Conflicts list and Recent changes, the Tags, Rooms and Settings choices (the rest of tcc_pco_settings, with
 *    tcc_pco_tags and tcc_pco_rooms_all), which features are switched on (tcc_site_features), the search's
 *    "words that mean the same" and "not shown" lists, and the list of code edits (tcc_code_edits). After a
 *    reinstall only the Planning Center connection has to be made again (Settings tab).
 *  - Events, their dates, venues, categories and graphics, and the custom fields on them (_tcc_pco_..., _tcc_register_...).
 *    They are the church's content: visitors, links and search engines still use them. Deleting the plugin must
 *    never empty the calendar.
 *  - Pictures copied from Planning Center into the Media Library. Events and pages use them.
 *  - The folder wp-content/tcc-code-edits, with any code edited inside WordPress. It is someone's work and may be the
 *    only copy.
 *  - Planning Center itself. It is only ever read, never changed, by this plugin.
 *
 * To remove the plugin's settings completely as well (only when the church stops using it for good): after deleting
 * it, delete the options whose names start with tcc_ with a database tool, or ask whoever looks after the website.
 *
 * Added in 0.14.4. On a multisite network this tidies the site it runs for.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// The Planning Center sign-in goes; every other choice in that setting stays.
$tcc_uninstall_pco = get_option( 'tcc_pco_settings', null );
if ( is_array( $tcc_uninstall_pco ) ) {
	unset( $tcc_uninstall_pco['app_id'], $tcc_uninstall_pco['secret'] );
	update_option( 'tcc_pco_settings', $tcc_uninstall_pco, false );
}

// Results and logs that are worked out again, or are not settings.
foreach ( array( 'tcc_pco_last_run', 'tcc_site_update_status', 'tcc_site_lists_version', 'tcc_search_misses', 'tcc_search_misses_once' ) as $tcc_uninstall_option ) {
	delete_option( $tcc_uninstall_option );
}

// Transients with a fixed name, removed by name as well, in case the host keeps transients outside the database.
foreach ( array( 'tcc_pco_running', 'tcc_site_update_latest', 'tcc_site_notice' ) as $tcc_uninstall_transient ) {
	delete_transient( $tcc_uninstall_transient );
}

// The rest have a number or a code in their names, so look them up. Only names that start with tcc_ are touched.
$tcc_uninstall_names = (array) $GLOBALS['wpdb']->get_col( "SELECT option_name FROM {$GLOBALS['wpdb']->options} WHERE option_name LIKE '%tcc%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a one-off tidy-up; no value from outside is used.
foreach ( $tcc_uninstall_names as $tcc_uninstall_name ) {
	$tcc_uninstall_name = (string) $tcc_uninstall_name;
	if ( preg_match( '/^tcc_[a-z0-9]+_gen$/', $tcc_uninstall_name ) ) {
		delete_option( $tcc_uninstall_name );
	} elseif ( preg_match( '/^_transient_(?:timeout_)?(tcc_.+)$/', $tcc_uninstall_name, $tcc_uninstall_m ) ) {
		delete_transient( $tcc_uninstall_m[1] );
	} elseif ( preg_match( '/^_site_transient_(?:timeout_)?(tcc_.+)$/', $tcc_uninstall_name, $tcc_uninstall_m ) ) {
		delete_site_transient( $tcc_uninstall_m[1] );
	}
}

// The hourly Planning Center check (deactivating the plugin already stops it; this makes sure).
wp_clear_scheduled_hook( 'tcc_pco_sync_cron' );
