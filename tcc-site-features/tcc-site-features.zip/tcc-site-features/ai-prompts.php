<?php
/**
 * TCC Website Features: the briefings for an AI assistant ("AI prompts").
 *
 * Someone who has to change this website may not have access to the church's GitHub repository
 * or its notes. These briefings stand in for that: they tell an AI assistant how this plugin is
 * put together and what each feature leans on outside its own file (which Divi layout, which
 * layer names, which fields), so the assistant can help straight away.
 *
 * They are shown, with a Copy button, on TCC Website > Code (one per file, and one for the whole
 * plugin) and on TCC Website > Help. code-edits.php puts the pieces together: the briefing about the
 * website (the same for both plugins), then the plugin part below, then the part for one file.
 *
 * Keep these true. When a feature changes, change its lines here in the same version, exactly as
 * with the Help tab. Write for an AI that has never seen this website: short, exact, no guessing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What only a person who built the feature would know: what it leans on outside its own file,
 * and which pages to look at after changing it. One entry per feature key.
 */
function tcc_site_ai_feature_notes() {
	return array(
		'event-date-venue'  => array(
			'leans'  => 'The Events Calendar functions (tribe_get_start_date and the like). It is only used by the OLDER event page layout in Divi > Theme Builder, "Individual event page - NATIVE (kept for rollback)", which is not assigned to any page today. It is kept so that layout still works if it is ever brought back.',
			'check'  => 'Nothing on the public website uses it today. To see it, the older layout would have to be assigned to events on the staging copy.',
		),
		'event-feeds'       => array(
			'leans'  => 'The Events Calendar (events are the post type tribe_events, categories are tribe_events_cat). It gives Divi made-up "post types" that a Divi loop can choose, named "Upcoming Events (automatic)", "Upcoming Events - every date (automatic)", "Upcoming Events - next 6 months (automatic)" and one per event category; it answers those loops itself (the posts_pre_query filter) with a short list of event ids. The lists are remembered for 10 minutes and thrown away whenever an event or an event category is saved or an event is trashed. The filter tcc_upcoming_series_key lets Planning Center Sync treat the dates of one repeating event as one event. Other features read these lists: the Events filter bar and the Sitewide search page. Event cards in Divi carry the classes tcc-event-card and tcc-event-title.',
			'check'  => 'The home page (event cards), /events/, one ministry page that lists its own events (for example The Forge), and the Events drop-down in the header menu. Also open one of those in the Divi editor: a loop that is right on the website can preview wrongly there.',
		),
		'menu-hover'        => array(
			'leans'  => 'The header built in Divi > Theme Builder (the global header) and Divi\'s own drop-down menu markup. It is JavaScript printed in the page footer; it only acts for mouse users, on hover drop-downs in the header, and never inside the Divi builder. At 1920 pixels wide the drop-down panel is centred in the window, not under its button, which is why the mouse path matters.',
			'check'  => 'The main menu with a mouse at 1920 and 1440 wide: move from a menu button down to its panel, diagonally across other buttons. Check a phone width too (the mobile menu must be unaffected), and an event page as well as an ordinary page.',
		),
		'events-filter'     => array(
			'leans'  => 'The "Event feeds" feature (it must be on). On the Events page the list of cards must keep the CSS ID tcc-events, and every card must hold the short code [tcc_event_data], which prints a hidden tag with that event\'s categories and month. Filtering happens in the visitor\'s browser on the cards already on the page; nothing is asked of the server. The bar hides itself when there are fewer than two upcoming events.',
			'check'  => '/events/ at 1920, 1440, 768 and 375 wide: choose a category, a month, type a search word, combine them, clear them. Check the "Showing 3 of 8 events" line and the removable tags.',
		),
		'sermon-audio'      => array(
			'leans'  => 'The custom field sermon_podcast on each sermon (shown in the editor as "Podcast" under Sermon Info), which holds the Buzzsprout embed code. It exists because Divi 5 strips <script> tags from custom fields shown through Dynamic Content. It prints only a genuine Buzzsprout player and nothing otherwise. buzzsprout.com is marked Essential in the Termly cookie banner so the player always loads.',
			'check'  => 'A sermon page that has a podcast code: switch the player to Audio and press play. Then a sermon with no podcast code: the Audio side should be empty, with no error.',
		),
		'event-banner'      => array(
			'leans'  => 'The event page layout in Divi > Theme Builder, "Individual event page - BANNER (new)". Its layers carry the classes tcc-event-banner (the banner), tcc-event-place (the Location card) and tcc-event-about (the description column); the CSS this file prints on event pages looks for those names. It follows the "what shows" choices of Planning Center Sync (location, end time) when that plugin is active (the function tcc_pco_shows), and works without it. "Get directions" is a plain link to Google Maps.',
			'check'  => 'Several event pages at 1920, 1440, 768 and 375 wide: one with a wide graphic, one with a square or tall graphic, one with no graphic, one with no location, and an all-day event. Between 768 and 1280 wide the banner stacks (graphic on top).',
		),
		'sitewide-search'   => array(
			'leans'  => 'A Divi Theme Builder template named "Search results - SITEWIDE (new)" whose body holds the short code [tcc_search_results]. That template is deliberately NOT assigned to Search Results; this file finds it and shows it for searches of the whole website only (a search limited to one kind of content keeps its own page). It reads sermon fields (short and long description, speaker name), sermon categories, and community group fields, as well as WordPress\'s own search. Its settings live under TCC Website > Search: words that mean the same (option tcc_search_synonyms) and searches that found nothing (option tcc_search_misses). Results are remembered for 10 minutes and thrown away when content is saved. It uses the "Event feeds" lists for upcoming events. The function tcc_search_health() reports problems to the Features tab.',
			'check'  => 'Search from the box in the main menu for: a common word ("baptism"), a misspelling ("baptizm"), a word with a synonym ("kids"), and nonsense that finds nothing. Check the Top results, each group, a "See all" link, and the page at 1920, 1440, 768 and 375 wide. Then TCC Website > Search still loads and saves.',
		),
		'sermon-filters'    => array(
			'leans'  => 'The Divi Theme Builder layouts "Sermons page - NEW" and "Sermon series page - NEW". Sermons are ordinary posts; a series is a category filed under the parent category "Series", and speakers, Bible books and topics are categories under "Speaker", "Bible" and "Topics". Divi draws the newest 12 sermon cards with its own loop; this file\'s script copies the first card for older sermons, so the card layers must keep their classes: tcc-sermon-card on the card, tcc-sermon-pic, tcc-sermon-title and tcc-sermon-series inside it, and the list must keep the CSS ID tcc-sermons. Series cards use the classes tcc-series-list and tcc-series-card. It gives Divi two lists to loop over: "Sermon series - newest first (automatic)" (a loop of terms) and "Sermons in this series - oldest first (automatic)". The series graphic is a field on the category; Divi\'s own "Category Image" is filled with it. Everything is worked out once, remembered for 12 hours, and worked out again when a sermon or category is saved. The "Sermon page (one sermon)" feature and the home page (the short code [tcc_sermon_meta]) depend on this file.',
			'check'  => '/sermons/ at 1920, 1440, 768 and 375 wide: search, each filter (Series, Speaker, Book, Topic), "See all series", loading older sermons. One series page: the graphic, the facts line, the part numbers. The home page\'s Latest Sermon speaker and date line. Then the same pages in the Divi editor.',
		),
		'sermon-page'       => array(
			'leans'  => 'The Divi Theme Builder layout "Individual sermon page - NEW", and the feature "Sermons page: search, filters and series", which must be on (it works out series, speaker, book and topic). Layer names it looks for: the CSS ID tcc-sermon-long on the long description (for "Read the full summary"), and the classes tcc-sp-player, tcc-sp-eyebrow, tcc-sp-byline, tcc-sp-series, tcc-sp-cell, tcc-sp-row with tcc-sp-prev or tcc-sp-next, tcc-sp-step, tcc-sp-pic and tcc-sp-card. It gives Divi three lists to loop over: "Sermon page: previous part of the series (automatic)", "... next part ..." and "Sermon page: more sermons (automatic)". The Video / Audio switch is a Divi Pixel Content Toggle holding the Divi Library layouts "Sermon Video" and "Sermon Podcast". Part numbers go by date, oldest first. [tcc_sermon_crumbs] prints the trail of the "Page trail" feature when that is on.',
			'check'  => 'A sermon in the middle of a series (previous and next rows, "Part 6 of 27", four cards at the foot), the first and the last part of a series, and a sermon in no series. At 1920, 1440, 768 and 375 wide. Press a "Find more like this" button: the Sermons page should open already filtered.',
		),
		'page-trail'        => array(
			'leans'  => 'A Divi Text layer that holds only [tcc_trail], placed above the title in the Theme Builder layouts for the Sermons page, the series page, the sermon page and the search page (labelled "Trail: Home > ... (automatic)"). The gap under it is that layer\'s own bottom margin in Divi (10px), not CSS from this file. It is styled to match Divi\'s own Breadcrumbs layer, which ordinary pages use. If this feature is off, a stand-in in the main plugin file makes [tcc_trail] print nothing.',
			'check'  => '/sermons/, one series page, one sermon page and a search results page, beside an ordinary page that uses Divi\'s own breadcrumbs (for example a ministry page): the two trails should look the same, at 1920, 1440, 768 and 375 wide.',
		),
		'first-view-styles' => array(
			'leans'  => 'How Divi prints styles. On the first view after a Divi save, and on every view of a page with a Divi loop, Divi prints the page\'s styles far down the page; this file collects the whole page before it is sent (output buffering started on template_redirect) and moves those style blocks into the head, keeping their order. It never runs in the admin, in the Divi editor, or for feeds and background requests. On the live website WP Rocket also processes styles ("Remove Unused CSS"); how the two sit together has not been checked there yet.',
			'check'  => 'As a signed-out visitor, open /sermons/, a series page, /events/ and a search page with the network slowed down: the page should not flash plain teal pill buttons before settling. View the page source: no large <style> block should sit after the content. Check an event page and an ordinary page still look right.',
		),
		'event-search-text' => array(
			'leans'  => 'Yoast SEO (it does nothing without it). It reads the wording typed under Yoast SEO > Settings > Events and > Event Categories (the option wpseo_titles) and hands it to Yoast\'s filters for the Events page and event category pages. For one event with no Yoast description it uses the event\'s Planning Center summary (the custom field _tcc_pco_summary), or the start of its description, cut to about 155 characters. A description typed in Yoast on the event always wins.',
			'check'  => 'View the page source of /events/, one event category page, and one event that came from Planning Center: look at <title>, <meta name="description"> and the og: tags. A page for one month or one day should keep The Events Calendar\'s own dated title.',
		),
	);
}

/** The briefing for the whole plugin, and one per file that can be edited. Used by code-edits.php. */
function tcc_site_ai_notes() {
	$features = tcc_site_features();
	$on       = tcc_site_switches();
	$notes    = tcc_site_ai_feature_notes();

	$plugin = array(
		'What it is: the church\'s own small website features in one plugin. Each feature fills in something Divi and the other plugins cannot do by themselves. The pages are still built in Divi; this plugin only supplies the automatic parts those pages call for.',
		'',
		'How it is put together:',
		'- tcc-site-features.php is the main file. It holds the list of features (the function tcc_site_features: each has a key, a label, what it does, where it is used, what a visitor notices if it is off, the short codes it provides, and any feature it needs). It loads the file features/<key>.php for every feature that is switched ON. The switches are saved in the WordPress option tcc_site_features (key => 1). A new install starts with everything off.',
		'- features/<key>.php: one file per feature. Each wraps its code in  if ( ! function_exists( \'...\' ) ) { }  so a second copy of the same code (an old snippet in the Code Snippets plugin) can never clash with it. A feature file that fails to load is skipped and reported on the Features tab; the rest of the website carries on.',
		'- admin.php draws the screen TCC Website with its tabs: Features (a switch and a status for each feature: Working, Needs a look, Off), Search (belongs to the sitewide search feature), Code and Help. Switching a feature clears the WP Rocket and SiteGround page caches.',
		'- help.php is the Help tab, written for volunteers. updater.php brings new versions from the public GitHub repository tccknox/tcc-pco-sync-releases (folder tcc-site-features); a person still presses "Update now" on the Plugins screen. code-edits.php is the Code tab. ai-prompts.php is the wording of this briefing.',
		'',
		'How Divi uses the features (this is where most "it stopped working" problems come from):',
		'- Short codes such as [tcc_event_facts] sit in Divi Text layers. A layer filled in by a feature is labelled "(automatic)" in the Divi builder.',
		'- Some features give Divi a ready-made list to loop over. In a Divi loop\'s settings it appears as a post type with "(automatic)" in its name, for example "Upcoming Events (automatic)".',
		'- Some features find a Divi layer by its CSS ID or class (set in Divi under Advanced > Attributes), for example tcc-events or tcc-sermon-card. If someone renames or removes that in Divi, the feature quietly stops working. Always consider this before changing code.',
		'- The layouts live in Divi > Theme Builder. Older versions are kept beside the new ones, named "OLD (kept for rollback)".',
		'',
		'What can and cannot be changed on the Code tab: every feature file and the Help tab can be. The list of features, the admin screen, the updater and the Code tab itself cannot; those need the church\'s GitHub repository. So a brand-new feature cannot be added from the Code tab, but an existing one can be changed.',
		'',
		'If a change alters what a feature does or how a volunteer uses it, also give the new wording for the Help tab (file help.php), so the help stays true.',
		'',
		'The features (ON or OFF is how they are set on this website right now):',
	);
	foreach ( $features as $key => $feature ) {
		$line  = '- ' . $feature['label'] . ' [' . ( empty( $on[ $key ] ) ? 'OFF' : 'ON' ) . '] (file features/' . $key . '.php). ' . $feature['what'] . ' Used: ' . $feature['where'];
		$line .= $feature['codes'] ? ' Short codes: ' . implode( ' ', $feature['codes'] ) . '.' : '';
		$line .= '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) ? ' Needs the feature "' . $features[ $feature['needs'] ]['label'] . '".' : '';
		$line .= ! empty( $feature['events'] ) ? ' Needs The Events Calendar plugin.' : '';
		$plugin[] = $line;
	}

	$files = array();
	foreach ( $features as $key => $feature ) {
		$part   = array();
		$part[] = 'What it does: ' . $feature['what'];
		$part[] = 'Where it is used: ' . $feature['where'];
		$part[] = 'If it were switched off, a visitor would notice: ' . $feature['off'];
		$part[] = 'It is switched ' . ( empty( $on[ $key ] ) ? 'OFF' : 'ON' ) . ' on this website right now (TCC Website > Features).';
		if ( $feature['codes'] ) {
			$part[] = 'Short codes it provides: ' . implode( ' ', $feature['codes'] ) . '. The Help tab explains each one for whoever builds the pages.';
		}
		if ( '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) ) {
			$part[] = 'It cannot work without the feature "' . $features[ $feature['needs'] ]['label'] . '" (file features/' . $feature['needs'] . '.php), which must be switched on as well.';
		}
		if ( ! empty( $feature['events'] ) ) {
			$part[] = 'It needs The Events Calendar plugin to be active.';
		}
		$part[] = 'The Features tab decides whether this feature is "Working" by checking that the function ' . $feature['fn'] . '() exists and comes from this file. Keep that function, with that name, inside the file.';
		if ( '' !== $feature['snippet'] ) {
			$part[] = 'Before this plugin existed it was the Code Snippets snippet "' . $feature['snippet'] . '". That old copy is kept, deactivated, under Snippets as a fallback.';
		}
		if ( isset( $notes[ $key ] ) ) {
			$part[] = 'What it leans on outside this file: ' . $notes[ $key ]['leans'];
			$part[] = 'Pages to check after any change: ' . $notes[ $key ]['check'];
		}
		$part[] = 'The long comment at the top of the file explains the rest. Read it before changing anything.';
		$files[ 'features/' . $key . '.php' ] = implode( "\n", $part );
	}

	$files['help.php'] = implode(
		"\n",
		array(
			'What it is: the Help tab (TCC Website > Help), one function, tcc_site_help_tab(), that prints panels of plain-English help.',
			'Who reads it: church volunteers, not programmers. Keep every sentence short and plain. Say where to click. Avoid jargon; where a technical word is needed (short code, CSS class), it belongs in the last panel, "For whoever builds the pages".',
			'How it is arranged: what the plugin does; the features; how to switch one on or off; where to find things; what it is connected to; changing the code and asking an AI; if something looks wrong (grouped by area, each item a bold symptom followed by what to do); and the short codes for whoever builds the pages.',
			'The list of features and their status labels are drawn from tcc_site_features() automatically, so only the hand-written panels need editing.',
			'Rules: every piece of text printed must be escaped or be fixed text written in this file; keep the function name and its three arguments; keep the panels\' CSS classes (tcc-card, tcc-help, tcc-pill).',
			'Pages to check after any change: TCC Website > Help at a wide screen and at phone width (the tables stack on a narrow screen).',
		)
	);

	return array(
		'plugin' => implode( "\n", $plugin ),
		'files'  => $files,
	);
}
