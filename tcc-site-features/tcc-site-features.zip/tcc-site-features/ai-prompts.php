<?php
/**
 * TCC Website Features: the briefings for an AI assistant ("AI prompts").
 *
 * Someone who has to change this website may not have access to the church's GitHub repository
 * or its notes. These briefings stand in for that: they tell an AI assistant how this plugin is
 * put together and what each feature leans on outside its own file (which Divi layout, which
 * layer names, which fields), so the assistant can help straight away.
 *
 * They are shown, with a Copy button, on TCC Website > Features (one on each file's code page, and
 * one for the whole plugin at the bottom) and on TCC Website > Help. code-edits.php puts the pieces together: the briefing about the
 * website (the same for both plugins), then the plugin part below, then the part for one file.
 *
 * Keep these true. When a feature changes, change its lines here in the same version, exactly as
 * with the Help tab. Write for an AI that has never seen this website: short, exact, no guessing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What only a person who built the feature would know: what it leans on outside its own file,
 * and which pages to look at after changing it. One entry per feature key.
 */
function tcc_site_ai_feature_notes() {
	return array(
		'event-date-venue'  => array(
			'leans'  => 'The Events Calendar functions (tribe_get_start_date and the like). It is only used by the OLDER event page layout in Divi > Theme Builder, "Individual event page - NATIVE (kept for rollback)", which is not assigned to any page today. It is kept so that layout still works if it is ever brought back.',
			'check'  => 'Nothing on the public website uses it today. To see it, the older layout would have to be assigned to events on the staging copy.',
		),
		'event-feeds'       => array(
			'leans'  => 'The Events Calendar (events are the post type tribe_events, categories are tribe_events_cat). It gives Divi made-up "post types" that a Divi loop can choose, named "Upcoming Events (automatic)", "Upcoming Events - every date (automatic)", "Upcoming Events - next 6 months (automatic)" and one per event category; it answers those loops itself (the posts_pre_query filter) with a short list of event ids. The lists are remembered for 10 minutes and thrown away whenever an event or an event category is saved or an event is trashed. The filter tcc_upcoming_series_key lets Planning Center Sync treat the dates of one repeating event as one event. A repeating event is ONE card in every list except "every date" (up to three); the card says that it repeats through the short code [tcc_event_repeats], placed straight in front of [tcc_event_day] in the card\'s date text: it prints a teal line such as "Every Wednesday" and the word "Next:", and nothing for a one-off event. The words come from the "Repeats" box on the event\'s edit screen (post meta _tcc_repeats; "none" hides the line) or, when that is empty, from the filter tcc_event_repeats_text, which Planning Center Sync answers with Planning Center\'s own wording. tcc_upcoming_months_for() gives the months a card stands for, so the filter bar finds a repeating event under every month it has a date in. Other features read these lists: the Events filter bar and the Sitewide search page. Event cards in Divi carry the classes tcc-event-card and tcc-event-title.',
			'check'  => 'The home page (event cards), /events/, one ministry page that lists its own events (for example The Forge), and the Events drop-down in the header menu. Also open one of those in the Divi editor: a loop that is right on the website can preview wrongly there.',
		),
		'menu-hover'        => array(
			'leans'  => 'The header built in Divi > Theme Builder (the global header) and Divi\'s own drop-down menu markup. It is JavaScript printed in the page footer; it only acts for mouse users, on hover drop-downs in the header, and never inside the Divi builder. It tells \'moving along the menu\' from \'heading down to the panel\' by the direction the mouse has moved in the last 150 milliseconds (the numbers are at the top of the script). At 1920 pixels wide the drop-down panel is centred in the window, not under its button, which is why the mouse path matters.',
			'check'  => 'The main menu with a mouse at 1920 and 1440 wide: move from a menu button down to its panel, diagonally across other buttons (the panel must stay), and move sideways from one menu button to the next, even drifting a little downward (the panel must switch at once, with no wait). Check a phone width too (the mobile menu must be unaffected), and an event page as well as an ordinary page.',
		),
		'events-filter'     => array(
			'leans'  => 'The "Event feeds" feature (it must be on). On the Events page the list of cards must keep the CSS ID tcc-events, and every card must hold the short code [tcc_event_data], which prints a hidden tag with that event\'s categories and month (several months for an event that repeats, because it is one card). Filtering happens in the visitor\'s browser on the cards already on the page; nothing is asked of the server. The bar hides itself when there are fewer than two upcoming events. Twelve cards show at first, then a quiet "Show 12 more" button with "Showing 12 of N" (added in 0.9.3; a filter shows every match), and any <span class="tcc-events-count"> on the page is filled with how many events there are (0.9.2). The bar\'s look (grey, 48px boxes with 10px corners and a #d9d9da edge, a label on the left) is shared with the Community Groups and Sermons bars; keep the three alike.',
			'check'  => '/events/ at 1920, 1440, 768 and 375 wide: choose a category, a month, type a search word, combine them, clear them. Choose a month in which only a later date of a repeating event falls: its one card must still show. Check the "Showing 3 of 8 events" line and the removable tags.',
		),
		'sermon-audio'      => array(
			'leans'  => 'The custom field sermon_podcast on each sermon (shown in the editor as "Podcast" under Sermon Info), which holds the Buzzsprout embed code. It exists because Divi 5 strips <script> tags from custom fields shown through Dynamic Content. It prints only a genuine Buzzsprout player and nothing otherwise. Two forms of the Buzzsprout address are accepted: the newer one with "/episodes/" in it and the older one without (sermons before late 2024). buzzsprout.com is marked Essential in the Termly cookie banner so the player always loads.',
			'check'  => 'A sermon page that has a podcast code: switch the player to Audio and press play. Then a sermon with no podcast code: the Audio side should be empty, with no error.',
		),
		'event-banner'      => array(
			'leans'  => 'The event page layout in Divi > Theme Builder, "Individual event page - BANNER (new)". Its layers carry the classes tcc-event-banner (the banner), tcc-event-place (the Location card) and tcc-event-about (the description column); the CSS this file prints on event pages looks for those names. It follows the "what shows" choices of Planning Center Sync (location, end time) when that plugin is active (the function tcc_pco_shows), and works without it. "Get directions" is a plain link to Google Maps.',
			'check'  => 'Several event pages at 1920, 1440, 768 and 375 wide: one with a wide graphic, one with a square or tall graphic, one with no graphic, one with no location, and an all-day event. Between 768 and 1280 wide the banner stacks (graphic on top).',
		),
		'event-editor-preview' => array(
			'leans'  => 'The Divi 5 editor. Inside the editor, Divi 5 draws each short code in a template layer by POSTing it to a hidden preview of the home page (/?et_pb_preview=true&et_pb_preview_nonce=..., with shortcode, post_id = the open event, and is_fb_preview=1) and reading back the .entry-content of the answer; the results are kept in the editor\'s "divi/shortcode-module" store per post id. (Divi also has a REST route, /wp-json/divi/v1/module-data/shortcode-module/html, which needs its X-ET-Nonce header; the editor did not use it for these layers in Divi 5.19.) In that request the open event is not the current post, so the event short codes printed their "(filled in automatically)" stand-ins. This file (added in 0.9.9), only for signed-in editors and only inside the editor (tcc_editor_preview_in_editor(): tcc_site_in_divi_editor(), or that preview request), finds the open event (a postId / post_id / et_post_id / currentPage[id] the editor sent, including inside JSON kept from rest_pre_dispatch; otherwise the /event/slug/ address in the Referer) and, on pre_do_shortcode_tag at priority 1, makes it the global $post for the short codes in tcc_editor_preview_codes() (from this plugin and from Planning Center Sync), putting the previous post back on do_shortcode_tag (or on pre_do_shortcode_tag at PHP_INT_MAX when another filter answers early). It never changes anything on a page that is already an event. It also prints, in the editor only, a <style id="tcc-event-editor-labels"> that labels #theme-builder-area--post_content (the event\'s own Post Content box, "This event only") and, when a layer inside #theme-builder-area--body but outside the event\'s own box has Divi\'s class et-vb-module--is-edited (its settings are open), shows a fixed dark notice 110px from the top (under the floating menu, which is drawn above that area) saying the shared template is being changed (CSS :has() with a complex :not()). Divi 5 marks the event\'s own box theme-builder-area--active and the template --inactive, but that never changes: a single click edits a template layer directly, which is how a button meant for one event ended up on every event (2026-11-23). Those ids and classes are Divi\'s own; if a Divi update renames them, the labels stop showing (nothing breaks).',
			'check'  => 'Open an event in the Divi editor (Events > the event > Edit With Divi): the banner must show its real day, time and place, the description and Location card their real text, and a room chip and Register button where the event has them. Try a Planning Center event, a website-only event, a repeating event and an off-site event. The teal "This event only" caption must sit above the box under About this event. Open the settings of a banner layer (click it, then its gear): the dark notice must appear under the menu and the teal caption turn grey; close them: both must go back. Open a layer inside the teal box: no strip. Exit without saving. Then view the same events signed out: nothing may have changed. Note: Divi only opens an event in the editor once its "Use The Divi Builder" switch is on (the hidden field et_pb_use_builder = on); otherwise ?et_fb=1 is dropped by a redirect to the plain page. Planning Center Sync makes one website event per date and never rewrites an existing event\'s content; a new date copies the content (not the builder switch) of the date before.',
		),
		'sitewide-search'   => array(
			'leans'  => 'A Divi Theme Builder template named "Search results - SITEWIDE (new)" whose body holds the short code [tcc_search_results]. That template is deliberately NOT assigned to Search Results; this file finds it and shows it for searches of the whole website only (a search limited to one kind of content keeps its own page). It reads sermon fields (short and long description, speaker name), sermon categories, community group fields, and the display name of the account a post was saved under (tcc_search_extra_ids(); since 0.10.0, when the WP Extended Search plugin, which used to add author names to WordPress\'s search, was switched off; accounts listed in tcc_search_author_skip(), such as the church\'s own account and the sermon upload app, are not matched), as well as WordPress\'s own search. Divi\'s Search box in the header adds its own settings to every search (search_post_types and the like); tcc_search_keep_our_query() puts this feature\'s query back. The Divi Search Helper plugin, which used to add more of those settings, was switched off in 0.10.0. Its settings live under TCC Website > Search: words that mean the same (option tcc_search_synonyms) and searches that found nothing (option tcc_search_misses). Results are remembered for 10 minutes and thrown away when content is saved. It uses the "Event feeds" lists for upcoming events. The function tcc_search_health() reports problems to the Features tab.',
			'check'  => 'Search from the box in the main menu for: a common word ("baptism"), a misspelling ("baptizm"), a word with a synonym ("kids"), and nonsense that finds nothing. Check the Top results, each group, a "See all" link, and the page at 1920, 1440, 768 and 375 wide. Then TCC Website > Search still loads and saves.',
		),
		'group-filter'      => array(
			'leans'  => 'The Community Groups page (an ordinary page built in Divi) and the Community Groups themselves (the post type "project", with the ACF field group "Community Groups Info"). Divi draws the cards with its own loop (active groups only, A to Z); this file only hides and shows them in the browser. The list of cards must keep the CSS ID tcc-groups, each card the CSS class tcc-group-card, and each card must hold the short code [tcc_group_data], which prints a hidden tag made from three fields: gender_specific (who), date_and_meeting_time (day names are picked out of the words) and how_often. A <span class="tcc-group-count"> on the page is filled with the number of groups. Who a group is for is shown as press-buttons that the script builds from the hidden "who" menu (the menu still holds the choice). Below 768px wide the buttons are a two-column grid, and an odd last button spans the row (0.9.6). Twelve cards show at first, then "Show 12 more" (0.9.3). The bar is grey like the Events bar. The main file gives both short codes an empty stand-in when this feature is off. In the Divi editor the bar still starts "hidden", but two style rules scoped to body.et-fb (a class only the editor page has) show it as a plain preview with menus and add a grey note saying it is an editor preview (0.9.7). The editor draws this layer through its own requests, so a PHP check for the editor does not reach it; that is why it is done in CSS.',
			'check'  => '/community-groups/ at 1920, 1440, 768 and 375 wide: 12 of 16 cards show and "Show 4 more" shows the rest; press Women, choose a day, a schedule, type a search word, combine them, clear them. Check "Showing 3 of 16 groups", the message when nothing matches, and that a group whose meeting time names two days is found under both. Then switch the feature off for a moment: the bar goes, every group shows and no short code name is printed.',
		),
		'sermon-filters'    => array(
			'leans'  => 'The Divi Theme Builder layouts "Sermons page - NEW" and "Sermon series page - NEW". Sermons are ordinary posts; a series is a category filed under the parent category "Series", and speakers, Bible books and topics are categories under "Speaker", "Bible" and "Topics". Divi draws the newest 12 sermon cards with its own loop; this file\'s script copies the first card for older sermons, so the card layers must keep their classes: tcc-sermon-card on the card, tcc-sermon-pic, tcc-sermon-title and tcc-sermon-series inside it, and the list must keep the CSS ID tcc-sermons. Series cards use the classes tcc-series-list and tcc-series-card. It gives Divi two lists to loop over: "Sermon series - newest first (automatic)" (a loop of terms) and "Sermons in this series - oldest first (automatic)". The series graphic is a field on the category; Divi\'s own "Category Image" is filled with it. Everything is worked out once, remembered for 12 hours, and worked out again when a sermon or category is saved. The "Sermon page (one sermon)" feature and the home page (the short code [tcc_sermon_meta]) depend on this file.',
			'check'  => '/sermons/ at 1920, 1440, 768 and 375 wide: search, each filter (Series, Speaker, Book, Topic), "See all series", loading older sermons. One series page: the graphic, the facts line, the part numbers. The home page\'s Latest Sermon speaker and date line. Then the same pages in the Divi editor. Also: the bar reads Find a sermon, then the four menus, then the search box last, all 48px (0.9.0); in the Divi editor the bar is styled too, because the wp_head hook also prints the styles when tcc_site_in_divi_editor() says yes (0.9.7); one menu per row on phones 480px wide or less so "All speakers" is not cut short (0.9.6); the "Show more" button is the quiet white button shared with Events, Community Groups and Trinity Talk (0.9.1).',
		),
		'sermon-page'       => array(
			'leans'  => 'The Divi Theme Builder layout "Individual sermon page - NEW", and the feature "Sermons page: search, filters and series", which must be on (it works out series, speaker, book and topic). Layer names it looks for: the CSS ID tcc-sermon-long on the long description (for "Read the full summary"), and the classes tcc-sp-player, tcc-sp-eyebrow, tcc-sp-byline, tcc-sp-series, tcc-sp-cell, tcc-sp-row with tcc-sp-prev or tcc-sp-next, tcc-sp-step, tcc-sp-pic and tcc-sp-card. It gives Divi three lists to loop over: "Sermon page: previous part of the series (automatic)", "... next part ..." and "Sermon page: more sermons (automatic)". The Video / Audio switch is a Divi Pixel Content Toggle holding the Divi Library layouts "Sermon Video" and "Sermon Podcast". Part numbers go by date, oldest first. [tcc_sermon_crumbs] prints the trail of the "Page trail" feature when that is on.',
			'check'  => 'A sermon in the middle of a series (previous and next rows, "Part 6 of 27", four cards at the foot), the first and the last part of a series, and a sermon in no series. At 1920, 1440, 768 and 375 wide. Press a "Find more like this" button: the Sermons page should open already filtered.',
		),
		'trinity-talk'      => array(
			'leans'  => 'Three Divi Theme Builder templates named "Trinity Talk: one piece - NEW (shows automatically)", "Trinity Talk: a book\'s page - NEW (shows automatically)" and "Trinity Talk: home - NEW (shows automatically)". They are deliberately NOT assigned to anything; this file finds each by the short code its body holds ([tcc_talk_panel], [tcc_talk_book_panel], [tcc_talk_shelf]) and shows it with the filter et_theme_builder_template_layouts on a single "article", on a "trinity-talk" category page, and on the article archive (/articles/). The heading categories New Testament and Old Testament show the home layout. The older templates stay assigned underneath, so switching the feature off is the rollback. A piece is a post of the type "article" (made with ACF); its book is a "trinity-talk" category filed under New Testament; its chapter number is read from the start of its title ("Matthew 5 | ..."), and chapters are ordered by that number. Everything is worked out once in tcc_talk_index(), remembered for 12 hours and worked out again when an article or a Trinity Talk category is saved. It gives Divi five lists to loop over (hidden post types answered by posts_pre_query): previous chapter, next chapter, more from this book, every chapter of this book, pieces in no book. Layer classes it looks for: tcc-tt-facts, tcc-tt-prose, tcc-tt-side, tcc-tt-book-side, tcc-tt-steps, tcc-tt-cell, tcc-tt-row with tcc-tt-prev, tcc-tt-next or tcc-tt-list-row, tcc-tt-tile, tcc-tt-step, tcc-tt-card, tcc-tt-clamp with tcc-tt-clamp-2 or tcc-tt-clamp-3, tcc-tt-row-meta and tcc-tt-loose. The trail comes from the "Page trail" feature, which asks this file for the steps (tcc_talk_trail_steps). "Read Matthew 5 in the Bible" is a plain link to biblegateway.com in the ESV (the translation is one word in tcc_talk_panel_shortcode).',
			'check'  => 'One piece in the middle of a book (/article/matthew-5-choosing-to-walk-the-hard-path/), the first and last chapter of a book, a piece in no book, a book page (/trinity-talk/matthew/), a book with one piece (/trinity-talk/jude/), /trinity-talk/christian-living/ and the home page /articles/. At 1920, 1440, 768 and 375 wide. Add ?tcc_talk_test=old to an address while signed in as an administrator to see the older page beside it. Then the three layouts in the Divi editor.',
		),
		'page-trail'        => array(
			'leans'  => 'A Divi Text layer that holds only [tcc_trail], labelled "Back link (automatic)", placed above the title in every layout that has a page title: the shared page heading that ordinary pages use, and the Theme Builder layouts for the Events page, an event, a community group, the Sermons page, the series page, the sermon page ([tcc_sermon_crumbs] there), the Trinity Talk pages and the search page. It prints one link: an arrow and the name of the top-level page of that part of the site, or Home on a top-level page. tcc_trail_back() decides where it points: events and community groups are named there by their WordPress post type (tribe_events, project); an ordinary page (is_page) goes to its direct parent page; everything else (sermons, series, Trinity Talk) uses the first step of tcc_trail_steps(), so a sermon goes to Sermons and not to its series. The Trinity Talk feature supplies its own steps through tcc_talk_trail_steps(). The gap under the link is the Text layer\'s own bottom margin in Divi, not CSS from this file. The arrow is a character of Divi\'s icon font (ETmodules), so it needs Divi\'s icons loaded on the page. Its style block (id tcc-trail-css) is excluded from WP Rocket\'s Remove Unused CSS by two filters at the foot of the file; without them WP Rocket can empty the block and the link shows unstyled to signed-out visitors, so check signed out as well as signed in. If this feature is off, a stand-in in the main plugin file makes [tcc_trail] print nothing.',
			'check'  => 'An ordinary top-level page (Give: Home), a page below one (Men\'s Ministry: Ministries), a page two levels down (The Blessed Life: Core Classes Archive), /events/ (Home), one event (Events), /community-groups/ (Home), one group (Community Groups), /sermons/ (Home), a series page and a sermon page (Sermons), a Trinity Talk piece (Trinity Talk) and a search results page (Home). The arrow and name should sit at the same place on every one, at 1920, 1440, 768 and 375 wide, and the link should be easy to press on a phone.',
		),
		'first-view-styles' => array(
			'leans'  => 'How Divi prints styles. On the first view after a Divi save, and on every view of a page with a Divi loop, Divi prints the page\'s styles far down the page; this file collects the whole page before it is sent (output buffering started on template_redirect) and moves those style blocks into the head, keeping their order. It never runs in the admin, in the Divi editor, or for feeds and background requests. WP Rocket\'s "Remove Unused CSS" also processes styles: left alone it puts those in-page blocks before Divi\'s defaults, so the defaults win (the phone header stacked on three lines). Since 0.5.4 this file adds "cached-inline-styles" to WP Rocket\'s filter rocket_rucss_inline_atts_exclusions so WP Rocket leaves the blocks in place. After changing this, clear WP Rocket\'s Used CSS and cache.',
			'check'  => 'As a signed-out visitor, open /sermons/, a series page, /events/ and a search page with the network slowed down: the page should not flash plain teal pill buttons before settling. View the page source: no large <style> block should sit after the content. Check an event page and an ordinary page still look right. With WP Rocket on, open /events/ and /sermons/ signed out at 375 wide: the header must be one line (logo, Give, Menu).',
		),
		'termly-look'       => array(
			'leans'  => 'Termly, the cookie service (its script is added by the site\'s cookie setup, not by this plugin). Termly draws the banner (class t-consentPrompt) and the Preferences window (t-preference-modal, with its buttons t-declineAllButton and t-allowAllButton beside it) straight into the page, with style names such as termly-styles-button-a5641f whose endings change; the rules match the start of those names ([class*="termly-styles-button"]). This file prints one <style id="tcc-termly-look"> in the head of every page and tells WP Rocket\'s Remove Unused CSS to keep it (by that id, and by the text .t-consentPrompt), because the banner is added after the page loads. The policy pages show Termly\'s text in an iframe from termly.io, which no site styles can reach.',
			'check'  => 'Signed out in a private window (or after clearing this site\'s stored data) so the banner shows: 15px words, teal links, Decline and Accept as 48px teal buttons with 10px corners, Preferences as the white quiet button. Press Preferences, and Consent Preferences in the footer: the window has 15px corners, a 26px title and 15px words; the tick boxes are teal. At 1440 and 375 wide. Then press Decline and Accept once each and reload: the banner must stay away (this file must not change what it does).',
		),
		'admin-look'        => array(
			'leans'  => 'Nothing outside WordPress itself. On the sign-in page it prints a small <style id="tcc-admin-look-login"> on login_enqueue_scripts (the logo as the background of #login h1 a, 300 by 113 pixels, and 20px corners on .login form) and uses the filters login_headerurl (the home page), login_headertext (the site name) and register (empty, so no Register link). In the admin it prints <style id="tcc-admin-look"> on admin_head (the menu logo, 15px corners on #adminmenu .wp-submenu when it pops out, and #contextual-help-link-wrap hidden) and a few lines of script on admin_footer that put <a id="tcc-admin-logo"> with the logo at the top of #adminmenuwrap, because WordPress has no hook there. The logo is hidden when the menu is folded, and at 960px wide or less (on phones the menu slides out under the admin bar, which would cut the logo off). On wp_dashboard_setup (priority 99) it removes the boxes dashboard_activity, dashboard_quick_press and dashboard_primary and the Welcome panel. The logo address is in tcc_admin_look_logo_url() (a picture in uploads/2022/05). It replaced the plugin AGCA - Custom Dashboard & Login Page in 0.10.0; AGCA\'s other settings (custom menu, colours, CSS and JavaScript) were all empty, so nothing else was carried over.',
			'check'  => 'Sign out and open /wp-login.php at 1440 and 375 wide: the church logo (not the WordPress logo) above a box with rounded corners, no Register link, and the logo goes to the home page. Sign in: the Dashboard has no Welcome, Activity, Quick Draft or WordPress Events and News box, no grey Help tab at the top right, and the church logo sits at the top of the left-hand menu (opens the website in a new tab). Point at a menu item such as Pages: the menu that pops out has round corners. Fold the menu (Collapse menu): the logo hides and nothing overlaps. At 375 wide open the menu: no logo, and nothing peeks out under the black bar.',
		),
		'event-search-text' => array(
			'leans'  => 'Yoast SEO (it does nothing without it). It reads the wording typed under Yoast SEO > Settings > Events and > Event Categories (the option wpseo_titles) and hands it to Yoast\'s filters for the Events page and event category pages. For one event with no Yoast description it uses the event\'s Planning Center summary (the custom field _tcc_pco_summary), or the start of its description, cut to about 155 characters. A description typed in Yoast on the event always wins.',
			'check'  => 'View the page source of /events/, one event category page, and one event that came from Planning Center: look at <title>, <meta name="description"> and the og: tags. A page for one month or one day should keep The Events Calendar\'s own dated title.',
		),
	);
}

/** The briefing for the whole plugin, and one per file that can be edited. Used by code-edits.php. */
function tcc_site_ai_notes() {
	$features = tcc_site_features();
	$on       = tcc_site_switches();
	$notes    = tcc_site_ai_feature_notes();

	$plugin = array(
		'What it is: the church\'s own small website features in one plugin. Each feature fills in something Divi and the other plugins cannot do by themselves. The pages are still built in Divi; this plugin only supplies the automatic parts those pages call for.',
		'',
		'How it is put together:',
		'- tcc-site-features.php is the main file. It holds the list of features (the function tcc_site_features: each has a key, a label, what it does, where it is used, what a visitor notices if it is off, the short codes it provides, and any feature it needs). It loads the file features/<key>.php for every feature that is switched ON. It also holds tcc_site_in_divi_editor(), which features ask before showing a plain preview inside the Divi editor: yes only for a signed-in editor, on the editor\'s own page (?et_fb) or the editor\'s requests to /wp-json/divi/. The switches are saved in the WordPress option tcc_site_features (key => 1). A new install starts with everything off.',
		'- features/<key>.php: one file per feature. Each wraps its code in  if ( ! function_exists( \'...\' ) ) { }  so a second copy of the same code (an old snippet in the Code Snippets plugin) can never clash with it. A feature file that fails to load is skipped and reported on the Features tab; the rest of the website carries on.',
		'- admin.php draws the screen TCC Website with its tabs: Features (a switch and a status for each feature: Working, Needs a look, Off), Search (belongs to the sitewide search feature) and Help. Each feature on the Features tab has a link to its code. Switching a feature clears the WP Rocket and SiteGround page caches.',
		'- help.php is the Help tab, written for volunteers. updater.php brings new versions from the public GitHub repository tccknox/tcc-pco-sync-releases (folder tcc-site-features); a person still presses "Update now" on the Plugins screen. code-edits.php draws the code pages and saves edits. ai-prompts.php is the wording of this briefing.',
		'',
		'How Divi uses the features (this is where most "it stopped working" problems come from):',
		'- Short codes such as [tcc_event_facts] sit in Divi Text layers. A layer filled in by a feature is labelled "(automatic)" in the Divi builder.',
		'- Some features give Divi a ready-made list to loop over. In a Divi loop\'s settings it appears as a post type with "(automatic)" in its name, for example "Upcoming Events (automatic)".',
		'- Some features find a Divi layer by its CSS ID or class (set in Divi under Advanced > Attributes), for example tcc-events or tcc-sermon-card. If someone renames or removes that in Divi, the feature quietly stops working. Always consider this before changing code.',
		'- The layouts live in Divi > Theme Builder. Older versions are kept beside the new ones, named "OLD (kept for rollback)".',
		'',
		'What can and cannot be changed inside WordPress: every feature file and the Help tab can be. The list of features, the admin screen, the updater and code-edits.php itself cannot; those need the church\'s GitHub repository. So a brand-new feature cannot be added from inside WordPress, but an existing one can be changed.',
		'',
		'If a change alters what a feature does or how a volunteer uses it, also give the new wording for the Help tab (file help.php), so the help stays true.',
		'',
		'The features (ON or OFF is how they are set on this website right now):',
	);
	foreach ( $features as $key => $feature ) {
		$line  = '- ' . $feature['label'] . ' [' . ( empty( $on[ $key ] ) ? 'OFF' : 'ON' ) . '] (file features/' . $key . '.php). ' . $feature['what'] . ' Used: ' . $feature['where'];
		$line .= $feature['codes'] ? ' Short codes: ' . implode( ' ', $feature['codes'] ) . '.' : '';
		$line .= '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) ? ' Needs the feature "' . $features[ $feature['needs'] ]['label'] . '".' : '';
		$line .= ! empty( $feature['events'] ) ? ' Needs The Events Calendar plugin.' : '';
		$plugin[] = $line;
	}

	$files = array();
	foreach ( $features as $key => $feature ) {
		$part   = array();
		$part[] = 'What it does: ' . $feature['what'];
		$part[] = 'Where it is used: ' . $feature['where'];
		$part[] = 'If it were switched off, a visitor would notice: ' . $feature['off'];
		$part[] = 'It is switched ' . ( empty( $on[ $key ] ) ? 'OFF' : 'ON' ) . ' on this website right now (TCC Website > Features).';
		if ( $feature['codes'] ) {
			$part[] = 'Short codes it provides: ' . implode( ' ', $feature['codes'] ) . '. The Help tab explains each one for whoever builds the pages.';
		}
		if ( '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) ) {
			$part[] = 'It cannot work without the feature "' . $features[ $feature['needs'] ]['label'] . '" (file features/' . $feature['needs'] . '.php), which must be switched on as well.';
		}
		if ( ! empty( $feature['events'] ) ) {
			$part[] = 'It needs The Events Calendar plugin to be active.';
		}
		$part[] = 'The Features tab decides whether this feature is "Working" by checking that the function ' . $feature['fn'] . '() exists and comes from this file. Keep that function, with that name, inside the file.';
		if ( '' !== $feature['snippet'] ) {
			$part[] = 'Before this plugin existed it was the Code Snippets snippet "' . $feature['snippet'] . '". That old copy is kept, deactivated, under Snippets as a fallback.';
		}
		if ( isset( $notes[ $key ] ) ) {
			$part[] = 'What it leans on outside this file: ' . $notes[ $key ]['leans'];
			$part[] = 'Pages to check after any change: ' . $notes[ $key ]['check'];
		}
		$part[] = 'The long comment at the top of the file explains the rest. Read it before changing anything.';
		$files[ 'features/' . $key . '.php' ] = implode( "\n", $part );
	}

	$files['help.php'] = implode(
		"\n",
		array(
			'What it is: the Help tab (TCC Website > Help), one function, tcc_site_help_tab(), that prints panels of plain-English help.',
			'Who reads it: church volunteers, not programmers. Keep every sentence short and plain. Say where to click. Avoid jargon; where a technical word is needed (short code, CSS class), it belongs in the last panel, "For whoever builds the pages".',
			'How it is arranged: what the plugin does; the features; how to switch one on or off; where to find things; what it is connected to; changing the code and asking an AI; if something looks wrong (grouped by area, each item a bold symptom followed by what to do); and the short codes for whoever builds the pages.',
			'The list of features and their status labels are drawn from tcc_site_features() automatically, so only the hand-written panels need editing.',
			'Rules: every piece of text printed must be escaped or be fixed text written in this file; keep the function name and its three arguments; keep the panels\' CSS classes (tcc-card, tcc-help, tcc-pill).',
			'Pages to check after any change: TCC Website > Help at a wide screen and at phone width (the tables stack on a narrow screen).',
		)
	);

	return array(
		'plugin' => implode( "\n", $plugin ),
		'files'  => $files,
	);
}
