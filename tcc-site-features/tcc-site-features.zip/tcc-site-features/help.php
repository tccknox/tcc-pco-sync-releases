<?php
/**
 * TCC Website Features: the Help tab.
 *
 * Written for volunteers. It says what the plugin does, how the main job is done, where to find
 * things, what it is connected to, what to do when something looks wrong (grouped by the part of the
 * website), how to change the code safely, and how to brief an AI assistant. Keep it in plain
 * English and keep it true: when a feature changes, change the matching lines here in the same version.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_site_help_tab( $features, $on, $statuses ) {
	$features_link = '<a href="' . esc_url( tcc_site_url( 'features' ) ) . '">Features</a>';
	$pill          = function ( $ok, $yes, $no ) {
		return $ok ? '<span class="tcc-pill tcc-pill--ok">' . esc_html( $yes ) . '</span>' : '<span class="tcc-pill tcc-pill--muted">' . esc_html( $no ) . '</span>';
	};

	$code_link = '<a href="' . esc_url( tcc_site_url( 'features' ) ) . '">TCC Website &rarr; Features</a>';

	echo '<div class="tcc-help">';

	// A way to jump straight to a part of this long page.
	echo '<div class="tcc-card tcc-jump"><strong>On this page:</strong> ';
	$jumps = array(
		'tcc-help-what'    => 'What this does',
		'tcc-help-list'    => 'The features',
		'tcc-help-switch'  => 'Switching a feature on or off',
		'tcc-help-one-event' => 'Adding something to one event',
		'tcc-help-where'   => 'Where to find things',
		'tcc-help-links'   => 'What it is connected to',
		'tcc-help-wrong'   => 'If something looks wrong',
		'tcc-help-code'    => 'Changing the code',
		'tcc-ai'           => 'Asking an AI assistant',
		'tcc-help-builder' => 'For whoever builds the pages',
	);
	foreach ( $jumps as $id => $label ) {
		echo '<a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</div>';

	echo '<div class="tcc-card" id="tcc-help-what"><h2>What this does</h2>';
	echo '<p>It holds the small pieces of the website that the church had built for itself, the things Divi and the other plugins cannot do on their own. Each piece is a <strong>feature</strong> with its own switch.</p><ul>';
	echo '<li>The pages themselves are still built and edited in <strong>Divi</strong>. This plugin only supplies the automatic parts those pages use.</li>';
	echo '<li>It has <strong>no settings to fill in</strong>. Each feature is either on or off.</li>';
	echo '<li>If switching a feature off and on is not enough, each feature has a link, <em>See or edit the code</em>, that lets an administrator look at or change its code, with one button to put the original back.</li>';
	echo '<li>Most weeks nobody needs to open this screen. Come here when something on the website looks wrong, or to check that everything is working.</li>';
	echo '</ul></div>';

	echo '<div class="tcc-card" id="tcc-help-list"><h2>The features</h2><table>';
	foreach ( $features as $key => $feature ) {
		$status = $statuses[ $key ];
		echo '<tr><th>' . esc_html( $feature['label'] ) . '<br><span class="tcc-pill tcc-pill--' . esc_attr( $status['level'] ) . '">' . esc_html( $status['label'] ) . '</span></th>';
		echo '<td>' . esc_html( $feature['what'] ) . '<br><span class="tcc-muted"><strong>Where:</strong> ' . esc_html( $feature['where'] ) . '<br><strong>If it were switched off:</strong> ' . esc_html( $feature['off'] ) . '</span></td></tr>';
	}
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-switch"><h2>How to switch a feature on or off</h2><ol>';
	echo '<li>Open the ' . $features_link . ' tab.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped above.
	echo '<li>Find the feature and press <strong>Switch on</strong> or <strong>Switch off</strong>. Switching off asks you to confirm and tells you what visitors would notice.</li>';
	echo '<li>The change happens straight away. Open the website and look at a page that uses it (each feature says where it is used).</li>';
	echo '<li>If it is not what you expected, press the button again to put it back. Nothing is lost by switching a feature off and on.</li>';
	echo '</ol><p class="tcc-muted">Leave a feature on unless you have a reason to switch it off. Every one of them is used somewhere on the website.</p></div>';

	echo '<div class="tcc-card" id="tcc-help-one-event"><h2>How to add a button or picture to one event only</h2><ol>';
	echo '<li>Go to <strong>Events</strong> and open the event. If its edit screen shows a purple <strong>Use The Divi Builder</strong> button, the event has not been set up for Divi yet: press it once (this is needed only the first time for each event; Divi should keep any words already on the event, but look at the page afterwards to be sure). Then press <strong>Build On The Front End</strong> (or, later, <em>Edit With Divi</em>). Until an event is set up this way, adding <code>?et_fb=1</code> to its address just shows the normal page.</li>';
	echo '<li>Scroll to <strong>About this event</strong>. Under it is a box with a teal dashed edge and the words <em>This event only: add buttons, pictures or text here</em>.</li>';
	echo '<li>Press the <strong>+</strong> inside that box and add a Button, Image or Text. Fill it in as usual.</li>';
	echo '<li>Press <strong>Save</strong> (a real click on the Save button; nothing is kept until you do).</li>';
	echo '<li>Open the event on the website to check it, and open one other event to check that it is not there.</li>';
	echo '</ol><p><strong>Events from Planning Center that repeat:</strong> each date is its own event on the website, so something added to one date is not on the others. Add it to each date that needs it. A date that Planning Center adds later starts with a copy of what the date before it had.</p>';
	echo '<p>Everything else on the page (the title, the banner with the day and time, Add To Calendar, the Location card) is the <strong>shared event template</strong>. Changing it changes every event, and Divi lets you change it with one click, without any warning of its own. So whenever you open a part of the shared template, a dark notice appears just under the menu saying <em>You are changing the shared event template</em>. If you see it, close that part without changing anything. If you already changed something, press <strong>Exit</strong>, choose not to save, and start again from step 1.</p>';
	echo '<p class="tcc-muted">While you edit, the template shows this event\'s own day, time, place, description, rooms and Register button, as they will look on the website. These come from the event itself (and from Planning Center), not from the editor: change them on the event\'s edit screen or in Planning Center, not in Divi. The Register button for one event is set in the <em>Planning Center and registration</em> box on the event\'s edit screen. Both of these come from the feature <em>Event details and labels in the Divi editor</em>.</p></div>';

	echo '<div class="tcc-card" id="tcc-help-where"><h2>Where to find things</h2><table>';
	echo '<tr><th>' . $features_link . '</th><td>Every feature, whether it is working, and its switch. Under each switch is <em>See or edit the code</em>, for troubleshooting: an edit is saved as a separate copy and one button puts the original back, and each file has a ready-made briefing to hand to an AI assistant. Also the button that checks for a new version.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Divi &rarr; Theme Builder</th><td>The layouts that use these features: the header (Events menu), the Events page, the individual event page, the Sermons page, the series page and the sermon page. Layers that a feature fills in are labelled "(automatic)". The back link above the title on the Sermons, series, sermon and search pages is one of them: the layer still called "Trail: Home &gt; ... (automatic)" (its name from before it became one back link), filled in by the <em>Page trail</em> feature.</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Search results - SITEWIDE (new)"</th><td>The frame of the search page: its heading, the search-again box and the results area. It is not assigned to anything in the Theme Builder on purpose: the <em>Sitewide search page</em> feature shows it for searches of the whole website. The older results page, which is assigned to "Search Results", is what shows when that feature is off.</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Sermons page - NEW" and "Sermon series page - NEW"</th><td>The Sermons page and the page each sermon series gets. Both are ordinary Divi layouts: the cards are Divi loops, and the layers the <em>Sermons page: search, filters and series</em> feature fills in are labelled "(automatic)". The older Sermons page is kept beside them, named "OLD (kept for rollback)".</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Individual sermon page - NEW"</th><td>The page every sermon gets. It is an ordinary Divi layout: the player and its Video / Audio switch (a Divi Pixel Content Toggle), the title, the short and long descriptions, the previous and next rows and the four cards at the foot are all Divi layers, and the layers the <em>Sermon page (one sermon)</em> feature fills in are labelled "(automatic)". The sermon page as it was before is kept beside it, named "Individual sermon page - OLD (kept for rollback)". The two players inside the switch are the Divi Library layouts "Sermon Video" and "Sermon Podcast" (Divi &rarr; Divi Library).</td></tr>';
	echo '<tr><th>Posts &rarr; Categories</th><td>Where a <strong>sermon series</strong> is set up. A series is a category filed under "Series". Its <strong>Description</strong> box is the text shown on the series page, and its <strong>Series graphic</strong> field is the picture on its card and page. Speakers, books of the Bible and topics are categories too, filed under "Speaker", "Bible" and "Topics".</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; the three "Trinity Talk: ... - NEW (shows automatically)" templates</th><td>The page of one Trinity Talk piece, the page of one book, and the Trinity Talk home page. They are ordinary Divi layouts: the words of the piece, the rows and the cards are Divi layers, and the layers the <em>Trinity Talk pages</em> feature fills in are labelled "(automatic)". They are not assigned to anything in the Theme Builder on purpose: the feature shows them on the right pages. The older Trinity Talk layouts are still assigned underneath and show again if the feature is switched off.</td></tr>';
	echo '<tr><th>Articles, and Articles &rarr; Trinity Talk</th><td>Where the Trinity Talk pieces are written (<strong>Articles</strong>) and where the books are (<strong>Trinity Talk</strong>, the categories). A piece belongs to a book when it has that book\'s category, and its chapter number is read from the start of its title, for example "Matthew 5 | Choosing to Walk The Hard Path".</td></tr>';
	echo '<tr><th>TCC Website &rarr; Search</th><td>Two things for the website search: the list of <strong>searches that found nothing</strong> (what visitors looked for and could not find), and the <strong>words that mean the same</strong> (so "kids" also finds "children"). It also says what the search reads.</td></tr>';
	echo '<tr><th>Yoast SEO &rarr; Settings &rarr; Events, and Event Categories</th><td>The wording search engines show for the Events page and for each event category page: the <strong>SEO title</strong> and <strong>Meta description</strong> boxes. The <em>Events: titles and descriptions for search engines</em> feature puts that wording on those pages. For one event, the description is typed on the event itself, in the Yoast SEO box under the editor.</td></tr>';
	echo '<tr><th>Pages</th><td>The home page and the ministry and class pages hold event cards. Each card area is a normal Divi loop that uses an "Upcoming Events (automatic)" list.</td></tr>';
	echo '<tr><th>Events</th><td>The events themselves (The Events Calendar). The feeds show whatever upcoming events are published there.</td></tr>';
	echo '<tr><th>Snippets</th><td>Where these features lived before this plugin. The old copies are kept there, deactivated, as a safety net. Please do not delete them.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-links"><h2>What it is connected to</h2><table>';
	echo '<tr><th>Divi</th><td>The pages and layouts call these features by short codes (listed at the bottom of this page) and by choosing an "Upcoming Events (automatic)" list in a loop. Those are set in the Divi editor, on the layer that shows them.</td></tr>';
	echo '<tr><th>The Events Calendar</th><td>' . $pill( function_exists( 'tribe_get_events' ), 'Active', 'Not active' ) . ' Every event feature reads its events from here. If it is switched off under <strong>Plugins</strong>, the event lists are simply empty.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Planning Center Sync</th><td>' . $pill( function_exists( 'tcc_pco_shows' ), 'Active', 'Not active' ) . ' The church\'s other plugin (<strong>Planning Center</strong> in the left menu). The event page banner follows its "what shows" choices (location, end time), and the feeds use it to treat the dates of one repeating event as one event. Both features also work without it.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Buzzsprout</th><td>The sermon audio player comes from Buzzsprout. It uses the podcast code saved in the <strong>Podcast</strong> field on each sermon (Sermons &rarr; the sermon &rarr; Sermon Info). No sign-in is stored on the website.</td></tr>';
	echo '<tr><th>The cookie banner (Termly)</th><td>Termly can hold back outside players until a visitor agrees. buzzsprout.com is marked Essential in Termly (Consent Management &rarr; Domain Rules) so the audio player always loads. The banner and its Preferences window are given the website\'s look by the feature <em>Cookie banner and preferences window in the church\'s look</em>. The text on the Privacy Policy, Terms &amp; Conditions and Cookie Policy pages is shown in a Termly frame and keeps Termly\'s look; that is set in Termly.</td></tr>';
	echo '<tr><th>Google Maps</th><td>"Get directions" on an event page is an ordinary link that opens Google Maps with the event\'s address. Nothing is set up for it.</td></tr>';
	echo '<tr><th>Yoast SEO</th><td>' . $pill( defined( 'WPSEO_VERSION' ), 'Active', 'Not active' ) . ' Writes the titles and descriptions search engines see. The Events feature reads the wording typed under Yoast SEO &rarr; Settings and hands it to Yoast for the Events pages. Without Yoast it does nothing.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Code Snippets</th><td>' . $pill( defined( 'CODE_SNIPPETS_VERSION' ) || function_exists( 'code_snippets' ), 'Active', 'Not active' ) . ' The plugin behind <strong>Snippets</strong> in the left menu. It still runs a few other snippets, and it holds the old, deactivated copies of these features.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Updates</th><td>Version ' . esc_html( TCC_SITE_VERSION ) . '. New versions come from <code>github.com/' . esc_html( TCC_SITE_RELEASES ) . '</code> and show on the <strong>Plugins</strong> screen like any other update. No password is stored for this.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-wrong"><h2>If something looks wrong</h2>';
	echo '<p class="tcc-muted">Find the heading for the part of the website that looks wrong. Each line starts with what you see, then says what to do.</p>';
	echo '<h3 id="tcc-help-wrong-start">Start here</h3><ul>';
	echo '<li><strong>Look at the ' . $features_link . ' tab first.</strong> Each feature should say <em>Working</em>. One that says <em>Needs a look</em> explains why underneath, in plain words.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-events">Events</h3><ul>';
	echo '<li><strong>The event cards are missing everywhere.</strong> Check that <em>Event feeds</em> is on, and that The Events Calendar is active under Plugins. If both are fine, check that there really are upcoming, published events under <strong>Events</strong>.</li>';
	echo '<li><strong>Something added to one event shows on every event.</strong> It was added to the shared event template instead of the event\'s own box. Open Divi &rarr; Theme Builder, open the event template (the one assigned to All Events) and remove it there, then add it again inside the teal <em>This event only</em> box of that one event (see <a href="#tcc-help-one-event">How to add a button or picture to one event only</a>).</li>';
	echo '<li><strong>In the Divi editor an event shows "(filled in automatically)" instead of its day, time and place, or has no teal "This event only" box.</strong> Check that <em>Event details and labels in the Divi editor</em> is on. Visitors are not affected either way. If it is on and the words still show, the event may be a draft or have no date yet; save it with a date and open the editor again.</li>';
	echo '<li><strong>A new or changed event is not on the cards yet.</strong> The lists are remembered for up to 10 minutes and refresh whenever an event is saved. Open the event, press Update, and look again.</li>';
	echo '<li><strong>One ministry page shows no events.</strong> That page only shows events in its own category. Open one of the events and check its Event Categories.</li>';
	echo '<li><strong>The filter bar is missing from the Events page.</strong> Check that <em>Events filter bar</em> and <em>Event feeds</em> are both on. The bar also hides itself when there are fewer than two upcoming events.</li>';
	echo '<li><strong>Only twelve events show.</strong> That is on purpose: press <em>Show 12 more</em> under the cards. Choosing any filter shows every match. The number beside "Upcoming Events" (a <code>&lt;span class="tcc-events-count"&gt;</code> in the heading) is how many there are in all.</li>';
	echo '<li><strong>The website looks right to you but not to visitors</strong> (an old colour, a missing style, a plain "#" where an arrow should be). WP Rocket keeps its own copies of pages. Go to Settings &rarr; WP Rocket and press <em>Clear Used CSS</em>, then <em>Clear and Preload Cache</em>, and look again in a private window.</li>';
	echo '<li><strong>An event shows the wrong description in Google or when its link is shared.</strong> Open the event and type one in the Yoast SEO box under the editor (Meta description). What is typed there always wins. When that box is empty, the <em>Events: titles and descriptions for search engines</em> feature uses the event\'s Planning Center summary, or the start of its description. Google can take days or weeks to show a change.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-search">Search</h3><ul>';
	echo '<li><strong>A page, sermon or event is missing from a search.</strong> Searches are remembered for 10 minutes and start afresh whenever a page, sermon, article, group or event is saved. Only published items show, only events that are still to come, and pages set to "do not show in search results" in Yoast are left out.</li>';
	echo '<li><strong>A sermon or group does not come up for a word that is in its description.</strong> Search reads titles and page text, plus these fields: on a sermon, <em>Sermon Description - Short</em>, <em>Sermon Description - Long</em>, <em>Speaker Name</em> and its categories (Bible book, topic, series, speaker); on a community group, its description, organizer, meeting time, location and ages. Check the word is in one of those, then save the sermon or group again.</li>';
	echo '<li><strong>A writer\'s name does not find their Trinity Talk pieces.</strong> Search also reads the name of the account a piece or sermon was saved under (Users &rarr; the person &rarr; <em>Display name publicly as</em>). Check the piece is saved under that person (on its edit screen, the Author box). The church\'s own account, the sermon upload app and the web support accounts are left out on purpose, so that a search for &ldquo;church&rdquo; or &ldquo;sermon&rdquo; does not bring back everything they saved; that list is at the top of the search feature\'s code (<code>tcc_search_author_skip</code>).</li>';
	echo '<li><strong>Visitors search for a word the website does not use.</strong> Open the <strong>Search</strong> tab. "Searches that found nothing" shows the words; add the word to a line under "Words that mean the same" beside the word the website does use (for example <code>vbs, vacation bible school</code>), and press Save the list.</li>';
	echo '<li><strong>A search brings up too much.</strong> A line under "Words that mean the same" may be too broad. Take the loose word off that line and save. "Put the starting list back" undoes all changes to the list.</li>';
	echo '<li><strong>A community group is missing from search.</strong> Open the group and check that "Is This Group Active?" is ticked. Groups with it unticked are left out.</li>';
	echo '<li><strong>Only the first 30 of a long list show.</strong> Under the list there is a "See all" link. It opens a page with only that kind of result, shown 30 at a time.</li>';
	echo '<li><strong>The search page looks like the old one.</strong> Check that <em>Sitewide search page</em> is on. It also needs the Theme Builder template "Search results - SITEWIDE (new)" to exist and to still hold the layer with <code>[tcc_search_results]</code> in it.</li>';
	echo '<li><strong>Sitewide search page says "Needs a look".</strong> The note under it says which of these it is: its Divi template is missing; Divi stopped showing the new page (visitors still get the older results page, which works); the new template was assigned to Search Results by mistake (it should be left unassigned, with the OLD search template assigned); a kind of content or the <em>Event feeds</em> feature is missing, so that group is left out; or the Events, Sermons or Community Groups page was moved or renamed, so its "See all" link is left off until the address in the code is updated.</li>';
	echo '<li><strong>Search shows a different word from the one typed.</strong> That is the spelling help: when nothing matches, it tries the closest word used in a title on the website, and says so above the results.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-groups">The Community Groups page</h3><ul>';
	echo '<li><strong>How the page works.</strong> The cards are ordinary Divi: a loop over Community Groups that shows every group with <em>Is this group active</em> ticked, A to Z. To add or retire a group, tick or untick that box on the group; there is nothing to change on the page. The feature <em>Community Groups filter bar</em> only adds the bar above the cards and the number beside the heading.</li>';
	echo '<li><strong>The filter bar is missing.</strong> Check that <em>Community Groups filter bar</em> is on. The bar also hides itself when there are fewer than two groups. In Divi, the list of cards must keep the CSS ID <code>tcc-groups</code> and each card the CSS class <code>tcc-group-card</code> (Advanced &rarr; Attributes).</li>';
	echo '<li><strong>A group is not found under its day, or under Women or Men.</strong> The bar reads the group\'s own fields: <em>Gender-Specific</em>, <em>How Often</em>, and the day names written in <em>Date And Meeting Time</em> (for example "Thursdays at 7:00 PM"). Fix the field on the group. A meeting time with no day name in it, such as "Twice a month", is only found under <em>Any day</em>.</li>';
	echo '<li><strong>A menu is missing from the bar, or a choice is missing from a menu.</strong> That is on purpose: a menu only lists choices that at least one group has, and a menu with fewer than two choices is hidden.</li>';
	echo '<li><strong>Only twelve groups show.</strong> That is on purpose, the same as the Sermons and Events pages: press <em>Show 12 more</em> under the cards. Choosing any filter shows every group that matches.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-sermons">The Sermons page and series pages</h3><ul>';
	echo '<li><strong>A new sermon is not on the Sermons page, or not under its series.</strong> The page is worked out afresh whenever a sermon or a category is saved, so open the sermon and press Update. Then check its categories: it needs one category under "Series" to belong to a series, and it shows under a speaker, book or topic only when it has that category.</li>';
	echo '<li><strong>A new series has no card.</strong> A series shows once at least one published sermon is in it. Create the category under "Series" (Posts &rarr; Categories), then put a sermon in it.</li>';
	echo '<li><strong>A series shows the wrong picture.</strong> Open the series under Posts &rarr; Categories and choose a picture in <em>Series graphic</em> (1920 by 1080 works best). Until one is chosen, the series borrows the graphic of its first sermon. A sermon with no graphic of its own borrows its series graphic on these pages; a sermon in no series shows the church\'s default graphic (the one chosen under Planning Center &rarr; Settings &rarr; Graphics).</li>';
	echo '<li><strong>A card says "Sermon from" and a date instead of a title.</strong> That sermon has no title. Open it under Posts, type its title and press Update.</li>';
	echo '<li><strong>The sermon card was changed in Divi but older sermons look different.</strong> Divi draws the newest 12 cards; older ones are copies of the first card, made when the page opens. Reload the page. For the copies to be filled in, keep the CSS classes on the card\'s layers: <code>tcc-sermon-pic</code> on the picture, <code>tcc-sermon-title</code> on the title and <code>tcc-sermon-series</code> on the series name.</li>';
	echo '<li><strong>Two people preached one sermon.</strong> Type both names in <em>Speaker Name</em> with a slash between them, for example "Tyler Lynde / Amy Lynde". The card shows the line as typed, and the Speaker menu lists the sermon under each person. Spell each name the same way every time: "Kelly Kinder" and "Kelly Kidner" would show as two speakers.</li>';
	echo '<li><strong>A sermon shows the wrong speaker.</strong> The card uses the <em>Speaker Name</em> field on the sermon. If that is empty it uses the sermon\'s Speaker category, and if that is empty too, the person who posted it.</li>';
	echo '<li><strong>A series card has no picture in the Divi editor.</strong> The card\'s picture layer uses Divi\'s own <em>Category Image</em>, which the feature fills with the series graphic, so the editor shows the real picture for each series. The small line under the name ("27 sermons &middot; 2025 to 2026") and the speaker and date lines are filled in by the feature, so the editor leaves them blank; the website shows them.</li>';
	echo '<li><strong>A visitor has JavaScript switched off.</strong> They see the newest 12 sermon cards, the series cards, and a plain list of every sermon that opens with one press. Search and the filters need JavaScript.</li>';
	echo '<li><strong>The search box and filters are missing from the Sermons page.</strong> Check that <em>Sermons page: search, filters and series</em> is on. The bar also needs the list of cards to keep its CSS ID <code>tcc-sermons</code> and each card to keep the layer "Speaker and date (automatic)".</li>';
	echo '<li><strong>In the Divi editor the filter bar does nothing.</strong> That is expected: the editor shows the bar with its look, but the menus and the search box only work on the website. The same goes for the Community Groups bar, which the editor shows as plain menus with a grey note.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-sermon">The page for one sermon</h3><ul>';
	echo '<li><strong>A sermon page does not say which series it is in, or has no previous and next rows.</strong> The sermon needs one category under "Series" (Posts &rarr; the sermon &rarr; Categories). The rows also need at least two sermons in that series. Part numbers go by date, oldest first, so a wrong part number means a wrong date on a sermon in that series.</li>';
	echo '<li><strong>The cards at the foot of a sermon page are not the ones expected.</strong> For a sermon in a series they are the four newest other parts of that series. For a sermon in no series they are the four newest other sermons.</li>';
	echo '<li><strong>A "Find more like this" button opens the Sermons page without choosing anything.</strong> The button uses the sermon\'s categories and its <em>Speaker Name</em>. Check that <em>Sermons page: search, filters and series</em> is on and that the name is spelled the same way as on that person\'s other sermons.</li>';
	echo '<li><strong>There is no "Read the full summary" button.</strong> That is right for a short write-up: the button only shows when the <em>Sermon Description - Long</em> text is long enough to be worth shortening. It also needs the long-description layer to keep its CSS ID <code>tcc-sermon-long</code>.</li>';
	echo '<li><strong>The Video side of a sermon is empty.</strong> Check the sermon\'s <em>Sermon Video</em> field holds the YouTube address. A visitor who has not answered the cookie banner may also see an empty player until they do.</li>';
	echo '<li><strong>A sermon has no audio.</strong> Check that <em>Sermon audio player</em> is on, then open the sermon and check that its Podcast field holds the Buzzsprout code for that episode.</li>';
	echo '<li><strong>A sermon page has to go back to how it was.</strong> Divi &rarr; Theme Builder: open the settings (cog) of "Individual sermon page - OLD (kept for rollback)", tick Posts &rarr; All Posts, press Save, then Save Changes at the top. That takes All Posts away from the new one. Nothing needs switching off.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-talk">Trinity Talk pages</h3><ul>';
	echo '<li><strong>A new piece is not on its book\'s page, or has no chapter number.</strong> Open it under Articles. It needs the book\'s category ticked in the <em>Trinity Talk</em> box (for example Matthew), and its title has to start with the book and chapter, then an upright bar: "Matthew 5 | Choosing to Walk The Hard Path". Press Update; the pages are worked out afresh whenever a piece is saved.</li>';
	echo '<li><strong>Chapters are in the wrong order.</strong> They go by the number at the start of the title, not by date. Check the title of the one that is out of place.</li>';
	echo '<li><strong>Two pieces show the same chapter number.</strong> That is right when two people wrote about the same chapter. Both show, the older one first.</li>';
	echo '<li><strong>The short summary on a row or card is not the one wanted.</strong> It is the first sentence or two of the piece. To choose the words, open the piece and type them in the Yoast SEO box, <em>Meta description</em>; that is used instead.</li>';
	echo '<li><strong>A piece shows under "More writing" on the Trinity Talk home page instead of under a book.</strong> It has no book category. Open it under Articles and tick its book in the <em>Trinity Talk</em> box.</li>';
	echo '<li><strong>A new book does not show on the home page.</strong> A book shows once it has a published piece. Create the category under Articles &rarr; Trinity Talk with <em>New Testament</em> as its parent, then put a piece in it.</li>';
	echo '<li><strong>The Trinity Talk pages have to go back to how they were.</strong> Switch <em>Trinity Talk pages</em> off on the Features tab. The older layouts are still assigned in the Theme Builder and show straight away. Nothing needs changing in Divi.</li>';
	echo '<li><strong>The pages show the older look although the feature is on.</strong> The feature finds its three templates by a short code each one holds: <code>[tcc_talk_panel]</code>, <code>[tcc_talk_book_panel]</code> and <code>[tcc_talk_shelf]</code>. If the layer holding one was deleted, that page falls back to the older layout. Put the short code back (the layer was labelled "(automatic)").</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-look">How pages look</h3><ul>';
	echo '<li><strong>The cookie banner or its Preferences window has small grey words and square buttons.</strong> Check that <em>Cookie banner and preferences window in the church\'s look</em> is on, then clear WP Rocket (Settings &gt; WP Rocket &gt; Clear Used CSS, then Clear and Preload Cache). If it is on and still plain, Termly may have renamed the parts it draws; the banner still works, it just has Termly\'s own look until the feature is updated.</li>';
	echo '<li><strong>A page appears for a moment with plain styles (teal pill buttons, wrong widths) and then settles.</strong> Check that <em>No flash of unstyled page</em> is on. Divi prints some pages\' styles far down the page: every page on its first view after a Divi save, and the Sermons, series, Events and search pages every time. That feature lifts them to the top of the page.</li>';
	echo '<li><strong>On a phone the header is tall, with the logo, Give and Menu on three lines.</strong> Check that <em>No flash of unstyled page</em> is on, then clear WP Rocket (Settings &gt; WP Rocket &gt; Clear Used CSS, then Clear and Preload Cache). That feature also stops WP Rocket from putting Divi\'s styles in the wrong order.</li>';
	echo '<li><strong>The back link above a title (an arrow and one name, such as &larr; Events) is missing, points to the wrong page, or sits too close to or too far from the title.</strong> Check that <em>Page trail</em> is on. The link is the short code <code>[tcc_trail]</code> alone in a Text layer above the title, labelled &ldquo;Back link (automatic)&rdquo; (on the sermon page, <code>[tcc_sermon_crumbs]</code>). An ordinary page points to the page above it, which is its Parent setting in WordPress (Pages &rarr; Quick Edit &rarr; Parent): Men\'s Ministry to Ministries, The Blessed Life to Core Classes Archive. An event points to Events, a community group to Community Groups, a sermon or series to Sermons, a Trinity Talk piece to Trinity Talk. A top-level page points to Home. The gap under it is that layer\'s own bottom margin in Divi (Design &rarr; Spacing). If visitors see a plain &ldquo;#&rdquo; where the arrow should be while you see the arrow when signed in, WP Rocket is serving old styles: go to Settings &rarr; WP Rocket and press <em>Clear Used CSS</em>.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-admin">Signing in and the Dashboard</h3><ul>';
	echo '<li><strong>The sign-in page shows the WordPress logo instead of the church logo, or the box has square corners.</strong> Check that <em>Church logo on the sign-in page and a tidier Dashboard</em> is on. The logo is the picture <code>Trinity-Community-Church-Logo-with-white-background-1.svg</code> in the Media Library (uploaded in May 2022). If that picture was deleted or renamed, upload it again with the same name, or change the address at the top of the feature\'s code.</li>';
	echo '<li><strong>The church logo is missing from the top of the left-hand menu.</strong> It is hidden on purpose when the menu is folded to icons (the <em>Collapse menu</em> button at the bottom, or a window narrower than about 960 pixels, which includes phones). Unfold the menu or widen the window. If it is still missing, check that the same feature is on.</li>';
	echo '<li><strong>The Dashboard is missing a box you want (Activity, Quick Draft, WordPress Events and News, the Welcome panel).</strong> The same feature hides those four. Switch it off to bring them back; the sign-in logo and the menu logo go back to WordPress\'s own look at the same time. Other boxes can be hidden or shown under <em>Screen Options</em> at the top of the Dashboard.</li>';
	echo '<li><strong>The grey Help tab at the top right of admin screens is missing.</strong> Also hidden by that feature, because the help it gives is WordPress\'s general help, not the church\'s. The church\'s help is on this page.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-plugin">The plugin itself</h3><ul>';
	echo '<li><strong>A new series turned into several categories (for example "Faith", "Hope" and "Love").</strong> WordPress splits a name at its commas when it is typed into "+ Add New Category" on a sermon\'s edit screen. Check that <em>Category names keep their commas</em> is on; with it on, the whole name is kept as one category. Remember to choose <strong>Series</strong> as the Parent in that box, or make the series under Posts &rarr; Categories, where there is room for its description and graphic too. Stray categories can be deleted under Posts &rarr; Categories once no sermon uses them.</li>';
	echo '<li><strong>A feature says "Another copy of this code is running".</strong> Its old snippet has been switched back on. Go to <strong>Snippets</strong> and deactivate the snippet it names (keep it, do not delete it).</li>';
	echo '<li><strong>Things went wrong right after a plugin update.</strong> Switch the affected feature off here, then go to <strong>Snippets</strong> and activate the old snippet with the matching name. That puts the previous copy back while someone looks into it.</li>';
	echo '<li><strong>A feature says "Working (edited code)".</strong> Someone changed its code and the website is running that edit. That is fine if it was meant. To go back, open ' . $code_link . ', press <em>Open my edit</em> beside the feature, then <em>Put the original back</em>.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<li><strong>A feature says its edit was switched off.</strong> An edit of its code caused an error, so the plugin went back to the original by itself. The website is working. Open ' . $code_link . ' and press <em>Fix or remove my edit</em> beside the feature: the error message is shown there. Fix the edit or put the original back.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<li><strong>Nobody here can work out what is wrong.</strong> Use the panel <a href="#tcc-ai">Ask an AI assistant about this plugin</a> on this page. It gives an AI assistant the background it needs to help.</li>';
	echo '</ul>';
	echo '</div>';

	// Changing the code, and the briefing for an AI assistant (both drawn by code-edits.php, the same in both plugins).
	tcc_code_help_card( 'tcc-site-features' );
	tcc_code_ai_card( 'tcc-site-features' );

	echo '<div class="tcc-card" id="tcc-help-builder"><h2>For whoever builds the pages</h2>';
	echo '<p>These short codes can be placed in a Divi Text layer. Each prints nothing when it has nothing to show. Label any layer that uses one with "(automatic)" so the next person knows it fills itself in.</p><table>';
	$notes = array(
		'[tcc_event_day]'        => 'Inside an event card: the event\'s day. Optional: <code>format="F d, Y"</code>.',
		'[tcc_event_time]'       => 'Inside an event card: the time, or "All Day".',
		'[tcc_event_repeats]'    => 'Inside an event card, straight in front of <code>[tcc_event_day]</code>: for an event that repeats, a teal line such as "Every Wednesday" and then the word "Next:". Nothing for a one-off event. The words come from Planning Center, or from the Repeats box on the event\'s edit screen (Events &rarr; the event &rarr; right-hand column), which wins when it is filled in; type <code>none</code> there to hide the line. Optional: <code>next=""</code> leaves out the word "Next:".',
		'[tcc_no_upcoming]'      => 'Under a list: a message that shows only when the list is empty. Optional: <code>category="mens-events"</code>, <code>message="..."</code>.',
		'[tcc_events_paging]'    => 'Previous / Next links for a list that uses "Upcoming Events - every date (automatic)". Optional: <code>per_page="8"</code>.',
		'[tcc_events_filter]'    => 'The filter bar. The list it filters needs the CSS ID <code>tcc-events</code>.',
		'[tcc_event_data]'       => 'Inside each event card on the Events page, so the filter bar knows that card\'s category and month. It is invisible. An event that repeats is one card, and is found under every month it has a date in.',
		'[tcc_sermon_audio]'     => 'The Buzzsprout player for the sermon being viewed.',
		'[tcc_event_facts]'      => 'On an event page: the day, time and place with small teal icons.',
		'[tcc_event_directions]' => 'On an event page: the "Get directions" link. Optional: <code>label="Get directions"</code>.',
		'[tcc_event_date]'       => 'Older event layout: the date and time as text. Optional: <code>layout="stacked"</code>.',
		'[tcc_event_venue]'      => 'Older event layout: the place and its address.',
		'[tcc_search_heading]'   => 'Search page: the words <code>Results for "baptism"</code>. Put it in a Heading or Text layer.',
		'[tcc_search_form]'      => 'Search page: the search-again box.',
		'[tcc_search_results]'   => 'Search page: the Top results cards, the jump buttons and the groups of results. The template that holds this short code is the one used for sitewide searches.',
		'[tcc_group_filter]'     => 'Community Groups page: the bar that filters the group cards by who a group is for, the day it meets and how often, with a search box. The list it filters needs the CSS ID <code>tcc-groups</code>, and each card the CSS class <code>tcc-group-card</code>. A <code>&lt;span class="tcc-group-count"&gt;</code> beside the heading is filled with the number of groups. Who a group is for shows as four press-buttons (Anyone, Co-ed, Women, Men); on a phone they sit two to a row. In the Divi editor the bar shows as a plain preview, with menus instead of buttons and a grey note saying so; that is expected. Twelve cards show at first, with a <em>Show 12 more</em> button and "Showing 12 of 16" under them; choosing a filter shows every match.',
		'[tcc_group_data]'       => 'Inside a group card: nothing a visitor sees. It carries the hidden facts the filter bar reads (who, days, how often) and the words of the group\'s description and organizer for the search box, so every card needs it.',
		'[tcc_sermon_filter]'    => 'Sermons page: the search box and the Series, Speaker, Book and Topic filters. The list it filters needs the CSS ID <code>tcc-sermons</code>, and each card the CSS class <code>tcc-sermon-card</code>. Optional: <code>first="12"</code> for how many cards show at first (keep it the same as the number of posts in the Divi loop).',
		'[tcc_sermon_meta]'      => 'Inside a sermon card: the speaker and the date. It also carries the hidden facts the filters read, so every card needs it.',
		'[tcc_sermon_series]'    => 'Inside a sermon card: the name of its series (nothing when it has none).',
		'[tcc_sermon_count]'     => 'How many sermons there are (on a series page, how many are in that series). <code>what="series"</code> gives the number of series.',
		'[tcc_series_toggle]'    => 'The "See all series" button. The list it opens needs the CSS class <code>tcc-series-list</code>, and each card <code>tcc-series-card</code>.',
		'[tcc_series_graphic]'   => 'Series page: the series graphic.',
		'[tcc_series_facts]'     => 'Series page: how many sermons and the dates of the first and last.',
		'[tcc_series_start]'     => 'Series page: the button to the first sermon. Optional: <code>label="Start with part 1"</code>.',
		'[tcc_trail]'               => 'The back link above a page title: an arrow and one name (&larr; Events on an event, &larr; Ministries on Men\'s Ministry, &larr; Home on a top-level page). Put it alone in a Text layer above the title, and give that layer a bottom margin of 10px. It works out where to point from the page it is on.',
		'[tcc_sermon_crumbs]'       => 'Sermon page: the back link at the top (&larr; Sermons). It prints the same link as <code>[tcc_trail]</code>.',
		'[tcc_sermon_eyebrow]'      => 'Sermon page: the series name and "Part 6 of 27" above the title, or the word Sermon.',
		'[tcc_sermon_byline]'       => 'Sermon page: the speaker and the date. The name opens the Sermons page filtered to that speaker.',
		'[tcc_sermon_series_title]' => 'Sermon page: the series name and part number, for the heading above the previous and next rows.',
		'[tcc_sermon_series_link]'  => 'Sermon page: the "See the whole series" link. Optional: <code>label="See the whole series"</code>.',
		'[tcc_sermon_step]'         => 'Inside a previous or next row: "Previous - Part 5" or "Next - Part 7".',
		'[tcc_sermon_end]'          => 'Sermon page: the note shown in place of a missing row. <code>which="first"</code> or <code>which="last"</code>.',
		'[tcc_sermon_tags]'         => 'Sermon page: the "Find more like this" buttons (speaker, series, scripture, topics).',
		'[tcc_sermon_read_more]'    => 'Sermon page: the "Read the full summary" button. The long text it opens needs the CSS ID <code>tcc-sermon-long</code>. Optional: <code>more="..."</code>, <code>less="..."</code>.',
		'[tcc_sermon_more_title]'   => 'Sermon page: "More from this series" or "Recent sermons", for the heading above the cards at the foot.',
		'[tcc_sermon_part]'         => 'Inside a card at the foot of a sermon page: the part number (or the speaker) and the date.',
		'[tcc_talk_title]'       => 'Trinity Talk: the title without its "Matthew 5 |" start. Inside a row or card it is that piece\'s title.',
		'[tcc_talk_facts]'       => 'One piece: the line under the title, "Matthew &middot; Chapter 5 of 28 &middot; By Mark Medley &middot; 3 minute read". The layer needs the CSS class <code>tcc-tt-facts</code>.',
		'[tcc_talk_panel]'       => 'One piece: the contents of the grey panel (Written by, a button for every chapter, Go further). The template that holds this short code is the one used for every piece.',
		'[tcc_talk_steps_title]' => 'One piece: "Keep reading in Matthew" and the chapter number, for the heading above the previous and next rows.',
		'[tcc_talk_book_link]'   => 'One piece: the "See all 28 chapters" link.',
		'[tcc_talk_step]'        => 'Inside a previous or next row: "Previous chapter" or "Next chapter".',
		'[tcc_talk_end]'         => 'One piece: the note shown in place of a missing row. <code>which="first"</code> or <code>which="last"</code>.',
		'[tcc_talk_more_title]'  => 'One piece: "More from Matthew" (or "More writing"), for the heading above the cards at the foot.',
		'[tcc_talk_home_link]'   => 'A link to the Trinity Talk home page. Optional: <code>label="Back to Trinity Talk"</code>.',
		'[tcc_talk_tile]'        => 'Inside a row: the small white tile with the book and chapter number. <code>label="Chapter"</code> prints the word Chapter instead of the book.',
		'[tcc_talk_card_meta]'   => 'Inside a card: "Matthew 7 &middot; Mark Medley".',
		'[tcc_talk_row_meta]'    => 'Inside a row on a book\'s page: the writer and how long the piece takes to read.',
		'[tcc_talk_summary]'     => 'Inside a row or card: the first sentence or two of the piece, or its Yoast meta description when one was typed.',
		'[tcc_talk_book_lead]'   => 'A book\'s page: the sentence under the book\'s name.',
		'[tcc_talk_start]'       => 'A book\'s page: the "Start with chapter 1" button.',
		'[tcc_talk_book_panel]'  => 'A book\'s page: the contents of the grey panel (Jump to a chapter, Written by, More). The template that holds this short code is the one used for every book.',
		'[tcc_talk_books]'       => 'A button for every book, with how many pieces each has.',
		'[tcc_talk_shelf]'       => 'Trinity Talk home page: one group of book cards. <code>group="gospels"</code>, <code>group="paul"</code> or <code>group="other"</code>. The template that holds this short code is the one used for the home page.',
		'[tcc_talk_loose_count]' => 'Trinity Talk home page: how many pieces are in no book.',
		'[tcc_talk_show_all]'    => 'Trinity Talk home page: the <em>Show 12 more</em> button under the More writing cards, with "Showing 12 of 37" beside it. Twelve cards show at first and each press adds twelve. The list of cards needs the CSS class <code>tcc-tt-loose</code>.',
	);
	foreach ( $features as $feature ) {
		foreach ( $feature['codes'] as $code ) {
			echo '<tr><th><code>' . esc_html( $code ) . '</code></th><td>' . ( isset( $notes[ $code ] ) ? wp_kses( $notes[ $code ], array( 'code' => array() ) ) : '' ) . ' <span class="tcc-muted">(' . esc_html( $feature['label'] ) . ')</span></td></tr>';
		}
	}
	echo '</table>';
	echo '<p>The event lists a Divi loop can choose from (loop settings &rarr; post type): <em>Upcoming Events (automatic)</em>, <em>Upcoming Events - every date (automatic)</em>, <em>Upcoming Events - next 6 months (automatic)</em>, and one per event category, such as <em>Upcoming Events: Men\'s Events (automatic)</em>. Every list shows an event that repeats once, at its next date, except the "every date" list, which shows up to three of its dates.</p>';
	echo '<p>The sermon lists: sermon cards are a Divi loop of <em>Posts</em>. Series cards are a Divi loop of terms that uses <em>Sermon series - newest first (automatic)</em>, and the rows on a series page are a Divi loop that uses <em>Sermons in this series - oldest first (automatic)</em>. In the series loop, Divi\'s own <em>Category Image</em> gives the series graphic (the website is sent a 768-pixel-wide copy, not the full-size file), and "Loop Term Custom Field" with the key <code>tcc_series_summary</code> gives a line such as "27 sermons &middot; 2025 to 2026".</p>';
	echo '<p>The sermon page lists (loop settings &rarr; post type): <em>Sermon page: previous part of the series (automatic)</em> and <em>Sermon page: next part of the series (automatic)</em> each hold one sermon or none, and <em>Sermon page: more sermons (automatic)</em> holds up to four. Class names on the sermon page: <code>tcc-sp-player</code> on the Video / Audio switch, <code>tcc-sp-eyebrow</code> and <code>tcc-sp-byline</code> on the lines above and below the title, <code>tcc-sp-series</code> on the previous / next section (it hides itself for a sermon with no series), <code>tcc-sp-cell</code> on each half of that section, <code>tcc-sp-row</code> with <code>tcc-sp-prev</code> or <code>tcc-sp-next</code> on the rows, <code>tcc-sp-step</code> on the row\'s small line, <code>tcc-sp-pic</code> on a picture and <code>tcc-sp-card</code> on a card.</p>';
	echo '<p>The Trinity Talk lists (loop settings &rarr; post type): <em>Trinity Talk: previous chapter (automatic)</em> and <em>Trinity Talk: next chapter (automatic)</em> each hold one piece or none, <em>Trinity Talk: more from this book (automatic)</em> holds up to four, <em>Trinity Talk: every chapter of this book (automatic)</em> holds the rows of a book\'s page, and <em>Trinity Talk: pieces in no book (automatic)</em> holds the More writing cards. Class names on those layouts: <code>tcc-tt-row</code> with <code>tcc-tt-prev</code>, <code>tcc-tt-next</code> or <code>tcc-tt-list-row</code> on a row, <code>tcc-tt-tile</code> on its white tile, <code>tcc-tt-card</code> on a card, <code>tcc-tt-side</code> and <code>tcc-tt-book-side</code> on the grey panels, <code>tcc-tt-steps</code> on the previous and next section, <code>tcc-tt-prose</code> on the words of the piece.</p>';
	echo '<p>Class names the features look for on Divi layers (Advanced &rarr; Attributes): <code>tcc-event-card</code> and <code>tcc-event-title</code> on an event card and its title (the hover arrow); <code>tcc-event-banner</code>, <code>tcc-event-place</code> and <code>tcc-event-about</code> on the event page; <code>tcc-sermon-card</code>, <code>tcc-series-list</code>, <code>tcc-series-card</code>, <code>tcc-part-list</code> and <code>tcc-part-row</code> (the row prints its own part number), <code>tcc-eyebrow</code> and <code>tcc-count</code> on the Sermons and series pages.</p>';
	echo '<p class="tcc-muted">The technical notes are in the church\'s website repository on GitHub, under <code>plugins/tcc-site-features</code> and <code>docs</code>. Without access to it, the panel <a href="#tcc-ai">Ask an AI assistant about this plugin</a> above carries the same background.</p></div>';

	echo '</div>';
}
