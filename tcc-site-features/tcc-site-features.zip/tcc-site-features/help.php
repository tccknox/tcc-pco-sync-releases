<?php
/**
 * TCC Website Features: the Help tab.
 *
 * Written for volunteers. It says what the plugin does, how the main job is done, where to find
 * things, what it is connected to, what to do when something looks wrong (grouped by the part of the
 * website), how to change the code safely, and how to brief an AI assistant. Keep it in plain
 * English and keep it true: when a feature changes, change the matching lines here in the same version.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_site_help_tab( $features, $on, $statuses ) {
	$features_link = '<a href="' . esc_url( tcc_site_url( 'features' ) ) . '">Features</a>';
	$pill          = function ( $ok, $yes, $no ) {
		return $ok ? '<span class="tcc-pill tcc-pill--ok">' . esc_html( $yes ) . '</span>' : '<span class="tcc-pill tcc-pill--muted">' . esc_html( $no ) . '</span>';
	};

	$code_link = '<a href="' . esc_url( tcc_site_url( 'features' ) ) . '">TCC Website &rarr; Features</a>';

	echo '<div class="tcc-help">';

	// A way to jump straight to a part of this long page.
	echo '<div class="tcc-card tcc-jump"><strong>On this page:</strong> ';
	$jumps = array(
		'tcc-help-what'    => 'What this does',
		'tcc-help-list'    => 'The features',
		'tcc-help-switch'  => 'Switching a feature on or off',
		'tcc-help-where'   => 'Where to find things',
		'tcc-help-links'   => 'What it is connected to',
		'tcc-help-wrong'   => 'If something looks wrong',
		'tcc-help-code'    => 'Changing the code',
		'tcc-ai'           => 'Asking an AI assistant',
		'tcc-help-builder' => 'For whoever builds the pages',
	);
	foreach ( $jumps as $id => $label ) {
		echo '<a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</div>';

	echo '<div class="tcc-card" id="tcc-help-what"><h2>What this does</h2>';
	echo '<p>It holds the small pieces of the website that the church had built for itself, the things Divi and the other plugins cannot do on their own. Each piece is a <strong>feature</strong> with its own switch.</p><ul>';
	echo '<li>The pages themselves are still built and edited in <strong>Divi</strong>. This plugin only supplies the automatic parts those pages use.</li>';
	echo '<li>It has <strong>no settings to fill in</strong>. Each feature is either on or off.</li>';
	echo '<li>If switching a feature off and on is not enough, each feature has a link, <em>See or edit the code</em>, that lets an administrator look at or change its code, with one button to put the original back.</li>';
	echo '<li>Most weeks nobody needs to open this screen. Come here when something on the website looks wrong, or to check that everything is working.</li>';
	echo '</ul></div>';

	echo '<div class="tcc-card" id="tcc-help-list"><h2>The features</h2><table>';
	foreach ( $features as $key => $feature ) {
		$status = $statuses[ $key ];
		echo '<tr><th>' . esc_html( $feature['label'] ) . '<br><span class="tcc-pill tcc-pill--' . esc_attr( $status['level'] ) . '">' . esc_html( $status['label'] ) . '</span></th>';
		echo '<td>' . esc_html( $feature['what'] ) . '<br><span class="tcc-muted"><strong>Where:</strong> ' . esc_html( $feature['where'] ) . '<br><strong>If it were switched off:</strong> ' . esc_html( $feature['off'] ) . '</span></td></tr>';
	}
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-switch"><h2>How to switch a feature on or off</h2><ol>';
	echo '<li>Open the ' . $features_link . ' tab.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped above.
	echo '<li>Find the feature and press <strong>Switch on</strong> or <strong>Switch off</strong>. Switching off asks you to confirm and tells you what visitors would notice.</li>';
	echo '<li>The change happens straight away. Open the website and look at a page that uses it (each feature says where it is used).</li>';
	echo '<li>If it is not what you expected, press the button again to put it back. Nothing is lost by switching a feature off and on.</li>';
	echo '</ol><p class="tcc-muted">Leave a feature on unless you have a reason to switch it off. Every one of them is used somewhere on the website.</p></div>';

	echo '<div class="tcc-card" id="tcc-help-where"><h2>Where to find things</h2><table>';
	echo '<tr><th>' . $features_link . '</th><td>Every feature, whether it is working, and its switch. Under each switch is <em>See or edit the code</em>, for troubleshooting: an edit is saved as a separate copy and one button puts the original back, and each file has a ready-made briefing to hand to an AI assistant. Also the button that checks for a new version.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Divi &rarr; Theme Builder</th><td>The layouts that use these features: the header (Events menu), the Events page, the individual event page, the Sermons page, the series page and the sermon page. Layers that a feature fills in are labelled "(automatic)". The trail above the title on the Sermons, series, sermon and search pages is one of them: the layer "Trail: Home &gt; ... (automatic)", filled in by the <em>Page trail</em> feature.</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Search results - SITEWIDE (new)"</th><td>The frame of the search page: its heading, the search-again box and the results area. It is not assigned to anything in the Theme Builder on purpose: the <em>Sitewide search page</em> feature shows it for searches of the whole website. The older results page, which is assigned to "Search Results", is what shows when that feature is off.</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Sermons page - NEW" and "Sermon series page - NEW"</th><td>The Sermons page and the page each sermon series gets. Both are ordinary Divi layouts: the cards are Divi loops, and the layers the <em>Sermons page: search, filters and series</em> feature fills in are labelled "(automatic)". The older Sermons page is kept beside them, named "OLD (kept for rollback)".</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Individual sermon page - NEW"</th><td>The page every sermon gets. It is an ordinary Divi layout: the player and its Video / Audio switch (a Divi Pixel Content Toggle), the title, the short and long descriptions, the previous and next rows and the four cards at the foot are all Divi layers, and the layers the <em>Sermon page (one sermon)</em> feature fills in are labelled "(automatic)". The sermon page as it was before is kept beside it, named "Individual sermon page - OLD (kept for rollback)". The two players inside the switch are the Divi Library layouts "Sermon Video" and "Sermon Podcast" (Divi &rarr; Divi Library).</td></tr>';
	echo '<tr><th>Posts &rarr; Categories</th><td>Where a <strong>sermon series</strong> is set up. A series is a category filed under "Series". Its <strong>Description</strong> box is the text shown on the series page, and its <strong>Series graphic</strong> field is the picture on its card and page. Speakers, books of the Bible and topics are categories too, filed under "Speaker", "Bible" and "Topics".</td></tr>';
	echo '<tr><th>TCC Website &rarr; Search</th><td>Two things for the website search: the list of <strong>searches that found nothing</strong> (what visitors looked for and could not find), and the <strong>words that mean the same</strong> (so "kids" also finds "children"). It also says what the search reads.</td></tr>';
	echo '<tr><th>Yoast SEO &rarr; Settings &rarr; Events, and Event Categories</th><td>The wording search engines show for the Events page and for each event category page: the <strong>SEO title</strong> and <strong>Meta description</strong> boxes. The <em>Events: titles and descriptions for search engines</em> feature puts that wording on those pages. For one event, the description is typed on the event itself, in the Yoast SEO box under the editor.</td></tr>';
	echo '<tr><th>Pages</th><td>The home page and the ministry and class pages hold event cards. Each card area is a normal Divi loop that uses an "Upcoming Events (automatic)" list.</td></tr>';
	echo '<tr><th>Events</th><td>The events themselves (The Events Calendar). The feeds show whatever upcoming events are published there.</td></tr>';
	echo '<tr><th>Snippets</th><td>Where these features lived before this plugin. The old copies are kept there, deactivated, as a safety net. Please do not delete them.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-links"><h2>What it is connected to</h2><table>';
	echo '<tr><th>Divi</th><td>The pages and layouts call these features by short codes (listed at the bottom of this page) and by choosing an "Upcoming Events (automatic)" list in a loop. Those are set in the Divi editor, on the layer that shows them.</td></tr>';
	echo '<tr><th>The Events Calendar</th><td>' . $pill( function_exists( 'tribe_get_events' ), 'Active', 'Not active' ) . ' Every event feature reads its events from here. If it is switched off under <strong>Plugins</strong>, the event lists are simply empty.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Planning Center Sync</th><td>' . $pill( function_exists( 'tcc_pco_shows' ), 'Active', 'Not active' ) . ' The church\'s other plugin (<strong>Planning Center</strong> in the left menu). The event page banner follows its "what shows" choices (location, end time), and the feeds use it to treat the dates of one repeating event as one event. Both features also work without it.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Buzzsprout</th><td>The sermon audio player comes from Buzzsprout. It uses the podcast code saved in the <strong>Podcast</strong> field on each sermon (Sermons &rarr; the sermon &rarr; Sermon Info). No sign-in is stored on the website.</td></tr>';
	echo '<tr><th>The cookie banner (Termly)</th><td>Termly can hold back outside players until a visitor agrees. buzzsprout.com is marked Essential in Termly (Consent Management &rarr; Domain Rules) so the audio player always loads.</td></tr>';
	echo '<tr><th>Google Maps</th><td>"Get directions" on an event page is an ordinary link that opens Google Maps with the event\'s address. Nothing is set up for it.</td></tr>';
	echo '<tr><th>Yoast SEO</th><td>' . $pill( defined( 'WPSEO_VERSION' ), 'Active', 'Not active' ) . ' Writes the titles and descriptions search engines see. The Events feature reads the wording typed under Yoast SEO &rarr; Settings and hands it to Yoast for the Events pages. Without Yoast it does nothing.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Code Snippets</th><td>' . $pill( defined( 'CODE_SNIPPETS_VERSION' ) || function_exists( 'code_snippets' ), 'Active', 'Not active' ) . ' The plugin behind <strong>Snippets</strong> in the left menu. It still runs a few other snippets, and it holds the old, deactivated copies of these features.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Updates</th><td>Version ' . esc_html( TCC_SITE_VERSION ) . '. New versions come from <code>github.com/' . esc_html( TCC_SITE_RELEASES ) . '</code> and show on the <strong>Plugins</strong> screen like any other update. No password is stored for this.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card" id="tcc-help-wrong"><h2>If something looks wrong</h2>';
	echo '<p class="tcc-muted">Find the heading for the part of the website that looks wrong. Each line starts with what you see, then says what to do.</p>';
	echo '<h3 id="tcc-help-wrong-start">Start here</h3><ul>';
	echo '<li><strong>Look at the ' . $features_link . ' tab first.</strong> Each feature should say <em>Working</em>. One that says <em>Needs a look</em> explains why underneath, in plain words.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-events">Events</h3><ul>';
	echo '<li><strong>The event cards are missing everywhere.</strong> Check that <em>Event feeds</em> is on, and that The Events Calendar is active under Plugins. If both are fine, check that there really are upcoming, published events under <strong>Events</strong>.</li>';
	echo '<li><strong>A new or changed event is not on the cards yet.</strong> The lists are remembered for up to 10 minutes and refresh whenever an event is saved. Open the event, press Update, and look again.</li>';
	echo '<li><strong>One ministry page shows no events.</strong> That page only shows events in its own category. Open one of the events and check its Event Categories.</li>';
	echo '<li><strong>The filter bar is missing from the Events page.</strong> Check that <em>Events filter bar</em> and <em>Event feeds</em> are both on. The bar also hides itself when there are fewer than two upcoming events.</li>';
	echo '<li><strong>An event shows the wrong description in Google or when its link is shared.</strong> Open the event and type one in the Yoast SEO box under the editor (Meta description). What is typed there always wins. When that box is empty, the <em>Events: titles and descriptions for search engines</em> feature uses the event\'s Planning Center summary, or the start of its description. Google can take days or weeks to show a change.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-search">Search</h3><ul>';
	echo '<li><strong>A page, sermon or event is missing from a search.</strong> Searches are remembered for 10 minutes and start afresh whenever a page, sermon, article, group or event is saved. Only published items show, only events that are still to come, and pages set to "do not show in search results" in Yoast are left out.</li>';
	echo '<li><strong>A sermon or group does not come up for a word that is in its description.</strong> Search reads titles and page text, plus these fields: on a sermon, <em>Sermon Description - Short</em>, <em>Sermon Description - Long</em>, <em>Speaker Name</em> and its categories (Bible book, topic, series, speaker); on a community group, its description, organizer, meeting time, location and ages. Check the word is in one of those, then save the sermon or group again.</li>';
	echo '<li><strong>Visitors search for a word the website does not use.</strong> Open the <strong>Search</strong> tab. "Searches that found nothing" shows the words; add the word to a line under "Words that mean the same" beside the word the website does use (for example <code>vbs, vacation bible school</code>), and press Save the list.</li>';
	echo '<li><strong>A search brings up too much.</strong> A line under "Words that mean the same" may be too broad. Take the loose word off that line and save. "Put the starting list back" undoes all changes to the list.</li>';
	echo '<li><strong>A community group is missing from search.</strong> Open the group and check that "Is This Group Active?" is ticked. Groups with it unticked are left out.</li>';
	echo '<li><strong>Only the first 30 of a long list show.</strong> Under the list there is a "See all" link. It opens a page with only that kind of result, shown 30 at a time.</li>';
	echo '<li><strong>The search page looks like the old one.</strong> Check that <em>Sitewide search page</em> is on. It also needs the Theme Builder template "Search results - SITEWIDE (new)" to exist and to still hold the layer with <code>[tcc_search_results]</code> in it.</li>';
	echo '<li><strong>Sitewide search page says "Needs a look".</strong> The note under it says which of these it is: its Divi template is missing; Divi stopped showing the new page (visitors still get the older results page, which works); the new template was assigned to Search Results by mistake (it should be left unassigned, with the OLD search template assigned); a kind of content or the <em>Event feeds</em> feature is missing, so that group is left out; or the Events, Sermons or Community Groups page was moved or renamed, so its "See all" link is left off until the address in the code is updated.</li>';
	echo '<li><strong>Search shows a different word from the one typed.</strong> That is the spelling help: when nothing matches, it tries the closest word used in a title on the website, and says so above the results.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-sermons">The Sermons page and series pages</h3><ul>';
	echo '<li><strong>A new sermon is not on the Sermons page, or not under its series.</strong> The page is worked out afresh whenever a sermon or a category is saved, so open the sermon and press Update. Then check its categories: it needs one category under "Series" to belong to a series, and it shows under a speaker, book or topic only when it has that category.</li>';
	echo '<li><strong>A new series has no card.</strong> A series shows once at least one published sermon is in it. Create the category under "Series" (Posts &rarr; Categories), then put a sermon in it.</li>';
	echo '<li><strong>A series shows the wrong picture.</strong> Open the series under Posts &rarr; Categories and choose a picture in <em>Series graphic</em> (1920 by 1080 works best). Until one is chosen, the series borrows the graphic of its first sermon. A sermon with no graphic of its own borrows its series graphic on these pages; a sermon in no series shows the church\'s default graphic (the one chosen under Planning Center &rarr; Settings &rarr; Graphics).</li>';
	echo '<li><strong>A card says "Sermon from" and a date instead of a title.</strong> That sermon has no title. Open it under Posts, type its title and press Update.</li>';
	echo '<li><strong>The sermon card was changed in Divi but older sermons look different.</strong> Divi draws the newest 12 cards; older ones are copies of the first card, made when the page opens. Reload the page. For the copies to be filled in, keep the CSS classes on the card\'s layers: <code>tcc-sermon-pic</code> on the picture, <code>tcc-sermon-title</code> on the title and <code>tcc-sermon-series</code> on the series name.</li>';
	echo '<li><strong>Two people preached one sermon.</strong> Type both names in <em>Speaker Name</em> with a slash between them, for example "Tyler Lynde / Amy Lynde". The card shows the line as typed, and the Speaker menu lists the sermon under each person. Spell each name the same way every time: "Kelly Kinder" and "Kelly Kidner" would show as two speakers.</li>';
	echo '<li><strong>A sermon shows the wrong speaker.</strong> The card uses the <em>Speaker Name</em> field on the sermon. If that is empty it uses the sermon\'s Speaker category, and if that is empty too, the person who posted it.</li>';
	echo '<li><strong>A series card has no picture in the Divi editor.</strong> The card\'s picture layer uses Divi\'s own <em>Category Image</em>, which the feature fills with the series graphic, so the editor shows the real picture for each series. The small line under the name ("27 sermons &middot; 2025 to 2026") and the speaker and date lines are filled in by the feature, so the editor leaves them blank; the website shows them.</li>';
	echo '<li><strong>A visitor has JavaScript switched off.</strong> They see the newest 12 sermon cards, the series cards, and a plain list of every sermon that opens with one press. Search and the filters need JavaScript.</li>';
	echo '<li><strong>The search box and filters are missing from the Sermons page.</strong> Check that <em>Sermons page: search, filters and series</em> is on. The bar also needs the list of cards to keep its CSS ID <code>tcc-sermons</code> and each card to keep the layer "Speaker and date (automatic)".</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-sermon">The page for one sermon</h3><ul>';
	echo '<li><strong>A sermon page does not say which series it is in, or has no previous and next rows.</strong> The sermon needs one category under "Series" (Posts &rarr; the sermon &rarr; Categories). The rows also need at least two sermons in that series. Part numbers go by date, oldest first, so a wrong part number means a wrong date on a sermon in that series.</li>';
	echo '<li><strong>The cards at the foot of a sermon page are not the ones expected.</strong> For a sermon in a series they are the four newest other parts of that series. For a sermon in no series they are the four newest other sermons.</li>';
	echo '<li><strong>A "Find more like this" button opens the Sermons page without choosing anything.</strong> The button uses the sermon\'s categories and its <em>Speaker Name</em>. Check that <em>Sermons page: search, filters and series</em> is on and that the name is spelled the same way as on that person\'s other sermons.</li>';
	echo '<li><strong>There is no "Read the full summary" button.</strong> That is right for a short write-up: the button only shows when the <em>Sermon Description - Long</em> text is long enough to be worth shortening. It also needs the long-description layer to keep its CSS ID <code>tcc-sermon-long</code>.</li>';
	echo '<li><strong>The Video side of a sermon is empty.</strong> Check the sermon\'s <em>Sermon Video</em> field holds the YouTube address. A visitor who has not answered the cookie banner may also see an empty player until they do.</li>';
	echo '<li><strong>A sermon has no audio.</strong> Check that <em>Sermon audio player</em> is on, then open the sermon and check that its Podcast field holds the Buzzsprout code for that episode.</li>';
	echo '<li><strong>A sermon page has to go back to how it was.</strong> Divi &rarr; Theme Builder: open the settings (cog) of "Individual sermon page - OLD (kept for rollback)", tick Posts &rarr; All Posts, press Save, then Save Changes at the top. That takes All Posts away from the new one. Nothing needs switching off.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-look">How pages look</h3><ul>';
	echo '<li><strong>A page appears for a moment with plain styles (teal pill buttons, wrong widths) and then settles.</strong> Check that <em>No flash of unstyled page</em> is on. Divi prints some pages\' styles far down the page: every page on its first view after a Divi save, and the Sermons, series, Events and search pages every time. That feature lifts them to the top of the page.</li>';
	echo '<li><strong>The trail above a title (the house, then Home &gt; Sermons &gt; ...) is missing, or sits too close to or too far from the title.</strong> Check that <em>Page trail</em> is on. The trail is the short code <code>[tcc_trail]</code> alone in a Text layer above the title (on the sermon page, <code>[tcc_sermon_crumbs]</code>). The gap under it is that layer\'s own bottom margin in Divi (Design &rarr; Spacing), 10px on every page. Ordinary pages do not use this feature: their trail is Divi\'s own Breadcrumbs layer, and the two are made to look the same.</li>';
	echo '</ul>';
	echo '<h3 id="tcc-help-wrong-plugin">The plugin itself</h3><ul>';
	echo '<li><strong>A new series turned into several categories (for example "Faith", "Hope" and "Love").</strong> WordPress splits a name at its commas when it is typed into "+ Add New Category" on a sermon\'s edit screen. Check that <em>Category names keep their commas</em> is on; with it on, the whole name is kept as one category. Remember to choose <strong>Series</strong> as the Parent in that box, or make the series under Posts &rarr; Categories, where there is room for its description and graphic too. Stray categories can be deleted under Posts &rarr; Categories once no sermon uses them.</li>';
	echo '<li><strong>A feature says "Another copy of this code is running".</strong> Its old snippet has been switched back on. Go to <strong>Snippets</strong> and deactivate the snippet it names (keep it, do not delete it).</li>';
	echo '<li><strong>Things went wrong right after a plugin update.</strong> Switch the affected feature off here, then go to <strong>Snippets</strong> and activate the old snippet with the matching name. That puts the previous copy back while someone looks into it.</li>';
	echo '<li><strong>A feature says "Working (edited code)".</strong> Someone changed its code and the website is running that edit. That is fine if it was meant. To go back, open ' . $code_link . ', press <em>Open my edit</em> beside the feature, then <em>Put the original back</em>.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<li><strong>A feature says its edit was switched off.</strong> An edit of its code caused an error, so the plugin went back to the original by itself. The website is working. Open ' . $code_link . ' and press <em>Fix or remove my edit</em> beside the feature: the error message is shown there. Fix the edit or put the original back.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<li><strong>Nobody here can work out what is wrong.</strong> Use the panel <a href="#tcc-ai">Ask an AI assistant about this plugin</a> on this page. It gives an AI assistant the background it needs to help.</li>';
	echo '</ul>';
	echo '</div>';

	// Changing the code, and the briefing for an AI assistant (both drawn by code-edits.php, the same in both plugins).
	tcc_code_help_card( 'tcc-site-features' );
	tcc_code_ai_card( 'tcc-site-features' );

	echo '<div class="tcc-card" id="tcc-help-builder"><h2>For whoever builds the pages</h2>';
	echo '<p>These short codes can be placed in a Divi Text layer. Each prints nothing when it has nothing to show. Label any layer that uses one with "(automatic)" so the next person knows it fills itself in.</p><table>';
	$notes = array(
		'[tcc_event_day]'        => 'Inside an event card: the event\'s day. Optional: <code>format="F d, Y"</code>.',
		'[tcc_event_time]'       => 'Inside an event card: the time, or "All Day".',
		'[tcc_no_upcoming]'      => 'Under a list: a message that shows only when the list is empty. Optional: <code>category="mens-events"</code>, <code>message="..."</code>.',
		'[tcc_events_paging]'    => 'Previous / Next links for a list that uses "Upcoming Events - every date (automatic)". Optional: <code>per_page="8"</code>.',
		'[tcc_events_filter]'    => 'The filter bar. The list it filters needs the CSS ID <code>tcc-events</code>.',
		'[tcc_event_data]'       => 'Inside each event card on the Events page, so the filter bar knows that card\'s category and month. It is invisible.',
		'[tcc_sermon_audio]'     => 'The Buzzsprout player for the sermon being viewed.',
		'[tcc_event_facts]'      => 'On an event page: the day, time and place with small teal icons.',
		'[tcc_event_directions]' => 'On an event page: the "Get directions" link. Optional: <code>label="Get directions"</code>.',
		'[tcc_event_date]'       => 'Older event layout: the date and time as text. Optional: <code>layout="stacked"</code>.',
		'[tcc_event_venue]'      => 'Older event layout: the place and its address.',
		'[tcc_search_heading]'   => 'Search page: the words <code>Results for "baptism"</code>. Put it in a Heading or Text layer.',
		'[tcc_search_form]'      => 'Search page: the search-again box.',
		'[tcc_search_results]'   => 'Search page: the Top results cards, the jump buttons and the groups of results. The template that holds this short code is the one used for sitewide searches.',
		'[tcc_sermon_filter]'    => 'Sermons page: the search box and the Series, Speaker, Book and Topic filters. The list it filters needs the CSS ID <code>tcc-sermons</code>, and each card the CSS class <code>tcc-sermon-card</code>. Optional: <code>first="12"</code> for how many cards show at first (keep it the same as the number of posts in the Divi loop).',
		'[tcc_sermon_meta]'      => 'Inside a sermon card: the speaker and the date. It also carries the hidden facts the filters read, so every card needs it.',
		'[tcc_sermon_series]'    => 'Inside a sermon card: the name of its series (nothing when it has none).',
		'[tcc_sermon_count]'     => 'How many sermons there are (on a series page, how many are in that series). <code>what="series"</code> gives the number of series.',
		'[tcc_series_toggle]'    => 'The "See all series" button. The list it opens needs the CSS class <code>tcc-series-list</code>, and each card <code>tcc-series-card</code>.',
		'[tcc_series_graphic]'   => 'Series page: the series graphic.',
		'[tcc_series_facts]'     => 'Series page: how many sermons and the dates of the first and last.',
		'[tcc_series_start]'     => 'Series page: the button to the first sermon. Optional: <code>label="Start with part 1"</code>.',
		'[tcc_trail]'               => 'The trail above a page title: a house, then Home &gt; Sermons &gt; In Christ. Put it alone in a Text layer above the title, and give that layer a bottom margin of 10px. It works out the trail from the page it is on (Sermons page, series page, sermon page, search page, or any ordinary page).',
		'[tcc_sermon_crumbs]'       => 'Sermon page: the trail at the top (Home, Sermons, the series, this sermon). It prints the same trail as <code>[tcc_trail]</code>.',
		'[tcc_sermon_eyebrow]'      => 'Sermon page: the series name and "Part 6 of 27" above the title, or the word Sermon.',
		'[tcc_sermon_byline]'       => 'Sermon page: the speaker and the date. The name opens the Sermons page filtered to that speaker.',
		'[tcc_sermon_series_title]' => 'Sermon page: the series name and part number, for the heading above the previous and next rows.',
		'[tcc_sermon_series_link]'  => 'Sermon page: the "See the whole series" link. Optional: <code>label="See the whole series"</code>.',
		'[tcc_sermon_step]'         => 'Inside a previous or next row: "Previous - Part 5" or "Next - Part 7".',
		'[tcc_sermon_end]'          => 'Sermon page: the note shown in place of a missing row. <code>which="first"</code> or <code>which="last"</code>.',
		'[tcc_sermon_tags]'         => 'Sermon page: the "Find more like this" buttons (speaker, series, scripture, topics).',
		'[tcc_sermon_read_more]'    => 'Sermon page: the "Read the full summary" button. The long text it opens needs the CSS ID <code>tcc-sermon-long</code>. Optional: <code>more="..."</code>, <code>less="..."</code>.',
		'[tcc_sermon_more_title]'   => 'Sermon page: "More from this series" or "Recent sermons", for the heading above the cards at the foot.',
		'[tcc_sermon_part]'         => 'Inside a card at the foot of a sermon page: the part number (or the speaker) and the date.',
	);
	foreach ( $features as $feature ) {
		foreach ( $feature['codes'] as $code ) {
			echo '<tr><th><code>' . esc_html( $code ) . '</code></th><td>' . ( isset( $notes[ $code ] ) ? wp_kses( $notes[ $code ], array( 'code' => array() ) ) : '' ) . ' <span class="tcc-muted">(' . esc_html( $feature['label'] ) . ')</span></td></tr>';
		}
	}
	echo '</table>';
	echo '<p>The event lists a Divi loop can choose from (loop settings &rarr; post type): <em>Upcoming Events (automatic)</em>, <em>Upcoming Events - every date (automatic)</em>, <em>Upcoming Events - next 6 months (automatic)</em>, and one per event category, such as <em>Upcoming Events: Men\'s Events (automatic)</em>.</p>';
	echo '<p>The sermon lists: sermon cards are a Divi loop of <em>Posts</em>. Series cards are a Divi loop of terms that uses <em>Sermon series - newest first (automatic)</em>, and the rows on a series page are a Divi loop that uses <em>Sermons in this series - oldest first (automatic)</em>. In the series loop, Divi\'s own <em>Category Image</em> gives the series graphic (the website is sent a 768-pixel-wide copy, not the full-size file), and "Loop Term Custom Field" with the key <code>tcc_series_summary</code> gives a line such as "27 sermons &middot; 2025 to 2026".</p>';
	echo '<p>The sermon page lists (loop settings &rarr; post type): <em>Sermon page: previous part of the series (automatic)</em> and <em>Sermon page: next part of the series (automatic)</em> each hold one sermon or none, and <em>Sermon page: more sermons (automatic)</em> holds up to four. Class names on the sermon page: <code>tcc-sp-player</code> on the Video / Audio switch, <code>tcc-sp-eyebrow</code> and <code>tcc-sp-byline</code> on the lines above and below the title, <code>tcc-sp-series</code> on the previous / next section (it hides itself for a sermon with no series), <code>tcc-sp-cell</code> on each half of that section, <code>tcc-sp-row</code> with <code>tcc-sp-prev</code> or <code>tcc-sp-next</code> on the rows, <code>tcc-sp-step</code> on the row\'s small line, <code>tcc-sp-pic</code> on a picture and <code>tcc-sp-card</code> on a card.</p>';
	echo '<p>Class names the features look for on Divi layers (Advanced &rarr; Attributes): <code>tcc-event-card</code> and <code>tcc-event-title</code> on an event card and its title (the hover arrow); <code>tcc-event-banner</code>, <code>tcc-event-place</code> and <code>tcc-event-about</code> on the event page; <code>tcc-sermon-card</code>, <code>tcc-series-list</code>, <code>tcc-series-card</code>, <code>tcc-part-list</code> and <code>tcc-part-row</code> (the row prints its own part number), <code>tcc-eyebrow</code> and <code>tcc-count</code> on the Sermons and series pages.</p>';
	echo '<p class="tcc-muted">The technical notes are in the church\'s website repository on GitHub, under <code>plugins/tcc-site-features</code> and <code>docs</code>. Without access to it, the panel <a href="#tcc-ai">Ask an AI assistant about this plugin</a> above carries the same background.</p></div>';

	echo '</div>';
}
