<?php
/**
 * TCC Website Features: the Help tab.
 *
 * Written for volunteers. It says what the plugin does, how the main job is done, where to find
 * things, what it is connected to, and what to do when something looks wrong. Keep it in plain
 * English and keep it true: when a feature changes, change the matching lines here in the same version.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_site_help_tab( $features, $on, $statuses ) {
	$features_link = '<a href="' . esc_url( tcc_site_url( 'features' ) ) . '">Features</a>';
	$pill          = function ( $ok, $yes, $no ) {
		return $ok ? '<span class="tcc-pill tcc-pill--ok">' . esc_html( $yes ) . '</span>' : '<span class="tcc-pill tcc-pill--muted">' . esc_html( $no ) . '</span>';
	};

	echo '<div class="tcc-help">';

	echo '<div class="tcc-card"><h2>What this does</h2>';
	echo '<p>It holds the small pieces of the website that the church had built for itself, the things Divi and the other plugins cannot do on their own. Each piece is a <strong>feature</strong> with its own switch.</p><ul>';
	echo '<li>The pages themselves are still built and edited in <strong>Divi</strong>. This plugin only supplies the automatic parts those pages use.</li>';
	echo '<li>It has <strong>no settings to fill in</strong>. Each feature is either on or off.</li>';
	echo '<li>Most weeks nobody needs to open this screen. Come here when something on the website looks wrong, or to check that everything is working.</li>';
	echo '</ul></div>';

	echo '<div class="tcc-card"><h2>The features</h2><table>';
	foreach ( $features as $key => $feature ) {
		$status = $statuses[ $key ];
		echo '<tr><th>' . esc_html( $feature['label'] ) . '<br><span class="tcc-pill tcc-pill--' . esc_attr( $status['level'] ) . '">' . esc_html( $status['label'] ) . '</span></th>';
		echo '<td>' . esc_html( $feature['what'] ) . '<br><span class="tcc-muted"><strong>Where:</strong> ' . esc_html( $feature['where'] ) . '<br><strong>If it were switched off:</strong> ' . esc_html( $feature['off'] ) . '</span></td></tr>';
	}
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>How to switch a feature on or off</h2><ol>';
	echo '<li>Open the ' . $features_link . ' tab.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped above.
	echo '<li>Find the feature and press <strong>Switch on</strong> or <strong>Switch off</strong>. Switching off asks you to confirm and tells you what visitors would notice.</li>';
	echo '<li>The change happens straight away. Open the website and look at a page that uses it (each feature says where it is used).</li>';
	echo '<li>If it is not what you expected, press the button again to put it back. Nothing is lost by switching a feature off and on.</li>';
	echo '</ol><p class="tcc-muted">Leave a feature on unless you have a reason to switch it off. Every one of them is used somewhere on the website.</p></div>';

	echo '<div class="tcc-card"><h2>Where to find things</h2><table>';
	echo '<tr><th>' . $features_link . '</th><td>Every feature, whether it is working, and its switch. Also the button that checks for a new version.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Divi &rarr; Theme Builder</th><td>The layouts that use these features: the header (Events menu), the Events page, the individual event page and the sermon page. Layers that a feature fills in are labelled "(automatic)".</td></tr>';
	echo '<tr><th>Divi &rarr; Theme Builder &rarr; "Search results - SITEWIDE (new)"</th><td>The frame of the search page: its heading, the search-again box and the results area. It is not assigned to anything in the Theme Builder on purpose: the <em>Sitewide search page</em> feature shows it for searches of the whole website. The older results page, which is assigned to "Search Results", is what shows when that feature is off.</td></tr>';
	echo '<tr><th>Pages</th><td>The home page and the ministry and class pages hold event cards. Each card area is a normal Divi loop that uses an "Upcoming Events (automatic)" list.</td></tr>';
	echo '<tr><th>Events</th><td>The events themselves (The Events Calendar). The feeds show whatever upcoming events are published there.</td></tr>';
	echo '<tr><th>Snippets</th><td>Where these features lived before this plugin. The old copies are kept there, deactivated, as a safety net. Please do not delete them.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>What it is connected to</h2><table>';
	echo '<tr><th>Divi</th><td>The pages and layouts call these features by short codes (listed at the bottom of this page) and by choosing an "Upcoming Events (automatic)" list in a loop. Those are set in the Divi editor, on the layer that shows them.</td></tr>';
	echo '<tr><th>The Events Calendar</th><td>' . $pill( function_exists( 'tribe_get_events' ), 'Active', 'Not active' ) . ' Every event feature reads its events from here. If it is switched off under <strong>Plugins</strong>, the event lists are simply empty.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Planning Center Sync</th><td>' . $pill( function_exists( 'tcc_pco_shows' ), 'Active', 'Not active' ) . ' The church\'s other plugin (<strong>Planning Center</strong> in the left menu). The event page banner follows its "what shows" choices (location, end time), and the feeds use it to treat the dates of one repeating event as one event. Both features also work without it.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Buzzsprout</th><td>The sermon audio player comes from Buzzsprout. It uses the podcast code saved in the <strong>Podcast</strong> field on each sermon (Sermons &rarr; the sermon &rarr; Sermon Info). No sign-in is stored on the website.</td></tr>';
	echo '<tr><th>The cookie banner (Termly)</th><td>Termly can hold back outside players until a visitor agrees. buzzsprout.com is marked Essential in Termly (Consent Management &rarr; Domain Rules) so the audio player always loads.</td></tr>';
	echo '<tr><th>Google Maps</th><td>"Get directions" on an event page is an ordinary link that opens Google Maps with the event\'s address. Nothing is set up for it.</td></tr>';
	echo '<tr><th>Code Snippets</th><td>' . $pill( defined( 'CODE_SNIPPETS_VERSION' ) || function_exists( 'code_snippets' ), 'Active', 'Not active' ) . ' The plugin behind <strong>Snippets</strong> in the left menu. It still runs a few other snippets, and it holds the old, deactivated copies of these features.</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<tr><th>Updates</th><td>Version ' . esc_html( TCC_SITE_VERSION ) . '. New versions come from <code>github.com/' . esc_html( TCC_SITE_RELEASES ) . '</code> and show on the <strong>Plugins</strong> screen like any other update. No password is stored for this.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>If something looks wrong</h2><ol>';
	echo '<li><strong>Look at the ' . $features_link . ' tab first.</strong> Each feature should say <em>Working</em>. One that says <em>Needs a look</em> explains why underneath, in plain words.</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<li><strong>The event cards are missing everywhere.</strong> Check that <em>Event feeds</em> is on, and that The Events Calendar is active under Plugins. If both are fine, check that there really are upcoming, published events under <strong>Events</strong>.</li>';
	echo '<li><strong>A new or changed event is not on the cards yet.</strong> The lists are remembered for up to 10 minutes and refresh whenever an event is saved. Open the event, press Update, and look again.</li>';
	echo '<li><strong>One ministry page shows no events.</strong> That page only shows events in its own category. Open one of the events and check its Event Categories.</li>';
	echo '<li><strong>A sermon has no audio.</strong> Check that <em>Sermon audio player</em> is on, then open the sermon and check that its Podcast field holds the Buzzsprout code for that episode.</li>';
	echo '<li><strong>The filter bar is missing from the Events page.</strong> Check that <em>Events filter bar</em> and <em>Event feeds</em> are both on. The bar also hides itself when there are fewer than two upcoming events.</li>';
	echo '<li><strong>A page, sermon or event is missing from a search.</strong> Searches are remembered for 10 minutes and start afresh whenever a page, sermon, article, group or event is saved. Only published items show, only events that are still to come, and pages set to "do not show in search results" in Yoast are left out.</li>';
	echo '<li><strong>A sermon or group does not come up for a word that is in its description.</strong> Search reads titles and page text, plus these fields: on a sermon, <em>Sermon Description - Short</em>, <em>Sermon Description - Long</em>, <em>Speaker Name</em> and its categories (Bible book, topic, series, speaker); on a community group, its description, organizer, meeting time, location and ages. Check the word is in one of those, then save the sermon or group again.</li>';
	echo '<li><strong>Only the first 30 of a long list show.</strong> Under the list there is a "See all" link. It opens a page with only that kind of result, shown 30 at a time.</li>';
	echo '<li><strong>The search page looks like the old one.</strong> Check that <em>Sitewide search page</em> is on. It also needs the Theme Builder template "Search results - SITEWIDE (new)" to exist and to still hold the layer with <code>[tcc_search_results]</code> in it.</li>';
	echo '<li><strong>Sitewide search page says "Needs a look".</strong> The note under it says which of these it is: its Divi template is missing; Divi stopped showing the new page (visitors still get the older results page, which works); the new template was assigned to Search Results by mistake (it should be left unassigned, with the OLD search template assigned); a kind of content or the <em>Event feeds</em> feature is missing, so that group is left out; or the Events, Sermons or Community Groups page was moved or renamed, so its "See all" link is left off until the address in the code is updated.</li>';
	echo '<li><strong>Search shows a different word from the one typed.</strong> That is the spelling help: when nothing matches, it tries the closest word used in a title on the website, and says so above the results.</li>';
	echo '<li><strong>A feature says "Another copy of this code is running".</strong> Its old snippet has been switched back on. Go to <strong>Snippets</strong> and deactivate the snippet it names (keep it, do not delete it).</li>';
	echo '<li><strong>Things went wrong right after a plugin update.</strong> Switch the affected feature off here, then go to <strong>Snippets</strong> and activate the old snippet with the matching name. That puts the previous copy back while someone looks into it.</li>';
	echo '</ol></div>';

	echo '<div class="tcc-card"><h2>For whoever builds the pages</h2>';
	echo '<p>These short codes can be placed in a Divi Text layer. Each prints nothing when it has nothing to show. Label any layer that uses one with "(automatic)" so the next person knows it fills itself in.</p><table>';
	$notes = array(
		'[tcc_event_day]'        => 'Inside an event card: the event\'s day. Optional: <code>format="F d, Y"</code>.',
		'[tcc_event_time]'       => 'Inside an event card: the time, or "All Day".',
		'[tcc_no_upcoming]'      => 'Under a list: a message that shows only when the list is empty. Optional: <code>category="mens-events"</code>, <code>message="..."</code>.',
		'[tcc_events_paging]'    => 'Previous / Next links for a list that uses "Upcoming Events - every date (automatic)". Optional: <code>per_page="8"</code>.',
		'[tcc_events_filter]'    => 'The filter bar. The list it filters needs the CSS ID <code>tcc-events</code>.',
		'[tcc_event_data]'       => 'Inside each event card on the Events page, so the filter bar knows that card\'s category and month. It is invisible.',
		'[tcc_sermon_audio]'     => 'The Buzzsprout player for the sermon being viewed.',
		'[tcc_event_facts]'      => 'On an event page: the day, time and place with small teal icons.',
		'[tcc_event_directions]' => 'On an event page: the "Get directions" link. Optional: <code>label="Get directions"</code>.',
		'[tcc_event_date]'       => 'Older event layout: the date and time as text. Optional: <code>layout="stacked"</code>.',
		'[tcc_event_venue]'      => 'Older event layout: the place and its address.',
		'[tcc_search_heading]'   => 'Search page: the words <code>Results for "baptism"</code>. Put it in a Heading or Text layer.',
		'[tcc_search_form]'      => 'Search page: the search-again box.',
		'[tcc_search_results]'   => 'Search page: the Top results cards, the jump buttons and the groups of results. The template that holds this short code is the one used for sitewide searches.',
	);
	foreach ( $features as $feature ) {
		foreach ( $feature['codes'] as $code ) {
			echo '<tr><th><code>' . esc_html( $code ) . '</code></th><td>' . ( isset( $notes[ $code ] ) ? wp_kses( $notes[ $code ], array( 'code' => array() ) ) : '' ) . ' <span class="tcc-muted">(' . esc_html( $feature['label'] ) . ')</span></td></tr>';
		}
	}
	echo '</table>';
	echo '<p>The event lists a Divi loop can choose from (loop settings &rarr; post type): <em>Upcoming Events (automatic)</em>, <em>Upcoming Events - every date (automatic)</em>, <em>Upcoming Events - next 6 months (automatic)</em>, and one per event category, such as <em>Upcoming Events: Men\'s Events (automatic)</em>.</p>';
	echo '<p>Class names the features look for on Divi layers (Advanced &rarr; Attributes): <code>tcc-event-card</code> and <code>tcc-event-title</code> on an event card and its title (the hover arrow); <code>tcc-event-banner</code>, <code>tcc-event-place</code> and <code>tcc-event-about</code> on the event page.</p>';
	echo '<p class="tcc-muted">The technical notes are in the church\'s website repository on GitHub, under <code>plugins/tcc-site-features</code> and <code>docs</code>.</p></div>';

	echo '</div>';
}
