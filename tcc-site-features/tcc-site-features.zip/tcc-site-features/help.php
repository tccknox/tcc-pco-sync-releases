<?php
/**
 * TCC Website: every word of help, for volunteers.
 *
 * Since 0.13.0 the help sits beside what it is about. Each feature's help is folded under its switch
 * on the Features tab, each group of features can have help of its own, each Planning Center tab and
 * the Search tab have a "How this tab works" box, and the Help tab keeps only what applies to the whole
 * plugin. The words are here, in tcc_site_help_content(), so one file holds all of them. Keep them in
 * plain English and keep them true: when a feature changes, change its lines here in the same version.
 *
 * Links inside the words are written as tokens and turned into links by tcc_site_help_render():
 *   {{feature:KEY|Words}}  a feature's card on the Features tab (KEY as in tcc_site_features())
 *   {{area:KEY|Words}}     a group on the Features tab (KEY as in tcc_site_areas())
 *   {{help:ID|Words}}      a panel on the Help tab (ID such as tcc-help-any-page)
 *   {{tab:search|Words}}   the Search tab
 *   {{pco:TAB|Words}}      a tab of the Planning Center screen (waiting, synced, conflicts, changes, tags, rooms, settings)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All the help wording, as data.
 *   'features'   feature key => array(
 *                  'where' => more words for "Where it is used" (after the feature's own 'where'),
 *                  'how'   => array( 'pick the speakers of a sermon' => html, ... ) (each becomes "How do I: ..."),
 *                  'wrong' => array( 'What you see.' => 'What to do.', ... ),
 *                  'links' => html for "What it is connected to",
 *                  'build' => html for "For whoever builds the pages", after its short codes,
 *                )
 *   'areas'      group key => the same keys, plus 'intro' => list of array( 'title', 'html', optional 'id' )
 *   'codes'      short code => note for whoever builds the pages
 *   'pco_tabs'   Planning Center tab => html for its "How this tab works" box
 *   'search_tab' html for the Search tab's box
 */
function tcc_site_help_content() {
	// The WP Rocket steps are written out once, on the Help tab ("Problems you might see on any page"). Everywhere else links there.
	$rocket = 'clear WP Rocket ({{help:tcc-help-any-page|see Problems you might see on any page}})';
	static $content = null; // built once per page, not on every call.
	if ( null === $content ) {
		$content = array(
		'features'   => array(
			'event-feeds'          => array(
				'wrong' => array(
					'A new or changed event is not on the cards yet.' => 'The lists are remembered for up to 10 minutes and refresh whenever an event is saved. Open the event, press Update, and look again.',
					'One ministry page shows no events.'               => 'That page only shows events in its own category. Open one of the events and check its Event Categories.',
				),
				'build' => '<p>The event lists a Divi loop can choose from (loop settings &rarr; post type): <em>Upcoming Events (automatic)</em>, <em>Upcoming Events - every date (automatic)</em>, <em>Upcoming Events - next 6 months (automatic)</em>, and one per event category, such as <em>Upcoming Events: Men\'s Events (automatic)</em>. Every list shows an event that repeats once, at its next date, except the "every date" list, which shows up to three of its dates.</p>'
					. '<p>Class names this feature looks for on Divi layers (Advanced &rarr; Attributes): <code>tcc-event-card</code> and <code>tcc-event-title</code> on an event card and its title (the hover arrow).</p>',
			),
			'events-filter'        => array(
				'wrong' => array(
					'The filter bar is missing from the Events page.' => 'Check that <em>Events filter bar</em> and <em>Event feeds</em> are both on. The bar also hides itself when there are fewer than two upcoming events.',
					'Only twelve events show.'                        => 'That is on purpose: press <em>Show 12 more</em> under the cards. Choosing any filter shows every match. The number beside "Upcoming Events" (a <code>&lt;span class="tcc-events-count"&gt;</code> in the heading) is how many there are in all.',
				),
			),
			'event-banner'         => array(
				'build' => '<p>Class names this feature looks for on Divi layers (Advanced &rarr; Attributes): <code>tcc-event-banner</code>, <code>tcc-event-place</code> and <code>tcc-event-about</code> on the event page.</p>',
			),
			'event-editor-preview' => array(
				'how'   => array(
					'add a button or picture to one event only' => '<ol>'
						. '<li>Go to <strong>Events</strong> and open the event. If its edit screen shows a purple <strong>Use The Divi Builder</strong> button, the event has not been set up for Divi yet: press it once (this is needed only the first time for each event; Divi should keep any words already on the event, but look at the page afterwards to be sure). Then press <strong>Build On The Front End</strong> (or, later, <em>Edit With Divi</em>). Until an event is set up this way, adding <code>?et_fb=1</code> to its address just shows the normal page.</li>'
						. '<li>Scroll to <strong>About this event</strong>. Under it is a box with a teal dashed edge and the words <em>This event only: add buttons, pictures or text here</em>.</li>'
						. '<li>Press the <strong>+</strong> inside that box and add a Button, Image or Text. Fill it in as usual.</li>'
						. '<li>Press <strong>Save</strong> (a real click on the Save button; nothing is kept until you do).</li>'
						. '<li>Open the event on the website to check it, and open one other event to check that it is not there.</li>'
						. '</ol><p><strong>Events from Planning Center that repeat:</strong> each date is its own event on the website, so something added to one date is not on the others. Add it to each date that needs it. A date that Planning Center adds later starts with a copy of what the date before it had.</p>'
						. '<p>Everything else on the page (the title, the banner with the day and time, Add To Calendar, the Location card) is the <strong>shared event template</strong>. Changing it changes every event, and Divi lets you change it with one click, without any warning of its own. So whenever you open a part of the shared template, a dark notice appears just under the menu saying <em>You are changing the shared event template</em>. If you see it, close that part without changing anything. If you already changed something, press <strong>Exit</strong>, choose not to save, and start again from step 1.</p>'
						. '<p class="tcc-muted">While you edit, the template shows this event\'s own day, time, place, description, rooms and Register button, as they will look on the website. These come from the event itself (and from Planning Center), not from the editor: change them on the event\'s edit screen or in Planning Center, not in Divi. The Register button for one event is set in the <em>Planning Center and registration</em> box on the event\'s edit screen. Both of these come from the feature <em>Event details and labels in the Divi editor</em>.</p>',
				),
				'wrong' => array(
					'Something added to one event shows on every event.' => 'It was added to the shared event template instead of the event\'s own box. Open Divi &rarr; Theme Builder, open the event template (the one assigned to All Events) and remove it there, then add it again inside the teal <em>This event only</em> box of that one event (see {{feature:event-editor-preview|How to add a button or picture to one event only}}).',
					'In the Divi editor an event shows "(filled in automatically)" instead of its day, time and place, or has no teal "This event only" box.' => 'Check that <em>Event details and labels in the Divi editor</em> is on. Visitors are not affected either way. If it is on and the words still show, the event may be a draft or have no date yet; save it with a date and open the editor again.',
				),
			),
			'event-search-text'    => array(
				'where' => '<strong>Yoast SEO &rarr; Settings &rarr; Events, and Event Categories</strong>: The wording search engines show for the Events page and for each event category page: the <strong>SEO title</strong> and <strong>Meta description</strong> boxes. The <em>Events: titles and descriptions for search engines</em> feature puts that wording on those pages. For one event, the description is typed on the event itself, in the Yoast SEO box under the editor.',
				'wrong' => array(
					'An event shows the wrong description in Google or when its link is shared.' => 'Open the event and type one in the Yoast SEO box under the editor (Meta description). What is typed there always wins. When that box is empty, the <em>Events: titles and descriptions for search engines</em> feature uses the event\'s Planning Center summary, or the start of its description. Google can take days or weeks to show a change.',
				),
			),
			'sitewide-search'      => array(
				'where' => '<strong>Divi &rarr; Theme Builder &rarr; "Search results - SITEWIDE (new)"</strong>: The frame of the search page: its heading, the search-again box and the results area. It is not assigned to anything in the Theme Builder on purpose: the <em>Sitewide search page</em> feature shows it for searches of the whole website. The older results page, which is assigned to "Search Results", is what shows when that feature is off.'
					. '</p><p><strong>TCC Website &rarr; Search</strong>: Two things for the website search: the list of <strong>searches that found nothing</strong> (what visitors looked for and could not find), and the <strong>words that mean the same</strong> (so "kids" also finds "children"). It also says what the search reads.',
				'wrong' => array(
					'A page, sermon or event is missing from a search.' => 'Searches are remembered for 10 minutes and start afresh whenever a page, sermon, article, group or event is saved. Only published items show, only events that are still to come, and pages set to "do not show in search results" in Yoast are left out.',
					'A sermon or group does not come up for a word that is in its description.' => 'Search reads titles and page text, plus these fields: on a sermon, <em>Sermon Description - Short</em>, <em>Sermon Description - Long</em>, <em>Speaker Name</em> and its categories (Bible book, topic, series, speaker); on a community group, its description, organizer, meeting time, location and ages. Check the word is in one of those, then save the sermon or group again.',
					'A writer\'s name does not find their Trinity Talk pieces.' => 'Search also reads the name of the account a piece or sermon was saved under (Users &rarr; the person &rarr; <em>Display name publicly as</em>). Check the piece is saved under that person (on its edit screen, the Author box). The church\'s own account, the sermon upload app and the web support accounts are left out on purpose, so that a search for &ldquo;church&rdquo; or &ldquo;sermon&rdquo; does not bring back everything they saved; that list is at the top of the search feature\'s code (<code>tcc_search_author_skip</code>).',
					'Visitors search for a word the website does not use, or a search brings up too much.' => 'See the box at the top of {{tab:search|the Search tab}}.',
					'A community group is missing from search.' => 'Open the group and check that "Is This Group Active?" is ticked. Groups with it unticked are left out.',
					'Only the first 30 of a long list show.' => 'Under the list there is a "See all" link. It opens a page with only that kind of result, shown 30 at a time.',
					'The search page looks like the old one.' => 'Check that <em>Sitewide search page</em> is on. It also needs the Theme Builder template "Search results - SITEWIDE (new)" to exist and to still hold the layer with <code>[tcc_search_results]</code> in it.',
					'Sitewide search page says "Needs a look".' => 'The note under it says which of these it is: its Divi template is missing; Divi stopped showing the new page (visitors still get the older results page, which works); the new template was assigned to Search Results by mistake (it should be left unassigned, with the OLD search template assigned); a kind of content or the <em>Event feeds</em> feature is missing, so that group is left out; or the Events, Sermons or Community Groups page was moved or renamed, so its "See all" link is left off until the address in the code is updated.',
					'The search page says &ldquo;The search is busy right now&rdquo;.' => 'To protect the server, one visitor can start 15 new searches a minute and the whole website 90; a search already made in the last 10 minutes does not count. It clears by itself within a minute. Signed-in editors are never held back. Seeing it often means a robot is searching the website; tell whoever looks after the hosting.',
					'Search shows a different word from the one typed.' => 'That is the spelling help: when nothing matches, it tries the closest word used in a title on the website, and says so above the results.',
				),
			),
			'group-filter'         => array(
				'how'   => array(
					'add or retire a group' => '<p><strong>How the page works.</strong> The cards are ordinary Divi: a loop over Community Groups that shows every group with <em>Is this group active</em> ticked, A to Z. To add or retire a group, tick or untick that box on the group; there is nothing to change on the page. The feature <em>Community Groups filter bar</em> only adds the bar above the cards and the number beside the heading.</p>',
				),
				'wrong' => array(
					'The filter bar is missing.' => 'Check that <em>Community Groups filter bar</em> is on. The bar also hides itself when there are fewer than two groups. In Divi, the list of cards must keep the CSS ID <code>tcc-groups</code> and each card the CSS class <code>tcc-group-card</code> (Advanced &rarr; Attributes).',
					'A group is not found under its day, or under Women or Men.' => 'The bar reads the group\'s own fields: <em>Gender-Specific</em>, <em>How Often</em>, and the day names written in <em>Date And Meeting Time</em> (for example "Thursdays at 7:00 PM"). Fix the field on the group. A meeting time with no day name in it, such as "Twice a month", is only found under <em>Any day</em>.',
					'A menu is missing from the bar, or a choice is missing from a menu.' => 'That is on purpose: a menu only lists choices that at least one group has, and a menu with fewer than two choices is hidden.',
					'Only twelve groups show.' => 'That is on purpose, the same as the Sermons and Events pages: press <em>Show 12 more</em> under the cards. Choosing any filter shows every group that matches.',
				),
			),
			'sermon-filters'       => array(
				'where' => '<strong>Divi &rarr; Theme Builder &rarr; "Sermons page - NEW" and "Sermon series page - NEW"</strong>: The Sermons page and the page each sermon series gets. Both are ordinary Divi layouts: the cards are Divi loops, and the layers the <em>Sermons page: search, filters and series</em> feature fills in are labelled "(automatic)". The older Sermons page is kept beside them, named "OLD (kept for rollback)".'
					. '</p><p><strong>Posts &rarr; Categories</strong>: Where a <strong>sermon series</strong> is set up. A series is a category filed under "Series". Its <strong>Description</strong> box is the text shown on the series page, and its <strong>Series graphic</strong> field is the picture on its card and page. Speakers, books of the Bible and topics are categories too, filed under "Speaker", "Bible" and "Topics".',
				'wrong' => array(
					'A new sermon is not on the Sermons page, or not under its series.' => 'The page is worked out afresh whenever a sermon or a category is saved, so open the sermon and press Update. Then check its categories: it needs one category under "Series" to belong to a series, and it shows under a speaker, book or topic only when it has that category.',
					'A new series has no card.' => 'A series shows once at least one published sermon is in it. Create the category under "Series" (Posts &rarr; Categories), then put a sermon in it.',
					'A series shows the wrong picture.' => 'Open the series under Posts &rarr; Categories and choose a picture in <em>Series graphic</em> (1920 by 1080 works best). Until one is chosen, the series borrows the graphic of its first sermon. A sermon with no graphic of its own borrows its series graphic on these pages; a sermon in no series shows the church\'s default graphic (the one chosen under Planning Center &rarr; Settings &rarr; Graphics).',
					'A card says "Sermon from" and a date instead of a title.' => 'That sermon has no title. Open it under Posts, type its title and press Update.',
					'The sermon card was changed in Divi but older sermons look different.' => 'Divi draws the newest 12 cards; older ones are copies of the first card, made when the page opens. Reload the page. For the copies to be filled in, keep the CSS classes on the card\'s layers: <code>tcc-sermon-pic</code> on the picture, <code>tcc-sermon-title</code> on the title and <code>tcc-sermon-series</code> on the series name.',
					'A series card has no picture in the Divi editor.' => 'The card\'s picture layer uses Divi\'s own <em>Category Image</em>, which the feature fills with the series graphic, so the editor shows the real picture for each series. The small line under the name ("27 sermons &middot; 2025 to 2026") and the speaker and date lines are filled in by the feature, so the editor leaves them blank; the website shows them.',
					'A visitor has JavaScript switched off.' => 'They see the newest 12 sermon cards, the series cards, and a plain list of every sermon that opens with one press. Search and the filters need JavaScript.',
					'The search box and filters are missing from the Sermons page.' => 'Check that <em>Sermons page: search, filters and series</em> is on. The bar also needs the list of cards to keep its CSS ID <code>tcc-sermons</code> and each card to keep the layer "Speaker and date (automatic)".',
					'In the Divi editor the filter bar does nothing.' => 'That is expected: the editor shows the bar with its look, but the menus and the search box only work on the website. The same goes for the Community Groups bar, which the editor shows as plain menus with a grey note.',
				),
				'build' => '<p>The sermon lists: sermon cards are a Divi loop of <em>Posts</em>. Series cards are a Divi loop of terms that uses <em>Sermon series - newest first (automatic)</em>, and the rows on a series page are a Divi loop that uses <em>Sermons in this series - oldest first (automatic)</em>. In the series loop, Divi\'s own <em>Category Image</em> gives the series graphic (the website is sent a 768-pixel-wide copy, not the full-size file), and "Loop Term Custom Field" with the key <code>tcc_series_summary</code> gives a line such as "27 sermons &middot; 2025 to 2026".</p>'
					. '<p>Class names this feature looks for on Divi layers (Advanced &rarr; Attributes): <code>tcc-sermon-card</code>, <code>tcc-series-list</code>, <code>tcc-series-card</code>, <code>tcc-part-list</code> and <code>tcc-part-row</code> (the row prints its own part number), <code>tcc-eyebrow</code> and <code>tcc-count</code> on the Sermons and series pages.</p>',
			),
			'sermon-page'          => array(
				'where' => '<strong>Divi &rarr; Theme Builder &rarr; "Individual sermon page - NEW"</strong>: The page every sermon gets. It is an ordinary Divi layout: the player and its Video / Audio switch (a Divi Pixel Content Toggle), the title, the short and long descriptions, the previous and next rows and the four cards at the foot are all Divi layers, and the layers the <em>Sermon page (one sermon)</em> feature fills in are labelled "(automatic)". The sermon page as it was before is kept beside it, named "Individual sermon page - OLD (kept for rollback)". The two players inside the switch are the Divi Library layouts "Sermon Video" and "Sermon Podcast" (Divi &rarr; Divi Library).',
				'wrong' => array(
					'A sermon page does not say which series it is in, or has no previous and next rows.' => 'The sermon needs one category under "Series" (Posts &rarr; the sermon &rarr; Categories). The rows also need at least two sermons in that series. Part numbers go by date, oldest first, so a wrong part number means a wrong date on a sermon in that series.',
					'The cards at the foot of a sermon page are not the ones expected.' => 'For a sermon in a series they are the four newest other parts of that series. For a sermon in no series they are the four newest other sermons.',
					'A "Find more like this" button opens the Sermons page without choosing anything.' => 'The button uses the sermon\'s categories and its speakers (the <em>Speakers</em> box, or the typed <em>Speaker Name</em> on a sermon not filled in yet). Check that <em>Sermons page: search, filters and series</em> is on and that the name is spelled the same way as on that person\'s other sermons.',
					'There is no "Read the full summary" button.' => 'That is right for a short write-up: the button only shows when the <em>Sermon Description - Long</em> text is long enough to be worth shortening. It also needs the long-description layer to keep its CSS ID <code>tcc-sermon-long</code>.',
					'The Video side of a sermon is empty.' => 'Check the sermon\'s <em>Sermon Video</em> field holds the YouTube address. A visitor who has not answered the cookie banner may also see an empty player until they do.',
					'A sermon page has to go back to how it was.' => 'Divi &rarr; Theme Builder: open the settings (cog) of "Individual sermon page - OLD (kept for rollback)", tick Posts &rarr; All Posts, press Save, then Save Changes at the top. That takes All Posts away from the new one. Nothing needs switching off.',
				),
				'build' => '<p>The sermon page lists (loop settings &rarr; post type): <em>Sermon page: previous part of the series (automatic)</em> and <em>Sermon page: next part of the series (automatic)</em> each hold one sermon or none, and <em>Sermon page: more sermons (automatic)</em> holds up to four. Class names on the sermon page: <code>tcc-sp-player</code> on the Video / Audio switch, <code>tcc-sp-eyebrow</code> and <code>tcc-sp-byline</code> on the lines above and below the title, <code>tcc-sp-series</code> on the previous / next section (it hides itself for a sermon with no series), <code>tcc-sp-cell</code> on each half of that section, <code>tcc-sp-row</code> with <code>tcc-sp-prev</code> or <code>tcc-sp-next</code> on the rows, <code>tcc-sp-step</code> on the row\'s small line, <code>tcc-sp-pic</code> on a picture and <code>tcc-sp-card</code> on a card.</p>',
			),
			'sermon-speakers'      => array(
				'where' => 'The <strong>Speakers</strong> box on each sermon\'s edit screen, straight under the Categories box. (The one-time fill-in page, Posts &rarr; Sermon speakers, was removed in 0.14.0 once the older sermons had been filled in on staging.)',
				'how'   => array(
					'pick the speakers of a sermon'               => '<ol>'
						. '<li>Open the sermon under <strong>Posts</strong>. On the right, straight under the Categories box, is a box called <strong>Speakers</strong>.</li>'
						. '<li>Tick everyone who spoke. A <strong>Main speaker</strong> choice appears beside each ticked name. If only one person is ticked, they are the main speaker already.</li>'
						. '<li>If someone is not in the list, type their first and last name under <strong>Add a new speaker</strong> and press <strong>Add</strong>. They are added under Speaker (Posts &rarr; Categories) and ticked. If they were in the list already, that one is ticked instead, so there is never a second copy. Only an Editor or Administrator can add a speaker. Others can tick the ones in the list.</li>'
						. '<li>Press <strong>Update</strong> (or Publish). The website then shows the main speaker first and the others after, for example "Tyler Lynde &amp; Amy Lynde", and each name opens that person\'s sermons.</li>'
						. '</ol><p>Speakers no longer appear in the ordinary <em>Categories</em> box, and "+ Add New Category" does not offer Speaker as a parent. A line under Categories says "Speakers are picked in the Speakers box."</p>'
						. '<p><strong>The Author follows the main speaker.</strong> When an Editor or Administrator saves, and exactly one login on the website has the main speaker\'s name and can write posts, that person becomes the post\'s Author. It is left alone for a guest without a login, when two logins have the same name, and when someone with the Author role saves, so a pastor who posts someone else\'s sermon keeps their own post. If you chose a different Author in the Author box and it changed back, this is why. To keep a different Author, change it with Quick Edit in the Posts list. The next Update on the sermon\'s edit screen by an Editor or Administrator sets it back to the main speaker while the main speaker has a login. Or choose a main speaker without a login.</p>'
						. '<p><strong>Speaker Name</strong> (Sermon Info) is filled in for you once a sermon has its speakers ticked, and shows "Filled in automatically". The Sermon-Publisher app still sends one name; when that name matches a speaker in the list, the box ticks them for you and they become the main speaker once you tick or untick anyone and save; if the name is not in the list, tick or add them. On a sermon that has not been filled in yet, the Speakers box only changes anything once you tick or untick someone, so fixing a typo never changes its speakers. If you untick everyone, the speakers are taken off but the typed Speaker Name stays, so the website shows that typed name again.</p>',
				),
				'wrong' => array(
					'Two people preached one sermon.' => 'Tick both in the sermon\'s <em>Speakers</em> box and choose the main speaker. The card shows "Tyler Lynde &amp; Amy Lynde", and the Speaker menu lists the sermon under each person.',
					'A sermon shows the wrong speaker.' => 'Open it and look at the <em>Speakers</em> box: the website shows the ticked speakers, main speaker first. A sermon nobody has ticked speakers on yet still shows its typed <em>Speaker Name</em>, then its Speaker category, then the person who posted it. Tick its speakers in the Speakers box and press Update.',
					'The Author changed by itself.' => 'That is this feature: the Author follows the main speaker (see "How do I: pick the speakers of a sermon" above for when, and how to keep a different Author).',
				),
			),
			'sermon-audio'         => array(
				'wrong' => array(
					'A sermon has no audio.' => 'Check that <em>Sermon audio player</em> is on, then open the sermon and check that its Podcast field holds the Buzzsprout code for that episode. Only the church\'s own Buzzsprout show (number 1987066, in the code\'s address) is accepted; a code from any other show is ignored. If the church moves to a new Buzzsprout show, the number at the top of the <em>Sermon audio player</em> code must be changed.',
				),
				'links' => '<p>The sermon audio player comes from Buzzsprout. It uses the podcast code saved in the <strong>Podcast</strong> field on each sermon (Sermons &rarr; the sermon &rarr; Sermon Info). No sign-in is stored on the website.</p>',
			),
			'trinity-talk'         => array(
				'where' => '<strong>Divi &rarr; Theme Builder &rarr; the three "Trinity Talk: ... - NEW (shows automatically)" templates</strong>: The page of one Trinity Talk piece, the page of one book, and the Trinity Talk home page. They are ordinary Divi layouts: the words of the piece, the rows and the cards are Divi layers, and the layers the <em>Trinity Talk pages</em> feature fills in are labelled "(automatic)". They are not assigned to anything in the Theme Builder on purpose: the feature shows them on the right pages. The older Trinity Talk layouts are still assigned underneath and show again if the feature is switched off.'
					. '</p><p><strong>Articles, and Articles &rarr; Trinity Talk</strong>: Where the Trinity Talk pieces are written (<strong>Articles</strong>) and where the books are (<strong>Trinity Talk</strong>, the categories). A piece belongs to a book when it has that book\'s category, and its chapter number is read from the start of its title, for example "Matthew 5 | Choosing to Walk The Hard Path".',
				'wrong' => array(
					'A new piece is not on its book\'s page, or has no chapter number.' => 'Open it under Articles. It needs the book\'s category ticked in the <em>Trinity Talk</em> box (for example Matthew), and its title has to start with the book and chapter, then an upright bar: "Matthew 5 | Choosing to Walk The Hard Path". Press Update; the pages are worked out afresh whenever a piece is saved.',
					'Chapters are in the wrong order.' => 'They go by the number at the start of the title, not by date. Check the title of the one that is out of place.',
					'Two pieces show the same chapter number.' => 'That is right when two people wrote about the same chapter. Both show, the older one first.',
					'The short summary on a row or card is not the one wanted.' => 'It is the first sentence or two of the piece. To choose the words, open the piece and type them in the Yoast SEO box, <em>Meta description</em>; that is used instead.',
					'A piece shows under "More writing" on the Trinity Talk home page instead of under a book.' => 'It has no book category. Open it under Articles and tick its book in the <em>Trinity Talk</em> box.',
					'A new book does not show on the home page.' => 'A book shows once it has a published piece. Create the category under Articles &rarr; Trinity Talk with <em>New Testament</em> as its parent, then put a piece in it.',
					'The Trinity Talk pages have to go back to how they were.' => 'Switch <em>Trinity Talk pages</em> off on the Features tab. The older layouts are still assigned in the Theme Builder and show straight away. Nothing needs changing in Divi.',
					'The pages show the older look although the feature is on.' => 'The feature finds its three templates by a short code each one holds: <code>[tcc_talk_panel]</code>, <code>[tcc_talk_book_panel]</code> and <code>[tcc_talk_shelf]</code>. If the layer holding one was deleted, that page falls back to the older layout. Put the short code back (the layer was labelled "(automatic)").',
				),
				'build' => '<p>The Trinity Talk lists (loop settings &rarr; post type): <em>Trinity Talk: previous chapter (automatic)</em> and <em>Trinity Talk: next chapter (automatic)</em> each hold one piece or none, <em>Trinity Talk: more from this book (automatic)</em> holds up to four, <em>Trinity Talk: every chapter of this book (automatic)</em> holds the rows of a book\'s page, and <em>Trinity Talk: pieces in no book (automatic)</em> holds the More writing cards. Class names on those layouts: <code>tcc-tt-row</code> with <code>tcc-tt-prev</code>, <code>tcc-tt-next</code> or <code>tcc-tt-list-row</code> on a row, <code>tcc-tt-tile</code> on its white tile, <code>tcc-tt-card</code> on a card, <code>tcc-tt-side</code> and <code>tcc-tt-book-side</code> on the grey panels, <code>tcc-tt-steps</code> on the previous and next section, <code>tcc-tt-prose</code> on the words of the piece.</p>',
			),
			'termly-look'          => array(
				'wrong' => array(
					'The cookie banner or its Preferences window has small grey words and square buttons.' => 'Check that <em>Cookie banner and preferences window in the church\'s look</em> is on, then ' . $rocket . '. If it is on and still plain, Termly may have renamed the parts it draws; the banner still works, it just has Termly\'s own look until the feature is updated.',
				),
				'links' => '<p>Termly can hold back outside players until a visitor agrees. buzzsprout.com is marked Essential in Termly (Consent Management &rarr; Domain Rules) so the audio player always loads. The banner and its Preferences window are given the website\'s look by the feature <em>Cookie banner and preferences window in the church\'s look</em>. The text on the Privacy Policy, Terms &amp; Conditions and Cookie Policy pages is shown in a Termly frame and keeps Termly\'s look; that is set in Termly.</p>',
			),
			'first-view-styles'    => array(
				'wrong' => array(
					'A page appears for a moment with plain styles (teal pill buttons, wrong widths) and then settles.' => 'Check that <em>No flash of unstyled page</em> is on. Divi prints some pages\' styles far down the page: every page on its first view after a Divi save, and the Sermons, series, Events and search pages every time. That feature lifts them to the top of the page.',
					'On a phone the header is tall, with the logo, Give and Menu on three lines.' => 'Check that <em>No flash of unstyled page</em> is on, then ' . $rocket . '. That feature also stops WP Rocket from putting Divi\'s styles in the wrong order.',
					'Signed out, pages have smaller text or different spacing than you see when signed in' => '(for example the home page text at 14px instead of 20px). Check that <em>No flash of unstyled page</em> is on, then ' . $rocket . ' and look again in a private window after a few minutes. WP Rocket keeps Divi\'s default styles inside the page, after the page\'s own Divi settings, so the defaults win; that feature puts them back in front when WP Rocket makes its copy of each page.',
				),
			),
			'menu-helpers'         => array(
				'where' => '<strong>Divi &rarr; Theme Builder &rarr; the Global Header</strong>: The main menu itself: its words, links, pictures, look, and the red Watch Online button. The <em>Main menu helpers</em> feature finds the menu\'s parts by CSS classes that start with <code>tccm-</code> on its layers (Advanced &rarr; Attributes), so keep those when changing the header.',
				'how'   => array(
					'change when Watch Online shows' => '<p>The button\'s words and link are in the Divi header (the layer with the CSS class <code>tccm-watch</code>). The day and times are in the feature\'s code: on TCC Website &rarr; Features, under <em>Main menu helpers</em>, press <em>See or edit the code</em> and find the line that starts <code>var LIVE</code>. The times are minutes after midnight in Knoxville: 510 is 8:30am and 720 is 12 noon. To see the button on any day, add <code>?navlive=1</code> to the end of a page address.</p>',
				),
				'wrong' => array(
					'The red Watch Online button shows all week, or not at all on a Sunday morning.' => 'Check that <em>Main menu helpers</em> is on, then ' . $rocket . '. It goes by Knoxville time (8:30am to 12 noon on Sunday), not the time on the visitor\'s computer, and checks again every half minute, so it can take up to 30 seconds to appear or go at the edges. To look at it on another day, add <code>?navlive=1</code> to the end of the address.',
					'The drop-down panels change height from one menu button to the next.' => 'Check that <em>Main menu helpers</em> is on. It only evens them out on computer-size screens (981 pixels wide or more); on phones each panel keeps its own height on purpose.',
					'In a window about 1000 pixels wide the menu buttons are missing.' => 'Check that <em>Main menu helpers</em> is on. Divi hides them there when a page has a scroll bar; this feature puts them back.',
				),
			),
			'page-trail'           => array(
				'where' => '<strong>Divi &rarr; Theme Builder</strong>: Layers that a feature fills in are labelled "(automatic)". The back link above the title on the Sermons, series, sermon and search pages is one of them: the layer still called "Trail: Home &gt; ... (automatic)" (its name from before it became one back link), filled in by the <em>Page trail</em> feature.',
				'wrong' => array(
					'The back link above a title (an arrow and one name, such as &larr; Events) is missing, points to the wrong page, or sits too close to or too far from the title.' => 'Check that <em>Page trail</em> is on. The link is the short code <code>[tcc_trail]</code> alone in a Text layer above the title, labelled &ldquo;Back link (automatic)&rdquo; (on the sermon page, <code>[tcc_sermon_crumbs]</code>). An ordinary page points to the page above it, which is its Parent setting in WordPress (Pages &rarr; Quick Edit &rarr; Parent): Men\'s Ministry to Ministries, The Blessed Life to Core Classes Archive. An event points to Events, a community group to Community Groups, a sermon or series to Sermons, a Trinity Talk piece to Trinity Talk. A top-level page points to Home. The gap under it is that layer\'s own bottom margin in Divi (Design &rarr; Spacing). If visitors see a plain &ldquo;#&rdquo; where the arrow should be while you see the arrow when signed in, WP Rocket is serving old styles: ' . $rocket . '.',
				),
			),
			'admin-look'           => array(
				'wrong' => array(
					'The sign-in page shows the WordPress logo instead of the church logo, or the box has square corners.' => 'Check that <em>Church logo on the sign-in page and a tidier Dashboard</em> is on. The logo is the picture <code>Trinity-Community-Church-Logo-with-white-background-1.svg</code> in the Media Library (uploaded in May 2022). If that picture was deleted or renamed, upload it again with the same name, or change the address at the top of the feature\'s code.',
					'The church logo is missing from the top of the left-hand menu.' => 'It is hidden on purpose when the menu is folded to icons (the <em>Collapse menu</em> button at the bottom, or a window narrower than about 960 pixels, which includes phones). Unfold the menu or widen the window. If it is still missing, check that the same feature is on.',
					'The Dashboard is missing a box you want (Activity, Quick Draft, WordPress Events and News, the Welcome panel).' => 'The same feature hides those four. Switch it off to bring them back; the sign-in logo and the menu logo go back to WordPress\'s own look at the same time. Other boxes can be hidden or shown under <em>Screen Options</em> at the top of the Dashboard.',
					'The grey Help tab at the top right of admin screens is missing.' => 'Also hidden by that feature, because the help it gives is WordPress\'s general help, not the church\'s. The church\'s help is beside each feature on TCC Website &rarr; Features, and on its Help tab.',
				),
			),
			'sermon-labels'        => array(
				'wrong' => array(
					'The admin menu says "Posts" again instead of "Sermons".' => 'Check that <em>Sermons, not Posts, in the admin menu</em> is on. The sermons are all still there: they are WordPress posts, so nothing is lost while the menu says Posts.',
					'An edit screen still says "Edit Post" or "Search Posts".' => 'That is expected. This feature only renames the left-hand menu and the "+ New" menu in the top bar, as the old snippet did; the words on the post screens themselves are WordPress\'s own.',
				),
			),
			'category-commas'      => array(
				'wrong' => array(
					'A new series turned into several categories (for example "Faith", "Hope" and "Love").' => 'WordPress splits a name at its commas when it is typed into "+ Add New Category" on a sermon\'s edit screen. Check that <em>Category names keep their commas</em> is on; with it on, the whole name is kept as one category. Remember to choose <strong>Series</strong> as the Parent in that box, or make the series under Posts &rarr; Categories, where there is room for its description and graphic too. Stray categories can be deleted under Posts &rarr; Categories once no sermon uses them.',
				),
			),
		),
		'areas'      => array(
			'events'          => array(
				'wrong' => array(
					'The event cards are missing everywhere.' => 'Check that <em>Event feeds</em> is on, and that The Events Calendar is active under Plugins. If both are fine, check that there really are upcoming, published events under <strong>Events</strong>.',
					'The website looks right to you but not to visitors.' => 'Clear WP Rocket ({{help:tcc-help-any-page|see Problems you might see on any page}}).',
				),
			),
			'planning-center' => array(
				'intro' => array(
					array(
						'title' => 'What this does',
						'html'  => '<p>It copies events from <strong>Planning Center Calendar</strong> onto the website, so nobody has to type them in twice.</p><ul>'
							. '<li>It only brings in events that are <strong>published to Church Center</strong> in Planning Center.</li>'
							. '<li>Nothing appears on the website until someone <strong>approves</strong> it here.</li>'
							. '<li>After that, the website copy is <strong>kept up to date</strong>: change the time in Planning Center and the website follows, usually within the hour.</li>'
							. '<li>It only <strong>reads</strong> Planning Center. It can never change anything there.</li>'
							. '</ul>',
					),
					array(
						'title' => 'How an event gets on the website',
						'html'  => '<ol>'
							. '<li>In Planning Center Calendar, the event is set to show in Church Center.</li>'
							. '<li>Within the hour it appears here under {{pco:waiting|Waiting for approval}}. (Press <em>Check Planning Center now</em> if you do not want to wait.)</li>'
							. '<li>You press <strong>Approve and add to website</strong>. If the website already has the same event made by hand, the page tells you and offers to replace it.</li>'
							. '<li>The event is now on the website and listed under {{pco:synced|On the website}}. A repeating event has its next few dates here; on the website\'s event lists it is one card, with a line such as "Every Wednesday" (Planning Center\'s own wording) and its next date.</li>'
							. '<li>When its last date is over, it drops off these lists by itself. Its page stays as it was.</li>'
							. '</ol>',
					),
					array(
						'title' => 'What comes from Planning Center, and what is yours',
						'html'  => '<p><strong>From Planning Center:</strong> title, date and time, graphic, description, registration link, location, rooms, and categories (from tags marked public).</p>'
							. '<p><strong>Yours on the website:</strong> anything you add to the page itself (text, pictures, buttons), the Register button\'s wording, and every choice in the event\'s <em>Planning Center and registration</em> box.</p>'
							. '<p>If you want to keep your own version of a detail, tick it under <strong>Keep the website\'s version</strong> on that event. Planning Center then leaves it alone.</p>'
							. '<p class="tcc-muted">A change that should apply everywhere (Church Center, the website, room bookings) has to be made in Planning Center. Each event has an <em>Edit in Planning Center</em> link.</p>',
					),
					array(
						'title' => 'Where to find things',
						'html'  => '<p>The tabs of TCC Website &gt; Planning Center: {{pco:waiting|Waiting for approval}}, {{pco:synced|On the website}}, {{pco:conflicts|Conflicts}}, {{pco:changes|Recent changes}}, {{pco:tags|Tags}}, {{pco:rooms|Rooms}} and {{pco:settings|Settings}}. Each tab says what it is for in a "How this tab works" box at its top.</p>'
							. '<p><strong>Events &rarr; an event</strong>: Each event\'s edit screen has a box called <strong>Planning Center and registration</strong>. That is where you change things for one event only.</p>'
							. '<p><strong>Dashboard</strong>: A small box called <strong>Planning Center events</strong> says whether everything is working.</p>',
					),
					array(
						'title' => 'Changing one event',
						'id'    => 'tcc-pco-one-event',
						'html'  => '<ul>'
							. '<li><strong>Hide a room for one event.</strong> Open the event (Events &rarr; the event) and untick the room under <em>Rooms shown</em>. To hide a room everywhere, use the {{pco:rooms|Rooms}} tab.</li>'
							. '<li><strong>Hide the location, end time or description.</strong> On the event, untick it under <em>Show on the event page</em>. To change it for every event, use {{pco:settings|Settings}}.</li>'
							. '<li><strong>Use my own title or graphic.</strong> Change it on the event as usual, then tick <em>Title</em> or <em>Graphic</em> under <em>Keep the website\'s version</em>.</li>'
							. '<li><strong>Write my own description.</strong> On the event, under <em>Description on the event page</em> choose <em>My own text, typed here</em> and type it in the box that opens.</li>'
							. '<li><strong>Change the Register button.</strong> On the event, under <em>Register button</em>, fill in <em>Button text</em> (and <em>Button link</em>, if it should go somewhere other than Planning Center).</li>'
							. '<li><strong>Add text, pictures or buttons.</strong> Just add them to the event\'s page like any other page. The sync never touches the page content.</li>'
							. '<li><strong>Change the "Every Wednesday" line on an event card.</strong> The words are Planning Center\'s, so changing how the event repeats there changes them here at the next check. To use your own words on the website, open the event (Events in the left menu) and type them in the <em>Repeats</em> box in the right-hand column; type <code>none</code> to hide the line.</li>'
							. '<li><strong>Show more dates of a repeating event.</strong> On the event, under <em>If this event repeats</em>, set <em>Upcoming dates to keep on the website</em>. The number for all events is on {{pco:settings|Settings}}. More dates do not add more cards (a repeating event is one card); they let the Events page\'s Month filter find it in later months.</li>'
							. '<li><strong>Fix a wrong start time.</strong> Fix it in Planning Center. If the website shows an earlier time than the real start, a setup or pre-cool time is marked visible on that event in Planning Center.</li>'
							. '</ul>',
					),
				),
				'wrong' => array(
					'Look at the top of TCC Website &gt; Planning Center.' => 'A red label means the last check failed; the message under it says why.',
					'An event is missing.' => 'Is it set to show in Church Center in Planning Center? Is it sitting under {{pco:waiting|Waiting for approval}}, or in the Hidden list at the bottom of that tab?',
					'A change did not come through.' => 'Press <em>Check Planning Center now</em>. If it still does not, look at {{pco:conflicts|Conflicts}}, and check whether that detail is ticked under <em>Keep the website\'s version</em> on the event.',
					'Something changed and you do not know why.' => '{{pco:changes|Recent changes}} lists what it did and when.',
					'An event was removed by mistake.' => 'Removed events go to <strong>Events &rarr; Trash</strong> and can be restored from there.',
					'The checks have stopped.' => 'The Dashboard box says so. Pressing <em>Check Planning Center now</em> always works; if the hourly check stays stopped, the website\'s scheduled tasks need looking at by whoever manages the hosting.',
					'An edit of the code was switched off.' => 'See {{help:tcc-help-needs-look|When a feature says "Needs a look"}}.',
					'It behaves differently from what this page says.' => 'See {{help:tcc-help-needs-look|When a feature says "Needs a look"}}.',
				),
			),
			'sermons'         => array(
				'wrong' => array(
					'The website looks right to you but not to visitors.' => 'Clear WP Rocket ({{help:tcc-help-any-page|see Problems you might see on any page}}).',
				),
			),
			'look'            => array(
				'wrong' => array(
					'The website looks right to you but not to visitors.' => 'Clear WP Rocket ({{help:tcc-help-any-page|see Problems you might see on any page}}).',
				),
			),
		),
		'codes'      => array(
			// Moved unchanged from the old Help tab (0.12.3), with the three Planning Center ones at the end.
			'[tcc_event_day]'        => 'Inside an event card: the event\'s day. Optional: <code>format="F d, Y"</code>.',
			'[tcc_event_time]'       => 'Inside an event card: the time, or "All Day".',
			'[tcc_event_repeats]'    => 'Inside an event card, straight in front of <code>[tcc_event_day]</code>: for an event that repeats, a teal line such as "Every Wednesday" and then the word "Next:". Nothing for a one-off event. The words come from Planning Center, or from the Repeats box on the event\'s edit screen (Events &rarr; the event &rarr; right-hand column), which wins when it is filled in; type <code>none</code> there to hide the line. Optional: <code>next=""</code> leaves out the word "Next:".',
			'[tcc_no_upcoming]'      => 'Under a list: a message that shows only when the list is empty. Optional: <code>category="mens-events"</code>, <code>message="..."</code>.',
			'[tcc_events_paging]'    => 'Previous / Next links for a list that uses "Upcoming Events - every date (automatic)". Optional: <code>per_page="8"</code>.',
			'[tcc_events_filter]'    => 'The filter bar. The list it filters needs the CSS ID <code>tcc-events</code>.',
			'[tcc_event_data]'       => 'Inside each event card on the Events page, so the filter bar knows that card\'s category and month. It is invisible. An event that repeats is one card, and is found under every month it has a date in.',
			'[tcc_sermon_audio]'     => 'The Buzzsprout player for the sermon being viewed.',
			'[tcc_event_facts]'      => 'On an event page: the day, time and place with small teal icons.',
			'[tcc_event_directions]' => 'On an event page: the "Get directions" link. Optional: <code>label="Get directions"</code>.',
			'[tcc_event_date]'       => 'Older event layout: the date and time as text. Optional: <code>layout="stacked"</code>.',
			'[tcc_event_venue]'      => 'Older event layout: the place and its address.',
			'[tcc_search_heading]'   => 'Search page: the words <code>Results for "baptism"</code>. Put it in a Heading or Text layer.',
			'[tcc_search_form]'      => 'Search page: the search-again box.',
			'[tcc_search_results]'   => 'Search page: the Top results cards, the jump buttons and the groups of results. The template that holds this short code is the one used for sitewide searches.',
			'[tcc_group_filter]'     => 'Community Groups page: the bar that filters the group cards by who a group is for, the day it meets and how often, with a search box. The list it filters needs the CSS ID <code>tcc-groups</code>, and each card the CSS class <code>tcc-group-card</code>. A <code>&lt;span class="tcc-group-count"&gt;</code> beside the heading is filled with the number of groups. Who a group is for shows as four press-buttons (Anyone, Co-ed, Women, Men); on a phone they sit two to a row. In the Divi editor the bar shows as a plain preview, with menus instead of buttons and a grey note saying so; that is expected. Twelve cards show at first, with a <em>Show 12 more</em> button and "Showing 12 of 16" under them; choosing a filter shows every match.',
			'[tcc_group_data]'       => 'Inside a group card: nothing a visitor sees. It carries the hidden facts the filter bar reads (who, days, how often) and the words of the group\'s description and organizer for the search box, so every card needs it.',
			'[tcc_sermon_filter]'    => 'Sermons page: the search box and the Series, Speaker, Book and Topic filters. The list it filters needs the CSS ID <code>tcc-sermons</code>, and each card the CSS class <code>tcc-sermon-card</code>. Optional: <code>first="12"</code> for how many cards show at first (keep it the same as the number of posts in the Divi loop).',
			'[tcc_sermon_meta]'      => 'Inside a sermon card: the speaker and the date. It also carries the hidden facts the filters read, so every card needs it.',
			'[tcc_sermon_series]'    => 'Inside a sermon card: the name of its series (nothing when it has none).',
			'[tcc_sermon_count]'     => 'How many sermons there are (on a series page, how many are in that series). <code>what="series"</code> gives the number of series.',
			'[tcc_series_toggle]'    => 'The "See all series" button. The list it opens needs the CSS class <code>tcc-series-list</code>, and each card <code>tcc-series-card</code>.',
			'[tcc_series_graphic]'   => 'Series page: the series graphic.',
			'[tcc_series_facts]'     => 'Series page: how many sermons and the dates of the first and last.',
			'[tcc_series_start]'     => 'Series page: the button to the first sermon. Optional: <code>label="Start with part 1"</code>.',
			'[tcc_trail]'               => 'The back link above a page title: an arrow and one name (&larr; Events on an event, &larr; Ministries on Men\'s Ministry, &larr; Home on a top-level page). Put it alone in a Text layer above the title, and give that layer a bottom margin of 10px. It works out where to point from the page it is on.',
			'[tcc_sermon_crumbs]'       => 'Sermon page: the back link at the top (&larr; Sermons). It prints the same link as <code>[tcc_trail]</code>.',
			'[tcc_sermon_eyebrow]'      => 'Sermon page: the series name and "Part 6 of 27" above the title, or the word Sermon.',
			'[tcc_sermon_byline]'       => 'Sermon page: the speaker and the date. The name opens the Sermons page filtered to that speaker.',
			'[tcc_sermon_series_title]' => 'Sermon page: the series name and part number, for the heading above the previous and next rows.',
			'[tcc_sermon_series_link]'  => 'Sermon page: the "See the whole series" link. Optional: <code>label="See the whole series"</code>.',
			'[tcc_sermon_step]'         => 'Inside a previous or next row: "Previous - Part 5" or "Next - Part 7".',
			'[tcc_sermon_end]'          => 'Sermon page: the note shown in place of a missing row. <code>which="first"</code> or <code>which="last"</code>.',
			'[tcc_sermon_tags]'         => 'Sermon page: the "Find more like this" buttons (speaker, series, scripture, topics).',
			'[tcc_sermon_read_more]'    => 'Sermon page: the "Read the full summary" button. The long text it opens needs the CSS ID <code>tcc-sermon-long</code>. Optional: <code>more="..."</code>, <code>less="..."</code>.',
			'[tcc_sermon_more_title]'   => 'Sermon page: "More from this series" or "Recent sermons", for the heading above the cards at the foot.',
			'[tcc_sermon_part]'         => 'Inside a card at the foot of a sermon page: the part number (or the speaker) and the date.',
			'[tcc_talk_title]'       => 'Trinity Talk: the title without its "Matthew 5 |" start. Inside a row or card it is that piece\'s title.',
			'[tcc_talk_facts]'       => 'One piece: the line under the title, "Matthew &middot; Chapter 5 of 28 &middot; By Mark Medley &middot; 3 minute read". The layer needs the CSS class <code>tcc-tt-facts</code>.',
			'[tcc_talk_panel]'       => 'One piece: the contents of the grey panel (Written by, a button for every chapter, Go further). The template that holds this short code is the one used for every piece.',
			'[tcc_talk_steps_title]' => 'One piece: "Keep reading in Matthew" and the chapter number, for the heading above the previous and next rows.',
			'[tcc_talk_book_link]'   => 'One piece: the "See all 28 chapters" link.',
			'[tcc_talk_step]'        => 'Inside a previous or next row: "Previous chapter" or "Next chapter".',
			'[tcc_talk_end]'         => 'One piece: the note shown in place of a missing row. <code>which="first"</code> or <code>which="last"</code>.',
			'[tcc_talk_more_title]'  => 'One piece: "More from Matthew" (or "More writing"), for the heading above the cards at the foot.',
			'[tcc_talk_home_link]'   => 'A link to the Trinity Talk home page. Optional: <code>label="Back to Trinity Talk"</code>.',
			'[tcc_talk_tile]'        => 'Inside a row: the small white tile with the book and chapter number. <code>label="Chapter"</code> prints the word Chapter instead of the book.',
			'[tcc_talk_card_meta]'   => 'Inside a card: "Matthew 7 &middot; Mark Medley".',
			'[tcc_talk_row_meta]'    => 'Inside a row on a book\'s page: the writer and how long the piece takes to read.',
			'[tcc_talk_summary]'     => 'Inside a row or card: the first sentence or two of the piece, or its Yoast meta description when one was typed.',
			'[tcc_talk_book_lead]'   => 'A book\'s page: the sentence under the book\'s name.',
			'[tcc_talk_start]'       => 'A book\'s page: the "Start with chapter 1" button.',
			'[tcc_talk_book_panel]'  => 'A book\'s page: the contents of the grey panel (Jump to a chapter, Written by, More). The template that holds this short code is the one used for every book.',
			'[tcc_talk_books]'       => 'A button for every book, with how many pieces each has.',
			'[tcc_talk_shelf]'       => 'Trinity Talk home page: one group of book cards. <code>group="gospels"</code>, <code>group="paul"</code> or <code>group="other"</code>. The template that holds this short code is the one used for the home page.',
			'[tcc_talk_loose_count]' => 'Trinity Talk home page: how many pieces are in no book.',
			'[tcc_talk_show_all]'    => 'Trinity Talk home page: the <em>Show 12 more</em> button under the More writing cards, with "Showing 12 of 37" beside it. Twelve cards show at first and each press adds twelve. The list of cards needs the CSS class <code>tcc-tt-loose</code>.',
			'[tcc_pco_description]'  => 'The event\'s description (Planning Center\'s, or the text typed on the event).',
			'[tcc_event_register]'   => 'The Register button. Optional: <code>label="Register"</code>.',
			'[tcc_event_rooms]'      => 'The rooms, as small rounded labels.',
		),
		'pco_tabs'   => array(
			'waiting'   => '<p>New events from Planning Center. Approve them, or hide the ones that should not be on the website.</p>'
				. '<p>An event set to show in Church Center appears here within the hour. (Press <em>Check Planning Center now</em> if you do not want to wait.) Press <strong>Approve and add to website</strong>. If the website already has the same event made by hand, the page tells you and offers to replace it.</p>'
				. '<p>An event you hid is in the Hidden list at the bottom of this tab.</p>',
			'synced'    => '<p>Events you approved. Stop syncing one here, choose its rooms, or jump to its edit screen.</p>'
				. '<p>When an event\'s last date is over, it drops off these lists by itself. Its page stays as it was.</p>'
				. '<p><strong>Take an event off the website.</strong> On this tab, press <em>Stop syncing and remove</em>. Or take it off Church Center in Planning Center and it leaves the website at the next check.</p>',
			'conflicts' => '<p>Only used when the same detail was changed on the website <em>and</em> in Planning Center. You pick which one to keep. Nothing is overwritten until you choose.</p>',
			'changes'   => '<p>A diary of everything it did. Look here first when you wonder "why did that change?".</p>',
			'tags'      => '<p>Which Planning Center tags become website categories (and so which ministry pages an event shows on). Also where a tag can be set to approve events automatically.</p>',
			'rooms'     => '<p>Which rooms may be shown to visitors, and the public name for each.</p>'
				. '<p>This tab hides a room everywhere. To hide it for one event, open the event and untick it under <em>Rooms shown</em>.</p>',
			'settings'  => '<p>The connection to Planning Center, what shows on event pages, and the default graphic.</p>'
				. '<p>The website signs in with a <em>Personal Access Token</em> (an Application ID and a Secret), saved on this tab. It is made at <code>api.planningcenteronline.com/oauth/applications</code> while signed in to Planning Center. The token can do whatever that Planning Center person can do, everywhere in Planning Center, even though the website only reads Calendar with it. So make it while signed in as a Planning Center person who can only see Calendar (Viewer), not as an administrator; Settings &rarr; "How to get these two values" has the steps. If it is ever deleted there, the checks fail until a new one is pasted in.</p>'
				. '<p><strong>Give events without a graphic a picture.</strong> Set the <em>Default graphic</em> on this tab. It is shown for any event that has none. A change shows on the event cards straight away.</p>'
				. '<p><strong>Hide the location, end time or description.</strong> This tab sets it for every event. To hide it for one event, untick it under <em>Show on the event page</em> on the event.</p>'
				. '<p><strong>Show more dates of a repeating event.</strong> This tab sets the number for every event. For one event, set <em>Upcoming dates to keep on the website</em> under <em>If this event repeats</em> on the event.</p>',
		),
		'search_tab' => '<ul>'
			. '<li><strong>Visitors search for a word the website does not use.</strong> On this tab: "Searches that found nothing" shows the words; add the word to a line under "Words that mean the same" beside the word the website does use (for example <code>vbs, vacation bible school</code>), and press Save the list.</li>'
			. '<li><strong>A search brings up too much.</strong> A line under "Words that mean the same" may be too broad. Take the loose word off that line and save. "Put the starting list back" undoes all changes to the list.</li>'
			. '</ul>',
		);
	}
	return $content;
}

/**
 * Turns the link tokens in help wording into links (see the top of this file). A link to the tab
 * being looked at becomes just "#spot", so the page does not reload; the script in screens-look.php
 * opens the folded sections around it.
 */
function tcc_site_help_render( $html ) {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only decides how a link is written.
	$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( 'tcc-site-features' === $page && '' === $tab ) {
		$tab = 'features';
	}
	return preg_replace_callback(
		'/\{\{(feature|area|help|tab|pco):([a-z0-9-]+)\|([^{}]+)\}\}/',
		function ( $m ) use ( $page, $tab ) {
			// The words are fixed text written in this file, so they are printed as they are, like the rest of the help.
			$words = $m[3];
			if ( 'pco' === $m[1] ) {
				if ( ! function_exists( 'tcc_pco_url' ) ) {
					return $words; // Planning Center events is switched off: no screen to link to.
				}
				return '<a href="' . esc_url( tcc_pco_url( $m[2] ) ) . '">' . $words . '</a>';
			}
			if ( 'tab' === $m[1] ) {
				return '<a href="' . esc_url( tcc_site_url( $m[2] ) ) . '">' . $words . '</a>';
			}
			$targets = array(
				'feature' => array( 'features', 'tcc-f-' . $m[2] ),
				'area'    => array( 'features', 'tcc-area-' . $m[2] ),
				'help'    => array( 'help', $m[2] ),
			);
			list( $to_tab, $spot ) = $targets[ $m[1] ];
			$href = ( 'tcc-site-features' === $page && $to_tab === $tab ) ? '#' . $spot : tcc_site_url( $to_tab ) . '#' . $spot;
			return '<a href="' . esc_url( $href ) . '">' . $words . '</a>';
		},
		(string) $html
	);
}

/** A list of problems: each line starts with what you see (bold), then says what to do. */
function tcc_site_help_list( $items ) {
	$html = '<ul>';
	foreach ( (array) $items as $see => $do ) {
		$html .= '<li><strong>' . $see . '</strong> ' . $do . '</li>';
	}
	return $html . '</ul>';
}

/** The short codes a feature provides, each with its note, for whoever builds the pages. */
function tcc_site_help_codes_html( $codes ) {
	if ( ! $codes ) {
		return '';
	}
	$notes = tcc_site_help_content()['codes'];
	$html  = '<p>Each can be placed in a Divi Text layer, and prints nothing when it has nothing to show. Label the layer "(automatic)".</p><table>';
	foreach ( $codes as $code ) {
		$html .= '<tr><th><code>' . esc_html( $code ) . '</code></th><td>' . ( isset( $notes[ $code ] ) ? wp_kses( $notes[ $code ], array( 'code' => array(), 'em' => array() ) ) : '' ) . '</td></tr>';
	}
	return $html . '</table>';
}

/** The parts of one feature's help, in the order they are shown. Every feature has at least three. */
function tcc_site_feature_help_parts( $key, $feature ) {
	$all   = tcc_site_help_content();
	$help  = isset( $all['features'][ $key ] ) ? $all['features'][ $key ] : array();
	$parts = array(
		array( 'title' => 'What it does', 'html' => '<p>' . esc_html( isset( $feature['what'] ) ? $feature['what'] : '' ) . '</p>' ),
		array( 'title' => 'Where it is used', 'html' => '<p>' . esc_html( isset( $feature['where'] ) ? $feature['where'] : '' ) . '</p>' . ( ! empty( $help['where'] ) ? '<p>' . $help['where'] . '</p>' : '' ) ),
	);
	foreach ( isset( $help['how'] ) ? (array) $help['how'] : array() as $title => $html ) {
		$parts[] = array( 'title' => 'How do I: ' . $title, 'html' => $html, 'wide' => true );
	}
	if ( ! empty( $help['wrong'] ) ) {
		$parts[] = array( 'title' => 'If something looks wrong', 'html' => tcc_site_help_list( $help['wrong'] ), 'wide' => count( $help['wrong'] ) > 2 );
	}
	$parts[] = array( 'title' => 'If it were switched off', 'html' => '<p>' . esc_html( isset( $feature['off'] ) ? $feature['off'] : '' ) . '</p>' );
	if ( ! empty( $help['links'] ) ) {
		$parts[] = array( 'title' => 'What it is connected to', 'html' => $help['links'] );
	}
	$build = tcc_site_help_codes_html( isset( $feature['codes'] ) ? $feature['codes'] : array() ) . ( ! empty( $help['build'] ) ? $help['build'] : '' );
	if ( '' !== $build ) {
		$parts[] = array( 'title' => 'For whoever builds the pages', 'html' => $build, 'wide' => true );
	}
	return $parts;
}

/** The parts of a group's own help (things that involve more than one feature in it). Often none. */
function tcc_site_area_help_parts( $area ) {
	$all  = tcc_site_help_content();
	$help = isset( $all['areas'][ $area ] ) ? $all['areas'][ $area ] : array();
	if ( 'planning-center' === $area && function_exists( 'tcc_site_help_pco_live' ) ) {
		$help = tcc_site_help_pco_live( $help );
	}
	$parts = array();
	foreach ( isset( $help['intro'] ) ? (array) $help['intro'] : array() as $one ) {
		$parts[] = array( 'title' => $one['title'], 'html' => $one['html'], 'wide' => true, 'id' => isset( $one['id'] ) ? $one['id'] : '' );
	}
	foreach ( isset( $help['how'] ) ? (array) $help['how'] : array() as $title => $html ) {
		$parts[] = array( 'title' => 'How do I: ' . $title, 'html' => $html, 'wide' => true );
	}
	if ( ! empty( $help['wrong'] ) ) {
		$parts[] = array( 'title' => 'If something looks wrong', 'html' => tcc_site_help_list( $help['wrong'] ), 'wide' => true );
	}
	if ( ! empty( $help['links'] ) ) {
		$parts[] = array( 'title' => 'What it is connected to', 'html' => $help['links'], 'wide' => true );
	}
	return $parts;
}

/** Help parts as one box of columns, with the link tokens turned into links. */
function tcc_site_help_parts_html( $parts ) {
	if ( ! $parts ) {
		return '';
	}
	$html = '<div class="tcc-help-body tcc-help">';
	foreach ( $parts as $part ) {
		$html .= '<section class="tcc-help-part' . ( ! empty( $part['wide'] ) ? ' tcc-help-part--wide' : '' ) . '"' . ( ! empty( $part['id'] ) ? ' id="' . esc_attr( $part['id'] ) . '"' : '' ) . '>';
		$html .= '<h4>' . esc_html( $part['title'] ) . '</h4>' . tcc_site_help_render( $part['html'] ) . '</section>';
	}
	return $html . '</div>';
}

/** The "How this tab works" box of one Planning Center tab ('' for a tab without one). */
function tcc_site_pco_tab_help( $tab ) {
	$boxes = tcc_site_help_content()['pco_tabs'];
	return isset( $boxes[ $tab ] ) ? tcc_site_help_render( $boxes[ $tab ] ) : '';
}

/** The "How this tab works" box of the Search tab. */
function tcc_site_search_tab_help() {
	return tcc_site_help_render( tcc_site_help_content()['search_tab'] );
}

/**
 * The parts of the Planning Center group's help that depend on the website as it is now: whether the
 * feature is on, whether it is connected, and when it last checked (old help.php lines 297 and 358-363).
 */
function tcc_site_help_pco_live( $help ) {
	if ( ! function_exists( 'tcc_planning_center_loaded' ) ) {
		return array(
			'intro' => array(
				array(
					'title' => 'Planning Center events is switched off',
					'html'  => '<p>Switch on <em>Planning Center events</em> below to bring in events from Planning Center. While it is off, nothing new comes in and changes in Planning Center do not reach the website. Events already on the website stay, but their pages lose the description, the rooms and the Register button that Planning Center fills in (a button typed on the event itself still shows). Switching it back on brings everything back.</p>',
				),
			),
		);
	}
	$s    = tcc_pco_settings();
	$last = get_option( 'tcc_pco_last_run', array() );
	$next = wp_next_scheduled( 'tcc_pco_sync_cron' );
	$help['links'] = '<table>'
		. '<tr><th>Planning Center</th><td>' . ( '' !== $s['app_id'] && '' !== $s['secret'] ? tcc_site_pill( 'ok', 'Connected' ) : tcc_site_pill( 'bad', 'Not connected' ) ) . ' The website signs in with a <em>Personal Access Token</em> (an Application ID and a Secret), saved on {{pco:settings|Settings}}. '
		. 'It is made at <code>api.planningcenteronline.com/oauth/applications</code> while signed in to Planning Center. The token can do whatever that Planning Center person can do, everywhere in Planning Center, even though the website only reads Calendar with it. So make it while signed in as a Planning Center person who can only see Calendar (Viewer), not as an administrator; {{pco:settings|Settings}} &rarr; "How to get these two values" has the steps. If it is ever deleted there, the checks fail until a new one is pasted in.'
		. '</td></tr>'
		. '<tr><th>The Events Calendar</th><td>' . ( function_exists( 'tribe_create_event' ) ? tcc_site_pill( 'ok', 'Active' ) : tcc_site_pill( 'bad', 'Not active' ) ) . ' The website\'s events plugin. Approved events are saved there as ordinary events, under <strong>Events</strong> in the left menu.</td></tr>'
		. '<tr><th>The hourly check</th><td>' . ( ! empty( $last['time'] ) ? 'Last ran ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago' : 'Has not run yet' ) . ( $next ? ', next in about ' . esc_html( human_time_diff( time(), max( time(), (int) $next ) ) ) : '' ) . '. The website asks Planning Center for changes about once an hour, using the website\'s scheduled tasks.</td></tr>'
		. '<tr><th>Media Library</th><td>Each Planning Center graphic is copied in once, with "planning-center" in its file name, and shared by every date of the event.</td></tr>'
		. '</table>';
	return $help;
}

/**
 * The Help tab: only what applies to the whole plugin. Each feature's own help is beside its switch
 * on the Features tab. The arguments are kept as they were (the features, the switches, the statuses).
 */
function tcc_site_help_tab( $features, $on, $statuses ) {
	$pill = function ( $ok, $yes, $no ) {
		return tcc_site_pill( $ok ? 'ok' : 'muted', $ok ? $yes : $no );
	};
	$card = function ( $id, $title, $html ) {
		echo '<div class="tcc-card tcc-help" id="' . esc_attr( $id ) . '"><h2>' . esc_html( $title ) . '</h2>' . tcc_site_help_render( $html ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed help wording.
	};

	// Start here (old lines 47-51 and 123).
	$jobs = '<div class="tcc-jobs">'
		. '<a class="tcc-job" href="' . esc_url( tcc_site_url( 'features' ) . '#tcc-f-event-editor-preview' ) . '">' . tcc_site_icon( 'calendar-plus', 24 ) . 'Add a button or picture to one event</a>'
		. '<a class="tcc-job" href="' . esc_url( tcc_site_url( 'features' ) . '#tcc-f-sermon-speakers' ) . '">' . tcc_site_icon( 'microphone', 24 ) . 'Pick the speakers of a sermon</a>'
		. ( function_exists( 'tcc_pco_url' ) ? '<a class="tcc-job" href="' . esc_url( tcc_pco_url( 'waiting' ) ) . '">' . tcc_site_icon( 'circle-check', 24 ) . 'Approve an event from Planning Center</a>' : '' )
		. '</div>';
	$card(
		'tcc-help-start',
		'Start here',
		'<p>It holds the small pieces of the website that the church had built for itself, the things Divi and the website\'s other add-ons cannot do on their own. Each piece is a <strong>feature</strong> with its own switch, and its own help folded under it on the Features tab.</p><ul>'
		. '<li>The pages themselves are still built and edited in <strong>Divi</strong>. This plugin only supplies the automatic parts those pages use.</li>'
		. '<li>Most features have <strong>nothing to fill in</strong>: each is either on or off. <em>Planning Center events</em> is the exception: its settings are on TCC Website &gt; Planning Center.</li>'
		. '<li>If switching a feature off and on is not enough, each feature has a link, <em>See or edit the code</em>, that lets an administrator look at or change its code, with one button to put the original back.</li>'
		. '<li>Most weeks nobody needs to open this screen. Come here when something on the website looks wrong, or to check that everything is working.</li>'
		. '</ul><p><strong>Look at the Features tab first.</strong> Each feature should say <em>Working</em>. One that says <em>Needs a look</em> explains why underneath, in plain words, and its group opens by itself.</p>'
		. $jobs
	);

	// Switching a feature on or off (old lines 62-67, for the switch instead of the buttons).
	$card(
		'tcc-help-switch',
		'Switching a feature on or off',
		'<ol><li>Open the Features tab and open the group the feature is in.</li>'
		. '<li>Press the feature\'s switch. Switching off asks you to confirm and tells you what visitors would notice.</li>'
		. '<li>The change happens straight away. Open the website and look at a page that uses it (each feature\'s help says where it is used).</li>'
		. '<li>If it is not what you expected, press the switch again to put it back. Nothing is lost: switching a feature back on brings everything back.</li>'
		. '</ol><p class="tcc-muted">Leave a feature on unless you have a reason to switch it off. Every one of them is used somewhere on the website.</p>'
	);

	// When a feature says "Needs a look" (old lines 204-208; $code_link becomes the Features tab).
	$card(
		'tcc-help-needs-look',
		'When a feature says "Needs a look"',
		'<p class="tcc-muted">Each line starts with what you see, then says what to do.</p><ul>'
		. '<li><strong>A feature says "Another copy of this code is running".</strong> Its old snippet has been switched back on. Go to <strong>Snippets</strong> and deactivate the snippet it names.</li>'
		. '<li><strong>Things went wrong right after a plugin update.</strong> Switch the affected feature off here and tell whoever looks after the website\'s code. Most features were once a snippet under <strong>Snippets</strong>. Those old snippets are no longer kept switched off there as a stand-by (on this website they were moved to the Snippets Trash in November 2026), but a copy of each is in the website\'s code repository, in the <code>snippets</code> folder, if someone needs one back while they look into it.</li>'
		. '<li><strong>A feature says "Working (edited code)".</strong> Someone changed its code and the website is running that edit. That is fine if it was meant. To go back, press <em>Open my edit</em> under the feature\'s switch on the Features tab, then <em>Put the original back</em>.</li>'
		. '<li><strong>A feature says its edit was switched off.</strong> An edit of its code caused an error, so the plugin went back to the original by itself. The website is working. Press <em>Fix or remove my edit</em> under the feature\'s switch on the Features tab: the error message is shown there. Fix the edit or put the original back.</li>'
		. '<li><strong>Nobody here can work out what is wrong.</strong> Use the panel {{help:tcc-ai|Ask an AI assistant about this plugin}} on this page. It gives an AI assistant the background it needs to help.</li>'
		. '</ul>'
	);

	// Problems you might see on any page (old line 133: the one place the WP Rocket steps are written out).
	$card(
		'tcc-help-any-page',
		'Problems you might see on any page',
		'<ul>'
		. '<li><strong>The website looks right to you but not to visitors</strong> (an old colour, a missing style, a plain "#" where an arrow should be). WP Rocket keeps its own copies of pages. Go to Settings &rarr; WP Rocket and press <em>Clear Used CSS</em>, then <em>Clear and Preload Cache</em>, and look again in a private window.</li>'
		. '<li><strong>Pages look different signed out, or appear for a moment with plain styles.</strong> See {{feature:first-view-styles|No flash of unstyled page}}.</li>'
		. '</ul>'
	);

	// Where things are (old lines 91-92, 96, 100, 101, 103-105, shortened to the places several features share).
	$card(
		'tcc-help-where',
		'Where things are',
		'<table>'
		. '<tr><th>TCC Website &rarr; Features</th><td>Every feature, in groups, with whether it is working, its switch and its own help. Under each switch is <em>See or edit the code</em>, for troubleshooting. Also the button that checks for a new version.</td></tr>'
		. '<tr><th>Divi &rarr; Theme Builder</th><td>The layouts that use these features: the header (Events menu), the Events page, the individual event page, the Sermons page, the series page and the sermon page. Layers that a feature fills in are labelled "(automatic)". Each feature\'s help names its own templates.</td></tr>'
		. '<tr><th>Posts &rarr; Categories</th><td>Sermon series, speakers, books of the Bible and topics, filed under "Series", "Speaker", "Bible" and "Topics". See {{area:sermons|Sermons}}.</td></tr>'
		. '<tr><th>TCC Website &rarr; Planning Center</th><td>Events from Planning Center waiting for approval, the ones on the website, conflicts, tags, rooms and the connection. See {{area:planning-center|Planning Center}}.</td></tr>'
		. '<tr><th>TCC Website &rarr; Search</th><td>Two things for the website search: the list of <strong>searches that found nothing</strong>, and the <strong>words that mean the same</strong> (so "kids" also finds "children"). See {{feature:sitewide-search|Sitewide search page}}.</td></tr>'
		. '<tr><th>Pages</th><td>The home page and the ministry and class pages hold event cards. Each card area is a normal Divi loop that uses an "Upcoming Events (automatic)" list.</td></tr>'
		. '<tr><th>Events</th><td>The events themselves (The Events Calendar). The feeds show whatever upcoming events are published there.</td></tr>'
		. '<tr><th>Snippets</th><td>Where many of these features lived before this plugin. Only two older snippets still run there: <em>Current year</em> (the year in the footer\'s copyright line) and <em>WP Rocket Image Lazy Load Helper</em>. The old copies of the features were moved to the Snippets Trash in November 2026.</td></tr>'
		. '</table>'
	);

	// What it is connected to (old lines 109-117; Buzzsprout and Termly point to their features, which hold the detail).
	$card(
		'tcc-help-links',
		'What it is connected to',
		'<table>'
		. '<tr><th>Divi</th><td>The pages and layouts call these features by short codes (listed in each feature\'s help) and by choosing an "Upcoming Events (automatic)" list in a loop. Those are set in the Divi editor, on the layer that shows them.</td></tr>'
		. '<tr><th>The Events Calendar</th><td>' . $pill( function_exists( 'tribe_get_events' ), 'Active', 'Not active' ) . ' Every event feature reads its events from here. If it is switched off under <strong>Plugins</strong>, the event lists are simply empty.</td></tr>'
		. '<tr><th>Planning Center</th><td>' . $pill( function_exists( 'tcc_planning_center_loaded' ), 'On', 'Off' ) . ' Part of this plugin (<em>Planning Center events</em>). The event page banner follows its "what shows" choices, and the feeds use it to treat the dates of one repeating event as one event. Both also work with it switched off. See {{area:planning-center|Planning Center}}.</td></tr>'
		. '<tr><th>Buzzsprout</th><td>The sermon audio player. See {{feature:sermon-audio|Sermon audio player}}.</td></tr>'
		. '<tr><th>The cookie banner (Termly)</th><td>Can hold back outside players until a visitor agrees. See {{feature:termly-look|Cookie banner and preferences window}}.</td></tr>'
		. '<tr><th>Google Maps</th><td>"Get directions" on an event page is an ordinary link that opens Google Maps with the event\'s address. Nothing is set up for it.</td></tr>'
		. '<tr><th>Yoast SEO</th><td>' . $pill( defined( 'WPSEO_VERSION' ), 'Active', 'Not active' ) . ' Writes the titles and descriptions search engines see. The Events feature reads the wording typed under Yoast SEO &rarr; Settings and hands it to Yoast for the Events pages. Without Yoast it does nothing.</td></tr>'
		. '<tr><th>Code Snippets</th><td>' . $pill( defined( 'CODE_SNIPPETS_VERSION' ) || function_exists( 'code_snippets' ), 'Active', 'Not active' ) . ' The plugin behind <strong>Snippets</strong> in the left menu. It still runs two older snippets: <em>Current year</em>, which prints the year in the footer\'s copyright line, and <em>WP Rocket Image Lazy Load Helper</em>. Keep it switched on for those.</td></tr>'
		. '<tr><th>Updates</th><td>Version ' . esc_html( TCC_SITE_VERSION ) . '. New versions come from <code>github.com/' . esc_html( TCC_SITE_RELEASES ) . '</code> and show on the <strong>Plugins</strong> screen like any other update. No password is stored for this. Each version is signed with the church\'s release key, and the website only offers one whose signature matches; if a version on GitHub is not signed, the Updates panel on the Features tab says so and nothing is offered. Tell whoever looks after the church\'s code.</td></tr>'
		. '</table>'
	);

	// Changing the code, and the briefing for an AI assistant (both drawn by code-edits.php; the only AI panel).
	tcc_code_help_card( 'tcc-site-features' );
	tcc_code_ai_card( 'tcc-site-features' );

	// For whoever builds the pages (old lines 217 and 288).
	$card(
		'tcc-help-builder',
		'For whoever builds the pages',
		'<p>Short codes can be placed in a Divi Text layer. Each prints nothing when it has nothing to show. Label any layer that uses one with "(automatic)" so the next person knows it fills itself in.</p>'
		. '<p>Each feature\'s help lists its own short codes, the Divi loop lists it gives and the class names it looks for, under <em>For whoever builds the pages</em>. Press <strong>Open everything</strong> on the Features tab to see them all.</p>'
		. '<p class="tcc-muted">The technical notes are in the church\'s website repository on GitHub, under <code>plugins/tcc-site-features</code> and <code>docs</code>. Without access to it, the panel {{help:tcc-ai|Ask an AI assistant about this plugin}} above carries the same background.</p>'
	);
}
