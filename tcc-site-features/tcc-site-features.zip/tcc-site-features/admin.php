<?php
/**
 * TCC Website Features: the admin screen (TCC Website in the left menu).
 *
 * Two tabs:
 *   Features  one panel per feature: what it does, where it is used, whether it is working, and its switch.
 *   Help      plain-English help for volunteers (see help.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_site_menu() {
	add_menu_page( 'TCC Website Features', 'TCC Website', 'manage_options', 'tcc-site-features', 'tcc_site_admin_page', 'dashicons-admin-site-alt3', 8 );
}
add_action( 'admin_menu', 'tcc_site_menu' );

function tcc_site_url( $tab = 'features', $extra = array() ) {
	return add_query_arg( array_merge( array( 'page' => 'tcc-site-features', 'tab' => $tab ), $extra ), admin_url( 'admin.php' ) );
}

/** A "Features" link beside Deactivate on the Plugins screen. */
function tcc_site_plugin_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( tcc_site_url() ) . '">Features</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __DIR__ . '/tcc-site-features.php' ), 'tcc_site_plugin_links' );

/**
 * Where a feature's code is running from: 'plugin' (this plugin), 'elsewhere' (another copy,
 * normally the old snippet) or '' (not running at all).
 */
function tcc_site_feature_source( $fn ) {
	if ( ! function_exists( $fn ) ) {
		return '';
	}
	try {
		$ref  = new ReflectionFunction( $fn );
		$file = wp_normalize_path( (string) $ref->getFileName() );
	} catch ( \Throwable $e ) {
		return 'elsewhere';
	}
	return ( 0 === strpos( $file, wp_normalize_path( __DIR__ . '/features/' ) ) ) ? 'plugin' : 'elsewhere';
}

/** Names of the snippets that are switched on in the Code Snippets plugin (empty when that plugin is off). */
function tcc_site_active_snippets() {
	global $wpdb;
	if ( ! defined( 'CODE_SNIPPETS_VERSION' ) && ! function_exists( 'code_snippets' ) ) {
		return array();
	}
	$table = $wpdb->prefix . 'snippets';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) !== $table ) {
		return array();
	}
	$names = $wpdb->get_col( "SELECT name FROM {$table} WHERE active = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the table name is built above, nothing here comes from a visitor.
	return is_array( $names ) ? $names : array();
}

/**
 * The status of one feature.
 * Returns array( 'level' => ok | warn | bad | muted, 'label' => short label, 'detail' => a sentence or '' ).
 */
function tcc_site_feature_status( $key, $feature, $on, $snippets ) {
	$features   = tcc_site_features();
	$errors     = isset( $GLOBALS['tcc_site_load_errors'] ) && is_array( $GLOBALS['tcc_site_load_errors'] ) ? $GLOBALS['tcc_site_load_errors'] : array();
	$source     = tcc_site_feature_source( $feature['fn'] );
	$snippet_on = in_array( $feature['snippet'], $snippets, true );
	$old        = 'the old snippet "' . $feature['snippet'] . '" (Snippets in the left menu)';

	if ( empty( $on[ $key ] ) ) {
		if ( 'elsewhere' === $source ) {
			return array( 'level' => 'muted', 'label' => 'Off here', 'detail' => 'It is still running from ' . $old . '.' );
		}
		return array( 'level' => 'muted', 'label' => 'Off', 'detail' => '' );
	}
	if ( isset( $errors[ $key ] ) ) {
		return array( 'level' => 'bad', 'label' => 'Needs a look', 'detail' => 'This feature could not start, so it has been skipped. The rest of the website is not affected. Pass this message to whoever looks after the website\'s code: ' . $errors[ $key ] );
	}
	if ( 'elsewhere' === $source ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'Another copy of this code is running instead of this plugin\'s copy, probably ' . $old . '. The website still works, but updates to this plugin will not reach this feature until that copy is switched off.' );
	}
	if ( 'plugin' !== $source ) {
		return array( 'level' => 'bad', 'label' => 'Needs a look', 'detail' => 'It is switched on but did not start. Try switching it off and on again; if that does not help, tell whoever looks after the website\'s code.' );
	}
	if ( '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) && ! function_exists( $features[ $feature['needs'] ]['fn'] ) ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'It needs "' . $features[ $feature['needs'] ]['label'] . '", which is switched off. Switch that on as well.' );
	}
	if ( ! empty( $feature['events'] ) && ! function_exists( 'tribe_get_events' ) ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'The Events Calendar plugin is switched off, so this has no events to show. Switch it back on under Plugins.' );
	}
	return array(
		'level'  => 'ok',
		'label'  => 'Working',
		'detail' => $snippet_on ? 'The old snippet "' . $feature['snippet'] . '" is still switched on under Snippets. It does nothing now. It can be deactivated there (keep it, do not delete it).' : '',
	);
}

/** Clears saved copies of whole pages, so a switch shows for visitors straight away. */
function tcc_site_clear_page_caches() {
	try {
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
		}
	} catch ( \Throwable $e ) {
		// A cache that will not clear is not a reason to stop: the pages refresh by themselves later.
	}
}

/** The buttons on the screen all post here. */
function tcc_site_handle_post() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'You are not allowed to change this.' );
	}
	check_admin_referer( 'tcc_site_do', '_tcc_site_nonce' );
	$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';

	if ( 'switch' === $op ) {
		$key      = isset( $_POST['feature'] ) ? sanitize_key( wp_unslash( $_POST['feature'] ) ) : '';
		$turn_on  = ! empty( $_POST['to'] );
		$features = tcc_site_features();
		if ( isset( $features[ $key ] ) ) {
			$on = tcc_site_switches();
			if ( $turn_on ) {
				$on[ $key ] = 1;
			} else {
				unset( $on[ $key ] );
			}
			update_option( 'tcc_site_features', $on, true );
			tcc_site_clear_page_caches();
			wp_safe_redirect( tcc_site_url( 'features', array( 'done' => $turn_on ? 'on' : 'off', 'f' => $key ) ) );
			exit;
		}
	}

	if ( 'check_update' === $op ) {
		$message = tcc_site_update_check_now();
		set_transient( 'tcc_site_notice', $message, 60 );
		wp_safe_redirect( tcc_site_url( 'features', array( 'done' => 'checked' ) ) );
		exit;
	}

	wp_safe_redirect( tcc_site_url() );
	exit;
}
add_action( 'admin_post_tcc_site_do', 'tcc_site_handle_post' );

/** A small button that posts one action. */
function tcc_site_button( $op, $label, $fields = array(), $class = 'button', $confirm = '' ) {
	$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
	$html .= '<input type="hidden" name="action" value="tcc_site_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
	$html .= wp_nonce_field( 'tcc_site_do', '_tcc_site_nonce', true, false );
	foreach ( $fields as $name => $value ) {
		$html .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	return $html;
}

/** The look of the screen: the same white rounded panels and small status labels as Planning Center Sync. */
function tcc_site_admin_css() {
	echo '<style>'
		. '.tcc-site{max-width:1100px}'
		. '.tcc-top{display:flex;flex-wrap:wrap;align-items:center;gap:12px 16px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 18px;margin:14px 0 18px}'
		. '.tcc-top__text{flex:1 1 320px;margin:0;color:#50575e}'
		. '.tcc-pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;line-height:1.7;white-space:nowrap;vertical-align:middle}'
		. '.tcc-pill--ok{background:#e6f6ea;color:#0a6b25}.tcc-pill--warn{background:#fcf3d7;color:#7a5200}.tcc-pill--bad{background:#fbe9e9;color:#8a1f1f}.tcc-pill--muted{background:#f0f0f1;color:#50575e}'
		. '.tcc-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px 18px;margin:0 0 14px}'
		. '.tcc-card>h2:first-child{margin-top:0}'
		. '.tcc-card h2{font-size:16px;margin:0 0 8px}'
		. '.tcc-muted{color:#50575e}'
		. '.tcc-feature{display:flex;flex-wrap:wrap;gap:10px 24px;align-items:flex-start}'
		. '.tcc-feature__text{flex:1 1 420px;min-width:0}'
		. '.tcc-feature__title{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:0 0 6px}'
		. '.tcc-feature__title h2{margin:0}'
		. '.tcc-feature__text p{margin:0 0 6px}'
		. '.tcc-feature__switch{flex:0 0 170px}'
		. '.tcc-feature__switch form{margin:0}'
		. '.tcc-feature__switch .button{width:100%;min-height:40px;text-align:center;font-size:14px}'
		. '.tcc-feature--warn{border-left:4px solid #dba617}.tcc-feature--bad{border-left:4px solid #d63638}'
		. '.tcc-label{font-weight:600;color:#1d2327}'
		. '.tcc-note{background:#f6f7f7;border-radius:6px;padding:8px 12px;margin:8px 0 0!important}'
		. '.tcc-updates{display:flex;flex-wrap:wrap;align-items:center;gap:10px 16px}'
		. '.tcc-updates p{flex:1 1 320px;margin:0}'
		. '.tcc-updates form{margin:0}'
		. '.tcc-help li{margin-bottom:6px}.tcc-help ol,.tcc-help ul{margin-left:20px}.tcc-help ul{list-style:disc}'
		. '.tcc-help table{border-collapse:collapse;width:100%}.tcc-help td,.tcc-help th{padding:8px 12px 8px 0;text-align:left;vertical-align:top;border-top:1px solid #f0f0f1}.tcc-help th{width:210px}'
		. '.tcc-help code{white-space:nowrap}'
		. '@media(max-width:600px){.tcc-feature__switch{flex:1 1 100%}.tcc-help table,.tcc-help tbody,.tcc-help tr,.tcc-help th,.tcc-help td{display:block;width:auto}.tcc-help th{padding-bottom:0}.tcc-help td{border-top:0;padding-top:2px}}'
		. '</style>';
}

function tcc_site_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'features'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only chooses which tab to show.
	$tab      = in_array( $tab, array( 'features', 'help' ), true ) ? $tab : 'features';
	$features = tcc_site_features();
	$on       = tcc_site_switches();
	$snippets = tcc_site_active_snippets();

	$statuses = array();
	$on_count = 0;
	$problems = 0;
	foreach ( $features as $key => $feature ) {
		$statuses[ $key ] = tcc_site_feature_status( $key, $feature, $on, $snippets );
		if ( ! empty( $on[ $key ] ) ) {
			$on_count++;
		}
		if ( in_array( $statuses[ $key ]['level'], array( 'warn', 'bad' ), true ) ) {
			$problems++;
		}
	}

	tcc_site_admin_css();
	echo '<div class="wrap tcc-site"><h1>TCC Website Features</h1>';

	// The strip at the top: what this is, and whether everything is working.
	echo '<div class="tcc-top"><p class="tcc-top__text">The church\'s own website features, each with its own switch. ' . (int) $on_count . ' of ' . count( $features ) . ' are switched on. <a href="' . esc_url( tcc_site_url( 'help' ) ) . '">How this works</a></p>';
	if ( $problems > 0 ) {
		echo '<span class="tcc-pill tcc-pill--warn">' . (int) $problems . ' ' . ( 1 === $problems ? 'feature needs' : 'features need' ) . ' a look</span>';
	} elseif ( 0 === $on_count ) {
		echo '<span class="tcc-pill tcc-pill--muted">Nothing switched on yet</span>';
	} else {
		echo '<span class="tcc-pill tcc-pill--ok">Everything switched on is working</span>';
	}
	echo '</div>';

	// What just happened.
	$done = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$f    = isset( $_GET['f'] ) ? sanitize_key( wp_unslash( $_GET['f'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ( 'on' === $done || 'off' === $done ) && isset( $features[ $f ] ) ) {
		echo '<div class="notice notice-success inline"><p>"' . esc_html( $features[ $f ]['label'] ) . '" is now switched ' . esc_html( $done ) . '. Have a look at the website to make sure it is as you expect.</p></div>';
	} elseif ( 'checked' === $done ) {
		$message = get_transient( 'tcc_site_notice' );
		if ( is_string( $message ) && '' !== $message ) {
			delete_transient( 'tcc_site_notice' );
			echo '<div class="notice notice-info inline"><p>' . esc_html( $message ) . '</p></div>';
		}
	}

	echo '<h2 class="nav-tab-wrapper">';
	foreach ( array( 'features' => 'Features', 'help' => 'Help' ) as $key => $label ) {
		echo '<a class="nav-tab' . ( $tab === $key ? ' nav-tab-active' : '' ) . '" href="' . esc_url( tcc_site_url( $key ) ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</h2><div style="margin-top:16px">';

	if ( 'help' === $tab ) {
		tcc_site_help_tab( $features, $on, $statuses );
	} else {
		foreach ( $features as $key => $feature ) {
			$status = $statuses[ $key ];
			$is_on  = ! empty( $on[ $key ] );
			echo '<div class="tcc-card tcc-feature tcc-feature--' . esc_attr( $status['level'] ) . '">';
			echo '<div class="tcc-feature__text">';
			echo '<div class="tcc-feature__title"><h2>' . esc_html( $feature['label'] ) . '</h2><span class="tcc-pill tcc-pill--' . esc_attr( $status['level'] ) . '">' . esc_html( $status['label'] ) . '</span></div>';
			echo '<p>' . esc_html( $feature['what'] ) . '</p>';
			echo '<p class="tcc-muted"><span class="tcc-label">Where it is used:</span> ' . esc_html( $feature['where'] ) . '</p>';
			if ( '' !== $status['detail'] ) {
				echo '<p class="tcc-note">' . esc_html( $status['detail'] ) . '</p>';
			}
			echo '</div><div class="tcc-feature__switch">';
			if ( $is_on ) {
				echo tcc_site_button( 'switch', 'Switch off', array( 'feature' => $key, 'to' => '0' ), 'button', 'Switch off "' . $feature['label'] . '"? What visitors would notice: ' . $feature['off'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in tcc_site_button().
			} else {
				echo tcc_site_button( 'switch', 'Switch on', array( 'feature' => $key, 'to' => '1' ), 'button button-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div></div>';
		}

		// Updates.
		$update = get_option( 'tcc_site_update_status', array() );
		echo '<div class="tcc-card"><h2>Updates</h2><div class="tcc-updates"><p>This is version ' . esc_html( TCC_SITE_VERSION ) . '. ';
		if ( ! empty( $update['message'] ) ) {
			echo esc_html( $update['message'] ) . ' <span class="tcc-muted">(checked ' . esc_html( human_time_diff( (int) $update['time'] ) ) . ' ago)</span> ';
		}
		echo 'New versions show on the <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Plugins</a> screen like any other update; someone still has to press "Update now".</p>';
		echo tcc_site_button( 'check_update', 'Check for a new version now' ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	echo '</div></div>';
}
