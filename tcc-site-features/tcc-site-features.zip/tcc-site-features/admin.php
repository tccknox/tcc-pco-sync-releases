<?php
/**
 * TCC Website: the admin screen (TCC Website in the left menu).
 *
 * Three tabs:
 *   Features  the features in groups (by part of the website). Each feature has its status, one line, its
 *             switch, a link to see or edit its code safely (drawn by code-edits.php) and its own folded help
 *             (the words are in help.php). The look is in screens-look.php.
 *   Search    what visitors searched for and did not find, and the words that mean the same (drawn by
 *             features/sitewide-search.php, so it only has content while that feature is on).
 *   Help      plain-English help for volunteers (see help.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The TCC Website menu: Planning Center (added by planning-center/admin.php while that feature is on),
 * Features, Search and Help. Features, Search and Help are tabs of one screen, so their sub-items link to
 * the tab. The number beside TCC Website is what waits on the Planning Center screen.
 */
function tcc_site_menu() {
	$count = function_exists( 'tcc_pco_waiting_count' ) ? (int) tcc_pco_waiting_count() : 0;
	$badge = $count ? ' <span class="awaiting-mod">' . $count . '</span>' : '';
	add_menu_page( 'TCC Website', 'TCC Website' . $badge, 'manage_options', 'tcc-site-features', 'tcc_site_admin_page', 'dashicons-admin-site-alt3', 7 );
	add_submenu_page( 'tcc-site-features', 'TCC Website: Features', 'Features', 'manage_options', 'tcc-site-features', 'tcc_site_admin_page', 1 );
	add_submenu_page( 'tcc-site-features', 'TCC Website: Search', 'Search', 'manage_options', 'admin.php?page=tcc-site-features&tab=search', '', 2 );
	add_submenu_page( 'tcc-site-features', 'TCC Website: Help', 'Help', 'manage_options', 'admin.php?page=tcc-site-features&tab=help', '', 3 );
}
add_action( 'admin_menu', 'tcc_site_menu', 9 );

/** Keeps the right sub-item highlighted when the Search or Help tab is open. */
function tcc_site_submenu_file( $submenu_file ) {
	if ( isset( $_GET['page'], $_GET['tab'] ) && 'tcc-site-features' === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only highlights a menu item.
		$tab = sanitize_key( wp_unslash( $_GET['tab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( in_array( $tab, array( 'search', 'help' ), true ) ) {
			return 'admin.php?page=tcc-site-features&tab=' . $tab;
		}
	}
	return $submenu_file;
}
add_filter( 'submenu_file', 'tcc_site_submenu_file' );

function tcc_site_url( $tab = 'features', $extra = array() ) {
	return add_query_arg( array_merge( array( 'page' => 'tcc-site-features', 'tab' => $tab ), $extra ), admin_url( 'admin.php' ) );
}

/** A "Features" link beside Deactivate on the Plugins screen. */
function tcc_site_plugin_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( tcc_site_url() ) . '">Features</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __DIR__ . '/tcc-site-features.php' ), 'tcc_site_plugin_links' );

/**
 * Where a feature's code is running from: 'plugin' (this plugin), 'elsewhere' (another copy of the
 * same functions, from some other plugin or code, set up first) or '' (not running at all).
 */
function tcc_site_feature_source( $fn ) {
	if ( ! function_exists( $fn ) ) {
		return '';
	}
	try {
		$ref  = new ReflectionFunction( $fn );
		$file = wp_normalize_path( (string) $ref->getFileName() );
	} catch ( \Throwable $e ) {
		return 'elsewhere';
	}
	// A saved edit of the feature  counts as this plugin's copy too.
	if ( tcc_code_is_edit_file( $file, 'tcc-site-features' ) ) {
		return 'plugin';
	}
	return ( 0 === strpos( $file, wp_normalize_path( __DIR__ . '/features/' ) ) ) ? 'plugin' : 'elsewhere';
}

/**
 * The status of one feature.
 * Returns array( 'level' => ok | warn | bad | muted, 'label' => short label, 'detail' => a sentence or '' ).
 */
function tcc_site_feature_status( $key, $feature, $on ) {
	$features   = tcc_site_features();
	$errors     = isset( $GLOBALS['tcc_site_load_errors'] ) && is_array( $GLOBALS['tcc_site_load_errors'] ) ? $GLOBALS['tcc_site_load_errors'] : array();
	$source     = tcc_site_feature_source( $feature['fn'] );

	if ( empty( $on[ $key ] ) ) {
		return array( 'level' => 'muted', 'label' => 'Off', 'detail' => '' );
	}
	// An edit of this feature's code  that caused an error has been switched off by itself.
	$code_state = tcc_code_state( 'tcc-site-features', 'features/' . $key . '.php' );
	if ( 'planning-center' === $key && 'broken' !== $code_state ) {
		// Planning Center events is four files; a broken edit of any of the other three counts the same.
		foreach ( array( 'sync.php', 'options.php', 'admin.php' ) as $pc_file ) {
			if ( 'broken' === tcc_code_state( 'tcc-site-features', 'planning-center/' . $pc_file ) ) {
				$code_state = 'broken';
			}
		}
	}
	if ( 'broken' === $code_state && ! isset( $errors[ $key ] ) && 'plugin' === $source && 'broken' !== tcc_code_state( 'tcc-site-features', 'features/' . $key . '.php' ) ) {
		// An edit of one of Planning Center events' other files: its "Fix or remove my edit" button is in the list of files at the bottom, not beside the switch.
		foreach ( array( 'sync.php', 'options.php', 'admin.php' ) as $pc_file ) {
			if ( 'broken' === tcc_code_state( 'tcc-site-features', 'planning-center/' . $pc_file ) ) {
				$files = tcc_site_code_files();
				return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'Someone edited the code of "' . $files[ 'planning-center/' . $pc_file ]['label'] . '" and the edit caused an error, so it was switched off automatically. The original code is running and the website is working. Open "The rest of the plugin\'s code, and how editing it works" at the bottom of this page, find "' . $files[ 'planning-center/' . $pc_file ]['label'] . '" and press "Fix or remove my edit" there.' );
			}
		}
	}
	if ( 'broken' === $code_state && ! isset( $errors[ $key ] ) && 'plugin' === $source ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'Someone edited this feature\'s code and the edit caused an error, so it was switched off automatically. The original code is running and the website is working. Press "Fix or remove my edit" beside it to fix the edit or put the original back.' );
	}
	if ( isset( $errors[ $key ] ) ) {
		return array( 'level' => 'bad', 'label' => 'Needs a look', 'detail' => 'This feature could not start, so it has been skipped. The rest of the website is not affected. Pass this message to whoever looks after the website\'s code: ' . $errors[ $key ] );
	}
	if ( 'elsewhere' === $source ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'Another copy of this code (from some other plugin or code on the website, not from this plugin) is running instead of this plugin\'s copy. The website still works, but updates to this plugin will not reach this feature until that copy is switched off. Tell whoever looks after the website\'s code.' );
	}
	if ( 'plugin' !== $source ) {
		return array( 'level' => 'bad', 'label' => 'Needs a look', 'detail' => 'It is switched on but did not start. Try switching it off and on again; if that does not help, tell whoever looks after the website\'s code.' );
	}
	if ( '' !== $feature['needs'] && isset( $features[ $feature['needs'] ] ) && ! function_exists( $features[ $feature['needs'] ]['fn'] ) ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'It needs "' . $features[ $feature['needs'] ]['label'] . '", which is switched off. Switch that on as well.' );
	}
	if ( ! empty( $feature['events'] ) && ! function_exists( 'tribe_get_events' ) ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'The Events Calendar plugin is switched off, so this has no events to show. Switch it back on under Plugins.' );
	}
	// A feature may report things that would quietly make it worse (see tcc_search_health in sitewide-search.php).
	if ( 'sitewide-search' === $key && function_exists( 'tcc_search_health' ) ) {
		$problems = tcc_search_health();
		if ( $problems ) {
			return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => implode( ' ', $problems ) );
		}
	}
	if ( 'edited' === $code_state && tcc_code_is_behind( 'tcc-site-features', 'features/' . $key . '.php' ) ) {
		return array( 'level' => 'warn', 'label' => 'Needs a look', 'detail' => 'This feature is running an edited copy of its code that was made before the last plugin update, so it is missing whatever that update changed in this file. Press "Open my edit" beside it, compare it with the new original, then put the original back or make the same change again on top of it.' );
	}
	if ( 'edited' === $code_state ) {
		return array( 'level' => 'ok', 'label' => 'Working (edited code)', 'detail' => 'This feature is running an edited copy of its code, not the original that came with the plugin. Plugin updates will not change it until the original is put back. Press "Open my edit" beside it.' );
	}
	return array(
		'level'  => 'ok',
		'label'  => 'Working',
		'detail' => '',
	);
}

/** Clears saved copies of whole pages, so a switch shows for visitors straight away. */
function tcc_site_clear_page_caches() {
	try {
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			sg_cachepress_purge_cache();
		}
	} catch ( \Throwable $e ) {
		// A cache that will not clear is not a reason to stop: the pages refresh by themselves later.
	}
}

/** The buttons on the screen all post here. */
function tcc_site_handle_post() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'You are not allowed to change this.' );
	}
	check_admin_referer( 'tcc_site_do', '_tcc_site_nonce' );
	$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';

	if ( 'switch' === $op ) {
		$key      = isset( $_POST['feature'] ) ? sanitize_key( wp_unslash( $_POST['feature'] ) ) : '';
		$turn_on  = ! empty( $_POST['to'] );
		$features = tcc_site_features();
		if ( isset( $features[ $key ] ) ) {
			$on = tcc_site_switches();
			if ( $turn_on ) {
				$on[ $key ] = 1;
			} else {
				unset( $on[ $key ] );
			}
			update_option( 'tcc_site_features', $on, true );
			/** Lets a feature react to being switched on or off (Planning Center starts and stops its hourly check). */
			do_action( 'tcc_site_feature_switched', $key, $turn_on );
			tcc_site_clear_page_caches();
			wp_safe_redirect( tcc_site_url( 'features', array( 'done' => $turn_on ? 'on' : 'off', 'f' => $key ) ) );
			exit;
		}
	}

	if ( 'check_update' === $op ) {
		$message = tcc_site_update_check_now();
		set_transient( 'tcc_site_notice', $message, 60 );
		wp_safe_redirect( tcc_site_url( 'features', array( 'done' => 'checked' ) ) );
		exit;
	}

	// The Search tab (words that mean the same, and the list of searches that found nothing).
	if ( 0 === strpos( $op, 'search_' ) && function_exists( 'tcc_search_admin_save' ) ) {
		$done = tcc_search_admin_save( $op );
		wp_safe_redirect( tcc_site_url( 'search', $done ? array( 'done' => $done ) : array() ) );
		exit;
	}

	wp_safe_redirect( tcc_site_url() );
	exit;
}
add_action( 'admin_post_tcc_site_do', 'tcc_site_handle_post' );

/** A small button that posts one action. */
function tcc_site_button( $op, $label, $fields = array(), $class = 'button', $confirm = '' ) {
	$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
	$html .= '<input type="hidden" name="action" value="tcc_site_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
	$html .= wp_nonce_field( 'tcc_site_do', '_tcc_site_nonce', true, false );
	foreach ( $fields as $name => $value ) {
		$html .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	return $html;
}

function tcc_site_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'features'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only chooses which tab to show.
	$tab      = in_array( $tab, array( 'features', 'search', 'help' ), true ) ? $tab : 'features';
	$features = tcc_site_features();
	$on       = tcc_site_switches();

	$statuses = array();
	$on_count = 0;
	$problems = 0;
	foreach ( $features as $key => $feature ) {
		$statuses[ $key ] = tcc_site_feature_status( $key, $feature, $on );
		if ( ! empty( $on[ $key ] ) ) {
			$on_count++;
		}
		if ( in_array( $statuses[ $key ]['level'], array( 'warn', 'bad' ), true ) ) {
			$problems++;
		}
	}

	if ( $problems > 0 ) {
		$pill = tcc_site_pill( 'warn', $problems . ' ' . ( 1 === $problems ? 'feature needs' : 'features need' ) . ' a look' );
	} elseif ( 0 === $on_count ) {
		$pill = tcc_site_pill( 'muted', 'Nothing switched on yet' );
	} else {
		$pill = tcc_site_pill( 'ok', 'Everything switched on is working' );
	}
	$sentence = 'The pieces of the website the church built for itself, each with its own switch and its own help. ' . (int) $on_count . ' of ' . count( $features ) . ' are switched on. <a href="' . esc_url( tcc_site_url( 'help' ) . '#tcc-help-start' ) . '">How this works</a>';
	$tabs     = array(
		'features' => array( 'label' => 'Features', 'url' => tcc_site_url( 'features' ) ),
		'search'   => array( 'label' => 'Search', 'url' => tcc_site_url( 'search' ) ),
		'help'     => array( 'label' => 'Help', 'url' => tcc_site_url( 'help' ) ),
	);

	echo '<div class="wrap tcc-site">';
	tcc_site_screen_header( 'TCC Website', $sentence, $pill, $tabs, $tab );

	// What just happened.
	$done = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$f    = isset( $_GET['f'] ) ? sanitize_key( wp_unslash( $_GET['f'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ( 'on' === $done || 'off' === $done ) && isset( $features[ $f ] ) ) {
		echo '<div class="notice notice-success inline"><p>"' . esc_html( $features[ $f ]['label'] ) . '" is now switched ' . esc_html( $done ) . '. Have a look at the website to make sure it is as you expect.</p></div>';
	} elseif ( 'checked' === $done ) {
		$message = get_transient( 'tcc_site_notice' );
		if ( is_string( $message ) && '' !== $message ) {
			delete_transient( 'tcc_site_notice' );
			echo '<div class="notice notice-info inline"><p>' . esc_html( $message ) . '</p></div>';
		}
	}

	if ( 'help' === $tab ) {
		tcc_site_help_tab( $features, $on, $statuses );
	} elseif ( 'features' === $tab && '' !== tcc_code_open_file( 'tcc-site-features' ) ) {
		// One file's code is open (reached by "See or edit the code" on a feature).
		tcc_code_tab( 'tcc-site-features' );
	} elseif ( 'search' === $tab ) {
		if ( function_exists( 'tcc_site_search_tab_help' ) ) {
			echo tcc_site_fold( 'How this tab works', tcc_site_search_tab_help(), 'tcc-tabhelp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed help wording, links already made.
		}
		if ( function_exists( 'tcc_search_admin_tab' ) ) {
			tcc_search_admin_tab();
		} else {
			echo '<div class="tcc-card"><h2>Search</h2><p>' . tcc_site_pill( 'muted', 'Off' ) . ' This tab belongs to the "Sitewide search page" feature, which is switched off. Switch it on under <a href="' . esc_url( tcc_site_url() . '#tcc-f-sitewide-search' ) . '">Features</a> to see what visitors search for and to set the words that mean the same.</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	} else {
		tcc_code_notices( 'tcc-site-features' );
		echo '<div class="tcc-tools"><button type="button" class="tcc-linkbutton" data-tcc-open="all">Open everything</button><button type="button" class="tcc-linkbutton" data-tcc-open="none">Close everything</button></div>';
		echo '<div class="tcc-areas">';
		$areas = tcc_site_areas();
		foreach ( tcc_site_features_by_area() as $area_key => $keys ) {
			tcc_site_area_section( $area_key, $areas[ $area_key ], $keys, $features, $on, $statuses );
		}
		echo '</div>';

		// Updates.
		$update = tcc_site_update_status(); // In updater.php: the last check, never in an older version's words.
		echo '<div class="tcc-card"><h2>Updates</h2><div class="tcc-updates"><p>This is version ' . esc_html( TCC_SITE_VERSION ) . '. ';
		if ( ! empty( $update['message'] ) ) {
			echo esc_html( $update['message'] ) . ' <span class="tcc-muted">(checked ' . esc_html( human_time_diff( (int) $update['time'] ) ) . ' ago)</span> ';
		}
		echo 'New versions show on the <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Plugins</a> screen like any other update; someone still has to press "Update now".</p>';
		echo tcc_site_button( 'check_update', 'Check for a new version now' ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		// The rest of the code (Planning Center's files, the help's words), folded away.
		// The fold opens by itself when an edit of a file that is not a feature has been switched off after an error.
		$code_open = '';
		foreach ( array_keys( tcc_site_code_files() ) as $rel ) {
			if ( 0 !== strpos( $rel, 'features/' ) && 'broken' === tcc_code_state( 'tcc-site-features', $rel ) ) {
				$code_open = ' open';
				break;
			}
		}
		echo '<details class="tcc-fold tcc-tabhelp" id="tcc-code-list"' . $code_open . '><summary>' . tcc_site_icon( 'puzzle', 18 ) . '<span>The rest of the plugin\'s code, and how editing it works</span>' . tcc_site_icon( 'chevron-down', 18, 'tcc-chev' ) . '</summary><div class="tcc-fold__body">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		tcc_code_tab( 'tcc-site-features', 'The features', false );
		echo '</div></details>';
	}

	echo '</div>';
}

/**
 * The status of a group of features: its label, and whether it opens by itself.
 * A group opens by itself when a feature in it needs a look.
 */
function tcc_site_area_status( $keys, $on, $statuses ) {
	$total    = count( $keys );
	$on_count = 0;
	$problems = 0;
	foreach ( $keys as $key ) {
		if ( ! empty( $on[ $key ] ) ) {
			$on_count++;
		}
		if ( in_array( $statuses[ $key ]['level'], array( 'warn', 'bad' ), true ) ) {
			$problems++;
		}
	}
	if ( $problems > 0 ) {
		return array( 'level' => 'warn', 'label' => $problems . ( 1 === $problems ? ' needs a look' : ' need a look' ), 'open' => true );
	}
	if ( 0 === $on_count ) {
		return array( 'level' => 'muted', 'label' => 'Off', 'open' => false );
	}
	if ( $on_count === $total ) {
		return array( 'level' => 'ok', 'label' => 1 === $total ? 'Working' : 'All working', 'open' => false );
	}
	return array( 'level' => 'ok', 'label' => $on_count . ' of ' . $total . ' on, all working', 'open' => false );
}

/** One group on the Features tab: its row, its own help (folded), and its features. */
function tcc_site_area_section( $area_key, $area, $keys, $features, $on, $statuses ) {
	$status = tcc_site_area_status( $keys, $on, $statuses );
	$count  = count( $keys );
	echo '<details class="tcc-area" id="tcc-area-' . esc_attr( $area_key ) . '"' . ( $status['open'] ? ' open' : '' ) . '>';
	echo '<summary><span class="tcc-area__icon">' . tcc_site_icon( $area['icon'] ) . '</span><span class="tcc-area__name">' . esc_html( $area['label'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a fixed drawing.
	echo '<span class="tcc-area__count">' . (int) $count . ( 1 === $count ? ' feature' : ' features' ) . '</span>' . tcc_site_pill( $status['level'], $status['label'] ) . tcc_site_icon( 'chevron-down', 22, 'tcc-chev' ) . '</summary>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<div class="tcc-area__body"><p class="tcc-area__about">' . esc_html( $area['about'] ) . '</p>';
	$parts = function_exists( 'tcc_site_area_help_parts' ) ? tcc_site_area_help_parts( $area_key ) : array();
	if ( $parts ) {
		echo '<div class="tcc-area__help">' . tcc_site_fold( 'Help for the whole group', tcc_site_help_parts_html( $parts ) ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed help wording.
	}
	foreach ( $keys as $key ) {
		tcc_site_feature_card( $key, $features[ $key ], $statuses[ $key ], ! empty( $on[ $key ] ) );
	}
	echo '</div></details>';
}

/** One feature: name, status, one line, its note, the switch, the code link, and its help (folded). */
function tcc_site_feature_card( $key, $feature, $status, $is_on ) {
	$short = isset( $feature['short'] ) && '' !== $feature['short'] ? $feature['short'] : $feature['what'];
	echo '<article class="tcc-feature tcc-feature--' . esc_attr( $status['level'] ) . '" id="tcc-f-' . esc_attr( $key ) . '">';
	echo '<div class="tcc-feature__text"><h3>' . esc_html( $feature['label'] ) . ' ' . tcc_site_pill( $status['level'], $status['label'] ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<p class="tcc-feature__short">' . esc_html( $short ) . '</p>';
	if ( '' !== $status['detail'] ) {
		echo '<p class="tcc-feature__note">' . esc_html( $status['detail'] ) . '</p>';
	}
	echo '</div><div class="tcc-feature__do">';
	$confirm = $is_on ? 'Switch off "' . $feature['label'] . '"? What visitors would notice: ' . $feature['off'] : '';
	echo tcc_site_switch( $key, $is_on, $feature['label'], $confirm ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in tcc_site_switch().
	// The step beyond the switch: this feature's code (drawn by code-edits.php).
	echo tcc_code_file_link( 'tcc-site-features', 'features/' . $key . '.php', 'tcc-feature__code' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</div>';
	if ( function_exists( 'tcc_site_feature_help_parts' ) ) {
		echo tcc_site_fold( 'Help for this feature', tcc_site_help_parts_html( tcc_site_feature_help_parts( $key, $feature ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed help wording.
	}
	echo '</article>';
}
