<?php
/**
 * TCC Website: updates from GitHub.
 *
 * How it works (see docs/plugin-updates.md in the church's website repository). The releases repository
 * is named tcc-pco-sync-releases for historical reasons; only the folder tcc-site-features is used:
 *  - New versions are published to the public repository TCC_SITE_RELEASES, in the folder
 *    "tcc-site-features". It holds two files: tcc-site-features.zip and latest.json (version, download
 *    link, checksum, notes). They are written automatically when a version is tagged in the church's
 *    private website repository (see .github/workflows/release-site-features.yml there).
 *  - When WordPress looks for plugin updates, this file reads latest.json. If its version is higher
 *    than the installed one, the normal "Update available" notice shows on the Plugins screen.
 *    Nothing installs by itself: a person presses "Update now".
 *  - No password or secret is stored on the website. The download is checked against the
 *    checksum in latest.json before it is installed.
 *  - Since 0.14.0 every published version is also SIGNED. The release on GitHub signs the version
 *    number and checksum with the church's private release key, which exists only as a secret in the
 *    private website repository. This file holds the matching PUBLIC key (TCC_SITE_RELEASE_KEY) and
 *    offers a new version only when its signature matches. So someone who could change the public
 *    releases repository still could not get the website to install their own code.
 *    A version that is not signed (or signed with another key) is simply not offered; the Features
 *    tab says why. A plugin zip can still be installed by hand under Plugins > Add New > Upload.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_SITE_RELEASES', 'tccknox/tcc-pco-sync-releases' ); // The releases repository is named tcc-pco-sync-releases for historical reasons; only the folder tcc-site-features is used.
define( 'TCC_SITE_RELEASES_FOLDER', 'tcc-site-features' );
define( 'TCC_SITE_RELEASES_RAW', 'https://raw.githubusercontent.com/' . TCC_SITE_RELEASES . '/' );
// The church's public release key (Ed25519, base64). Its private half is the RELEASE_SIGNING_KEY secret of the
// private repository tccknox/tcc-website. To change keys, see docs/plugin-updates.md ("The release key").
define( 'TCC_SITE_RELEASE_KEY', 'GG2hUDsE7hfL9gRznUMe9oE8E5GXdS0ibsoBFuzWASY=' );

/** The exact words a release signs: the plugin, the version and the zip's checksum, one per line. */
function tcc_site_update_signed_text( $version, $sha256 ) {
	return "tcc-site-features\n" . $version . "\n" . $sha256;
}

/**
 * True when $signature (base64) is the church's signature of this version and checksum.
 * $key is only given by the tests; the website always uses TCC_SITE_RELEASE_KEY.
 */
function tcc_site_update_signature_ok( $version, $sha256, $signature, $key = TCC_SITE_RELEASE_KEY ) {
	if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) && is_readable( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php'; // WordPress's own copy, for hosts without PHP's sodium.
	}
	if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
		return false;
	}
	$sig = base64_decode( (string) $signature, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- a signature, not code.
	$pub = base64_decode( (string) $key, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
	if ( false === $sig || 64 !== strlen( $sig ) || false === $pub || 32 !== strlen( $pub ) ) {
		return false;
	}
	try {
		return sodium_crypto_sign_verify_detached( $sig, tcc_site_update_signed_text( $version, $sha256 ), $pub );
	} catch ( \Throwable $e ) {
		return false;
	}
}

function tcc_site_update_basename() {
	return plugin_basename( __DIR__ . '/tcc-site-features.php' );
}

/**
 * Is this download link one of this plugin's own published files? It must come from the releases
 * repository and end in this plugin's folder and file name (the same repository also holds
 * older files of the plugin that was folded into this one, which are not ours to install).
 */
function tcc_site_update_is_ours( $url ) {
	// Exactly: the releases address, one version name (letters, digits, dots, dashes; never "..",
	// so the address cannot step out of the repository), this plugin's folder, and its zip.
	$shape = '#^' . preg_quote( TCC_SITE_RELEASES_RAW, '#' ) . '[A-Za-z0-9_][A-Za-z0-9._-]*/' . preg_quote( TCC_SITE_RELEASES_FOLDER, '#' ) . '/tcc-site-features\.zip$#';
	return is_string( $url ) && 1 === preg_match( $shape, $url ) && false === strpos( $url, '..' );
}

function tcc_site_update_note( $ok, $message ) {
	// 'installed' remembers which version wrote this, because the words can name it ("This is the newest version (0.14.0)").
	update_option( 'tcc_site_update_status', array( 'time' => time(), 'ok' => (bool) $ok, 'message' => (string) $message, 'installed' => TCC_SITE_VERSION ), false );
}

/**
 * The last check, as the Features tab shows it: array( 'time', 'ok', 'message' ), or an empty array.
 *
 * Straight after an update, WordPress runs its own check while the OLD version of this file is still
 * loaded for that one request, so the saved words can name the old version. A note written by any
 * other version than the one running now is therefore not repeated word for word: it says the check
 * was made before the last update, until the next check.
 */
function tcc_site_update_status() {
	$status = get_option( 'tcc_site_update_status', array() );
	if ( ! is_array( $status ) || empty( $status['message'] ) ) {
		return array();
	}
	if ( isset( $status['installed'] ) && TCC_SITE_VERSION === (string) $status['installed'] ) {
		return $status;
	}
	$status['ok']      = true;
	$status['message'] = 'The last check was made before this version was installed. Press "Check for a new version now" to check again.';
	return $status;
}

/**
 * The newest published version, or null. Asked at most every six hours unless $fresh is true.
 * Returns array( 'version', 'asset_url', 'sha256', 'page', 'notes', 'date' ).
 */
function tcc_site_update_latest( $fresh = false ) {
	if ( ! $fresh ) {
		$cached = get_transient( 'tcc_site_update_latest' );
		if ( is_array( $cached ) ) {
			return ! empty( $cached['version'] ) ? $cached : null;
		}
	}
	$response = wp_remote_get(
		TCC_SITE_RELEASES_RAW . 'main/' . TCC_SITE_RELEASES_FOLDER . '/latest.json',
		array( 'timeout' => 15, 'headers' => array( 'User-Agent' => 'TCC Website Features' ) )
	);
	if ( is_wp_error( $response ) ) {
		tcc_site_update_note( false, 'GitHub could not be reached: ' . $response->get_error_message() );
		set_transient( 'tcc_site_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		tcc_site_update_note( false, 'The list of versions could not be read (error ' . $code . ').' );
		set_transient( 'tcc_site_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$data     = json_decode( wp_remote_retrieve_body( $response ), true );
	$version  = is_array( $data ) && isset( $data['version'] ) ? (string) $data['version'] : '';
	$download = is_array( $data ) && isset( $data['download'] ) ? (string) $data['download'] : '';
	$sha      = is_array( $data ) && isset( $data['sha256'] ) ? strtolower( (string) $data['sha256'] ) : '';
	// Only accept a proper version number, a download from the releases repository itself, and a real checksum.
	if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $version ) || ! tcc_site_update_is_ours( $download ) || ! preg_match( '/^[0-9a-f]{64}$/', $sha ) ) {
		tcc_site_update_note( true, 'No published version was found yet.' );
		set_transient( 'tcc_site_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	// Only a version signed with the church's release key is offered (see the top of this file).
	$signature = is_array( $data ) && isset( $data['signature'] ) ? (string) $data['signature'] : '';
	if ( ! tcc_site_update_signature_ok( $version, $sha, $signature ) ) {
		$newer = version_compare( $version, TCC_SITE_VERSION, '>' );
		tcc_site_update_note( ! $newer, $newer ? 'Version ' . $version . ' is on GitHub, but it is not signed with the church\'s release key, so it is not offered here. Tell whoever looks after the church\'s code.' : 'This is the newest version (' . TCC_SITE_VERSION . ').' );
		set_transient( 'tcc_site_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$best  = array(
		'version'   => $version,
		'asset_url' => $download,
		'sha256'    => $sha,
		'page'      => 'https://github.com/' . TCC_SITE_RELEASES . '/tree/main/' . TCC_SITE_RELEASES_FOLDER,
		'notes'     => isset( $data['notes'] ) ? (string) $data['notes'] : '',
		'date'      => isset( $data['date'] ) ? (string) $data['date'] : '',
	);
	$newer = version_compare( $version, TCC_SITE_VERSION, '>' );
	tcc_site_update_note( true, $newer ? 'Version ' . $version . ' is available. Update it on the Plugins screen.' : 'This is the newest version (' . TCC_SITE_VERSION . ').' );
	set_transient( 'tcc_site_update_latest', $best, 6 * HOUR_IN_SECONDS );
	return $best;
}

/** Tells WordPress about a newer version, so the Plugins screen shows the normal update notice. */
function tcc_site_update_inject( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}
	$latest   = tcc_site_update_latest();
	$basename = tcc_site_update_basename();
	// Only our own signed releases may update this plugin. The "Update URI" line at the top of the
	// main file already tells WordPress not to ask wordpress.org about it; this is a second lock in
	// case anything else (wordpress.org, another plugin) offers an "update" for the same folder name.
	if ( isset( $transient->response[ $basename ] ) ) {
		$offer   = $transient->response[ $basename ];
		$package = is_object( $offer ) && isset( $offer->package ) ? (string) $offer->package : '';
		if ( '' === $package || ! tcc_site_update_is_ours( $package ) ) {
			unset( $transient->response[ $basename ] );
		}
	}
	if ( ! $latest ) {
		return $transient;
	}
	$item = (object) array(
		'id'          => 'github.com/' . TCC_SITE_RELEASES . '/' . TCC_SITE_RELEASES_FOLDER,
		'slug'        => 'tcc-site-features',
		'plugin'      => $basename,
		'new_version' => $latest['version'],
		'url'         => $latest['page'],
		'package'     => $latest['asset_url'],
	);
	if ( version_compare( $latest['version'], TCC_SITE_VERSION, '>' ) ) {
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $basename ] = $item;
	} else {
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		$transient->no_update[ $basename ] = $item;
	}
	return $transient;
}
add_filter( 'pre_set_site_transient_update_plugins', 'tcc_site_update_inject' );

/** The "View details" window on the Plugins screen. */
function tcc_site_update_details( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'tcc-site-features' !== $args->slug ) {
		return $result;
	}
	$latest = tcc_site_update_latest();
	if ( ! $latest ) {
		return $result;
	}
	return (object) array(
		'name'          => 'TCC Website',
		'slug'          => 'tcc-site-features',
		'version'       => $latest['version'],
		'author'        => 'Trinity Community Church',
		'homepage'      => $latest['page'],
		'last_updated'  => $latest['date'],
		'download_link' => $latest['asset_url'],
		'sections'      => array(
			'changelog' => '' !== trim( $latest['notes'] ) ? wpautop( esc_html( $latest['notes'] ) ) : '<p>No notes were written for this version.</p>',
		),
	);
}
add_filter( 'plugins_api', 'tcc_site_update_details', 10, 3 );

/**
 * Downloads the new version and checks it against the checksum in latest.json before WordPress installs it.
 */
function tcc_site_update_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
	if ( false !== $reply || ! is_string( $package ) || ! tcc_site_update_is_ours( $package ) ) {
		return $reply;
	}
	$latest = tcc_site_update_latest();
	if ( ! $latest || $latest['asset_url'] !== $package ) {
		$latest = tcc_site_update_latest( true );
	}
	if ( ! $latest || $latest['asset_url'] !== $package ) {
		return new WP_Error( 'tcc_site_download', 'The new version could not be confirmed. Press "Check for a new version now" on TCC Website > Features and try again.' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = download_url( $package, 120 );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	if ( ! hash_equals( $latest['sha256'], strtolower( (string) hash_file( 'sha256', $tmp ) ) ) ) {
		@unlink( $tmp );
		return new WP_Error( 'tcc_site_checksum', 'The downloaded file did not match its checksum, so it was not installed.' );
	}
	return $tmp;
}
// Priority 9: answer early, before any other check of downloads from this repository that could turn this
// plugin's download away as "not confirmed".
add_filter( 'upgrader_pre_download', 'tcc_site_update_download', 9, 4 );

/** Looks again right now (the "Check for a new version" button). Returns the message to show. */
function tcc_site_update_check_now() {
	delete_transient( 'tcc_site_update_latest' );
	tcc_site_update_latest( true );
	delete_site_transient( 'update_plugins' );
	if ( function_exists( 'wp_update_plugins' ) ) {
		wp_update_plugins();
	}
	$status = tcc_site_update_status();
	return isset( $status['message'] ) ? (string) $status['message'] : 'Checked.';
}

/** After this plugin is updated, forget the old "a new version is available" note so the Features tab is not out of date. */
function tcc_site_update_done( $upgrader, $extra ) {
	if ( isset( $extra['type'], $extra['plugins'] ) && 'plugin' === $extra['type'] && in_array( tcc_site_update_basename(), (array) $extra['plugins'], true ) ) {
		delete_transient( 'tcc_site_update_latest' );
		delete_option( 'tcc_site_update_status' );
	}
}
add_action( 'upgrader_process_complete', 'tcc_site_update_done', 10, 2 );
