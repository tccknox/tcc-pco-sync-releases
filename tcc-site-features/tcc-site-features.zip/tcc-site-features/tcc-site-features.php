<?php
/**
 * Plugin Name: TCC Website
 * Description: The church's own website features in one place: the Planning Center events (approving events from Planning Center Calendar and keeping them up to date), the event feeds, the Events filter bar, the pieces of the event page, the real event details and plain labels when an event is open in the Divi editor, the sermon audio player, the Sermons page search and series, the page for one sermon, the Speakers box on sermons, the Trinity Talk pages, the back link above page titles, the forgiving menu hover, the main menu helpers (Watch Online on Sunday mornings and more), the sitewide search page, the first-view style fix, the Community Groups filter bar, the Events titles and descriptions for search engines, the church logo on the sign-in page and in the admin menu, and "Sermons" instead of "Posts" in the admin menu. Each one can be switched on or off under TCC Website in the left menu.
 * Version: 0.14.1
 * Author: Trinity Community Church
 *
 * How it works, in short:
 *  1. Each feature is one file in the "features" folder. Before this plugin existed, each was a
 *     separate snippet in the Code Snippets plugin, stored only in the website's database.
 *  2. A feature's file is loaded only when that feature is switched on (TCC Website > Features).
 *     A new install starts with everything off, so installing the plugin changes nothing by itself.
 *  3. Every feature only sets itself up "if it is not already set up". WordPress loads plugins before
 *     Code Snippets runs its snippets, so when a feature is switched on here, this plugin's copy runs
 *     and an old snippet with the same code quietly steps aside. Nothing is printed twice.
 *  4. If a feature's file ever has a mistake in it, that one feature is skipped and the Features tab
 *     says so. The rest of the website carries on.
 *
 *  5. The Features tab also lets an administrator edit a feature's code. The edit is saved as a separate copy
 *     (wp-content/tcc-code-edits) and run instead of the file here, which is never changed. See code-edits.php.
 *
 *  6. Planning Center events lives in the folder planning-center/ and is loaded by features/planning-center.php,
 *     like any other feature.
 *
 * Apart from the switches, the only settings are those of Planning Center events, on TCC Website > Planning
 * Center. The plugin makes no database tables and contacts no outside service for visitors. It makes two kinds
 * of outside call, both from the admin side or a scheduled task, never for a visitor: the check for a new
 * version (updater.php, a few times a day), and Planning Center events asking Planning Center for changes
 * once an hour (and when someone presses "Check Planning Center now").
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_SITE_VERSION', '0.14.1' );

/**
 * Editing code (code-edits.php): lets an administrator change a feature's code from the admin without
 * touching the original, and put the original back with one button. It has to be loaded before the
 * features, because it decides whether a feature runs its original file or a saved edit of it.
 */
require_once __DIR__ . '/code-edits.php';
tcc_code_register(
	'tcc-site-features',
	array(
		'name'    => 'TCC Website',
		'menu'    => 'TCC Website',
		'dir'     => __DIR__,
		'version' => TCC_SITE_VERSION,
		'page'    => 'tcc-site-features',
		'tab'     => 'features',
		'tab_label' => 'Features',
		'place'   => 'TCC Website > Features',
		'find'    => 'Each feature has a link under its switch, "See or edit the code". The help\'s words and the Planning Center files are in the folded panel "The rest of the plugin\'s code" at the bottom of that tab.',
		'files'   => 'tcc_site_code_files',
		'extra'   => 'tcc_site_code_extra',
		'ai'      => 'tcc_site_ai_notes', // In ai-prompts.php, which is only loaded on the plugin's own screens (tcc_site_on_own_screen).
	)
);

/** The files that can be edited from the Features tab: every feature, and all the help (help.php). */
function tcc_site_code_files() {
	$files = array();
	foreach ( tcc_site_features() as $key => $feature ) {
		$files[ 'features/' . $key . '.php' ] = array(
			'label' => $feature['label'],
			'what'  => $feature['what'],
			'group' => 'The features',
		);
	}
	// A feature's look (features/<key>.css) and script (features/<key>.js), where it has them.
	foreach ( tcc_site_features() as $key => $feature ) {
		foreach ( array( 'css' => 'its look (CSS)', 'js' => 'its script (JavaScript)' ) as $ext => $what ) {
			if ( is_readable( __DIR__ . '/features/' . $key . '.' . $ext ) ) {
				$files[ 'features/' . $key . '.' . $ext ] = array(
					'label' => $feature['label'] . ': ' . $what,
					'what'  => 'css' === $ext
						? 'The styles of "' . $feature['label'] . '". They are printed inside the pages that use them, so a change shows straight away.'
						: 'The script of "' . $feature['label'] . '": what it does in the visitor\'s browser.',
					'group' => 'Looks and scripts of the features',
				);
			}
		}
	}
	// The filter bar shared by the Events page and the Community Groups page.
	foreach ( array( 'css' => 'its look (CSS)', 'js' => 'its script (JavaScript)' ) as $ext => $what ) {
		if ( is_readable( __DIR__ . '/features/filter-bar.' . $ext ) ) {
			$files[ 'features/filter-bar.' . $ext ] = array(
				'label' => 'The filter bar (Events page and Community Groups page): ' . $what,
				'what'  => 'One filter bar, used by "Events filter bar" and "Community Groups filter bar". A change here changes both pages.',
				'group' => 'Looks and scripts of the features',
			);
		}
	}
	$files['planning-center/sync.php']    = array(
		'label' => 'Planning Center events: the sync itself',
		'what'  => 'Asks Planning Center for events, decides what is new or changed, and makes and updates the website\'s events. Also the Register button, the rooms and the description on event pages.',
		'group' => 'Planning Center events',
	);
	$files['planning-center/options.php'] = array(
		'label' => 'Planning Center events: choices for one event',
		'what'  => 'The "what shows" and "keep the website\'s version" choices, the description choice, the default graphic for events without one, and the box on the WordPress Dashboard.',
		'group' => 'Planning Center events',
	);
	$files['planning-center/admin.php']   = array(
		'label' => 'Planning Center events: the screens',
		'what'  => 'The Planning Center screen and its tabs (Waiting for approval, On the website, Conflicts, Recent changes, Tags, Rooms, Settings), every button on them, and the box on each event\'s edit screen.',
		'group' => 'Planning Center events',
	);
	$files['help.php'] = array(
		'label' => 'The help',
		'what'  => 'Every word of help: the help beside each feature on the Features tab, the help of each group, the "How this tab works" boxes on the Planning Center and Search tabs, and the Help tab. Change them here when a feature changes, so the help stays true.',
		'group' => 'The plugin\'s own screens',
	);
	return $files;
}

/** Files an AI assistant is shown so it understands the whole plugin, but which cannot be edited in WordPress. */
function tcc_site_code_extra() {
	return array(
		'tcc-site-features.php' => 'The main file: the list of features and the loader',
		'admin.php'             => 'The admin screen: the tabs, the switches and the status labels',
		'screens-look.php'      => 'The look of the TCC Website screens: styles, icons, the header, the switch',
		'ai-prompts.php'        => 'The wording of the AI prompts',
	);
}

/**
 * The list of features.
 *
 * key (also the file name in /features) => array(
 *   'label'   what volunteers see,
 *   'area'    which group it is shown in on the Features tab (a key of tcc_site_areas()),
 *   'short'   one line under its name on the Features tab ('what' is shown in its help),
 *   'what'    one plain sentence on what it does,
 *   'where'   where on the website it is used,
 *   'off'     what a visitor would notice if it were switched off,
 *   'fn'      a function the file defines (used to tell whether the feature is running, and from where),
 *   'snippet' the name of the old Code Snippets snippet it replaced,
 *   'needs'   key of another feature it cannot work without ('' for none),
 *   'events'  true when it needs The Events Calendar plugin,
 *   'codes'   the short codes it provides, for whoever builds the pages.
 * )
 *
 * Order matters a little: "Event feeds" comes before "Events filter bar", which uses it.
 */
function tcc_site_features() {
	$features = array(
		'event-feeds'      => array(
			'label'   => 'Event feeds',
			'area'    => 'events',
			'short'   => 'The lists of upcoming events that every event card is built from.',
			'what'    => 'Gives Divi the "Upcoming Events (automatic)" lists that the event cards are built from, and the date and time lines on each card. An event that repeats is shown once, with a line such as "Every Wednesday" and its next date.',
			'where'   => 'The home page, the Events page, the Events menu in the header, and the ministry and class pages (Core Classes, The Forge, Men\'s, Women\'s, The Gathering Place, Next Steps, Discovering TCC, Foundations, F.I.T., Baptism).',
			'off'     => 'Every list of upcoming events on the website would be empty.',
			'fn'      => 'tcc_upcoming_ids_for',
			'snippet' => 'TCC upcoming events source for Divi loops',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_day]', '[tcc_event_time]', '[tcc_event_repeats]', '[tcc_no_upcoming]', '[tcc_events_paging]' ),
		),
		'planning-center'  => array(
			'label'   => 'Planning Center events',
			'area'    => 'planning-center',
			'short'   => 'Brings events from Planning Center onto the website after someone approves them.',
			'what'    => 'Brings events that are published to Church Center in Planning Center Calendar onto the website, after someone approves them on TCC Website > Planning Center. Approved events are kept up to date every hour. It only reads Planning Center and never changes anything there.',
			'where'   => 'TCC Website > Planning Center (approving events, conflicts, tags, rooms, settings), a box on the WordPress Dashboard, and a box on each event\'s edit screen. On the website: the events it brings in, and their Register button, rooms and description.',
			'off'     => 'Nothing new comes in from Planning Center and changes there no longer reach the website. Events already on the website stay, but their pages lose what Planning Center fills in: the description, the rooms and the Register button (a button typed on the event itself still shows). A repeating event shows one card per date instead of one card, without its \'Every Wednesday\' line, and events without a graphic lose the default graphic. The Planning Center screen, the Dashboard box and the event box disappear. Nothing is lost: switching it back on brings everything back.',
			'fn'      => 'tcc_planning_center_loaded',
			'snippet' => '',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_pco_description]', '[tcc_event_register]', '[tcc_event_rooms]' ),
		),
		'menu-hover'       => array(
			'label'   => 'Forgiving menu hover',
			'area'    => 'look',
			'short'   => 'Keeps a menu drop-down open while the mouse moves to it.',
			'what'    => 'Keeps a drop-down in the main menu open while the mouse travels to it, so it does not snap shut or jump to another menu.',
			'where'   => 'The header on every page, for people using a mouse.',
			'off'     => 'The menu still works, but the drop-downs close the instant the mouse slips off the button.',
			'fn'      => 'tcc_mega_menu_hover_script',
			'snippet' => 'TCC mega menu forgiving hover',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'menu-helpers'     => array(
			'label'   => 'Main menu helpers',
			'area'    => 'look',
			'short'   => 'Watch Online on Sunday mornings, even drop-downs, and a menu that never goes missing.',
			'what'    => 'Five small jobs for the main menu that Divi cannot do by itself: it shows the red Watch Online button only on Sunday from 8:30am to 12 noon (Knoxville time), makes every drop-down panel the same height, puts the typing cursor in the search box when Search is clicked, keeps the menu buttons showing in windows about 981 to 995 pixels wide (where Divi would hide them), and closes the phone menu when a window changes from the computer layout to the phone layout.',
			'where'   => 'The header on every page.',
			'off'     => 'Watch Online never shows, the drop-downs change height from one menu button to the next, Search needs a second click in its box, the menu buttons can disappear in windows about 981 to 995 pixels wide, and the phone menu can open by itself when a window is made narrower.',
			'fn'      => 'tcc_main_menu_helpers',
			'snippet' => 'TCC main menu helpers',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'events-filter'    => array(
			'label'   => 'Events filter bar',
			'area'    => 'events',
			'short'   => 'The filter bar above the cards on the Events page.',
			'what'    => 'The bar above the list on the Events page that filters the cards by category, month or a search word.',
			'where'   => 'The Events page only.',
			'off'     => 'The filter bar disappears and the Events page simply shows every event.',
			'fn'      => 'tcc_events_filter_shortcode',
			'snippet' => 'TCC events filter bar',
			'needs'   => 'event-feeds',
			'events'  => true,
			'codes'   => array( '[tcc_events_filter]', '[tcc_event_data]' ),
		),
		'sermon-audio'     => array(
			'label'   => 'Sermon audio player',
			'area'    => 'sermons',
			'short'   => 'The Buzzsprout audio player on each sermon page.',
			'what'    => 'Shows the Buzzsprout audio player on a sermon page, using the podcast code saved on that sermon.',
			'where'   => 'Every sermon page (the Audio side of the Video / Audio switch).',
			'off'     => 'The Audio side of every sermon player would be empty.',
			'fn'      => 'tcc_sermon_audio_shortcode',
			'snippet' => 'TCC sermon audio player',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_audio]' ),
		),
		'event-banner'     => array(
			'label'   => 'Event page banner',
			'area'    => 'events',
			'short'   => 'The banner with the day, time and place at the top of each event page.',
			'what'    => 'The day, time and place list beside an event\'s graphic, the "Get directions" link, and the styling that keeps the banner tidy on every screen size.',
			'where'   => 'Every individual event page (the layout "Individual event page - BANNER (new)").',
			'off'     => 'Event pages would lose their day, time and place list and the directions link, and the banner would look untidy.',
			'fn'      => 'tcc_event_facts_shortcode',
			'snippet' => 'TCC event banner shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_facts]', '[tcc_event_directions]' ),
		),
		'event-editor-preview' => array(
			'label'   => 'Event details and labels in the Divi editor',
			'area'    => 'events',
			'short'   => 'Shows each event\'s real details in the Divi editor, and the box for things on one event only.',
			'what'    => 'When an event is open in the Divi editor, the template shows that event\'s real day, time, place, description, rooms and Register button instead of "(filled in automatically)". It also marks the box under "About this event" as "This event only", and shows a warning just under the menu whenever a part of the shared event template is opened, because changes there show on every event.',
			'where'   => 'Only inside the Divi editor, on an event (Events > the event > Edit With Divi). Visitors never see any of it.',
			'off'     => 'Visitors notice nothing. In the editor, events go back to showing "(filled in automatically)" and the two labels disappear.',
			'fn'      => 'tcc_editor_preview_set_event',
			'snippet' => '',
			'needs'   => '',
			'events'  => true,
			'codes'   => array(),
		),
		'sitewide-search'  => array(
			'label'   => 'Sitewide search page',
			'area'    => 'search',
			'short'   => 'The search page for the whole website, and the Search tab.',
			'what'    => 'The page of results a visitor gets from the Search box in the main menu: the three best matches first, then pages, upcoming events, sermons, Trinity Talk and community groups in their own groups. It reads sermon descriptions, speakers and categories and community group details as well as titles and page text, knows words that mean the same, and tries the closest spelling when nothing is found. The Search tab lists what visitors could not find.',
			'where'   => 'Searches of the whole website only. A search limited to one kind of content (such as a sermon-only search) keeps its own page.',
			'off'     => 'Searches would go back to the older, plainer results page. Nothing else changes.',
			'fn'      => 'tcc_search_results_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_search_heading]', '[tcc_search_form]', '[tcc_search_results]' ),
		),
		'sermon-filters'   => array(
			'label'   => 'Sermons page: search, filters and series',
			'area'    => 'sermons',
			'short'   => 'The search box and filters on the Sermons page, and the series cards and series pages.',
			'what'    => 'The search box and the Series, Speaker, Book and Topic filters above the sermon cards, the list of sermon series Divi builds the series cards from, and the facts at the top of each series page. Divi draws the newest 12 cards and the feature copies that card for older sermons, so the page stays quick. It reads everything from the sermons and their categories; nothing is typed in twice.',
			'where'   => 'The Sermons page and the page of each sermon series (the Theme Builder layouts "Sermons page - NEW" and "Sermon series page - NEW").',
			'off'     => 'The Sermons page would lose its search, its filters and its series cards and would show only the newest 12 sermons; series pages would lose their graphic, their facts and their part numbers.',
			'fn'      => 'tcc_sermon_filter_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_filter]', '[tcc_sermon_meta]', '[tcc_sermon_series]', '[tcc_sermon_count]', '[tcc_series_toggle]', '[tcc_series_graphic]', '[tcc_series_facts]', '[tcc_series_start]' ),
		),
		'sermon-page'      => array(
			'label'   => 'Sermon page (one sermon)',
			'area'    => 'sermons',
			'short'   => 'The series line, speaker, previous and next rows and cards on each sermon\'s page.',
			'what'    => 'The pieces of the page for one sermon that Divi cannot work out by itself: the trail at the top, the series name and "Part 6 of 27", the speaker and date, the previous and next part of the series, the "Find more like this" buttons, the "Read the full summary" button, and the four cards at the foot. It reads everything from the sermon and its categories; nothing is typed in twice.',
			'where'   => 'Every sermon page (the Theme Builder layout "Individual sermon page - NEW").',
			'off'     => 'Sermon pages would keep their player, title and descriptions but lose the trail, the series line, the speaker and date, the previous and next rows, the "Find more like this" buttons and the cards at the foot.',
			'fn'      => 'tcc_sermon_crumbs_shortcode',
			'snippet' => '',
			'needs'   => 'sermon-filters',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_crumbs]', '[tcc_sermon_eyebrow]', '[tcc_sermon_byline]', '[tcc_sermon_series_title]', '[tcc_sermon_series_link]', '[tcc_sermon_step]', '[tcc_sermon_end]', '[tcc_sermon_tags]', '[tcc_sermon_read_more]', '[tcc_sermon_more_title]', '[tcc_sermon_part]' ),
		),
		'sermon-speakers'  => array(
			'label'   => 'Sermon speakers: pick them from a list',
			'area'    => 'sermons',
			'short'   => 'Tick a sermon\'s speakers from a list and choose the main speaker.',
			'what'    => 'A Speakers box on each sermon\'s edit screen: tick everyone who spoke, choose the main speaker, and add a new speaker without leaving the page. The speakers are the categories under "Speaker", as before. On save it fills in the Speaker Name field ("Tyler Lynde & Amy Lynde") and, when an Editor or Administrator saves and the main speaker has a login on the website, makes the main speaker the post\'s Author.',
			'where'   => 'Only in the admin area: the edit screen of a sermon (a Post). The website shows the speakers through the Sermons page and sermon page features.',
			'off'     => 'Visitors notice nothing straight away: sermons keep the speakers already ticked. The Speakers box disappears, speakers show again in the ordinary Categories box, and the Author is no longer set for you.',
			'fn'      => 'tcc_speakers_box',
			'snippet' => '',
			'needs'   => 'sermon-filters',
			'events'  => false,
			'codes'   => array(),
		),
		'trinity-talk'     => array(
			'label'   => 'Trinity Talk pages',
			'area'    => 'trinity-talk',
			'short'   => 'The Trinity Talk home page, each book\'s page and each piece\'s page.',
			'what'    => 'The three Trinity Talk pages: the page of one piece (the words on the left, a grey panel with a button for every chapter on the right, the previous and next chapter and four more cards), the page of one book (every chapter as a row with a short summary) and the Trinity Talk home page (all the books). It works out the book from the piece\'s Trinity Talk category and the chapter number from the start of its title, and it shows the three new Divi layouts on those pages by itself.',
			'where'   => 'Every Trinity Talk piece (Articles in the WordPress menu), every book page such as /trinity-talk/matthew/, and the Trinity Talk home page at /articles/. The layouts are in Divi > Theme Builder, named "Trinity Talk: ... - NEW (shows automatically)".',
			'off'     => 'The three Trinity Talk pages would go straight back to their older look (a plain page of text, and dark cards nine to a page). Nothing is lost.',
			'fn'      => 'tcc_talk_title_shortcode',
			'snippet' => '',
			'needs'   => 'page-trail',
			'events'  => false,
			'codes'   => array( '[tcc_talk_title]', '[tcc_talk_facts]', '[tcc_talk_panel]', '[tcc_talk_steps_title]', '[tcc_talk_book_link]', '[tcc_talk_step]', '[tcc_talk_end]', '[tcc_talk_more_title]', '[tcc_talk_home_link]', '[tcc_talk_tile]', '[tcc_talk_card_meta]', '[tcc_talk_row_meta]', '[tcc_talk_summary]', '[tcc_talk_book_lead]', '[tcc_talk_start]', '[tcc_talk_book_panel]', '[tcc_talk_books]', '[tcc_talk_shelf]', '[tcc_talk_loose_count]', '[tcc_talk_show_all]' ),
		),
		'page-trail'       => array(
			'label'   => 'Page trail (the back link above a title)',
			'area'    => 'look',
			'short'   => 'The back link above each page\'s title, such as "← Events".',
			'what'    => 'The small back link above a page title: an arrow and one name, for example "Events" on an event or "Ministries" on Men\'s Ministry. An ordinary page points to the page above it (The Blessed Life to Core Classes Archive); events, groups, sermons and Trinity Talk point to the top of their part of the site (a sermon to Sermons, not its series); a top-level page points back to Home. It replaced the longer line (Home > Ministries > Men\'s Ministry) in November 2026.',
			'where'   => 'Above the title on every page that has one: ordinary pages, the Events page and each event, the Community Groups page and each group, the Sermons, series and sermon pages, the Trinity Talk pages and the search page. In Divi it is a Text layer labelled "Back link (automatic)" holding [tcc_trail].',
			'off'     => 'Those pages would lose the back link above their title (the sermon page would go back to its older, plainer trail). Nothing else changes.',
			'fn'      => 'tcc_trail_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_trail]' ),
		),
		'first-view-styles' => array(
			'label'   => 'No flash of unstyled page',
			'area'    => 'look',
			'short'   => 'Stops pages from showing for a moment with the wrong styles, and keeps signed-out pages right.',
			'what'    => 'Divi sometimes prints a page\'s styles far down the page, after the content they style, so the page appears for a moment with plain default styles (teal pill buttons, wrong widths) and then settles. It does this on the first view of every page after anything is saved in Divi, and on every view of pages that hold an automatic list (Sermons, a sermon series, Events, search). This lifts those styles to the top of the page before it is sent, so the page looks right from the start. It also keeps the styles in the right order in WP Rocket\'s saved copies of pages, which are what signed-out visitors see.',
			'where'   => 'Every page a visitor sees. It does nothing on a page whose styles are already at the top.',
			'off'     => 'The Sermons, series, Events and search pages would flash unstyled for a moment each time they open, and every other page would do so on its first view after a Divi save. Signed-out visitors could also get Divi\'s plain defaults (smaller text, wrong spacing) instead of the page\'s own settings, and the phone header could stack on three lines.',
			'fn'      => 'tcc_first_view_styles_start',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'event-search-text' => array(
			'label'   => 'Events: titles and descriptions for search engines',
			'area'    => 'events',
			'short'   => 'The wording Google shows for the Events pages and for each event.',
			'what'    => 'Gives the Events page and each event category page the title and description that Google and shared links show, using the wording typed in Yoast SEO. It also gives any event with no description of its own a short one, taken from its Planning Center summary.',
			'where'   => 'Not seen on the page itself. It shows in search results, in the browser tab, and when a link to the Events page or an event is shared.',
			'off'     => 'The Events page would go back to a title such as "Events from November 22 - January 6" with no description, and events from Planning Center would have no description in search results.',
			'fn'      => 'tcc_event_search_text_view',
			'snippet' => '',
			'needs'   => '',
			'events'  => true,
			'codes'   => array(),
		),
		'event-date-venue' => array(
			'label'   => 'Event date and venue (older event layout)',
			'area'    => 'events',
			'short'   => 'Prints an event\'s date and place on the older event layout, kept for rollback.',
			'what'    => 'Prints an event\'s date, time and place as plain lines of text.',
			'where'   => 'Only the older event page layout, "Individual event page - NATIVE (kept for rollback)". Keep it on so that layout still works if it is ever needed again.',
			'off'     => 'Nothing today. The older event layout would lose its date and place if it were brought back.',
			'fn'      => 'tcc_event_date_shortcode',
			'snippet' => 'TCC event date and venue shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_date]', '[tcc_event_venue]' ),
		),
		'category-commas'   => array(
			'label'   => 'Category names keep their commas',
			'area'    => 'editing',
			'short'   => 'Keeps a category name with commas in it as one category.',
			'what'    => 'When someone adds a category from a sermon\'s edit screen and its name has a comma in it, such as the series "Faith, Hope, Love", it is saved as one category. Without this, WordPress makes a separate category for each part.',
			'where'   => 'Only in the admin area: the Categories box on the edit screen of a sermon (a Post), under "+ Add New Category". Visitors never see it.',
			'off'     => 'Typing a name with commas into "+ Add New Category" would make several categories again, one for each part of the name.',
			'fn'      => 'tcc_category_commas_hold',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'group-filter'      => array(
			'label'   => 'Community Groups filter bar',
			'area'    => 'groups',
			'short'   => 'The filter bar above the cards on the Community Groups page.',
			'what'    => 'The bar above the group cards on the Community Groups page: who a group is for, the day it meets, how often, and a search box. It also fills in the number beside the heading. It only hides and shows the cards Divi has already drawn, in the visitor\'s browser, and reads everything from each group\'s own fields.',
			'where'   => 'The Community Groups page only.',
			'off'     => 'The filter bar and the number beside the heading disappear, and the page simply shows every active group.',
			'fn'      => 'tcc_group_filter_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_group_filter]', '[tcc_group_data]' ),
		),
		'termly-look'       => array(
			'label'   => 'Cookie banner and preferences window in the church\'s look',
			'area'    => 'look',
			'short'   => 'Gives the cookie banner and its Preferences window the church\'s look.',
			'what'    => 'The cookie banner on a first visit and the Preferences window ("Consent Preferences" in the footer) come from Termly, in Termly\'s small type and square buttons. This gives them the website\'s look: 15px Open Sans, teal links and the website\'s own buttons. What the banner does and remembers is not changed.',
			'where'   => 'Every page: the banner at the foot of the page on a first visit, and the window that opens from it or from Consent Preferences in the footer. The policy pages\' own text is inside a Termly frame and keeps Termly\'s look.',
			'off'     => 'The banner and the Preferences window go back to Termly\'s own look (12px type, square buttons). They keep working the same way.',
			'fn'      => 'tcc_termly_look_css',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'admin-look'        => array(
			'label'   => 'Church logo on the sign-in page and a tidier Dashboard',
			'area'    => 'editing',
			'short'   => 'The church logo on the sign-in page and in the menu, and a tidier Dashboard.',
			'what'    => 'Shows the church logo on the sign-in page (it links to the website) with rounded corners on the sign-in box and no "Register" link, puts the logo at the top of the left-hand admin menu (it opens the website in a new tab), rounds the corners of the small menus that pop out from it, and hides the Dashboard boxes nobody here uses (Welcome, Activity, Quick Draft, WordPress Events and News) and the grey Help tab. The plugin "AGCA - Custom Dashboard & Login Page" did this until November 2026.',
			'where'   => 'Only the sign-in page and the admin screens. Visitors to the website never see it.',
			'off'     => 'Visitors notice nothing. The sign-in page goes back to the WordPress logo, the admin menu loses the church logo, and the four Dashboard boxes and the Help tab come back.',
			'fn'      => 'tcc_admin_look_login_css',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'sermon-labels'     => array(
			'label'   => 'Sermons, not Posts, in the admin menu',
			'area'    => 'editing',
			'short'   => 'Calls posts "Sermons" in the left-hand admin menu and the top bar.',
			'what'    => 'The church keeps its sermons as WordPress posts. This calls them Sermons in the left-hand admin menu ("Sermons" and "Add New Sermon" instead of "Posts", "All Posts" and "Add New Post") and in the black bar along the top ("+ New" > "Sermon"). The sermons themselves are not changed.',
			'where'   => 'Only the admin screens. Visitors to the website never see it.',
			'off'     => 'Visitors notice nothing. In the admin, the menu and the top bar say "Posts" and "Post" again; the sermons are all still there under Posts.',
			'fn'      => 'tcc_sermon_labels_menu',
			'snippet' => 'Change "Posts" to "Sermons',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
	);
	/** Only the tests use this, to try a feature with a group the screen does not know. */
	return apply_filters( 'tcc_site_features', $features );
}

/**
 * The groups on the Features tab, in the order they are shown. Each has a label, an icon (a name
 * known to tcc_site_icon() in screens-look.php) and one sentence. A feature whose 'area' is not here
 * is shown under "Other", so it is never hidden.
 */
function tcc_site_areas() {
	return array(
		'events'          => array( 'label' => 'Events', 'icon' => 'calendar-event', 'about' => 'The event cards, the Events page, each event\'s page, and editing events in Divi.' ),
		'planning-center' => array( 'label' => 'Planning Center', 'icon' => 'refresh', 'about' => 'Events from Planning Center Calendar, approved here and kept up to date.' ),
		'sermons'         => array( 'label' => 'Sermons', 'icon' => 'microphone', 'about' => 'The Sermons page, each series page, each sermon\'s page, and picking a sermon\'s speakers.' ),
		'trinity-talk'    => array( 'label' => 'Trinity Talk', 'icon' => 'book', 'about' => 'The Trinity Talk home page, each book\'s page and each piece\'s page.' ),
		'groups'          => array( 'label' => 'Community Groups', 'icon' => 'users-group', 'about' => 'The filter bar on the Community Groups page.' ),
		'search'          => array( 'label' => 'Search', 'icon' => 'search', 'about' => 'The search page for the whole website.' ),
		'look'            => array( 'label' => 'How every page looks', 'icon' => 'layout', 'about' => 'Pieces that show on every page: the menu, the back link, the styles, and the cookie banner.' ),
		'editing'         => array( 'label' => 'Signing in and editing', 'icon' => 'login-2', 'about' => 'The sign-in page and Dashboard, the word Sermons in the admin menu, and adding categories.' ),
		'other'           => array( 'label' => 'Other', 'icon' => 'puzzle', 'about' => 'Features that have not been given a group yet.' ),
	);
}

/**
 * The features, grouped for the Features tab: area key => list of feature keys, in the order of
 * tcc_site_areas(), leaving out empty groups. Features keep their order from tcc_site_features(), which is also the loading order,
 * so a feature another one needs must stay above it.
 */
function tcc_site_features_by_area() {
	$areas  = tcc_site_areas();
	$groups = array_fill_keys( array_keys( $areas ), array() );
	foreach ( tcc_site_features() as $key => $feature ) {
		$area              = isset( $feature['area'], $areas[ $feature['area'] ] ) ? $feature['area'] : 'other';
		$groups[ $area ][] = $key;
	}
	return array_filter( $groups );
}

/** Which features are switched on: key => 1. Everything is off until someone switches it on. */
function tcc_site_switches() {
	$saved = get_option( 'tcc_site_features', array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Loads the file of every feature that is switched on.
 * A file with a mistake in it is skipped (and remembered for the Features tab) instead of stopping the website.
 */
function tcc_site_load_features() {
	$on     = tcc_site_switches();
	$errors = array();
	foreach ( array_keys( tcc_site_features() ) as $key ) {
		if ( empty( $on[ $key ] ) ) {
			continue;
		}
		$file = __DIR__ . '/features/' . $key . '.php';
		if ( ! is_readable( $file ) ) {
			$errors[ $key ] = 'Its file is missing from the plugin.';
			continue;
		}
		try {
			// Runs the saved edit of this file if there is a healthy one, otherwise the original.
			tcc_code_require( 'tcc-site-features', 'features/' . $key . '.php' );
		} catch ( \Throwable $e ) {
			$errors[ $key ] = $e->getMessage();
		}
	}
	$GLOBALS['tcc_site_load_errors'] = $errors;
}

/**
 * Is this page being drawn for the Divi editor (the visual builder), for someone who can edit?
 *
 * Some features start hidden, or put their styles only on the pages they belong to, and let their
 * script finish the job on the website. The Divi editor does not run those scripts and previews a
 * layout outside its page, so those features ask this first and show a plain preview instead.
 * Visitors never get a "yes": it needs a signed-in editor.
 */
function tcc_site_in_divi_editor() {
	if ( ! did_action( 'init' ) || ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return false;
	}
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	return isset( $_GET['et_fb'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the editor's own page; nothing is changed.
		|| ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() )
		|| false !== strpos( $uri, '/wp-json/divi/' ) // The editor asking the site to draw a piece of a page.
		|| false !== strpos( $uri, 'rest_route=/divi/' );
}

/**
 * Is something other than a visitor's ordinary page view drawing this? The admin, a REST request (the
 * Divi editor asks for its previews that way), the Divi editor itself, or a Theme Builder layout shown
 * as a page of its own while it is edited or previewed.
 *
 * Looser than tcc_site_in_divi_editor(): it does not ask who is signed in. It is only used to show a
 * published example (a sermon, a Trinity Talk book) where nothing is being viewed, so a "yes" for
 * anyone else shows nothing private. Used by the sermon page and Trinity Talk features.
 */
function tcc_site_divi_drawing() {
	$drawing = is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || isset( $_GET['et_fb'] ); // phpcs:ignore WordPress.Security.NonceVerification -- only decides what to preview.
	if ( ! $drawing && did_action( 'wp' ) && is_singular() ) {
		$type    = (string) get_post_type( get_queried_object_id() );
		$drawing = in_array( $type, array( 'et_body_layout', 'et_template', 'et_pb_layout' ), true );
	}
	return $drawing;
}

/* ----------------------------------------------------------------------------------------------
 * Helpers the features share. They live here, not in a feature, because several features use them
 * and any feature can be switched off.
 * -------------------------------------------------------------------------------------------- */

/**
 * Remembered results. Features keep what they work out (the facts about every sermon, the upcoming
 * events, the search vocabulary, ...) in WordPress transients whose names carry a "generation" number.
 * Starting a new generation when the content they came from changes makes every remembered result of
 * that group out of date at once; the old ones simply expire.
 *
 * Groups in use: sermons, talk, search, upcoming, layouts. Each number is kept in the option tcc_<group>_gen.
 */
function tcc_site_gen( $group ) {
	return (int) get_option( 'tcc_' . $group . '_gen', 1 );
}

function tcc_site_new_gen( $group ) {
	update_option( 'tcc_' . $group . '_gen', tcc_site_gen( $group ) + 1, false );
}

/**
 * The text of one of the features' style or script files (features/<key>.css or features/<key>.js),
 * for printing inside the page in the feature's own <style> or <script> block. Keeping the CSS and
 * JavaScript in files of their own makes them readable (and editable with colours and line numbers),
 * while the page itself comes out exactly as before.
 *
 * If an administrator saved an edit of the file (TCC Website > Features, "The code behind this
 * plugin"), the edit is used; "Put the original back" returns to the plugin's own file.
 * Returns '' when the file is missing. The file's last line break is left out.
 */
function tcc_site_asset( $rel ) {
	static $memo = array();
	$rel = (string) $rel;
	if ( ! isset( $memo[ $rel ] ) ) {
		$text         = function_exists( 'tcc_code_text' ) ? tcc_code_text( 'tcc-site-features', $rel, 'running' ) : '';
		$memo[ $rel ] = (string) preg_replace( '/\n\z/', '', $text );
	}
	return $memo[ $rel ];
}

/**
 * WP Rocket's "Remove Unused CSS" keeps its own trimmed copy of each page's styles and can empty
 * small style blocks like the ones the features print. When its copy was made from an older version
 * of a page, a feature could lose its look (the back link once showed a "#" for its arrow). Every
 * style block the features print has an id starting "tcc-", so this one rule tells WP Rocket to leave
 * all of them alone. It does nothing if WP Rocket is not installed.
 */
function tcc_site_keep_styles_from_wp_rocket( $keep ) {
	$keep   = is_array( $keep ) ? $keep : array();
	$keep[] = 'tcc-';
	return $keep;
}
add_filter( 'rocket_rucss_inline_atts_exclusions', 'tcc_site_keep_styles_from_wp_rocket' );

/**
 * The church's default graphic (the church logo on soft grey): the Media Library id chosen under
 * TCC Website > Planning Center > Settings > Graphics, or 0. It is kept with the Planning Center
 * settings (the option tcc_pco_settings, 'fallback_image') and read from there even when that
 * feature is switched off, because sermons without a picture use it too.
 */
function tcc_site_default_graphic() {
	$pco = get_option( 'tcc_pco_settings', array() );
	return is_array( $pco ) && ! empty( $pco['fallback_image'] ) ? (int) $pco['fallback_image'] : 0;
}

/**
 * The items before and after one place in an ordered list (a sermon in its series, a chapter in its
 * book): array( 'prev' => id or 0, 'next' => id or 0 ). $at is the place, counting from 0.
 */
function tcc_site_neighbours( $ids, $at ) {
	$ids = array_values( array_map( 'intval', (array) $ids ) );
	$at  = (int) $at;
	return array(
		'prev' => ( $at > 0 && isset( $ids[ $at - 1 ] ) ) ? $ids[ $at - 1 ] : 0,
		'next' => isset( $ids[ $at + 1 ] ) && $at >= 0 ? $ids[ $at + 1 ] : 0,
	);
}

/**
 * The Divi Theme Builder body layouts that hold some given words (a short code, usually). Found by
 * looking, not by name or number, so renaming a template breaks nothing.
 *
 * $markers: name => text to look for, for example array( 'series' => 'tcc_series_facts' ).
 * Returns name => the layout's id, or 0 when no published layout of a published template holds it.
 * The newest template wins. Remembered for an hour, and forgotten whenever anything is saved in the
 * Theme Builder.
 */
function tcc_site_body_layouts( $markers ) {
	$markers = (array) $markers;
	$key     = 'tcc_layouts_' . tcc_site_gen( 'layouts' ) . '_' . md5( (string) wp_json_encode( $markers ) );
	$cached  = get_transient( $key );
	if ( is_array( $cached ) && ! array_diff_key( $markers, $cached ) ) {
		return $cached;
	}
	$found     = array_fill_keys( array_keys( $markers ), 0 );
	$templates = get_posts(
		array(
			'post_type'        => 'et_template',
			'post_status'      => 'publish',
			'numberposts'      => 100,
			'fields'           => 'ids',
			'orderby'          => 'ID',
			'order'            => 'DESC',
			'suppress_filters' => true,
		)
	);
	foreach ( (array) $templates as $template_id ) {
		$body_id = (int) get_post_meta( $template_id, '_et_body_layout_id', true );
		$body    = $body_id > 0 ? get_post( $body_id ) : null;
		if ( ! ( $body instanceof WP_Post ) || 'publish' !== $body->post_status ) {
			continue;
		}
		foreach ( $markers as $name => $marker ) {
			if ( ! $found[ $name ] && false !== strpos( (string) $body->post_content, (string) $marker ) ) {
				$found[ $name ] = $body_id;
			}
		}
	}
	set_transient( $key, $found, HOUR_IN_SECONDS );
	return $found;
}

function tcc_site_forget_body_layouts() {
	tcc_site_new_gen( 'layouts' );
}
add_action( 'save_post_et_body_layout', 'tcc_site_forget_body_layouts' );
add_action( 'save_post_et_template', 'tcc_site_forget_body_layouts' );
add_action( 'save_post_et_theme_builder', 'tcc_site_forget_body_layouts' );

/**
 * Asks Divi to show this body layout on this page view, whatever the Theme Builder has assigned to
 * the page. For use inside a filter on et_theme_builder_template_layouts.
 */
function tcc_site_use_body_layout( $layouts, $layout_id ) {
	if ( is_array( $layouts ) && (int) $layout_id > 0 ) {
		$layouts['et_body_layout'] = array(
			'id'       => (int) $layout_id,
			'enabled'  => true,
			'override' => true,
		);
	}
	return $layouts;
}

/**
 * Automatic lists for Divi loops.
 *
 * A Divi loop can only list one kind of post. So each automatic list ("Upcoming Events (automatic)",
 * "Sermons in this series - oldest first (automatic)", ...) is a hidden kind of post of its own that
 * never holds anything. When a loop asks for it, the feature that owns it answers with the real items.
 * The hidden kinds are kept out of Yoast's sitemap and out of the Theme Builder's Template Settings.
 *
 * $name      the hidden kind's name (20 letters at most),
 * $label     what Divi shows when someone picks the list in a loop,
 * $answer    a function( $name, $query ) giving the ids to show, in order. A plain list is cut to the
 *            loop's "posts per page". A paged list returns array( 'ids' => this page's ids,
 *            'found' => how many in all, 'pages' => how many pages ) instead.
 * $supports  what the hidden kind "has" (Divi offers its featured image when 'thumbnail' is there).
 *
 * Call it on init (the features use priority 30), or later.
 */
function tcc_site_loop_source( $name, $label, $answer, $supports = array( 'title', 'thumbnail' ) ) {
	$GLOBALS['tcc_site_loop_sources'][ $name ] = $answer;
	register_post_type(
		$name,
		array(
			'labels'              => array(
				'name'          => $label,
				'singular_name' => $label,
			),
			'public'              => true,
			// Must be true or the Divi editor's loop preview ignores the list and shows unrelated content.
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_ui'             => false,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'show_in_rest'        => false,
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => false,
			'supports'            => $supports,
		)
	);
}

/** Every automatic list that has been set up: name => the function that answers for it. */
function tcc_site_loop_sources() {
	return isset( $GLOBALS['tcc_site_loop_sources'] ) && is_array( $GLOBALS['tcc_site_loop_sources'] ) ? $GLOBALS['tcc_site_loop_sources'] : array();
}

/** Answers a Divi loop's request for one of the automatic lists. Any other query is left alone. */
function tcc_site_loop_sources_answer( $posts, $query ) {
	try {
		if ( ! ( $query instanceof WP_Query ) ) {
			return $posts;
		}
		$type    = $query->get( 'post_type' );
		$types   = is_array( $type ) ? array_values( $type ) : array( $type );
		$sources = tcc_site_loop_sources();
		if ( 1 !== count( $types ) || ! is_string( $types[0] ) || ! isset( $sources[ $types[0] ] ) ) {
			return $posts;
		}
		$got = call_user_func( $sources[ $types[0] ], $types[0], $query );
		if ( is_array( $got ) && isset( $got['ids'] ) ) {
			$ids   = array_map( 'intval', (array) $got['ids'] );
			$found = isset( $got['found'] ) ? (int) $got['found'] : count( $ids );
			$pages = isset( $got['pages'] ) ? (int) $got['pages'] : ( $ids ? 1 : 0 );
		} else {
			$ids   = array_map( 'intval', (array) $got );
			$count = (int) $query->get( 'posts_per_page' );
			if ( $count > 0 ) {
				$ids = array_slice( $ids, 0, $count );
			}
			$found = count( $ids );
			$pages = $ids ? 1 : 0;
		}
		$query->found_posts   = $found;
		$query->max_num_pages = $pages;

		if ( 'ids' === $query->get( 'fields' ) ) {
			return $ids;
		}
		$out = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( $post instanceof WP_Post ) {
				$out[] = $post;
			}
		}
		return $out;
	} catch ( \Throwable $e ) {
		return array();
	}
}
add_filter( 'posts_pre_query', 'tcc_site_loop_sources_answer', 10, 2 );

add_filter(
	'wpseo_sitemap_exclude_post_type',
	function ( $excluded, $post_type ) {
		return array_key_exists( (string) $post_type, tcc_site_loop_sources() ) ? true : $excluded;
	},
	10,
	2
);

/** Keeps the automatic lists out of the Theme Builder's "Template Settings" choices: nobody assigns a template to them. */
function tcc_site_loop_sources_hide( $options ) {
	if ( ! is_array( $options ) ) {
		return $options;
	}
	foreach ( array_keys( tcc_site_loop_sources() ) as $name ) {
		foreach ( array_keys( $options ) as $key ) {
			if ( is_string( $key ) && 0 === strpos( $key, $name ) ) {
				unset( $options[ $key ] );
			}
		}
	}
	return $options;
}
add_filter( 'et_theme_builder_template_settings_options', 'tcc_site_loop_sources_hide', 99 );

tcc_site_load_features();

/**
 * Planning Center events checks Planning Center every hour (the scheduled task tcc_pco_sync_cron).
 * It is started when that feature is switched on and stopped when it is switched off or the whole
 * plugin is deactivated. This lives here, not in the feature, because a feature's own file is not
 * loaded in the moment it is switched on.
 */
function tcc_site_feature_switched( $key, $turn_on ) {
	if ( 'planning-center' !== $key ) {
		return;
	}
	if ( $turn_on ) {
		if ( ! wp_next_scheduled( 'tcc_pco_sync_cron' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'tcc_pco_sync_cron' );
		}
	} else {
		wp_clear_scheduled_hook( 'tcc_pco_sync_cron' );
	}
}
add_action( 'tcc_site_feature_switched', 'tcc_site_feature_switched', 10, 2 );

/** Deactivating the plugin stops the hourly Planning Center check. Switches and saved settings are kept. */
function tcc_site_deactivate() {
	wp_clear_scheduled_hook( 'tcc_pco_sync_cron' );
}
register_deactivation_hook( __FILE__, 'tcc_site_deactivate' );

/**
 * A safety net for the search page.
 *
 * The search page template in Divi holds three short codes that the "Sitewide search page" feature
 * fills in. That template is meant to be left unassigned. If someone assigns it to Search Results
 * and the feature is then switched off (or fails to load), Divi would print the short codes as
 * plain text. These stand-ins make that page a plain, working list of results instead.
 * They are only used when the feature has not set up its own.
 */
function tcc_site_search_fallback() {
	if ( shortcode_exists( 'tcc_search_results' ) ) {
		return;
	}
	add_shortcode(
		'tcc_search_heading',
		function () {
			return is_search() ? 'Results for &ldquo;' . esc_html( get_search_query( false ) ) . '&rdquo;' : 'Search the website';
		}
	);
	add_shortcode(
		'tcc_search_form',
		function () {
			return get_search_form( array( 'echo' => false ) );
		}
	);
	add_shortcode(
		'tcc_search_results',
		function () {
			global $wp_query;
			if ( ! is_search() || ! ( $wp_query instanceof WP_Query ) || ! $wp_query->posts ) {
				return '<p>Nothing was found. Please try another word.</p>';
			}
			$html = '<ul>';
			foreach ( $wp_query->posts as $post ) {
				if ( $post instanceof WP_Post ) {
					$html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( wp_strip_all_tags( get_the_title( $post ) ) ) . '</a></li>';
				}
			}
			$html .= '</ul>';
			$pages = paginate_links( array( 'total' => (int) $wp_query->max_num_pages ) );
			return $html . ( $pages ? '<p>' . $pages . '</p>' : '' );
		}
	);
}
add_action( 'init', 'tcc_site_search_fallback', 20 );

/**
 * A safety net for the page trail.
 *
 * Several Divi layouts hold the short code [tcc_trail]. If the "Page trail" feature is switched off
 * (or fails to load), Divi would print the short code as plain text. This stand-in prints nothing
 * instead. It is only used when the feature has not set up its own.
 */
function tcc_site_trail_fallback() {
	if ( ! shortcode_exists( 'tcc_trail' ) ) {
		add_shortcode( 'tcc_trail', '__return_empty_string' );
	}
}
add_action( 'init', 'tcc_site_trail_fallback', 20 );

/**
 * A safety net for event pages when Planning Center events is switched off (or fails to start).
 *
 * The event page layout holds the short codes [tcc_event_register], [tcc_event_rooms] and
 * [tcc_pco_description], which Planning Center events provides. Without it Divi would print them as plain
 * text. These stand-ins print nothing, except that [tcc_event_register] still shows a button typed on the
 * event itself (its "Register button" box on the event's edit screen), looking like the usual one.
 * They are only used when Planning Center events has not set up its own.
 */
function tcc_site_event_codes_fallback() {
	if ( ! shortcode_exists( 'tcc_event_rooms' ) ) {
		add_shortcode( 'tcc_event_rooms', '__return_empty_string' );
	}
	if ( ! shortcode_exists( 'tcc_pco_description' ) ) {
		add_shortcode( 'tcc_pco_description', '__return_empty_string' );
	}
	if ( ! shortcode_exists( 'tcc_event_register' ) ) {
		add_shortcode( 'tcc_event_register', 'tcc_site_event_register_fallback' );
	}
}
add_action( 'init', 'tcc_site_event_codes_fallback', 20 );

/** The event's own Register button, in the same markup as the one Planning Center events prints. */
function tcc_site_event_register_fallback( $atts ) {
	$atts = shortcode_atts( array( 'label' => 'Register' ), $atts, 'tcc_event_register' );
	$id   = get_the_ID();
	if ( ! $id || 'tribe_events' !== get_post_type( $id ) ) {
		$id = is_singular( 'tribe_events' ) ? get_queried_object_id() : 0;
	}
	if ( ! $id ) {
		return '';
	}
	$url = (string) get_post_meta( $id, '_tcc_register_url', true );
	if ( '' === $url ) {
		return '';
	}
	$own = trim( (string) get_post_meta( $id, '_tcc_register_label', true ) );
	if ( '' !== $own ) {
		$atts['label'] = $own;
	}
	return '<span class="tcc-event-register-wrap" style="display:block;margin-top:24px"><a class="et_pb_button tcc-event-register" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $atts['label'] ) . '</a></span>';
}

/**
 * A safety net for the Community Groups page.
 *
 * That page holds the short codes [tcc_group_filter] and, in every group card, [tcc_group_data].
 * If the "Community Groups filter bar" feature is switched off (or fails to load), Divi would print
 * them as plain text. These stand-ins print nothing instead, so the page simply shows every group.
 * They are only used when the feature has not set up its own.
 */
function tcc_site_group_filter_fallback() {
	foreach ( array( 'tcc_group_filter', 'tcc_group_data' ) as $tcc_group_code ) {
		if ( ! shortcode_exists( $tcc_group_code ) ) {
			add_shortcode( $tcc_group_code, '__return_empty_string' );
		}
	}
}
add_action( 'init', 'tcc_site_group_filter_fallback', 20 );

/**
 * Is this admin request for one of the plugin's own screens (TCC Website > Features, Search, Help,
 * Planning Center) or a button pressed on one of them (they all go through admin-post.php)?
 *
 * Only then are the help wording (help.php) and the AI prompts (ai-prompts.php) loaded. They are the
 * two largest files of the plugin, and no other admin screen shows them: not the Dashboard, not the
 * lists of pages and events, and not the editor's background check-ins (admin-ajax.php, every 15 to
 * 60 seconds while someone edits). Since 0.14.1.
 */
function tcc_site_on_own_screen() {
	if ( ! is_admin() || wp_doing_ajax() ) {
		return false;
	}
	$script = isset( $GLOBALS['pagenow'] ) ? (string) $GLOBALS['pagenow'] : '';
	if ( '' === $script && isset( $_SERVER['SCRIPT_NAME'] ) ) {
		$script = basename( (string) wp_unslash( $_SERVER['SCRIPT_NAME'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- only compared with a fixed name.
	}
	if ( 'admin-post.php' === $script ) {
		return true;
	}
	$page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? (string) wp_unslash( $_GET['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput -- only decides which files to load.
	return 0 === strpos( $page, 'tcc-' );
}

if ( is_admin() ) {
	require_once __DIR__ . '/screens-look.php';
	require_once __DIR__ . '/admin.php';
	if ( tcc_site_on_own_screen() ) {
		require_once __DIR__ . '/ai-prompts.php';
		tcc_code_require( 'tcc-site-features', 'help.php' );
	}
}
require_once __DIR__ . '/updater.php';
