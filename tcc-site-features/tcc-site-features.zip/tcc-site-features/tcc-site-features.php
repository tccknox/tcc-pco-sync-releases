<?php
/**
 * Plugin Name: TCC Website Features
 * Description: The church's own small website features in one place: the event feeds, the Events filter bar, the pieces of the event page, the real event details and plain labels when an event is open in the Divi editor, the sermon audio player, the Sermons page search and series, the page for one sermon, the Trinity Talk pages, the back link above page titles, the forgiving menu hover, the sitewide search page, the first-view style fix, the Community Groups filter bar, the Events titles and descriptions for search engines, and the church logo on the sign-in page and in the admin menu. Each one can be switched on or off under TCC Website in the left menu.
 * Version: 0.10.0
 * Author: Trinity Community Church
 *
 * How it works, in short:
 *  1. Each feature is one file in the "features" folder. Before this plugin existed, each was a
 *     separate snippet in the Code Snippets plugin, stored only in the website's database.
 *  2. A feature's file is loaded only when that feature is switched on (TCC Website > Features).
 *     A new install starts with everything off, so installing the plugin changes nothing by itself.
 *  3. Every feature only sets itself up "if it is not already set up". WordPress loads plugins before
 *     Code Snippets runs its snippets, so when a feature is switched on here, this plugin's copy runs
 *     and an old snippet with the same code quietly steps aside. Nothing is printed twice.
 *  4. If a feature's file ever has a mistake in it, that one feature is skipped and the Features tab
 *     says so. The rest of the website carries on.
 *
 *  5. The Features tab also lets an administrator edit a feature's code. The edit is saved as a separate copy
 *     (wp-content/tcc-code-edits) and run instead of the file here, which is never changed. See code-edits.php.
 *
 * This plugin has no settings of its own beyond the switches, makes no database tables, and contacts
 * no outside service for visitors. The only outside call is the check for a new version (updater.php),
 * a few times a day, from the admin side.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_SITE_VERSION', '0.10.0' );

/**
 * Editing code (code-edits.php): lets an administrator change a feature's code from the admin without
 * touching the original, and put the original back with one button. It has to be loaded before the
 * features, because it decides whether a feature runs its original file or a saved edit of it.
 */
require_once __DIR__ . '/code-edits.php';
tcc_code_register(
	'tcc-site-features',
	array(
		'name'    => 'TCC Website Features',
		'menu'    => 'TCC Website',
		'dir'     => __DIR__,
		'version' => TCC_SITE_VERSION,
		'page'    => 'tcc-site-features',
		'tab'     => 'features',
		'tab_label' => 'Features',
		'place'   => 'TCC Website > Features',
		'find'    => 'Each feature has a link under its switch, "See or edit the code". The words of the Help tab are in the panel "The code behind this plugin" at the bottom of that tab.',
		'files'   => 'tcc_site_code_files',
		'extra'   => 'tcc_site_code_extra',
		'ai'      => 'tcc_site_ai_notes', // In ai-prompts.php, which is only loaded in the admin.
	)
);

/** The files that can be edited from the Features tab: every feature, and the Help tab. */
function tcc_site_code_files() {
	$files = array();
	foreach ( tcc_site_features() as $key => $feature ) {
		$files[ 'features/' . $key . '.php' ] = array(
			'label' => $feature['label'],
			'what'  => $feature['what'],
			'group' => 'The features',
		);
	}
	$files['help.php'] = array(
		'label' => 'The Help tab',
		'what'  => 'The words on TCC Website > Help. Change them here when a feature changes, so the help stays true.',
		'group' => 'The plugin\'s own screens',
	);
	return $files;
}

/** Files an AI assistant is shown so it understands the whole plugin, but which cannot be edited in WordPress. */
function tcc_site_code_extra() {
	return array(
		'tcc-site-features.php' => 'The main file: the list of features and the loader',
		'admin.php'             => 'The admin screen: the tabs, the switches and the status labels',
		'ai-prompts.php'        => 'The wording of the AI prompts',
	);
}

/**
 * The list of features.
 *
 * key (also the file name in /features) => array(
 *   'label'   what volunteers see,
 *   'what'    one plain sentence on what it does,
 *   'where'   where on the website it is used,
 *   'off'     what a visitor would notice if it were switched off,
 *   'fn'      a function the file defines (used to tell whether the feature is running, and from where),
 *   'snippet' the name of the old Code Snippets snippet it replaced,
 *   'needs'   key of another feature it cannot work without ('' for none),
 *   'events'  true when it needs The Events Calendar plugin,
 *   'codes'   the short codes it provides, for whoever builds the pages.
 * )
 *
 * Order matters a little: "Event feeds" comes before "Events filter bar", which uses it.
 */
function tcc_site_features() {
	return array(
		'event-date-venue' => array(
			'label'   => 'Event date and venue (older event layout)',
			'what'    => 'Prints an event\'s date, time and place as plain lines of text.',
			'where'   => 'Only the older event page layout, "Individual event page - NATIVE (kept for rollback)". Keep it on so that layout still works if it is ever needed again.',
			'off'     => 'Nothing today. The older event layout would lose its date and place if it were brought back.',
			'fn'      => 'tcc_event_date_shortcode',
			'snippet' => 'TCC event date and venue shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_date]', '[tcc_event_venue]' ),
		),
		'event-feeds'      => array(
			'label'   => 'Event feeds',
			'what'    => 'Gives Divi the "Upcoming Events (automatic)" lists that the event cards are built from, and the date and time lines on each card. An event that repeats is shown once, with a line such as "Every Wednesday" and its next date.',
			'where'   => 'The home page, the Events page, the Events menu in the header, and the ministry and class pages (Core Classes, The Forge, Men\'s, Women\'s, The Gathering Place, Next Steps, Discovering TCC, Foundations, F.I.T., Baptism).',
			'off'     => 'Every list of upcoming events on the website would be empty.',
			'fn'      => 'tcc_upcoming_ids_for',
			'snippet' => 'TCC upcoming events source for Divi loops',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_day]', '[tcc_event_time]', '[tcc_event_repeats]', '[tcc_no_upcoming]', '[tcc_events_paging]' ),
		),
		'menu-hover'       => array(
			'label'   => 'Forgiving menu hover',
			'what'    => 'Keeps a drop-down in the main menu open while the mouse travels to it, so it does not snap shut or jump to another menu.',
			'where'   => 'The header on every page, for people using a mouse.',
			'off'     => 'The menu still works, but the drop-downs close the instant the mouse slips off the button.',
			'fn'      => 'tcc_mega_menu_hover_script',
			'snippet' => 'TCC mega menu forgiving hover',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'events-filter'    => array(
			'label'   => 'Events filter bar',
			'what'    => 'The bar above the list on the Events page that filters the cards by category, month or a search word.',
			'where'   => 'The Events page only.',
			'off'     => 'The filter bar disappears and the Events page simply shows every event.',
			'fn'      => 'tcc_events_filter_shortcode',
			'snippet' => 'TCC events filter bar',
			'needs'   => 'event-feeds',
			'events'  => true,
			'codes'   => array( '[tcc_events_filter]', '[tcc_event_data]' ),
		),
		'sermon-audio'     => array(
			'label'   => 'Sermon audio player',
			'what'    => 'Shows the Buzzsprout audio player on a sermon page, using the podcast code saved on that sermon.',
			'where'   => 'Every sermon page (the Audio side of the Video / Audio switch).',
			'off'     => 'The Audio side of every sermon player would be empty.',
			'fn'      => 'tcc_sermon_audio_shortcode',
			'snippet' => 'TCC sermon audio player',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_audio]' ),
		),
		'event-banner'     => array(
			'label'   => 'Event page banner',
			'what'    => 'The day, time and place list beside an event\'s graphic, the "Get directions" link, and the styling that keeps the banner tidy on every screen size.',
			'where'   => 'Every individual event page (the layout "Individual event page - BANNER (new)").',
			'off'     => 'Event pages would lose their day, time and place list and the directions link, and the banner would look untidy.',
			'fn'      => 'tcc_event_facts_shortcode',
			'snippet' => 'TCC event banner shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_facts]', '[tcc_event_directions]' ),
		),
		'event-editor-preview' => array(
			'label'   => 'Event details and labels in the Divi editor',
			'what'    => 'When an event is open in the Divi editor, the template shows that event\'s real day, time, place, description, rooms and Register button instead of "(filled in automatically)". It also marks the box under "About this event" as "This event only", and shows a warning just under the menu whenever a part of the shared event template is opened, because changes there show on every event.',
			'where'   => 'Only inside the Divi editor, on an event (Events > the event > Edit With Divi). Visitors never see any of it.',
			'off'     => 'Visitors notice nothing. In the editor, events go back to showing "(filled in automatically)" and the two labels disappear.',
			'fn'      => 'tcc_editor_preview_set_event',
			'snippet' => '',
			'needs'   => '',
			'events'  => true,
			'codes'   => array(),
		),
		'sitewide-search'  => array(
			'label'   => 'Sitewide search page',
			'what'    => 'The page of results a visitor gets from the Search box in the main menu: the three best matches first, then pages, upcoming events, sermons, Trinity Talk and community groups in their own groups. It reads sermon descriptions, speakers and categories and community group details as well as titles and page text, knows words that mean the same, and tries the closest spelling when nothing is found. The Search tab lists what visitors could not find.',
			'where'   => 'Searches of the whole website only. A search limited to one kind of content (such as a sermon-only search) keeps its own page.',
			'off'     => 'Searches would go back to the older, plainer results page. Nothing else changes.',
			'fn'      => 'tcc_search_results_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_search_heading]', '[tcc_search_form]', '[tcc_search_results]' ),
		),
		'sermon-filters'   => array(
			'label'   => 'Sermons page: search, filters and series',
			'what'    => 'The search box and the Series, Speaker, Book and Topic filters above the sermon cards, the list of sermon series Divi builds the series cards from, and the facts at the top of each series page. Divi draws the newest 12 cards and the feature copies that card for older sermons, so the page stays quick. It reads everything from the sermons and their categories; nothing is typed in twice.',
			'where'   => 'The Sermons page and the page of each sermon series (the Theme Builder layouts "Sermons page - NEW" and "Sermon series page - NEW").',
			'off'     => 'The Sermons page would lose its search, its filters and its series cards and would show only the newest 12 sermons; series pages would lose their graphic, their facts and their part numbers.',
			'fn'      => 'tcc_sermon_filter_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_filter]', '[tcc_sermon_meta]', '[tcc_sermon_series]', '[tcc_sermon_count]', '[tcc_series_toggle]', '[tcc_series_graphic]', '[tcc_series_facts]', '[tcc_series_start]' ),
		),
		'sermon-page'      => array(
			'label'   => 'Sermon page (one sermon)',
			'what'    => 'The pieces of the page for one sermon that Divi cannot work out by itself: the trail at the top, the series name and "Part 6 of 27", the speaker and date, the previous and next part of the series, the "Find more like this" buttons, the "Read the full summary" button, and the four cards at the foot. It reads everything from the sermon and its categories; nothing is typed in twice.',
			'where'   => 'Every sermon page (the Theme Builder layout "Individual sermon page - NEW").',
			'off'     => 'Sermon pages would keep their player, title and descriptions but lose the trail, the series line, the speaker and date, the previous and next rows, the "Find more like this" buttons and the cards at the foot.',
			'fn'      => 'tcc_sermon_crumbs_shortcode',
			'snippet' => '',
			'needs'   => 'sermon-filters',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_crumbs]', '[tcc_sermon_eyebrow]', '[tcc_sermon_byline]', '[tcc_sermon_series_title]', '[tcc_sermon_series_link]', '[tcc_sermon_step]', '[tcc_sermon_end]', '[tcc_sermon_tags]', '[tcc_sermon_read_more]', '[tcc_sermon_more_title]', '[tcc_sermon_part]' ),
		),
		'trinity-talk'     => array(
			'label'   => 'Trinity Talk pages',
			'what'    => 'The three Trinity Talk pages: the page of one piece (the words on the left, a grey panel with a button for every chapter on the right, the previous and next chapter and four more cards), the page of one book (every chapter as a row with a short summary) and the Trinity Talk home page (all the books). It works out the book from the piece\'s Trinity Talk category and the chapter number from the start of its title, and it shows the three new Divi layouts on those pages by itself.',
			'where'   => 'Every Trinity Talk piece (Articles in the WordPress menu), every book page such as /trinity-talk/matthew/, and the Trinity Talk home page at /articles/. The layouts are in Divi > Theme Builder, named "Trinity Talk: ... - NEW (shows automatically)".',
			'off'     => 'The three Trinity Talk pages would go straight back to their older look (a plain page of text, and dark cards nine to a page). Nothing is lost.',
			'fn'      => 'tcc_talk_title_shortcode',
			'snippet' => '',
			'needs'   => 'page-trail',
			'events'  => false,
			'codes'   => array( '[tcc_talk_title]', '[tcc_talk_facts]', '[tcc_talk_panel]', '[tcc_talk_steps_title]', '[tcc_talk_book_link]', '[tcc_talk_step]', '[tcc_talk_end]', '[tcc_talk_more_title]', '[tcc_talk_home_link]', '[tcc_talk_tile]', '[tcc_talk_card_meta]', '[tcc_talk_row_meta]', '[tcc_talk_summary]', '[tcc_talk_book_lead]', '[tcc_talk_start]', '[tcc_talk_book_panel]', '[tcc_talk_books]', '[tcc_talk_shelf]', '[tcc_talk_loose_count]', '[tcc_talk_show_all]' ),
		),
		'page-trail'       => array(
			'label'   => 'Page trail (the back link above a title)',
			'what'    => 'The small back link above a page title: an arrow and one name, for example "Events" on an event or "Ministries" on Men\'s Ministry. An ordinary page points to the page above it (The Blessed Life to Core Classes Archive); events, groups, sermons and Trinity Talk point to the top of their part of the site (a sermon to Sermons, not its series); a top-level page points back to Home. It replaced the longer line (Home > Ministries > Men\'s Ministry) in November 2026.',
			'where'   => 'Above the title on every page that has one: ordinary pages, the Events page and each event, the Community Groups page and each group, the Sermons, series and sermon pages, the Trinity Talk pages and the search page. In Divi it is a Text layer labelled "Back link (automatic)" holding [tcc_trail].',
			'off'     => 'Those pages would lose the back link above their title (the sermon page would go back to its older, plainer trail). Nothing else changes.',
			'fn'      => 'tcc_trail_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_trail]' ),
		),
		'first-view-styles' => array(
			'label'   => 'No flash of unstyled page',
			'what'    => 'Divi sometimes prints a page\'s styles far down the page, after the content they style, so the page appears for a moment with plain default styles (teal pill buttons, wrong widths) and then settles. It does this on the first view of every page after anything is saved in Divi, and on every view of pages that hold an automatic list (Sermons, a sermon series, Events, search). This lifts those styles to the top of the page before it is sent, so the page looks right from the start.',
			'where'   => 'Every page a visitor sees. It does nothing on a page whose styles are already at the top.',
			'off'     => 'The Sermons, series, Events and search pages would flash unstyled for a moment each time they open, and every other page would do so on its first view after a Divi save.',
			'fn'      => 'tcc_first_view_styles_start',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'event-search-text' => array(
			'label'   => 'Events: titles and descriptions for search engines',
			'what'    => 'Gives the Events page and each event category page the title and description that Google and shared links show, using the wording typed in Yoast SEO. It also gives any event with no description of its own a short one, taken from its Planning Center summary.',
			'where'   => 'Not seen on the page itself. It shows in search results, in the browser tab, and when a link to the Events page or an event is shared.',
			'off'     => 'The Events page would go back to a title such as "Events from November 22 - January 6" with no description, and events from Planning Center would have no description in search results.',
			'fn'      => 'tcc_event_search_text_view',
			'snippet' => '',
			'needs'   => '',
			'events'  => true,
			'codes'   => array(),
		),
		'category-commas'   => array(
			'label'   => 'Category names keep their commas',
			'what'    => 'When someone adds a category from a sermon\'s edit screen and its name has a comma in it, such as the series "Faith, Hope, Love", it is saved as one category. Without this, WordPress makes a separate category for each part.',
			'where'   => 'Only in the admin area: the Categories box on the edit screen of a sermon (a Post), under "+ Add New Category". Visitors never see it.',
			'off'     => 'Typing a name with commas into "+ Add New Category" would make several categories again, one for each part of the name.',
			'fn'      => 'tcc_category_commas_hold',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'group-filter'      => array(
			'label'   => 'Community Groups filter bar',
			'what'    => 'The bar above the group cards on the Community Groups page: who a group is for, the day it meets, how often, and a search box. It also fills in the number beside the heading. It only hides and shows the cards Divi has already drawn, in the visitor\'s browser, and reads everything from each group\'s own fields.',
			'where'   => 'The Community Groups page only.',
			'off'     => 'The filter bar and the number beside the heading disappear, and the page simply shows every active group.',
			'fn'      => 'tcc_group_filter_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_group_filter]', '[tcc_group_data]' ),
		),
		'termly-look'       => array(
			'label'   => 'Cookie banner and preferences window in the church\'s look',
			'what'    => 'The cookie banner on a first visit and the Preferences window ("Consent Preferences" in the footer) come from Termly, in Termly\'s small type and square buttons. This gives them the website\'s look: 15px Open Sans, teal links and the website\'s own buttons. What the banner does and remembers is not changed.',
			'where'   => 'Every page: the banner at the foot of the page on a first visit, and the window that opens from it or from Consent Preferences in the footer. The policy pages\' own text is inside a Termly frame and keeps Termly\'s look.',
			'off'     => 'The banner and the Preferences window go back to Termly\'s own look (12px type, square buttons). They keep working the same way.',
			'fn'      => 'tcc_termly_look_css',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'admin-look'        => array(
			'label'   => 'Church logo on the sign-in page and a tidier Dashboard',
			'what'    => 'Shows the church logo on the sign-in page (it links to the website) with rounded corners on the sign-in box and no "Register" link, puts the logo at the top of the left-hand admin menu (it opens the website in a new tab), rounds the corners of the small menus that pop out from it, and hides the Dashboard boxes nobody here uses (Welcome, Activity, Quick Draft, WordPress Events and News) and the grey Help tab. The plugin "AGCA - Custom Dashboard & Login Page" did this until November 2026.',
			'where'   => 'Only the sign-in page and the admin screens. Visitors to the website never see it.',
			'off'     => 'Visitors notice nothing. The sign-in page goes back to the WordPress logo, the admin menu loses the church logo, and the four Dashboard boxes and the Help tab come back.',
			'fn'      => 'tcc_admin_look_login_css',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
	);
}

/** Which features are switched on: key => 1. Everything is off until someone switches it on. */
function tcc_site_switches() {
	$saved = get_option( 'tcc_site_features', array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Loads the file of every feature that is switched on.
 * A file with a mistake in it is skipped (and remembered for the Features tab) instead of stopping the website.
 */
function tcc_site_load_features() {
	$on     = tcc_site_switches();
	$errors = array();
	foreach ( array_keys( tcc_site_features() ) as $key ) {
		if ( empty( $on[ $key ] ) ) {
			continue;
		}
		$file = __DIR__ . '/features/' . $key . '.php';
		if ( ! is_readable( $file ) ) {
			$errors[ $key ] = 'Its file is missing from the plugin.';
			continue;
		}
		try {
			// Runs the saved edit of this file if there is a healthy one, otherwise the original.
			tcc_code_require( 'tcc-site-features', 'features/' . $key . '.php' );
		} catch ( \Throwable $e ) {
			$errors[ $key ] = $e->getMessage();
		}
	}
	$GLOBALS['tcc_site_load_errors'] = $errors;
}

/**
 * Is this page being drawn for the Divi editor (the visual builder), for someone who can edit?
 *
 * Some features start hidden, or put their styles only on the pages they belong to, and let their
 * script finish the job on the website. The Divi editor does not run those scripts and previews a
 * layout outside its page, so those features ask this first and show a plain preview instead.
 * Visitors never get a "yes": it needs a signed-in editor.
 */
function tcc_site_in_divi_editor() {
	if ( ! did_action( 'init' ) || ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return false;
	}
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	return isset( $_GET['et_fb'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the editor's own page; nothing is changed.
		|| ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() )
		|| false !== strpos( $uri, '/wp-json/divi/' ) // The editor asking the site to draw a piece of a page.
		|| false !== strpos( $uri, 'rest_route=/divi/' );
}

tcc_site_load_features();

/**
 * A safety net for the search page.
 *
 * The search page template in Divi holds three short codes that the "Sitewide search page" feature
 * fills in. That template is meant to be left unassigned. If someone assigns it to Search Results
 * and the feature is then switched off (or fails to load), Divi would print the short codes as
 * plain text. These stand-ins make that page a plain, working list of results instead.
 * They are only used when the feature has not set up its own.
 */
function tcc_site_search_fallback() {
	if ( shortcode_exists( 'tcc_search_results' ) ) {
		return;
	}
	add_shortcode(
		'tcc_search_heading',
		function () {
			return is_search() ? 'Results for &ldquo;' . esc_html( get_search_query( false ) ) . '&rdquo;' : 'Search the website';
		}
	);
	add_shortcode(
		'tcc_search_form',
		function () {
			return get_search_form( array( 'echo' => false ) );
		}
	);
	add_shortcode(
		'tcc_search_results',
		function () {
			global $wp_query;
			if ( ! is_search() || ! ( $wp_query instanceof WP_Query ) || ! $wp_query->posts ) {
				return '<p>Nothing was found. Please try another word.</p>';
			}
			$html = '<ul>';
			foreach ( $wp_query->posts as $post ) {
				if ( $post instanceof WP_Post ) {
					$html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( wp_strip_all_tags( get_the_title( $post ) ) ) . '</a></li>';
				}
			}
			$html .= '</ul>';
			$pages = paginate_links( array( 'total' => (int) $wp_query->max_num_pages ) );
			return $html . ( $pages ? '<p>' . $pages . '</p>' : '' );
		}
	);
}
add_action( 'init', 'tcc_site_search_fallback', 20 );

/**
 * A safety net for the page trail.
 *
 * Several Divi layouts hold the short code [tcc_trail]. If the "Page trail" feature is switched off
 * (or fails to load), Divi would print the short code as plain text. This stand-in prints nothing
 * instead. It is only used when the feature has not set up its own.
 */
function tcc_site_trail_fallback() {
	if ( ! shortcode_exists( 'tcc_trail' ) ) {
		add_shortcode( 'tcc_trail', '__return_empty_string' );
	}
}
add_action( 'init', 'tcc_site_trail_fallback', 20 );

/**
 * A safety net for the Community Groups page.
 *
 * That page holds the short codes [tcc_group_filter] and, in every group card, [tcc_group_data].
 * If the "Community Groups filter bar" feature is switched off (or fails to load), Divi would print
 * them as plain text. These stand-ins print nothing instead, so the page simply shows every group.
 * They are only used when the feature has not set up its own.
 */
function tcc_site_group_filter_fallback() {
	foreach ( array( 'tcc_group_filter', 'tcc_group_data' ) as $tcc_group_code ) {
		if ( ! shortcode_exists( $tcc_group_code ) ) {
			add_shortcode( $tcc_group_code, '__return_empty_string' );
		}
	}
}
add_action( 'init', 'tcc_site_group_filter_fallback', 20 );

if ( is_admin() ) {
	require_once __DIR__ . '/admin.php';
	require_once __DIR__ . '/ai-prompts.php';
	tcc_code_require( 'tcc-site-features', 'help.php' );
}
require_once __DIR__ . '/updater.php';
