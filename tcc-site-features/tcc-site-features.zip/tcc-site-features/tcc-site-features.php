<?php
/**
 * Plugin Name: TCC Website Features
 * Description: The church's own small website features in one place: the event feeds, the Events filter bar, the pieces of the event page, the sermon audio player, the forgiving menu hover and the sitewide search page. Each one can be switched on or off under TCC Website in the left menu.
 * Version: 0.2.1
 * Author: Trinity Community Church
 *
 * How it works, in short:
 *  1. Each feature is one file in the "features" folder. Before this plugin existed, each was a
 *     separate snippet in the Code Snippets plugin, stored only in the website's database.
 *  2. A feature's file is loaded only when that feature is switched on (TCC Website > Features).
 *     A new install starts with everything off, so installing the plugin changes nothing by itself.
 *  3. Every feature only sets itself up "if it is not already set up". WordPress loads plugins before
 *     Code Snippets runs its snippets, so when a feature is switched on here, this plugin's copy runs
 *     and an old snippet with the same code quietly steps aside. Nothing is printed twice.
 *  4. If a feature's file ever has a mistake in it, that one feature is skipped and the Features tab
 *     says so. The rest of the website carries on.
 *
 * This plugin has no settings of its own beyond the switches, makes no database tables, and contacts
 * no outside service for visitors. The only outside call is the check for a new version (updater.php),
 * a few times a day, from the admin side.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_SITE_VERSION', '0.2.1' );

/**
 * The list of features.
 *
 * key (also the file name in /features) => array(
 *   'label'   what volunteers see,
 *   'what'    one plain sentence on what it does,
 *   'where'   where on the website it is used,
 *   'off'     what a visitor would notice if it were switched off,
 *   'fn'      a function the file defines (used to tell whether the feature is running, and from where),
 *   'snippet' the name of the old Code Snippets snippet it replaced,
 *   'needs'   key of another feature it cannot work without ('' for none),
 *   'events'  true when it needs The Events Calendar plugin,
 *   'codes'   the short codes it provides, for whoever builds the pages.
 * )
 *
 * Order matters a little: "Event feeds" comes before "Events filter bar", which uses it.
 */
function tcc_site_features() {
	return array(
		'event-date-venue' => array(
			'label'   => 'Event date and venue (older event layout)',
			'what'    => 'Prints an event\'s date, time and place as plain lines of text.',
			'where'   => 'Only the older event page layout, "Individual event page - NATIVE (kept for rollback)". Keep it on so that layout still works if it is ever needed again.',
			'off'     => 'Nothing today. The older event layout would lose its date and place if it were brought back.',
			'fn'      => 'tcc_event_date_shortcode',
			'snippet' => 'TCC event date and venue shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_date]', '[tcc_event_venue]' ),
		),
		'event-feeds'      => array(
			'label'   => 'Event feeds',
			'what'    => 'Gives Divi the "Upcoming Events (automatic)" lists that the event cards are built from, and the date and time lines on each card.',
			'where'   => 'The home page, the Events page, the Events menu in the header, and the ministry and class pages (Core Classes, The Forge, Men\'s, Women\'s, The Gathering Place, Next Steps, Discovering TCC, Foundations, F.I.T., Baptism).',
			'off'     => 'Every list of upcoming events on the website would be empty.',
			'fn'      => 'tcc_upcoming_ids_for',
			'snippet' => 'TCC upcoming events source for Divi loops',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_day]', '[tcc_event_time]', '[tcc_no_upcoming]', '[tcc_events_paging]' ),
		),
		'menu-hover'       => array(
			'label'   => 'Forgiving menu hover',
			'what'    => 'Keeps a drop-down in the main menu open while the mouse travels to it, so it does not snap shut or jump to another menu.',
			'where'   => 'The header on every page, for people using a mouse.',
			'off'     => 'The menu still works, but the drop-downs close the instant the mouse slips off the button.',
			'fn'      => 'tcc_mega_menu_hover_script',
			'snippet' => 'TCC mega menu forgiving hover',
			'needs'   => '',
			'events'  => false,
			'codes'   => array(),
		),
		'events-filter'    => array(
			'label'   => 'Events filter bar',
			'what'    => 'The bar above the list on the Events page that filters the cards by category, month or a search word.',
			'where'   => 'The Events page only.',
			'off'     => 'The filter bar disappears and the Events page simply shows every event.',
			'fn'      => 'tcc_events_filter_shortcode',
			'snippet' => 'TCC events filter bar',
			'needs'   => 'event-feeds',
			'events'  => true,
			'codes'   => array( '[tcc_events_filter]', '[tcc_event_data]' ),
		),
		'sermon-audio'     => array(
			'label'   => 'Sermon audio player',
			'what'    => 'Shows the Buzzsprout audio player on a sermon page, using the podcast code saved on that sermon.',
			'where'   => 'Every sermon page (the Audio side of the Video / Audio switch).',
			'off'     => 'The Audio side of every sermon player would be empty.',
			'fn'      => 'tcc_sermon_audio_shortcode',
			'snippet' => 'TCC sermon audio player',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_sermon_audio]' ),
		),
		'event-banner'     => array(
			'label'   => 'Event page banner',
			'what'    => 'The day, time and place list beside an event\'s graphic, the "Get directions" link, and the styling that keeps the banner tidy on every screen size.',
			'where'   => 'Every individual event page (the layout "Individual event page - BANNER (new)").',
			'off'     => 'Event pages would lose their day, time and place list and the directions link, and the banner would look untidy.',
			'fn'      => 'tcc_event_facts_shortcode',
			'snippet' => 'TCC event banner shortcodes',
			'needs'   => '',
			'events'  => true,
			'codes'   => array( '[tcc_event_facts]', '[tcc_event_directions]' ),
		),
		'sitewide-search'  => array(
			'label'   => 'Sitewide search page',
			'what'    => 'The page of results a visitor gets from the Search box in the main menu: the three best matches first, then pages, upcoming events, sermons, Trinity Talk and community groups in their own groups. It reads sermon descriptions, speakers and categories and community group details as well as titles and page text, knows words that mean the same, and tries the closest spelling when nothing is found. The Search tab lists what visitors could not find.',
			'where'   => 'Searches of the whole website only. A search limited to one kind of content (such as a sermon-only search) keeps its own page.',
			'off'     => 'Searches would go back to the older, plainer results page. Nothing else changes.',
			'fn'      => 'tcc_search_results_shortcode',
			'snippet' => '',
			'needs'   => '',
			'events'  => false,
			'codes'   => array( '[tcc_search_heading]', '[tcc_search_form]', '[tcc_search_results]' ),
		),
	);
}

/** Which features are switched on: key => 1. Everything is off until someone switches it on. */
function tcc_site_switches() {
	$saved = get_option( 'tcc_site_features', array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Loads the file of every feature that is switched on.
 * A file with a mistake in it is skipped (and remembered for the Features tab) instead of stopping the website.
 */
function tcc_site_load_features() {
	$on     = tcc_site_switches();
	$errors = array();
	foreach ( array_keys( tcc_site_features() ) as $key ) {
		if ( empty( $on[ $key ] ) ) {
			continue;
		}
		$file = __DIR__ . '/features/' . $key . '.php';
		if ( ! is_readable( $file ) ) {
			$errors[ $key ] = 'Its file is missing from the plugin.';
			continue;
		}
		try {
			require_once $file;
		} catch ( \Throwable $e ) {
			$errors[ $key ] = $e->getMessage();
		}
	}
	$GLOBALS['tcc_site_load_errors'] = $errors;
}
tcc_site_load_features();

/**
 * A safety net for the search page.
 *
 * The search page template in Divi holds three short codes that the "Sitewide search page" feature
 * fills in. That template is meant to be left unassigned. If someone assigns it to Search Results
 * and the feature is then switched off (or fails to load), Divi would print the short codes as
 * plain text. These stand-ins make that page a plain, working list of results instead.
 * They are only used when the feature has not set up its own.
 */
function tcc_site_search_fallback() {
	if ( shortcode_exists( 'tcc_search_results' ) ) {
		return;
	}
	add_shortcode(
		'tcc_search_heading',
		function () {
			return is_search() ? 'Results for &ldquo;' . esc_html( get_search_query( false ) ) . '&rdquo;' : 'Search the website';
		}
	);
	add_shortcode(
		'tcc_search_form',
		function () {
			return get_search_form( array( 'echo' => false ) );
		}
	);
	add_shortcode(
		'tcc_search_results',
		function () {
			global $wp_query;
			if ( ! is_search() || ! ( $wp_query instanceof WP_Query ) || ! $wp_query->posts ) {
				return '<p>Nothing was found. Please try another word.</p>';
			}
			$html = '<ul>';
			foreach ( $wp_query->posts as $post ) {
				if ( $post instanceof WP_Post ) {
					$html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( wp_strip_all_tags( get_the_title( $post ) ) ) . '</a></li>';
				}
			}
			$html .= '</ul>';
			$pages = paginate_links( array( 'total' => (int) $wp_query->max_num_pages ) );
			return $html . ( $pages ? '<p>' . $pages . '</p>' : '' );
		}
	);
}
add_action( 'init', 'tcc_site_search_fallback', 20 );

if ( is_admin() ) {
	require_once __DIR__ . '/admin.php';
	require_once __DIR__ . '/help.php';
}
require_once __DIR__ . '/updater.php';
