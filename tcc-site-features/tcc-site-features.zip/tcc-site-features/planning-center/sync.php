<?php
/**
 * TCC Website, Planning Center events: the sync itself.
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php.
 *
 * Everything that talks to Planning Center and turns what it says into website events:
 *  - the settings and Planning Center events' stored lists (events seen, the diary of changes, conflicts);
 *  - asking Planning Center for upcoming events, tags and rooms (it only ever reads);
 *  - the hourly check, and what happens to new, changed and removed events;
 *  - making and updating the website's events (The Events Calendar), their graphic, place and categories;
 *  - the short codes for the event page: [tcc_pco_description], [tcc_event_register], [tcc_event_rooms].
 *
 * Until version 0.10.0 this code was in tcc-pco-sync.php. It was moved here, unchanged, so that it
 * can be edited from TCC Website > Features like the plugin's other files (see code-edits.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------------------------------------------------------------------------
 * Settings, stored items, log and conflicts
 * ------------------------------------------------------------------------- */

function tcc_pco_settings() {
	$defaults = array(
		'app_id'    => '',
		'secret'    => '',
		'per_event' => 2,
		'tag_map'   => array(), // Planning Center tag id => website category id. A tag that is not here is internal.
		'tags_seen' => array(), // Tag ids someone has already looked at on the Tags tab.
		'event_rooms' => array(), // Planning Center event id => array( room id => 1 or 0 ): room choices made for one event only.
		'rooms'     => array(), // Planning Center room id => array( 'show' => bool, 'label' => public name ).
		'show'           => array(), // Piece of the event page (see tcc_pco_show_keys) => 1 or 0. Missing means shown.
		'desc_source'    => 'description', // 'description' or 'summary': which Planning Center text event pages print.
		'fallback_image' => 0,       // Media Library image for events with no graphic in Planning Center.
		'cat_images'     => array(), // Website category id => Media Library image, tried before the default one.
		'auto_tags'      => array(), // Planning Center tag ids whose events are approved without waiting.
		'event_per'      => array(), // Planning Center event id => how many upcoming dates to keep (overrides per_event).
	);
	$saved = get_option( 'tcc_pco_settings', array() );
	return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
}

function tcc_pco_items() {
	$items = get_option( 'tcc_pco_items', array() );
	return is_array( $items ) ? $items : array();
}

function tcc_pco_save_items( $items ) {
	update_option( 'tcc_pco_items', $items, false );
}

/**
 * True when an event has dropped out of Planning Center's upcoming list and its last known date is over.
 * A passed event is left alone: its website pages keep the last details they had, and it is no longer
 * listed on its screens. (If Planning Center gives it new dates later, it comes back by itself.)
 */
function tcc_pco_item_passed( $item ) {
	if ( empty( $item['gone'] ) ) {
		return false;
	}
	$now = time();
	foreach ( isset( $item['data']['instances'] ) ? (array) $item['data']['instances'] : array() as $inst ) {
		$iso = ! empty( $inst['ends'] ) ? (string) $inst['ends'] : ( isset( $inst['starts'] ) ? (string) $inst['starts'] : '' );
		$end = '' !== $iso ? tcc_pco_local( $iso ) : null;
		if ( $end && $end->getTimestamp() > $now ) {
			return false;
		}
	}
	return true;
}

/** True when this website event date is over. */
function tcc_pco_post_passed( $post_id ) {
	$end = (string) get_post_meta( $post_id, '_EventEndDate', true );
	return '' !== $end && $end < current_time( 'Y-m-d H:i:s' );
}

function tcc_pco_log( $message, $post_id = 0 ) {
	$log = get_option( 'tcc_pco_log', array() );
	if ( ! is_array( $log ) ) {
		$log = array();
	}
	array_unshift(
		$log,
		array(
			'time'    => time(),
			'message' => (string) $message,
			'post_id' => (int) $post_id,
		)
	);
	update_option( 'tcc_pco_log', array_slice( $log, 0, 150 ), false );
}

function tcc_pco_conflicts() {
	$c = get_option( 'tcc_pco_conflicts', array() );
	return is_array( $c ) ? $c : array();
}

function tcc_pco_field_label( $field ) {
	$labels = array(
		'title' => 'Title',
		'start' => 'Start',
		'end'   => 'End',
		'image' => 'Graphic',
	);
	return isset( $labels[ $field ] ) ? $labels[ $field ] : $field;
}

/* ---------------------------------------------------------------------------
 * Talking to Planning Center (read only)
 * ------------------------------------------------------------------------- */

function tcc_pco_get( $path, $query = array() ) {
	$s = tcc_pco_settings();
	if ( '' === $s['app_id'] || '' === $s['secret'] ) {
		return new WP_Error( 'tcc_pco_no_key', 'Planning Center is not connected yet. Add the Application ID and Secret on TCC Website > Planning Center > Settings.' );
	}
	$url      = TCC_PCO_API . $path . ( $query ? '?' . http_build_query( $query ) : '' );
	$args     = array(
		'timeout'     => 20,
		// Planning Center never redirects; refusing to follow one means the sign-in header can only ever go to Planning Center.
		'redirection' => 0,
		'headers'     => array(
			'Authorization' => 'Basic ' . base64_encode( $s['app_id'] . ':' . $s['secret'] ),
			'User-Agent'    => 'TCC Website Sync',
		),
	);
	$response = wp_remote_get( $url, $args );
	// Planning Center lets a website ask about 100 questions every 20 seconds. A check with many events can
	// reach that; Planning Center then answers 429 ("too many requests") and says, in its Retry-After line,
	// how many seconds to wait. Wait that long (never more than 20 seconds, 10 if it does not say) and ask
	// once more. Since 0.14.3; before, one 429 made the whole check fail.
	if ( ! is_wp_error( $response ) && 429 === (int) wp_remote_retrieve_response_code( $response ) ) {
		$wait = wp_remote_retrieve_header( $response, 'retry-after' );
		$wait = is_array( $wait ) ? reset( $wait ) : $wait;
		sleep( max( 0, min( 20, is_numeric( $wait ) ? (int) $wait : 10 ) ) );
		$response = wp_remote_get( $url, $args );
	}
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 429 === $code ) {
		return new WP_Error( 'tcc_pco_http', 'Planning Center asked the website to slow down (error 429), even after waiting. The next check tries again.' );
	}
	if ( 200 !== $code ) {
		return new WP_Error( 'tcc_pco_http', 'Planning Center answered with error ' . $code . ( 401 === $code ? ' (the Application ID or Secret is not accepted)' : '' ) . '.' );
	}
	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	return is_array( $body ) ? $body : new WP_Error( 'tcc_pco_json', 'Planning Center sent something that could not be read.' );
}

/**
 * Every Planning Center tag with the group it sits in (Ministry, Department, ...). Saved for the Tags tab.
 */
function tcc_pco_known_tags() {
	$tags = get_option( 'tcc_pco_tags', array() );
	return is_array( $tags ) ? $tags : array();
}

function tcc_pco_refresh_tags() {
	// Planning Center hands tags over 100 at a time, so keep asking until there are no more, as for events
	// (tcc_pco_fetch_events). Until 0.14.4 only the first 100 were read. At most 20 pages (2,000 tags), so a fault
	// in Planning Center's answer can never keep the check asking for ever.
	$groups = array();
	$rows   = array();
	$offset = 0;
	for ( $page = 0; $page < 20; $page++ ) {
		$body = tcc_pco_get( '/tags', array( 'include' => 'tag_group', 'per_page' => 100, 'offset' => $offset ) );
		if ( is_wp_error( $body ) ) {
			return; // Keep the list we already have, rather than save one that is cut short.
		}
		foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
			if ( isset( $inc['type'], $inc['id'] ) && 'TagGroup' === $inc['type'] ) {
				$groups[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? (string) $inc['attributes']['name'] : '';
			}
		}
		$rows = array_merge( $rows, isset( $body['data'] ) ? (array) $body['data'] : array() );
		if ( empty( $body['meta']['next']['offset'] ) || (int) $body['meta']['next']['offset'] <= $offset ) {
			break;
		}
		$offset = (int) $body['meta']['next']['offset'];
	}
	$tags = array();
	foreach ( $rows as $row ) {
		if ( empty( $row['id'] ) ) {
			continue;
		}
		$gid                        = isset( $row['relationships']['tag_group']['data']['id'] ) ? (string) $row['relationships']['tag_group']['data']['id'] : '';
		$tags[ (string) $row['id'] ] = array(
			'name'  => isset( $row['attributes']['name'] ) ? trim( (string) $row['attributes']['name'] ) : '',
			'group' => isset( $groups[ $gid ] ) ? $groups[ $gid ] : '',
		);
	}
	if ( $tags ) {
		update_option( 'tcc_pco_tags', $tags, false );
	}
}

/**
 * Every room the church has in Planning Center (room id => name), whether or not an event uses it. Saved for the Rooms tab.
 */
function tcc_pco_all_rooms() {
	$rooms = get_option( 'tcc_pco_rooms_all', array() );
	return is_array( $rooms ) ? $rooms : array();
}

function tcc_pco_refresh_rooms() {
	$rooms = array();
	for ( $page = 0; $page < 10; $page++ ) {
		$body = tcc_pco_get( '/resources', array( 'per_page' => 100, 'offset' => $page * 100, 'order' => 'name' ) );
		if ( is_wp_error( $body ) ) {
			return; // Keep the list we already have.
		}
		$rows = isset( $body['data'] ) ? (array) $body['data'] : array();
		foreach ( $rows as $row ) {
			if ( ! empty( $row['id'] ) && isset( $row['attributes']['kind'] ) && 'Room' === $row['attributes']['kind'] ) {
				$rooms[ (string) $row['id'] ] = isset( $row['attributes']['name'] ) ? trim( (string) $row['attributes']['name'] ) : '';
			}
		}
		if ( count( $rows ) < 100 ) {
			break;
		}
	}
	if ( $rooms ) {
		asort( $rooms );
		update_option( 'tcc_pco_rooms_all', $rooms, false );
	}
}

/**
 * The rooms booked for one date of an event, as room id => name. Equipment is left out.
 * Returns null when Planning Center could not be asked, so the rooms already saved are kept.
 */
function tcc_pco_fetch_rooms( $instance_id ) {
	$body = tcc_pco_get(
		'/event_instances/' . rawurlencode( (string) $instance_id ) . '/resource_bookings',
		array( 'include' => 'resource', 'per_page' => 100 )
	);
	if ( is_wp_error( $body ) ) {
		return null;
	}
	$rooms = array();
	foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
		if ( isset( $inc['type'], $inc['id'] ) && 'Resource' === $inc['type'] && isset( $inc['attributes']['kind'] ) && 'Room' === $inc['attributes']['kind'] ) {
			$rooms[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? trim( (string) $inc['attributes']['name'] ) : '';
		}
	}
	asort( $rooms );
	return $rooms;
}

/**
 * Returns a plain list of upcoming events that are published to Church Center, each with its next dates.
 *
 * Since 0.14.3 it asks Planning Center less, and one bad answer no longer spoils the whole check:
 *  - A hidden event (Hidden list on the Waiting for approval tab) keeps the dates it had: nobody looks
 *    at them, so its dates and rooms are not asked for.
 *  - Rooms are asked for only for events that are on the website (or about to be, by a tag that
 *    approves automatically). A waiting event gets its rooms when someone presses Approve
 *    (tcc_pco_fill_rooms).
 *  - If Planning Center does not answer for the dates of one event, that event is marked
 *    'fetch_failed' and the check carries on with the others. tcc_pco_ingest() leaves it as it was.
 */
function tcc_pco_fetch_events() {
	$s     = tcc_pco_settings();
	$known = tcc_pco_items();
	$auto  = array_map( 'strval', (array) $s['auto_tags'] );
	tcc_pco_refresh_tags();
	tcc_pco_refresh_rooms();
	// Planning Center hands events over 100 at a time, so keep asking until there are no more.
	$rows      = array();
	$tag_names = array();
	$offset    = 0;
	for ( $page = 0; $page < 30; $page++ ) {
		$body = tcc_pco_get(
			'/events',
			array(
				'filter'                          => 'future',
				'where[visible_in_church_center]' => 'true',
				'include'                         => 'tags',
				'per_page'                        => 100,
				'offset'                          => $offset,
			)
		);
		if ( is_wp_error( $body ) ) {
			return $body;
		}
		foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
			if ( isset( $inc['type'], $inc['id'] ) && 'Tag' === $inc['type'] ) {
				$tag_names[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? (string) $inc['attributes']['name'] : '';
			}
		}
		$rows = array_merge( $rows, isset( $body['data'] ) ? (array) $body['data'] : array() );
		if ( empty( $body['meta']['next']['offset'] ) || (int) $body['meta']['next']['offset'] <= $offset ) {
			break;
		}
		$offset = (int) $body['meta']['next']['offset'];
	}
	$events = array();
	foreach ( $rows as $row ) {
		if ( empty( $row['id'] ) ) {
			continue;
		}
		$a    = isset( $row['attributes'] ) ? (array) $row['attributes'] : array();
		$tags = array();
		if ( isset( $row['relationships']['tags']['data'] ) ) {
			foreach ( (array) $row['relationships']['tags']['data'] as $t ) {
				$tid = isset( $t['id'] ) ? (string) $t['id'] : '';
				if ( '' !== $tid ) {
					$tags[ $tid ] = isset( $tag_names[ $tid ] ) ? $tag_names[ $tid ] : $tid;
				}
			}
		}
		$id     = (string) $row['id'];
		$old    = isset( $known[ $id ] ) && is_array( $known[ $id ] ) ? $known[ $id ] : array();
		$status = isset( $old['status'] ) ? (string) $old['status'] : 'new';
		$event  = array(
			'id'               => $id,
			// Names and places are plain text in Planning Center. Any HTML typed into them is removed
			// here, before it can reach a page title or the event's location.
			'name'             => isset( $a['name'] ) ? trim( wp_strip_all_tags( (string) $a['name'] ) ) : '',
			'summary'          => isset( $a['summary'] ) ? (string) $a['summary'] : '',
			'description'      => isset( $a['description'] ) ? (string) $a['description'] : '',
			'image_url'        => isset( $a['image_url'] ) ? (string) $a['image_url'] : '',
			'registration_url' => isset( $a['registration_url'] ) ? (string) $a['registration_url'] : '',
			'tags'             => $tags,
		);
		// The dates and rooms this event had at the last check, so they can be used again below.
		$had       = isset( $old['data']['instances'] ) && is_array( $old['data']['instances'] ) ? $old['data']['instances'] : array();
		$had_rooms = array();
		foreach ( $had as $h ) {
			if ( isset( $h['id'], $h['rooms'] ) && is_array( $h['rooms'] ) ) {
				$had_rooms[ (string) $h['id'] ] = $h['rooms'];
			}
		}
		if ( 'ignored' === $status ) {
			// Hidden: keep the dates it had (only those not over yet), without asking Planning Center.
			$event['instances'] = array_values( array_filter( $had, 'tcc_pco_instance_upcoming' ) );
			$events[]           = $event;
			continue;
		}
		$want_rooms = 'approved' === $status || ( 'new' === $status && array_intersect( array_map( 'strval', array_keys( $tags ) ), $auto ) );
		$inst       = tcc_pco_get(
			'/events/' . rawurlencode( $id ) . '/event_instances',
			array(
				'filter'   => 'future',
				'order'    => 'starts_at',
				'per_page' => tcc_pco_per_event( $s, $id ),
			)
		);
		if ( is_wp_error( $inst ) ) {
			// No dates this time. Leave this one as it was (tcc_pco_ingest) and carry on with the rest.
			$event['instances']    = $had;
			$event['fetch_failed'] = $inst->get_error_message();
			$events[]              = $event;
			continue;
		}
		$instances = array();
		foreach ( isset( $inst['data'] ) ? (array) $inst['data'] : array() as $i ) {
			$ia = isset( $i['attributes'] ) ? (array) $i['attributes'] : array();
			if ( empty( $i['id'] ) || empty( $ia['starts_at'] ) ) {
				continue;
			}
			$starts = ! empty( $ia['published_starts_at'] ) ? (string) $ia['published_starts_at'] : (string) $ia['starts_at'];
			$ends   = ! empty( $ia['published_ends_at'] ) ? (string) $ia['published_ends_at'] : ( ! empty( $ia['ends_at'] ) ? (string) $ia['ends_at'] : $starts );
			$instances[] = array(
				'id'       => (string) $i['id'],
				// Planning Center's "published" times are the public ones. starts_at / ends_at also cover
				// setup, teardown and room pre-cooling, which visitors should not see.
				'starts'   => $starts,
				'ends'     => $ends,
				'all_day'  => ! empty( $ia['all_day_event'] ),
				'location' => isset( $ia['location'] ) ? trim( wp_strip_all_tags( (string) $ia['location'] ) ) : '',
				// Rooms only where they are used (see above). Otherwise the rooms saved last time for this
				// date, or null ("not asked"), which every reader of 'rooms' already treats as "none known".
				'rooms'    => $want_rooms ? tcc_pco_fetch_rooms( (string) $i['id'] ) : ( isset( $had_rooms[ (string) $i['id'] ] ) ? $had_rooms[ (string) $i['id'] ] : null ),
				// Planning Center's own short wording for a repeating event, e.g. "Every Wednesday". Empty for a one-off.
				'repeats'  => ( ! empty( $ia['recurrence'] ) && 'none' !== strtolower( (string) $ia['recurrence'] ) && ! empty( $ia['compact_recurrence_description'] ) )
					? (string) $ia['compact_recurrence_description']
					: '',
			);
		}
		$event['instances'] = $instances;
		$events[]           = $event;
	}
	return $events;
}

/**
 * Asks Planning Center for the rooms of an event's dates that have none saved yet, and saves them.
 * Used when someone presses Approve (or Start syncing again), so a newly approved event shows its rooms
 * straight away: waiting events are not asked for rooms (see tcc_pco_fetch_events). Returns the event's data.
 */
function tcc_pco_fill_rooms( $event_id ) {
	$items = tcc_pco_items();
	$id    = (string) $event_id;
	if ( empty( $items[ $id ]['data']['instances'] ) ) {
		return isset( $items[ $id ]['data'] ) ? $items[ $id ]['data'] : array();
	}
	$changed = false;
	foreach ( $items[ $id ]['data']['instances'] as $n => $inst ) {
		if ( ! empty( $inst['id'] ) && ( ! isset( $inst['rooms'] ) || ! is_array( $inst['rooms'] ) ) ) {
			$rooms = tcc_pco_fetch_rooms( (string) $inst['id'] );
			if ( is_array( $rooms ) ) {
				$items[ $id ]['data']['instances'][ $n ]['rooms'] = $rooms;
				$changed = true;
			}
		}
	}
	if ( $changed ) {
		tcc_pco_save_items( $items );
	}
	return $items[ $id ]['data'];
}

/* ---------------------------------------------------------------------------
 * Safety checks used by the sync (since 0.14.3). Small functions that only look at the stored list,
 * so each rule can be read, and tested, on its own.
 * ------------------------------------------------------------------------- */

/** True when this date (one of an event's 'instances') has not ended yet. */
function tcc_pco_instance_upcoming( $inst ) {
	$iso = ! empty( $inst['ends'] ) ? (string) $inst['ends'] : ( isset( $inst['starts'] ) ? (string) $inst['starts'] : '' );
	$end = '' !== $iso ? tcc_pco_local( $iso ) : null;
	return $end && $end->getTimestamp() > time();
}

/** True when the stored data of an event has at least one date that has not ended yet. */
function tcc_pco_item_has_upcoming( $item ) {
	foreach ( isset( $item['data']['instances'] ) ? (array) $item['data']['instances'] : array() as $inst ) {
		if ( tcc_pco_instance_upcoming( $inst ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The guard against a bad answer from Planning Center.
 *
 * Normally an approved event that Planning Center no longer lists was taken off Church Center, and its
 * upcoming dates go to the Trash. But if Planning Center has a fault, its filter changes, or the website
 * signs in as a Planning Center person who can see less, it can answer "all fine" with few or no events.
 * Trashing every event because of that would empty the website's calendar, and the next good check would
 * make them again as new events without the choices made for them.
 *
 * So: when Planning Center's answer is empty, or more than half of the events on the website with
 * upcoming dates are missing from it at once (and that is more than one event), nothing is removed this
 * time and the check is marked "needs a look". One or two events taken off among many still leave as
 * before. $seen is event id => true for every event in the answer; $answer is how many events it had.
 * Returns hold (true: remove nothing), expected (approved events with upcoming dates) and missing (id => name).
 */
function tcc_pco_removal_check( $items, $seen, $answer ) {
	$expected = 0;
	$missing  = array();
	foreach ( (array) $items as $id => $item ) {
		if ( ! isset( $item['status'] ) || 'approved' !== $item['status'] || ! empty( $item['gone'] ) || ! tcc_pco_item_has_upcoming( $item ) ) {
			continue;
		}
		$expected++;
		if ( ! isset( $seen[ (string) $id ] ) ) {
			$missing[ (string) $id ] = isset( $item['data']['name'] ) ? (string) $item['data']['name'] : (string) $id;
		}
	}
	$hold = $missing && ( 0 === (int) $answer || ( count( $missing ) >= 2 && count( $missing ) * 2 > $expected ) );
	return array(
		'hold'     => (bool) $hold,
		'expected' => $expected,
		'missing'  => $missing,
	);
}

/**
 * The same guard for the dates of one event. Planning Center sometimes lists an approved event but sends
 * no dates for it. The first time that happens, its website dates are kept (and its last known dates are
 * used again); only if the next check also has no dates are they removed. The item's 'empty_runs' counts
 * how many checks in a row came back without dates. True means "keep the dates this time".
 */
function tcc_pco_hold_empty_dates( $item, $ev ) {
	return isset( $item['status'] ) && 'approved' === $item['status']
		&& empty( $ev['instances'] )
		&& tcc_pco_item_has_upcoming( $item )
		&& empty( $item['empty_runs'] );
}

/**
 * The stored list would otherwise grow for ever. An event that Planning Center no longer lists and whose
 * last date ended more than 90 days ago is taken off the list (its website pages stay as they are).
 * Events still listed by Planning Center, and events with dates to come, are never taken off.
 * Returns the list to keep and, for those taken off, id => the choice that had been made (approved,
 * hidden, stopped). Those choices are kept in tcc_pco_remembered_choices(), so an event that comes back
 * later is not offered again as new: a hidden one stays hidden, an approved one goes on the website again.
 */
function tcc_pco_prune_items( $items, $now ) {
	$keep   = array();
	$pruned = array();
	$limit  = (int) $now - 90 * DAY_IN_SECONDS;
	foreach ( (array) $items as $id => $item ) {
		if ( empty( $item['gone'] ) ) {
			$keep[ $id ] = $item;
			continue;
		}
		$last = 0;
		foreach ( isset( $item['data']['instances'] ) ? (array) $item['data']['instances'] : array() as $inst ) {
			$iso = ! empty( $inst['ends'] ) ? (string) $inst['ends'] : ( isset( $inst['starts'] ) ? (string) $inst['starts'] : '' );
			$end = '' !== $iso ? tcc_pco_local( $iso ) : null;
			$last = $end ? max( $last, $end->getTimestamp() ) : $last;
		}
		if ( ! $last ) {
			$last = isset( $item['last_seen'] ) ? (int) $item['last_seen'] : 0; // No dates known: go by when it was last listed.
		}
		if ( $last && $last < $limit ) {
			$pruned[ (string) $id ] = isset( $item['status'] ) ? (string) $item['status'] : 'new';
			continue;
		}
		$keep[ $id ] = $item;
	}
	return array( $keep, $pruned );
}

/** Choices made for events taken off the stored list (see tcc_pco_prune_items): event id => status. Ids only, no details. */
function tcc_pco_remembered_choices() {
	$list = get_option( 'tcc_pco_pruned', array() );
	return is_array( $list ) ? $list : array();
}

/**
 * Conflicts about a website date that no longer exists, is in the Trash, or is over are of no use to
 * anyone, so they are taken off the Conflicts tab at each check. Returns how many were taken off.
 */
function tcc_pco_prune_conflicts() {
	$all  = tcc_pco_conflicts();
	$keep = array();
	foreach ( $all as $key => $c ) {
		$post_id = isset( $c['post_id'] ) ? (int) $c['post_id'] : 0;
		$status  = $post_id ? get_post_status( $post_id ) : false;
		if ( ! $status || 'trash' === $status || tcc_pco_post_passed( $post_id ) ) {
			continue;
		}
		$keep[ $key ] = $c;
	}
	if ( count( $keep ) !== count( $all ) ) {
		update_option( 'tcc_pco_conflicts', $keep, false );
	}
	return count( $all ) - count( $keep );
}

/** A short list of event names for a message: "A", "B" and 3 more. */
function tcc_pco_name_list( $names ) {
	$names = array_values( array_map( 'strval', (array) $names ) );
	$shown = array_map(
		function ( $n ) {
			return '"' . $n . '"';
		},
		array_slice( $names, 0, 5 )
	);
	$more  = count( $names ) - count( $shown );
	return implode( ', ', $shown ) . ( $more > 0 ? ' and ' . $more . ' more' : '' );
}

/* ---------------------------------------------------------------------------
 * The sync itself
 * ------------------------------------------------------------------------- */

/**
 * Takes the list from Planning Center, updates the waiting list, and updates approved events on the website.
 *
 * $allow_removals is true only when someone pressed "They were taken off: remove them" on the Planning
 * Center screen, after a check was held back by the guard (tcc_pco_removal_check). $report is filled in
 * for tcc_pco_run(): whether removals were held back and why, and which events could not be read.
 */
function tcc_pco_ingest( $events, $allow_removals = false, &$report = null ) {
	$items      = tcc_pco_items();
	$remembered = tcc_pco_remembered_choices();
	$seen       = array();
	$skip       = array(); // Events whose dates could not be read this time: left exactly as they were.
	$new        = 0;
	$s          = tcc_pco_settings();
	$auto       = array_map( 'strval', (array) $s['auto_tags'] );
	$report     = array( 'held' => false, 'message' => '', 'failed' => array(), 'pruned' => 0 );
	foreach ( (array) $events as $ev ) {
		if ( empty( $ev['id'] ) ) {
			continue;
		}
		$id = (string) $ev['id'];
		if ( ! empty( $ev['fetch_failed'] ) ) {
			// Planning Center still lists it, so it is not gone; only its dates are unknown this time.
			$report['failed'][ $id ] = isset( $ev['name'] ) ? (string) $ev['name'] : $id;
			if ( isset( $items[ $id ] ) ) {
				$seen[ $id ]               = true;
				$skip[ $id ]               = true;
				$items[ $id ]['last_seen'] = time();
				$items[ $id ]['gone']      = false;
			}
			continue; // A new event is simply picked up at the next check.
		}
		$seen[ $id ] = true;
		$fresh       = ! isset( $items[ $id ] );
		if ( $fresh ) {
			// An event taken off the stored list long ago (tcc_pco_prune_items) comes back with the choice made for it.
			$status       = isset( $remembered[ $id ] ) ? (string) $remembered[ $id ] : 'new';
			$items[ $id ] = array(
				'status'     => $status,
				'first_seen' => time(),
			);
			if ( 'new' === $status ) {
				$new++;
			}
			if ( isset( $remembered[ $id ] ) ) {
				unset( $remembered[ $id ] );
				update_option( 'tcc_pco_pruned', $remembered, false );
			}
		}
		// No dates from Planning Center for an approved event that had some: keep its dates this time.
		if ( tcc_pco_hold_empty_dates( $items[ $id ], $ev ) ) {
			$ev['instances']            = $items[ $id ]['data']['instances'];
			$items[ $id ]['empty_runs'] = 1;
			tcc_pco_log( 'Planning Center sent no dates for "' . ( isset( $ev['name'] ) ? $ev['name'] : $id ) . '". Its dates on the website were kept for now. If the next check also has no dates, they are removed.' );
		} else {
			unset( $items[ $id ]['empty_runs'] );
		}
		$items[ $id ]['data']      = $ev;
		$items[ $id ]['last_seen'] = time();
		$items[ $id ]['gone']      = false;
		// A waiting event with a tag marked "approve automatically" on the Tags tab goes straight on the website.
		$hit = array_intersect( array_map( 'strval', array_keys( isset( $ev['tags'] ) ? (array) $ev['tags'] : array() ) ), $auto );
		if ( $hit && isset( $items[ $id ]['status'] ) && 'new' === $items[ $id ]['status'] ) {
			$first                  = (string) reset( $hit );
			$items[ $id ]['status'] = 'approved';
			$new                   -= $fresh ? 1 : 0;
			tcc_pco_log( 'Approved "' . ( isset( $ev['name'] ) ? $ev['name'] : $id ) . '" automatically because it has the tag "' . trim( (string) $ev['tags'][ $first ] ) . '".' );
		}
	}

	// Before anything is taken off the website: does this answer look like a fault (see tcc_pco_removal_check)?
	$check = tcc_pco_removal_check( $items, $seen, count( (array) $events ) );
	if ( $check['hold'] && ! $allow_removals ) {
		$report['held']    = true;
		$report['message'] = ( count( (array) $events ) ? 'Planning Center\'s answer is missing ' . count( $check['missing'] ) . ' of the ' . $check['expected'] . ' events that are on the website with upcoming dates (' . tcc_pco_name_list( $check['missing'] ) . ')' : 'Planning Center sent back no events at all' )
			. '. That looks like a problem in Planning Center or with the connection, so nothing was taken off the website. Check Planning Center and the Settings tab, then press "Check Planning Center now". If those events really were taken off Church Center, press "They were taken off: remove them".';
		$last = get_option( 'tcc_pco_last_run', array() );
		if ( empty( $last['held'] ) ) {
			tcc_pco_log( 'Nothing was taken off the website. ' . $report['message'] ); // Written once, not every hour while it lasts.
		}
	} else {
		if ( $check['hold'] ) {
			tcc_pco_log( 'Taking ' . tcc_pco_name_list( $check['missing'] ) . ' off the website, as asked on the Planning Center screen: Planning Center no longer lists them.' );
		}
		foreach ( $items as $id => $item ) {
			if ( isset( $seen[ $id ] ) || ! empty( $item['gone'] ) ) {
				continue;
			}
			// No longer upcoming or no longer published to Church Center.
			$items[ $id ]['gone'] = true;
			$label                = isset( $item['data']['name'] ) ? $item['data']['name'] : $id;
			if ( tcc_pco_item_passed( $items[ $id ] ) ) {
				// Its last date is over. Leave the website pages exactly as they are.
				if ( isset( $item['status'] ) && 'approved' === $item['status'] ) {
					tcc_pco_log( '"' . $label . '" has passed. Its page stays on the website with the last details it had, and it is no longer updated.' );
				}
				continue;
			}
			if ( isset( $item['status'] ) && 'approved' === $item['status'] ) {
				$removed = tcc_pco_trash_future_posts( $id, array() );
				if ( $removed ) {
					tcc_pco_log( 'Removed ' . $removed . ' upcoming date(s) of "' . ( isset( $item['data']['name'] ) ? $item['data']['name'] : $id ) . '" from the website: it is no longer published in Planning Center.' );
				}
			}
		}
	}

	// Keep the stored list small: events long over are taken off it, their choice remembered.
	list( $items, $pruned ) = tcc_pco_prune_items( $items, time() );
	if ( $pruned ) {
		$report['pruned'] = count( $pruned );
		$remembered       = tcc_pco_remembered_choices();
		foreach ( $pruned as $id => $status ) {
			if ( 'new' !== $status ) {
				unset( $remembered[ $id ] );
				$remembered[ $id ] = $status; // Newest last, so the trimming below drops the oldest.
			}
		}
		// Ids and one word each: even thousands of them are a few kilobytes.
		update_option( 'tcc_pco_pruned', array_slice( $remembered, -3000, null, true ), false );
	}

	tcc_pco_save_items( $items );
	foreach ( $items as $id => $item ) {
		if ( isset( $skip[ $id ] ) || ! isset( $seen[ $id ] ) ) {
			continue; // Not read this time (see above), or held back by the guard: left exactly as it was.
		}
		if ( isset( $item['status'] ) && 'approved' === $item['status'] && empty( $item['gone'] ) && ! empty( $item['data'] ) ) {
			tcc_pco_apply_event( $item['data'] );
		}
	}
	tcc_pco_prune_conflicts();
	if ( $report['failed'] ) {
		tcc_pco_log( 'Could not get the dates of ' . count( $report['failed'] ) . ' event(s) from Planning Center this time: ' . tcc_pco_name_list( $report['failed'] ) . '. They were left as they were and are tried again at the next check.' );
	}
	return $new;
}

/**
 * The whole check: ask Planning Center, then bring the website in line. Run every hour by WP-Cron and by
 * "Check Planning Center now". $allow_removals: see tcc_pco_ingest() (WP-Cron passes nothing, so false).
 * The result is saved in tcc_pco_last_run, which the Dashboard box and the Planning Center screen show:
 * ok false means "needs a look", with the reason in 'message'.
 */
function tcc_pco_run( $allow_removals = false ) {
	if ( get_transient( 'tcc_pco_running' ) ) {
		return new WP_Error( 'tcc_pco_busy', 'A check is already running. Try again in a few minutes.' );
	}
	// Only one check at a time. The lock lasts at most 10 minutes, so a check that was cut off (the server
	// stopped it, for example) cannot block the next ones for long; normally it is taken off at the end.
	set_transient( 'tcc_pco_running', 1, 10 * MINUTE_IN_SECONDS );
	// A check with many events makes many calls to Planning Center, and may wait for it (see tcc_pco_get).
	// Ask the server for up to 5 minutes instead of the usual 30 seconds. Some hosts do not allow this; that is fine.
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- refused on some hosts, which is harmless.
	}
	try {
		$events = tcc_pco_fetch_events();
		if ( is_wp_error( $events ) ) {
			update_option( 'tcc_pco_last_run', array( 'time' => time(), 'ok' => false, 'message' => $events->get_error_message() ), false );
			return $events;
		}
		$report = null;
		$new    = tcc_pco_ingest( $events, true === $allow_removals, $report );
		$ok     = ! $report['held'];
		$found  = count( $events ) - count( $report['failed'] );
		$msg    = $report['held'] ? $report['message'] : $found . ' published event(s) found, ' . $new . ' new.';
		if ( $report['failed'] ) {
			// One or two can happen on a busy day. More than a few means something is wrong in Planning Center.
			$ok   = $ok && count( $report['failed'] ) <= 3;
			$msg .= ' Planning Center did not send the dates of ' . count( $report['failed'] ) . ' event(s) (' . tcc_pco_name_list( $report['failed'] ) . '), so they were left as they were this time.';
		}
		update_option( 'tcc_pco_last_run', array( 'time' => time(), 'ok' => $ok, 'message' => $msg, 'held' => (bool) $report['held'] ), false );
		return $new;
	} finally {
		// Always taken off, even if something above went wrong, so the next check can run.
		delete_transient( 'tcc_pco_running' );
	}
}
add_action( 'tcc_pco_sync_cron', 'tcc_pco_run' );

function tcc_pco_local( $iso ) {
	try {
		$dt = new DateTime( $iso );
		$dt->setTimezone( wp_timezone() );
		return $dt;
	} catch ( Exception $e ) {
		return null;
	}
}

function tcc_pco_date_args( $start, $end, $all_day ) {
	$s = date_create( $start, wp_timezone() );
	$e = date_create( $end, wp_timezone() );
	if ( ! $s || ! $e ) {
		return array();
	}
	return array(
		'EventAllDay'        => (bool) $all_day,
		'EventStartDate'     => $s->format( 'Y-m-d' ),
		'EventStartHour'     => $s->format( 'h' ),
		'EventStartMinute'   => $s->format( 'i' ),
		'EventStartMeridian' => $s->format( 'a' ),
		'EventEndDate'       => $e->format( 'Y-m-d' ),
		'EventEndHour'       => $e->format( 'h' ),
		'EventEndMinute'     => $e->format( 'i' ),
		'EventEndMeridian'   => $e->format( 'a' ),
		'EventTimezone'      => wp_timezone_string(),
	);
}

/**
 * The start and end of an all-day date, written the way The Events Calendar saves an all-day event: from 00:00:00
 * on its first day to 23:59:59 on its last ("Y-m-d H:i:s", local time). $start and $end are the local times
 * Planning Center gave (DateTime). Since 0.14.4 an all-day date is compared and remembered in this form: until then
 * Planning Center's own times were compared with the website's 00:00:00 and 23:59:59, so moving an all-day event
 * to another day in Planning Center looked like a change on the website too and made a false conflict.
 * (This assumes The Events Calendar's "End of day cutoff" setting is left at its default, midnight.)
 */
function tcc_pco_all_day_span( $start, $end ) {
	$first = $start->format( 'Y-m-d' );
	$last  = $end->format( 'Y-m-d' );
	return array( $first . ' 00:00:00', ( $last > $first ? $last : $first ) . ' 23:59:59' );
}

function tcc_pco_posts_for( $event_id, $instance_id = '' ) {
	$meta = array(
		array(
			'key'   => '_tcc_pco_event_id',
			'value' => (string) $event_id,
		),
	);
	if ( '' !== $instance_id ) {
		$meta[] = array(
			'key'   => '_tcc_pco_instance_id',
			'value' => (string) $instance_id,
		);
	}
	return get_posts(
		array(
			'post_type'        => 'tribe_events',
			'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page'   => 50,
			'meta_query'       => $meta,
			'suppress_filters' => true,
			'orderby'          => 'ID',
			'order'            => 'ASC',
		)
	);
}

/**
 * Moves upcoming website dates of a Planning Center event to the Trash, except the instance ids in $keep.
 */
function tcc_pco_trash_future_posts( $event_id, $keep, $before = '' ) {
	$count = 0;
	$now   = current_time( 'Y-m-d H:i:s' );
	foreach ( tcc_pco_posts_for( $event_id ) as $post ) {
		$inst  = (string) get_post_meta( $post->ID, '_tcc_pco_instance_id', true );
		$start = (string) get_post_meta( $post->ID, '_EventStartDate', true );
		if ( in_array( $inst, $keep, true ) || $start <= $now ) {
			continue;
		}
		if ( '' !== $before && $start >= $before ) {
			continue;
		}
		if ( get_post_meta( $post->ID, '_tcc_pco_paused', true ) ) {
			continue;
		}
		wp_trash_post( $post->ID );
		$count++;
	}
	return $count;
}

function tcc_pco_image_key( $url ) {
	if ( '' === $url ) {
		return '';
	}
	$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
	parse_str( $query, $q );
	return isset( $q['key'] ) ? (string) $q['key'] : md5( (string) strtok( $url, '?' ) );
}

/**
 * Copies a Planning Center graphic into the Media Library once and returns the attachment id (0 if it could not).
 * "Once" means once per graphic, not once per date: every date of a repeating event, and every other
 * event that uses the same picture, shares the one copy.
 */
function tcc_pco_image_attachment( $url, $title ) {
	$key = tcc_pco_image_key( $url );
	if ( '' === $key ) {
		return 0;
	}
	$found = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_tcc_pco_image_key',
			'meta_value'     => $key,
		)
	);
	if ( $found ) {
		return (int) $found[0];
	}
	// Only pictures that Planning Center itself serves (images.planningcenterusercontent.com today),
	// over https. Anything else in the picture address is ignored.
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	if ( 'https' !== strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) ) || ! preg_match( '/(^|\.)(planningcenterusercontent\.com|planningcenteronline\.com)$/', $host ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = download_url( $url, 30 );
	if ( is_wp_error( $tmp ) ) {
		return 0;
	}
	$mime = wp_get_image_mime( $tmp );
	$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif' );
	if ( ! $mime || ! isset( $ext[ $mime ] ) ) {
		@unlink( $tmp );
		return 0;
	}
	// The same picture may be attached to several Planning Center events. If one with exactly the
	// same contents was copied in before, use that one again and do not add a second copy.
	$hash = (string) md5_file( $tmp );
	$same = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_tcc_pco_image_hash',
			'meta_value'     => $hash,
		)
	);
	if ( $same ) {
		@unlink( $tmp );
		add_post_meta( (int) $same[0], '_tcc_pco_image_key', $key ); // Remember this Planning Center graphic too, so it is not downloaded again.
		return (int) $same[0];
	}
	$file = array(
		'name'     => sanitize_title( $title ? $title : 'event' ) . '-planning-center.' . $ext[ $mime ],
		'tmp_name' => $tmp,
	);
	$id   = media_handle_sideload( $file, 0, $title );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp );
		return 0;
	}
	update_post_meta( $id, '_tcc_pco_image_key', $key );
	update_post_meta( $id, '_tcc_pco_image_hash', $hash );
	return (int) $id;
}

function tcc_pco_add_conflict( $post_id, $field, $website, $pco ) {
	$c = tcc_pco_conflicts();
	$c[ $post_id . ':' . $field ] = array(
		'post_id' => (int) $post_id,
		'field'   => $field,
		'website' => (string) $website,
		'pco'     => (string) $pco,
		'time'    => time(),
	);
	update_option( 'tcc_pco_conflicts', $c, false );
}

function tcc_pco_clear_conflict( $post_id, $field ) {
	$c = tcc_pco_conflicts();
	if ( isset( $c[ $post_id . ':' . $field ] ) ) {
		unset( $c[ $post_id . ':' . $field ] );
		update_option( 'tcc_pco_conflicts', $c, false );
	}
}

/**
 * Keeps the website categories that come from public Planning Center tags in step.
 * Categories someone added by hand on the website are never removed.
 */
function tcc_pco_sync_terms( $post_id, $ev, $s ) {
	if ( ! taxonomy_exists( 'tribe_events_cat' ) ) {
		return;
	}
	$want = array();
	foreach ( isset( $ev['tags'] ) ? (array) $ev['tags'] : array() as $tag_id => $tag_name ) {
		if ( ! empty( $s['tag_map'][ $tag_id ] ) && term_exists( (int) $s['tag_map'][ $tag_id ], 'tribe_events_cat' ) ) {
			$want[] = (int) $s['tag_map'][ $tag_id ];
		}
	}
	$want    = array_values( array_unique( $want ) );
	$last    = get_post_meta( $post_id, '_tcc_pco_terms', true );
	$last    = is_array( $last ) ? array_map( 'intval', $last ) : array();
	$current = wp_get_object_terms( $post_id, 'tribe_events_cat', array( 'fields' => 'ids' ) );
	$current = is_wp_error( $current ) ? array() : array_map( 'intval', $current );
	$new     = array_values( array_unique( array_merge( array_diff( $current, array_diff( $last, $want ) ), $want ) ) );
	sort( $new );
	sort( $current );
	if ( $new !== $current ) {
		wp_set_object_terms( $post_id, $new, 'tribe_events_cat' );
	}
	update_post_meta( $post_id, '_tcc_pco_terms', $want );
}

/**
 * Finds the website venue for a Planning Center location such as "Trinity Community Church - 6706 Central Ave Pike, ...".
 * An existing venue with the same name is reused; otherwise a new venue is made. Returns 0 when there is no location.
 */
function tcc_pco_venue_for( $location ) {
	static $cache = array();
	$location = trim( (string) $location );
	if ( '' === $location || ! post_type_exists( 'tribe_venue' ) ) {
		return 0;
	}
	if ( isset( $cache[ $location ] ) ) {
		return $cache[ $location ];
	}
	$parts   = preg_split( '/\s+-\s+/', $location, 2 );
	$name    = trim( (string) $parts[0] );
	$address = isset( $parts[1] ) ? trim( (string) $parts[1] ) : '';
	$venue   = 0;
	$found   = get_posts(
		array(
			'post_type'        => 'tribe_venue',
			'post_status'      => 'publish',
			'title'            => $name,
			'posts_per_page'   => 1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'fields'           => 'ids',
			'suppress_filters' => true,
		)
	);
	if ( $found ) {
		$venue = (int) $found[0];
	} elseif ( function_exists( 'tribe_create_venue' ) ) {
		$made = tribe_create_venue( array( 'Venue' => $name, 'Address' => $address ) );
		if ( $made && ! is_wp_error( $made ) ) {
			$venue = (int) $made;
			tcc_pco_log( 'Made a new location "' . $name . '" from Planning Center.' );
		}
	}
	$cache[ $location ] = $venue;
	return $venue;
}

/**
 * Titles are compared as plain text, so "Dinner &amp; Prayer" and "Dinner & Prayer" count as the same title.
 * (WordPress can save "&" either way; see tcc_pco_title_as_given.) Other details are compared exactly.
 */
function tcc_pco_same_value( $field, $a, $b ) {
	if ( 'title' === $field ) {
		$plain = function ( $text ) {
			return trim( html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		};
		return $plain( $a ) === $plain( $b );
	}
	return (string) $a === (string) $b;
}

/**
 * Saves titles the same way whoever (or whatever) is saving.
 *
 * When a person who may not type HTML saves a post, WordPress "cleans" its title, and one thing that does is
 * turn "&" into "&amp;". The hourly check runs with nobody signed in, so it counted as such a person: events it
 * made had "&amp;" in their title, while events made by an administrator's button press had "&". Until 0.14.3
 * that difference made a later title change in Planning Center look like a conflict.
 * Planning Center names have every HTML tag taken out when they are read (tcc_pco_fetch_events), so that
 * cleaning adds nothing here. It is switched off only while this file saves an event's title, and put back
 * straight after. Call with true before saving and false after.
 */
function tcc_pco_title_as_given( $start ) {
	static $had = false;
	if ( $start ) {
		$had = false !== has_filter( 'title_save_pre', 'wp_filter_kses' );
		if ( $had ) {
			remove_filter( 'title_save_pre', 'wp_filter_kses' );
		}
	} elseif ( $had ) {
		add_filter( 'title_save_pre', 'wp_filter_kses' );
		$had = false;
	}
}

/**
 * Creates or updates the website dates of one approved Planning Center event.
 */
function tcc_pco_apply_event( $ev ) {
	if ( ! function_exists( 'tribe_create_event' ) || ! function_exists( 'tribe_update_event' ) ) {
		return;
	}
	$s          = tcc_pco_settings();
	$keep       = array();
	$last_start = '';
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		$start = tcc_pco_local( $inst['starts'] );
		$end   = tcc_pco_local( $inst['ends'] );
		if ( ! $start || ! $end ) {
			continue;
		}
		$keep[]     = (string) $inst['id'];
		$all_day    = ! empty( $inst['all_day'] );
		$want       = array(
			'title' => (string) $ev['name'],
			'start' => $start->format( 'Y-m-d H:i:s' ),
			'end'   => $end->format( 'Y-m-d H:i:s' ),
		);
		if ( $all_day ) {
			// In the form the website saves an all-day date in, so the two can be compared (see tcc_pco_all_day_span).
			list( $want['start'], $want['end'] ) = tcc_pco_all_day_span( $start, $end );
		}
		$last_start = $want['start'];
		$posts      = tcc_pco_posts_for( $ev['id'], $inst['id'] );
		$post_id    = $posts ? (int) $posts[0]->ID : 0;
		$force      = array(); // Details just handed back to Planning Center on the edit screen.

		if ( ! $post_id ) {
			// A new date starts with the choices of the date before it (see tcc_pco_inherit).
			$inherit = tcc_pco_inherit( $ev['id'], $want['title'] );
			// When this event replaces a hand-made one, its page content and graphic are carried over (see tcc_pco_carry_from).
			$carry   = isset( $GLOBALS['tcc_pco_carry'][ (string) $ev['id'] ] ) ? (array) $GLOBALS['tcc_pco_carry'][ (string) $ev['id'] ] : array();
			$content = ! empty( $carry['content'] ) ? (string) $carry['content'] : (string) $inherit['content'];
			tcc_pco_title_as_given( true );
			$post_id = tribe_create_event(
				array_merge(
					array(
						'post_title'   => wp_slash( $inherit['title'] ),
						'post_status'  => 'publish',
						'post_content' => wp_slash( $content ),
					),
					tcc_pco_date_args( $want['start'], $want['end'], $all_day )
				)
			);
			tcc_pco_title_as_given( false );
			if ( ! $post_id || is_wp_error( $post_id ) ) {
				tcc_pco_log( 'Could not create "' . $want['title'] . '" on the website.' );
				continue;
			}
			$post_id = (int) $post_id;
			update_post_meta( $post_id, '_tcc_pco_event_id', (string) $ev['id'] );
			update_post_meta( $post_id, '_tcc_pco_instance_id', (string) $inst['id'] );
			tcc_pco_inherit_apply( $post_id, $inherit );
			if ( $carry ) {
				tcc_pco_carry_apply( $post_id, $carry );
			}
			$synced = $want;
			tcc_pco_log( 'Added "' . $want['title'] . '" (' . $start->format( 'M j, Y g:i a' ) . ') to the website.', $post_id );
		} else {
			if ( get_post_meta( $post_id, '_tcc_pco_paused', true ) ) {
				continue;
			}
			$force   = get_post_meta( $post_id, '_tcc_pco_force', true );
			$force   = is_array( $force ) ? $force : array();
			$synced  = get_post_meta( $post_id, '_tcc_pco_synced', true );
			$synced  = is_array( $synced ) ? $synced : array();
			$current = array(
				'title' => (string) get_post_field( 'post_title', $post_id, 'raw' ),
				'start' => (string) get_post_meta( $post_id, '_EventStartDate', true ),
				'end'   => (string) get_post_meta( $post_id, '_EventEndDate', true ),
			);
			$apply   = array();
			foreach ( $want as $field => $value ) {
				$lock_key = 'title' === $field ? 'title' : 'dates';
				if ( tcc_pco_locked( $post_id, $lock_key ) ) {
					tcc_pco_clear_conflict( $post_id, $field ); // "Keep mine" is ticked: nothing to ask.
					continue;
				}
				if ( in_array( $lock_key, $force, true ) ) {
					if ( ! tcc_pco_same_value( $field, $current[ $field ], $value ) ) {
						$apply[ $field ] = $value;
					}
					$synced[ $field ] = $value;
					tcc_pco_clear_conflict( $post_id, $field );
					continue;
				}
				$last = isset( $synced[ $field ] ) ? (string) $synced[ $field ] : $current[ $field ];
				if ( tcc_pco_same_value( $field, $value, $last ) ) {
					continue; // Planning Center has not changed this.
				}
				if ( tcc_pco_same_value( $field, $current[ $field ], $value ) ) {
					// The website already says what Planning Center now says: only remember it (since 0.14.4; nothing to save).
					$synced[ $field ] = $value;
					tcc_pco_clear_conflict( $post_id, $field );
				} elseif ( tcc_pco_same_value( $field, $current[ $field ], $last ) ) {
					// Changed only in Planning Center: bring the website in line.
					$apply[ $field ]  = $value;
					$synced[ $field ] = $value;
					tcc_pco_clear_conflict( $post_id, $field );
				} else {
					// The website's title is shown as plain text on the Conflicts tab ("&", not "&amp;").
					tcc_pco_add_conflict( $post_id, $field, 'title' === $field ? html_entity_decode( $current[ $field ], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : $current[ $field ], $value );
				}
			}
			if ( $apply ) {
				$args = array();
				if ( isset( $apply['title'] ) ) {
					$args['post_title'] = wp_slash( $apply['title'] );
				}
				if ( isset( $apply['start'] ) || isset( $apply['end'] ) ) {
					$args = array_merge(
						$args,
						tcc_pco_date_args(
							isset( $apply['start'] ) ? $apply['start'] : $current['start'],
							isset( $apply['end'] ) ? $apply['end'] : $current['end'],
							$all_day
						)
					);
				}
				tcc_pco_title_as_given( true );
				tribe_update_event( $post_id, $args );
				tcc_pco_title_as_given( false );
				$labels = array_map( 'tcc_pco_field_label', array_keys( $apply ) );
				tcc_pco_log( 'Updated ' . strtolower( implode( ', ', $labels ) ) . ' of "' . $want['title'] . '" from Planning Center.', $post_id );
			}
		}

		// The description and registration link live in their own fields, so the page body stays the website's.
		// Both Planning Center texts are kept, so each event can choose the summary or the description.
		$texts = array();
		foreach ( array( 'full' => $ev['description'], 'sum' => $ev['summary'] ) as $which => $html ) {
			$texts[ $which ] = wp_kses_post( (string) preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', '', (string) $html ) );
		}
		$store = array(
			'_tcc_pco_description' => '' !== $texts['full'] ? $texts['full'] : $texts['sum'],
			'_tcc_pco_desc_full'   => $texts['full'],
			'_tcc_pco_summary'     => $texts['sum'],
		);
		foreach ( $store as $meta_key => $text ) {
			if ( (string) get_post_meta( $post_id, $meta_key, true ) !== $text ) {
				update_post_meta( $post_id, $meta_key, wp_slash( $text ) );
			}
		}
		update_post_meta( $post_id, '_tcc_pco_registration_url', esc_url_raw( (string) $ev['registration_url'] ) );
		update_post_meta( $post_id, '_tcc_pco_location', sanitize_text_field( (string) $inst['location'] ) );
		// How often it repeats ("Every Wednesday"), shown on the event cards by TCC Website Features.
		update_post_meta( $post_id, '_tcc_pco_repeats', sanitize_text_field( isset( $inst['repeats'] ) ? (string) $inst['repeats'] : '' ) );

		// Location: set the website venue unless someone picked a different one on the website, or ticked "keep mine".
		$venue = tcc_pco_locked( $post_id, 'location' ) ? 0 : tcc_pco_venue_for( (string) $inst['location'] );
		if ( $venue ) {
			$now_venue  = (int) get_post_meta( $post_id, '_EventVenueID', true );
			$last_venue = isset( $synced['venue'] ) ? (int) $synced['venue'] : 0;
			if ( $now_venue !== $venue && ( 0 === $now_venue || $now_venue === $last_venue || in_array( 'location', $force, true ) ) ) {
				update_post_meta( $post_id, '_EventVenueID', $venue );
				$now_venue = $venue;
			}
			if ( $now_venue === $venue ) {
				$synced['venue'] = $venue;
			}
		}

		// Rooms (null means Planning Center could not be asked this time: keep what is saved).
		if ( isset( $inst['rooms'] ) && is_array( $inst['rooms'] ) ) {
			update_post_meta( $post_id, '_tcc_pco_rooms', $inst['rooms'] );
		}

		// Categories from public tags.
		if ( ! tcc_pco_locked( $post_id, 'categories' ) ) {
			tcc_pco_sync_terms( $post_id, $ev, $s );
		}

		// Graphic. The Planning Center graphic becomes the featured image unless a different one was chosen on the website.
		$key      = tcc_pco_image_key( (string) $ev['image_url'] );
		$thumb    = (int) get_post_meta( $post_id, '_thumbnail_id', true ); // The graphic really saved on the event, not the fallback shown to visitors.
		$last_att = isset( $synced['image_att'] ) ? (int) $synced['image_att'] : 0;
		$fallback = isset( $synced['fallback_att'] ) ? (int) $synced['fallback_att'] : 0;
		$forced   = in_array( 'image', $force, true );
		if ( tcc_pco_locked( $post_id, 'image' ) ) {
			tcc_pco_clear_conflict( $post_id, 'image' );
		} elseif ( '' !== $key && ( $forced || ! isset( $synced['image'] ) || $synced['image'] !== $key || ( $fallback && $thumb === $fallback ) ) ) {
			if ( $forced || 0 === $thumb || $thumb === $last_att || $thumb === $fallback ) {
				$att = tcc_pco_image_attachment( (string) $ev['image_url'], (string) $ev['name'] );
				if ( $att ) {
					set_post_thumbnail( $post_id, $att );
					$synced['image']     = $key;
					$synced['image_att'] = $att;
					unset( $synced['fallback_att'] );
					tcc_pco_clear_conflict( $post_id, 'image' );
				}
			} else {
				tcc_pco_add_conflict( $post_id, 'image', 'A different graphic was chosen on the website', (string) $ev['image_url'] );
			}
		} elseif ( '' === $key && $fallback && $thumb === $fallback ) {
			// Older versions saved the fallback graphic onto the event. It is now only shown (see
			// tcc_pco_fallback_thumbnail), so take the saved copy off again.
			delete_post_thumbnail( $post_id );
			unset( $synced['fallback_att'] );
		}
		update_post_meta( $post_id, '_tcc_pco_synced', $synced );
		if ( $force ) {
			delete_post_meta( $post_id, '_tcc_pco_force' );
		}
	}
	// A date that was on the website but is no longer among the next dates in Planning Center was cancelled or moved there.
	$per     = tcc_pco_per_event( $s, (string) $ev['id'] );
	$removed = tcc_pco_trash_future_posts( $ev['id'], $keep, count( $keep ) >= $per ? $last_start : '' );
	if ( $removed ) {
		tcc_pco_log( 'Removed ' . $removed . ' date(s) of "' . $ev['name'] . '" that are no longer in Planning Center.' );
	}
}

/* ---------------------------------------------------------------------------
 * Front end: description, registration button, and keeping recurring dates grouped in the event lists
 * ------------------------------------------------------------------------- */

function tcc_pco_description_shortcode() {
	$id = tcc_pco_current_event();
	if ( ! $id ) {
		return '';
	}
	if ( ! tcc_pco_shows( $id, 'description' ) ) {
		return '';
	}
	$desc = tcc_pco_description_text( $id );
	return '' === trim( $desc ) ? '' : '<div class="tcc-pco-description" style="margin-bottom:20px">' . wpautop( wp_kses_post( $desc ) ) . '</div>';
}
add_shortcode( 'tcc_pco_description', 'tcc_pco_description_shortcode' );

function tcc_pco_register_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'label' => 'Register' ), $atts, 'tcc_event_register' );
	$id   = tcc_pco_current_event();
	if ( ! $id ) {
		return '';
	}
	if ( ! tcc_pco_shows( $id, 'register' ) ) {
		return '';
	}
	$url = (string) get_post_meta( $id, '_tcc_register_url', true ); // Website's own link wins if someone typed one.
	if ( '' === $url ) {
		$url = (string) get_post_meta( $id, '_tcc_pco_registration_url', true );
	}
	if ( '' === $url ) {
		return '';
	}
	// Button text typed on the event's edit screen wins over the text set in the page builder.
	$own = trim( (string) get_post_meta( $id, '_tcc_register_label', true ) );
	if ( '' !== $own ) {
		$atts['label'] = $own;
	}
	return '<span class="tcc-event-register-wrap" style="display:block;margin-top:24px"><a class="et_pb_button tcc-event-register" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $atts['label'] ) . '</a></span>';
}
add_shortcode( 'tcc_event_register', 'tcc_pco_register_shortcode' );

/**
 * Should this room show on the pages of this event?
 * A choice made for the event itself (On the website tab) wins; otherwise the Rooms tab decides.
 */
function tcc_pco_room_visible( $s, $event_id, $room_id ) {
	if ( '' !== (string) $event_id && isset( $s['event_rooms'][ $event_id ][ $room_id ] ) ) {
		return (bool) $s['event_rooms'][ $event_id ][ $room_id ];
	}
	return ! empty( $s['rooms'][ $room_id ]['show'] );
}

/** The name visitors see for a room: the public name from the Rooms tab if there is one. */
function tcc_pco_room_label( $s, $room_id, $name ) {
	$label = isset( $s['rooms'][ $room_id ]['label'] ) ? trim( (string) $s['rooms'][ $room_id ]['label'] ) : '';
	return '' !== $label ? $label : trim( (string) $name );
}

/**
 * [tcc_event_rooms] shows the rooms of the event as small rounded labels ("chips"), in the same soft
 * grey, rounded style as the event cards. Only rooms that are allowed to show are printed, and nothing
 * at all when there are none. Optional: label="Room" (the word above the chips; "" for none).
 */
function tcc_pco_rooms_shortcode( $atts ) {
	static $styled = false;
	$atts = shortcode_atts( array( 'label' => '' ), $atts, 'tcc_event_rooms' );
	$id   = tcc_pco_current_event();
	if ( ! $id ) {
		return '';
	}
	$rooms = get_post_meta( $id, '_tcc_pco_rooms', true );
	if ( ! is_array( $rooms ) || ! $rooms || ! tcc_pco_shows( $id, 'rooms' ) ) {
		return '';
	}
	$s        = tcc_pco_settings();
	$event_id = (string) get_post_meta( $id, '_tcc_pco_event_id', true );
	$names    = array();
	foreach ( $rooms as $room_id => $name ) {
		if ( tcc_pco_room_visible( $s, $event_id, (string) $room_id ) ) {
			$names[] = tcc_pco_room_label( $s, (string) $room_id, $name );
		}
	}
	$names = array_values( array_unique( array_filter( $names ) ) );
	if ( ! $names ) {
		return '';
	}
	$label = trim( (string) $atts['label'] );
	if ( '' === $label || in_array( strtolower( $label ), array( 'room', 'rooms' ), true ) ) {
		$label = 1 === count( $names ) ? 'Room' : 'Rooms';
	}
	$html = '';
	if ( ! $styled ) {
		$styled = true;
		// Follows the event cards: 15px corners, dark grey text, the church teal as the accent.
		// The chips are white because the Event Details panel they sit in is the cards' soft grey.
		$html .= '<style>.tcc-event-rooms{display:block;margin-top:14px}.tcc-event-rooms__label{display:block;font-size:14px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;color:#6b6b6c;margin-bottom:8px}.tcc-event-rooms__list{display:flex;flex-wrap:wrap;gap:8px}.tcc-event-room{display:inline-flex;align-items:center;gap:8px;background:#fff;color:#404041;border-radius:15px;padding:7px 14px 7px 11px;font-size:16px;font-weight:600;line-height:1.3}.tcc-event-room svg{flex:0 0 auto;width:16px;height:16px;fill:#00a4cf}</style>';
	}
	$pin   = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.800 7-13a7 7 0 0 0-7-7zm0 9.500A2.500 2.500 0 1 1 12 6.500a2.500 2.500 0 0 1 0 5z"/></svg>';
	$chips = '';
	foreach ( $names as $name ) {
		$chips .= '<span class="tcc-event-room">' . $pin . '<span>' . esc_html( $name ) . '</span></span>';
	}
	return $html . '<span class="tcc-event-rooms"><span class="tcc-event-rooms__label">' . esc_html( $label ) . '</span><span class="tcc-event-rooms__list">' . $chips . '</span></span>';
}
add_shortcode( 'tcc_event_rooms', 'tcc_pco_rooms_shortcode' );

function tcc_pco_series_key( $key, $post_id ) {
	$event_id = (string) get_post_meta( $post_id, '_tcc_pco_event_id', true );
	return '' !== $event_id ? 'pco-' . $event_id : $key;
}
add_filter( 'tcc_upcoming_series_key', 'tcc_pco_series_key', 10, 2 );

/**
 * Tells the event cards (TCC Website Features, [tcc_event_repeats]) how often a synced event repeats,
 * in Planning Center's own words. Words typed in the "Repeats" box on the event's edit screen win.
 */
function tcc_pco_repeats_text( $text, $post_id ) {
	if ( '' !== trim( (string) $text ) ) {
		return $text;
	}
	return (string) get_post_meta( $post_id, '_tcc_pco_repeats', true );
}
add_filter( 'tcc_event_repeats_text', 'tcc_pco_repeats_text', 10, 2 );
