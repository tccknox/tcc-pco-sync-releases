<?php
/**
 * TCC Website, Planning Center events: the Tags, Rooms and Settings tabs of the Planning Center screen.
 * Part: the Tags, Rooms and Settings tabs
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php,
 * only inside the admin (is_admin(), which includes admin-post.php where every button goes).
 * Until 0.14.4 the four screen files (admin.php, admin-tabs.php, admin-buttons.php, admin-event-box.php) were one
 * file. They were cut into four, with the code unchanged, so that an AI asked to return a whole file has less to return.
 *
 * In this file: the Tags tab (tcc_pco_tags_form, with a first guess at the website category for a new tag) and
 * the website categories under it (tcc_pco_cats_form); the Rooms tab (tcc_pco_rooms_form); the Settings tab
 * (tcc_pco_settings_form) with its "Choose graphic" control; and the Save bar at the bottom of these forms.
 * Their Save buttons are handled in admin-buttons.php. The page around them is in admin.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Wrapped so that nothing is set up twice: if a saved edit of this file (TCC Website > Features) fails part-way,
// the original is loaded after it, and this test makes the original step aside. Keep the name it tests.
if ( ! function_exists( 'tcc_pco_settings_form' ) ) {

	/** A first guess at the website category for a Planning Center tag. Only a suggestion until someone saves the Tags tab. */
	function tcc_pco_suggest_term( $name, $group, $cats ) {
		if ( ! in_array( $group, array( 'Ministry', 'Event Type' ), true ) ) {
			return 0;
		}
		$guesses = array(
			'women'           => "Women's Event",
			'abide'           => "Women's Event",
			"men's"           => "Men's Events",
			'forge'           => 'The Forge',
			'kids'            => 'TCC Kids',
			'core class'      => 'Core Classes',
			'missions'        => 'Missions',
			'next steps'      => 'Next Steps',
			'community group' => 'Community Groups',
			'connect group'   => 'Community Groups',
		);
		$name    = strtolower( (string) $name );
		foreach ( $guesses as $needle => $cat_name ) {
			if ( false === strpos( $name, $needle ) ) {
				continue;
			}
			foreach ( (array) $cats as $cat ) {
				if ( is_object( $cat ) && 0 === strcasecmp( html_entity_decode( $cat->name, ENT_QUOTES ), $cat_name ) ) {
					return (int) $cat->term_id;
				}
			}
			return 0;
		}
		return 0;
	}

	/** The bar with the Save button that stays at the bottom of the window while you scroll a long form. */
	function tcc_pco_savebar( $label, $note = '' ) {
		return '<div class="tcc-savebar"><button type="submit" class="button button-primary">' . esc_html( $label ) . '</button>' . ( '' !== $note ? '<span class="tcc-muted">' . esc_html( $note ) . '</span>' : '' ) . '</div>';
	}

	function tcc_pco_tags_form( $s, $items ) {
		$tags = tcc_pco_known_tags();
		if ( ! $tags ) {
			echo '<div class="tcc-empty">Your Planning Center tags will be listed here after the next check. Press "Check Planning Center now" at the top to fetch them.</div>';
			return;
		}
		$cats   = taxonomy_exists( 'tribe_events_cat' ) ? get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) ) : array();
		$cats   = is_wp_error( $cats ) ? array() : $cats;
		$seen   = array_map( 'strval', (array) $s['tags_seen'] );
		$auto   = array_map( 'strval', (array) $s['auto_tags'] );
		$groups = array();
		foreach ( $tags as $tid => $tag ) {
			$groups[ '' !== $tag['group'] ? $tag['group'] : 'No group' ][ (string) $tid ] = $tag['name'];
		}
		$order  = array( 'Ministry', 'Event Type', 'Department', 'Event Location', 'No group' );
		$sorted = array();
		foreach ( $order as $g ) {
			if ( isset( $groups[ $g ] ) ) {
				$sorted[ $g ] = $groups[ $g ];
				unset( $groups[ $g ] );
			}
		}
		$sorted = array_merge( $sorted, $groups );

		// Counts for the summary at the top.
		$public = 0;
		$fresh  = 0;
		foreach ( $tags as $tid => $tag ) {
			$public += ! empty( $s['tag_map'][ $tid ] ) ? 1 : 0;
			$fresh  += in_array( (string) $tid, $seen, true ) ? 0 : 1;
		}

		echo '<div class="tcc-card"><h2>Which tags show on the website</h2>';
		echo '<p>These are your Planning Center tags. For each one, choose what it means on the website:</p>';
		echo '<div class="tcc-two"><div><span class="tcc-pill tcc-pill--teal">Public</span><p class="tcc-muted" style="margin:4px 0 0">Pick a website category. Events with this tag get that category, so they show in that ministry\'s lists.</p></div>';
		echo '<div><span class="tcc-pill tcc-pill--muted">Internal</span><p class="tcc-muted" style="margin:4px 0 0">Never shown on the website. Use this for things like HVAC, staffing and equipment. New tags start here.</p></div>';
		echo '<div><span class="tcc-pill tcc-pill--ok">Approve automatically</span><p class="tcc-muted" style="margin:4px 0 0">Optional. Events with this tag go on the website at the next check, without waiting for you.</p></div></div>';
		echo '<p class="tcc-stats" style="margin-top:14px"><span class="tcc-pill tcc-pill--teal">' . (int) $public . ' public</span> <span class="tcc-pill tcc-pill--muted">' . (int) ( count( $tags ) - $public ) . ' internal</span>' . ( $fresh ? ' <span class="tcc-pill tcc-pill--warn">' . (int) $fresh . ' new</span>' : '' ) . ( $auto ? ' <span class="tcc-pill tcc-pill--ok">' . count( $auto ) . ' approve automatically</span>' : '' ) . '</p></div>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_tags">';
		wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
		$suggested = 0;
		$grid      = 'grid-template-columns:minmax(0,1fr) minmax(200px,320px) 190px';
		foreach ( $sorted as $group => $list ) {
			asort( $list );
			echo '<div class="tcc-card"><h2>' . esc_html( $group ) . ' <span class="tcc-muted" style="font-weight:400;font-size:13px">' . count( $list ) . ' tag' . ( 1 === count( $list ) ? '' : 's' ) . '</span></h2>';
			echo '<div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Planning Center tag</span><span>On the website</span><span>Approval</span></div>';
			foreach ( $list as $tid => $name ) {
				$is_new = ! in_array( (string) $tid, $seen, true );
				$chosen = ! empty( $s['tag_map'][ $tid ] ) ? (int) $s['tag_map'][ $tid ] : 0;
				$guess  = 0;
				if ( $is_new && ! $chosen ) {
					$guess = tcc_pco_suggest_term( $name, $group, $cats );
					if ( $guess ) {
						$chosen = $guess;
						$suggested++;
					}
				}
				echo '<div class="tcc-row' . ( $chosen ? ' tcc-row--on' : '' ) . '" style="' . esc_attr( $grid ) . '"><span class="tcc-row__name">' . esc_html( trim( $name ) ) . ( $is_new ? ' <span class="tcc-pill tcc-pill--warn">new</span>' : '' ) . ( $guess ? ' <span class="tcc-pill tcc-pill--warn">suggested, not saved yet</span>' : '' ) . '</span>';
				echo '<span><input type="hidden" name="tag_ids[]" value="' . esc_attr( $tid ) . '"><select name="tag_map[' . esc_attr( $tid ) . ']" aria-label="' . esc_attr( 'Website category for ' . trim( $name ) ) . '"><option value="0">Internal (not on the website)</option>';
				foreach ( (array) $cats as $cat ) {
					if ( is_object( $cat ) ) {
						echo '<option value="' . (int) $cat->term_id . '"' . selected( $chosen, (int) $cat->term_id, false ) . '>Public: ' . esc_html( $cat->name ) . '</option>';
					}
				}
				echo '</select></span>';
				echo '<span><label><input type="checkbox" name="tag_auto[' . esc_attr( $tid ) . ']" value="1"' . checked( in_array( (string) $tid, $auto, true ), true, false ) . '> Approve automatically</label></span></div>';
			}
			echo '</div>';
		}
		echo tcc_pco_savebar( 'Save tags', $suggested ? $suggested . ' suggestion(s) are filled in but not saved. Check them, then save.' : 'Events already on the website are brought in line as soon as you save.' );
		echo '</form>';
		tcc_pco_cats_form( $cats );
	}

	/** Rename website event categories or add one, without leaving the plugin. */
	function tcc_pco_cats_form( $cats ) {
		echo '<div class="tcc-card"><h2>Website categories</h2>';
		echo '<p>These are the categories you can pick above. Change a name to rename it everywhere on the website, or add a new one at the bottom. Renaming is safe: every event and page list that uses the category keeps working.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_cats">';
		wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
		$grid = 'grid-template-columns:minmax(0,1fr) 130px';
		echo '<div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Category name</span><span>Events using it</span></div>';
		foreach ( (array) $cats as $cat ) {
			if ( ! is_object( $cat ) ) {
				continue;
			}
			$name = html_entity_decode( $cat->name, ENT_QUOTES );
			echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span><input type="text" name="cat_name[' . (int) $cat->term_id . ']" value="' . esc_attr( $name ) . '" maxlength="80" aria-label="' . esc_attr( 'Name of the category ' . $name ) . '"></span><span class="tcc-muted">' . (int) $cat->count . '</span></div>';
		}
		echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span><input type="text" name="cat_new" value="" maxlength="80" placeholder="Add a new category: type its name here" aria-label="New category name"></span><span class="tcc-pill tcc-pill--muted" style="justify-self:start">new</span></div>';
		echo '<p style="margin:14px 0 0"><button type="submit" class="button">Save website categories</button></p>';
		echo '</form>';
		echo '<p class="tcc-muted" style="margin-bottom:0">A new category is only a label until a page is set up to list it. To delete a category, use Events &rarr; Event Categories; it is left out here on purpose, because deleting one can empty a ministry page list.</p></div>';
	}

	function tcc_pco_rooms_form( $s, $items ) {
		$rooms = array();
		$used  = array();
		foreach ( (array) $s['rooms'] as $rid => $row ) {
			if ( ! empty( $row['name'] ) ) {
				$rooms[ (string) $rid ] = (string) $row['name'];
			}
		}
		foreach ( tcc_pco_all_rooms() as $rid => $name ) {
			$rooms[ (string) $rid ] = (string) $name;
		}
		foreach ( $items as $item ) {
			if ( empty( $item['data'] ) || ! empty( $item['gone'] ) ) {
				continue;
			}
			foreach ( tcc_pco_event_rooms( $item['data'] ) as $rid => $name ) {
				$rooms[ $rid ]  = $name;
				$used[ $rid ][] = (string) $item['data']['name'];
			}
		}
		asort( $rooms );
		if ( ! $rooms ) {
			echo '<div class="tcc-empty">Your Planning Center rooms will be listed here after the next check. Press "Check Planning Center now" at the top to fetch them.</div>';
			return;
		}
		$shown = 0;
		foreach ( $rooms as $rid => $name ) {
			$shown += ! empty( $s['rooms'][ $rid ]['show'] ) ? 1 : 0;
		}

		echo '<div class="tcc-card"><h2>Which rooms visitors can see</h2>';
		echo '<p>Every room the church has in Planning Center. Tick a room to let it show on event pages, as a small label with a pin. Give it a public name if the Planning Center name is not how you would say it to a visitor.</p>';
		echo '<p class="tcc-muted">This is the starting point for every event. To show or hide a room for one event only, use that event\'s own screen. Equipment is never listed.</p>';
		echo '<p class="tcc-stats"><span class="tcc-pill tcc-pill--teal">' . (int) $shown . ' can show</span> <span class="tcc-pill tcc-pill--muted">' . (int) ( count( $rooms ) - $shown ) . ' hidden</span></p></div>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_rooms">';
		wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
		$grid = 'grid-template-columns:90px minmax(0,1fr) minmax(180px,300px) minmax(0,1fr)';
		echo '<div class="tcc-card"><div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Show</span><span>Room in Planning Center</span><span>Public name (optional)</span><span>Booked for</span></div>';
		foreach ( $rooms as $rid => $name ) {
			$row = isset( $s['rooms'][ $rid ] ) ? (array) $s['rooms'][ $rid ] : array();
			$on  = ! empty( $row['show'] );
			echo '<div class="tcc-row' . ( $on ? ' tcc-row--on' : '' ) . '" style="' . esc_attr( $grid ) . '">';
			echo '<span><input type="hidden" name="room_names[' . esc_attr( $rid ) . ']" value="' . esc_attr( $name ) . '"><label><input type="checkbox" name="room_show[' . esc_attr( $rid ) . ']" value="1"' . checked( $on, true, false ) . '> Show</label></span>';
			echo '<span class="tcc-row__name">' . esc_html( $name ) . '</span>';
			echo '<span><input type="text" name="room_label[' . esc_attr( $rid ) . ']" value="' . esc_attr( isset( $row['label'] ) ? (string) $row['label'] : '' ) . '" placeholder="' . esc_attr( $name ) . '" aria-label="' . esc_attr( 'Public name for ' . $name ) . '"></span>';
			echo '<span class="tcc-muted">';
			foreach ( isset( $used[ $rid ] ) ? array_unique( $used[ $rid ] ) : array() as $event_name ) {
				echo '<span class="tcc-pill tcc-pill--muted" style="margin:1px 2px 1px 0">' . esc_html( $event_name ) . '</span>';
			}
			echo '</span></div>';
		}
		echo '</div>';
		echo tcc_pco_savebar( 'Save rooms', 'Event pages change as soon as you save.' );
		echo '</form>';
	}

	/** One "Choose graphic" control: a small preview, a button that opens the Media Library, and a Remove button. */
	function tcc_pco_image_picker( $name, $att_id ) {
		$url = $att_id ? wp_get_attachment_image_url( $att_id, 'medium' ) : '';
		if ( ! $url ) {
			$att_id = 0;
		}
		return '<span class="tcc-pco-picker" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><input type="hidden" name="' . esc_attr( $name ) . '" value="' . (int) $att_id . '"><img src="' . esc_url( (string) $url ) . '" alt="" style="width:120px;height:auto;border-radius:4px;' . ( $url ? '' : 'display:none' ) . '"><button type="button" class="button tcc-pco-pick">Choose graphic</button><button type="button" class="button button-link-delete tcc-pco-unpick"' . ( $url ? '' : ' style="display:none"' ) . '>Remove</button></span>';
	}

	/** One line under each "what shows" tick, saying what it is. */
	function tcc_pco_show_hints() {
		return array(
			'description' => 'The text from Planning Center (or typed on the event), above anything you add to the page.',
			'register'    => 'Only appears when the event has a registration link.',
			'location'    => 'The place name, the address, the Get directions link and the map.',
			'rooms'       => 'Only rooms that are ticked on the Rooms tab.',
			'end_time'    => 'Untick to show only when the event starts.',
		);
	}

	function tcc_pco_settings_form( $s, $items ) {
		$connected = '' !== $s['app_id'] && '' !== $s['secret'];
		$last      = get_option( 'tcc_pco_last_run', array() );
		$hints     = tcc_pco_show_hints();

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_settings"><input type="hidden" name="show_form" value="1">';
		wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );

		// Connection.
		echo '<div class="tcc-card"><h2>Connection to Planning Center ';
		if ( ! $connected ) {
			echo '<span class="tcc-pill tcc-pill--bad">Not connected</span>';
		} elseif ( ! empty( $last['time'] ) && empty( $last['ok'] ) ) {
			echo '<span class="tcc-pill tcc-pill--bad">Not working</span>';
		} else {
			echo '<span class="tcc-pill tcc-pill--ok">Connected</span>';
		}
		echo '</h2><p>The website signs in to Planning Center with a Personal Access Token. The website only ever reads Calendar with it and never changes anything. But the token itself can do whatever the Planning Center person who made it can do, in every part of Planning Center (People, Giving, Services and the rest), so anyone who got hold of the Secret could too. Make it from a Planning Center login that can only see Calendar; the steps are below.</p>';
		echo '<div class="tcc-two"><div class="tcc-field"><label for="tcc_app_id">Application ID</label><input type="text" id="tcc_app_id" name="app_id" autocomplete="off" value="' . esc_attr( $s['app_id'] ) . '"></div>';
		echo '<div class="tcc-field"><label for="tcc_secret">Secret</label><input type="password" id="tcc_secret" name="secret" autocomplete="new-password" value="" placeholder="' . ( '' !== $s['secret'] ? 'Saved. Leave empty to keep it.' : '' ) . '"><span class="description">The saved secret is never shown again. Type a new one only to replace it.</span></div></div>';
		echo '<details><summary>How to get these two values</summary><ol><li>Best: in Planning Center People, add a person just for the website (for example "TCC Website", with an email address the church controls). Give that person <strong>Viewer</strong> access to Calendar and <strong>no access</strong> to People, Giving, Services, Check-Ins, Groups, Registrations or Publishing. Sign in to Planning Center as that person. (If that is not possible, sign in as a Planning Center administrator, but know that the token then has all of that administrator\'s access.)</li><li>Go to <code>api.planningcenteronline.com/oauth/applications</code>.</li><li>Under Personal Access Tokens, create a new one (name it "Website").</li><li>Copy the Application ID and the Secret into the two boxes above and press Save settings.</li><li>If a token made by an administrator was used before, delete that old token on the same Planning Center page.</li></ol></details></div>';

		// What shows.
		echo '<div class="tcc-card"><h2>What shows on event pages</h2><p>The starting point for every event. You can change any of these for one event on its own screen.</p>';
		foreach ( tcc_pco_show_keys() as $key => $label ) {
			echo '<label class="tcc-check"><input type="checkbox" name="show[' . esc_attr( $key ) . ']" value="1"' . checked( ! isset( $s['show'][ $key ] ) || ! empty( $s['show'][ $key ] ), true, false ) . '><span><strong>' . esc_html( $label ) . '</strong>' . esc_html( isset( $hints[ $key ] ) ? $hints[ $key ] : '' ) . '</span></label>';
		}
		echo '</div>';

		// Description and repeating events.
		echo '<div class="tcc-card"><h2>Descriptions and repeating events</h2><div class="tcc-two">';
		echo '<div class="tcc-field"><label for="tcc_desc_source">Which Planning Center text to use as the description</label><select id="tcc_desc_source" name="desc_source"><option value="description"' . selected( $s['desc_source'], 'description', false ) . '>Description (the long text)</option><option value="summary"' . selected( $s['desc_source'], 'summary', false ) . '>Summary (the short text)</option></select><span class="description">If the one you choose is empty, the other is used. An event can also have its own text typed on the website.</span></div>';
		echo '<div class="tcc-field"><label for="tcc_per">Upcoming dates to keep for a repeating event</label><input type="number" id="tcc_per" name="per_event" min="1" max="10" value="' . (int) $s['per_event'] . '" class="small-text" style="width:80px"><span class="description">For example 2 shows this week\'s and next week\'s. One event can have its own number, set on that event.</span></div>';
		echo '</div></div>';

		// Graphics.
		echo '<div class="tcc-card"><h2>Graphics</h2><p>An approved event uses its Planning Center graphic. An event with no graphic of its own (from Planning Center or made by hand) is shown with the default below. Nothing is saved onto the event: give it its own graphic later and that one shows instead.</p>';
		echo '<div class="tcc-field"><span class="tcc-field__label">Default graphic</span>' . tcc_pco_image_picker( 'fallback_image', (int) $s['fallback_image'] ) . '</div>';
		$cats = taxonomy_exists( 'tribe_events_cat' ) ? get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) ) : array();
		$cats = is_wp_error( $cats ) ? array() : (array) $cats;
		if ( $cats ) {
			$set = count( array_filter( (array) $s['cat_images'] ) );
			echo '<details' . ( $set ? ' open' : '' ) . '><summary>A different default for one category (optional' . ( $set ? ', ' . (int) $set . ' set' : '' ) . ')</summary><p class="tcc-muted">An event in one of these categories uses that category\'s graphic before the default above.</p>';
			$grid = 'grid-template-columns:minmax(0,220px) minmax(0,1fr)';
			foreach ( $cats as $cat ) {
				if ( is_object( $cat ) ) {
					echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span class="tcc-row__name">' . esc_html( $cat->name ) . '</span><span>' . tcc_pco_image_picker( 'cat_images[' . (int) $cat->term_id . ']', isset( $s['cat_images'][ (int) $cat->term_id ] ) ? (int) $s['cat_images'][ (int) $cat->term_id ] : 0 ) . '</span></div>';
				}
			}
			echo '</details>';
		}
		echo '</div>';
		// The "Choose graphic" buttons open the normal Media Library window.
		echo '<script>jQuery(function($){$(document).on("click",".tcc-pco-pick",function(e){e.preventDefault();var box=$(this).closest(".tcc-pco-picker");var frame=wp.media({title:"Choose a graphic",button:{text:"Use this graphic"},library:{type:"image"},multiple:false});frame.on("select",function(){var a=frame.state().get("selection").first().toJSON();var url=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);box.find("input").val(a.id);box.find("img").attr("src",url).show();box.find(".tcc-pco-unpick").show();});frame.open();});$(document).on("click",".tcc-pco-unpick",function(e){e.preventDefault();var box=$(this).closest(".tcc-pco-picker");box.find("input").val("0");box.find("img").hide();$(this).hide();});});</script>';

		echo tcc_pco_savebar( 'Save settings', 'Nothing on this tab changes until you save.' );
		echo '</form>';

		echo '<p class="tcc-muted">Looking for the short codes for the page builder? They are in the help of <a href="' . esc_url( tcc_pco_help_url( 'tcc-f-planning-center' ) ) . '">Planning Center events</a> on the Features tab.</p>';
	}

}
