<?php
/**
 * TCC Website, Planning Center events: choices made for one event, and the pieces that act on them.
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php.
 *
 *  - "What shows": description, Register button, location, rooms, end time. TCC Website > Planning Center > Settings has the
 *    starting point for every event; the event edit screen can change it for one event.
 *  - "Keep mine": title, date and time, graphic, location, categories. A ticked one is never changed
 *    by Planning Center.
 *  - Description: Planning Center's summary, its description, or text typed on the website.
 *  - Fallback graphic for events with no graphic in Planning Center.
 *  - A box on the WordPress Dashboard that says whether the sync is healthy.
 *
 * The choices are saved on each website event as one custom field, _tcc_pco_opts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The pieces of an event page that can be switched off. */
function tcc_pco_show_keys() {
	return array(
		'description' => 'Description from Planning Center',
		'register'    => 'Register button',
		'location'    => 'Location (name, address and map)',
		'rooms'       => 'Rooms',
		'end_time'    => 'End time',
	);
}

/** The details that can be kept as they are on the website. */
function tcc_pco_lock_keys() {
	return array(
		'title'      => 'Title',
		'dates'      => 'Date and time',
		'image'      => 'Graphic',
		'location'   => 'Location',
		'categories' => 'Categories',
	);
}

/** The choices saved for one website event. */
function tcc_pco_post_opts( $post_id ) {
	$o = get_post_meta( (int) $post_id, '_tcc_pco_opts', true );
	$o = is_array( $o ) ? $o : array();
	$o = array_merge( array( 'show' => array(), 'lock' => array(), 'desc_source' => '', 'desc_text' => '' ), $o );
	if ( ! is_array( $o['show'] ) ) {
		$o['show'] = array();
	}
	if ( ! is_array( $o['lock'] ) ) {
		$o['lock'] = array();
	}
	return $o;
}

/** Does this piece show for this event? The event's own choice wins; otherwise TCC Website > Planning Center > Settings decides. */
function tcc_pco_shows( $post_id, $key, $s = null ) {
	$o = tcc_pco_post_opts( $post_id );
	if ( isset( $o['show'][ $key ] ) ) {
		return (bool) $o['show'][ $key ];
	}
	$s = is_array( $s ) ? $s : tcc_pco_settings();
	return isset( $s['show'][ $key ] ) ? (bool) $s['show'][ $key ] : true;
}

/** Is this detail kept as it is on the website? */
function tcc_pco_locked( $post_id, $field ) {
	$o = tcc_pco_post_opts( $post_id );
	return ! empty( $o['lock'][ $field ] );
}

/** How many upcoming dates of this Planning Center event are kept on the website. */
function tcc_pco_per_event( $s, $event_id ) {
	$n = isset( $s['event_per'][ $event_id ] ) ? (int) $s['event_per'][ $event_id ] : (int) $s['per_event'];
	return max( 1, min( 10, $n ) );
}

/** The page of an event in Planning Center Calendar, for the "Edit in Planning Center" links. */
function tcc_pco_pc_link( $event_id ) {
	return 'https://calendar.planningcenteronline.com/events/' . rawurlencode( (string) $event_id );
}

/**
 * The event a shortcode is being printed for (0 when there is none, such as inside the page builder).
 * Inside the event page template WordPress can report the template itself as "the current post",
 * so when the current post is not an event, the event whose page is being viewed is used.
 */
function tcc_pco_current_event() {
	$id = get_the_ID();
	if ( $id && 'tribe_events' === get_post_type( $id ) ) {
		return (int) $id;
	}
	$id = is_singular( 'tribe_events' ) ? get_queried_object_id() : 0;
	return ( $id && 'tribe_events' === get_post_type( $id ) ) ? (int) $id : 0;
}

/** The description text to print for an event, following the choice made for it. */
function tcc_pco_description_text( $post_id ) {
	$o   = tcc_pco_post_opts( $post_id );
	$s   = tcc_pco_settings();
	$src = '' !== $o['desc_source'] ? $o['desc_source'] : (string) $s['desc_source'];
	if ( 'mine' === $src ) {
		return (string) $o['desc_text'];
	}
	$full = (string) get_post_meta( $post_id, '_tcc_pco_desc_full', true );
	$sum  = (string) get_post_meta( $post_id, '_tcc_pco_summary', true );
	if ( '' === $full && '' === $sum ) {
		return (string) get_post_meta( $post_id, '_tcc_pco_description', true ); // Saved by versions before 0.6.0.
	}
	if ( 'summary' === $src ) {
		return '' !== $sum ? $sum : $full;
	}
	return '' !== $full ? $full : $sum;
}

/**
 * The location and date on event pages are printed by two shortcodes that live outside this plugin
 * ([tcc_event_venue] and [tcc_event_date]). This steps in before they run:
 *  - location switched off: print nothing;
 *  - end time switched off: print the date with the start time only.
 */
function tcc_pco_pre_shortcode( $out, $tag, $attr, $m ) {
	if ( 'tcc_event_venue' !== $tag && 'tcc_event_date' !== $tag ) {
		return $out;
	}
	$id = tcc_pco_current_event();
	if ( ! $id ) {
		return $out;
	}
	if ( 'tcc_event_venue' === $tag ) {
		return tcc_pco_shows( $id, 'location' ) ? $out : '';
	}
	if ( tcc_pco_shows( $id, 'end_time' ) || ! function_exists( 'tribe_get_start_date' ) || ! function_exists( 'tribe_get_end_date' ) ) {
		return $out;
	}
	$start_day = (string) tribe_get_start_date( $id, false, 'F j, Y' );
	$end_day   = (string) tribe_get_end_date( $id, false, 'F j, Y' );
	if ( '' === $start_day ) {
		return $out;
	}
	$days    = ( '' !== $end_day && $end_day !== $start_day ) ? $start_day . ' - ' . $end_day : $start_day;
	$all_day = function_exists( 'tribe_event_is_all_day' ) && tribe_event_is_all_day( $id );
	$time    = $all_day ? '' : (string) tribe_get_start_date( $id, false, 'g:i A' );
	$stacked = is_array( $attr ) && isset( $attr['layout'] ) && 'stacked' === $attr['layout'];
	return esc_html( $days ) . ( '' !== $time ? ( $stacked ? '<br />' : ' ' ) . esc_html( $time ) : '' );
}
add_filter( 'pre_do_shortcode_tag', 'tcc_pco_pre_shortcode', 10, 4 );

/** When the location is switched off, the map on the event page is hidden too. */
function tcc_pco_body_class( $classes ) {
	if ( is_singular( 'tribe_events' ) ) {
		$id = tcc_pco_current_event();
		if ( $id && ! tcc_pco_shows( $id, 'location' ) ) {
			$classes[] = 'tcc-event-no-location';
		}
	}
	return $classes;
}
add_filter( 'body_class', 'tcc_pco_body_class' );

function tcc_pco_head_css() {
	if ( is_singular( 'tribe_events' ) ) {
		echo '<style>.tcc-event-no-location .et_pb_map_container{display:none!important}</style>';
	}
}
add_action( 'wp_head', 'tcc_pco_head_css' );

/**
 * Make event cards pick up a new default or category graphic straight away.
 *
 * Divi keeps each page's styles, including the picture on every event card, in saved files.
 * Saving an event or a page throws those files away; saving this plugin's Settings does not,
 * so without this the cards on the home page, /events/, ministry pages and the Events menu
 * would keep the old picture until something else on the site was saved.
 * Called only when a graphic on TCC Website > Planning Center > Settings actually changes.
 */
function tcc_pco_refresh_cards() {
	if ( class_exists( 'ET_Core_PageResource' ) ) {
		ET_Core_PageResource::remove_static_resources( 'all', 'all' ); // Divi rebuilds each file the next time its page is viewed.
	}
	// Saved copies of whole pages (used for visitors who are not signed in) point at the old files, so clear those too.
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
	}
	if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
		sg_cachepress_purge_cache();
	}
}

/** The graphic to use when Planning Center has none: the event's category graphic if one is set, else the default. 0 for none. */
function tcc_pco_fallback_image( $post_id, $s ) {
	// get_the_terms() uses the categories WordPress already loaded with the list of events (same order:
	// by name), so a card without a graphic costs no extra database lookup. Until 0.14.1 this asked the
	// database again for every such card.
	$terms = taxonomy_exists( 'tribe_events_cat' ) ? get_the_terms( (int) $post_id, 'tribe_events_cat' ) : array();
	$terms = ( is_array( $terms ) ) ? wp_list_pluck( $terms, 'term_id' ) : array();
	foreach ( $terms as $term_id ) {
		$att = isset( $s['cat_images'][ (int) $term_id ] ) ? (int) $s['cat_images'][ (int) $term_id ] : 0;
		if ( $att && wp_attachment_is_image( $att ) ) {
			return $att;
		}
	}
	$att = (int) $s['fallback_image'];
	return ( $att && wp_attachment_is_image( $att ) ) ? $att : 0;
}

/**
 * Any event with no graphic of its own (hand-made or from Planning Center) is shown with the fallback
 * graphic. Nothing is saved onto the event: give it a graphic later and that one shows instead.
 * Only on the public website, so the edit screen and the sync still see that the event has no graphic.
 */
function tcc_pco_fallback_thumbnail( $thumbnail_id, $post = null ) {
	if ( $thumbnail_id || is_admin() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return $thumbnail_id;
	}
	$post = get_post( $post );
	if ( ! $post || 'tribe_events' !== $post->post_type ) {
		return $thumbnail_id;
	}
	$fallback = tcc_pco_fallback_image( $post->ID, tcc_pco_settings() );
	return $fallback ? $fallback : $thumbnail_id;
}
add_filter( 'post_thumbnail_id', 'tcc_pco_fallback_thumbnail', 10, 2 );

/**
 * A new date of a repeating event starts with the same choices as the date before it, so nobody has to
 * tick the same boxes every week. Kept details (title, graphic, location, categories) are copied across too.
 * Returns the title to create the new date with.
 */
function tcc_pco_inherit( $event_id, $pco_title ) {
	$siblings = tcc_pco_posts_for( $event_id );
	if ( ! $siblings ) {
		return array( 'title' => $pco_title, 'from' => 0, 'opts' => array(), 'content' => '' );
	}
	$from = end( $siblings );
	$o    = tcc_pco_post_opts( $from->ID );
	unset( $o['lock']['dates'] ); // Each date has its own date and time.
	return array(
		'title' => ! empty( $o['lock']['title'] ) ? (string) get_post_field( 'post_title', $from->ID, 'raw' ) : $pco_title,
		'from'    => (int) $from->ID,
		'opts'    => $o,
		'content' => (string) get_post_field( 'post_content', $from->ID, 'raw' ), // Page content written on the date before.
	);
}

/** Finishes what tcc_pco_inherit() started, once the new date exists. */
function tcc_pco_inherit_apply( $post_id, $inherit ) {
	if ( empty( $inherit['from'] ) ) {
		return;
	}
	$o    = $inherit['opts'];
	$from = (int) $inherit['from'];
	if ( $o['show'] || $o['lock'] || '' !== $o['desc_source'] ) {
		update_post_meta( $post_id, '_tcc_pco_opts', $o );
	}
	if ( ! empty( $o['lock']['image'] ) && get_post_thumbnail_id( $from ) ) {
		set_post_thumbnail( $post_id, (int) get_post_thumbnail_id( $from ) );
	}
	if ( ! empty( $o['lock']['location'] ) ) {
		update_post_meta( $post_id, '_EventVenueID', (int) get_post_meta( $from, '_EventVenueID', true ) );
	}
	if ( ! empty( $o['lock']['categories'] ) && taxonomy_exists( 'tribe_events_cat' ) ) {
		$terms = wp_get_object_terms( $from, 'tribe_events_cat', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $terms ) ) {
			wp_set_object_terms( $post_id, array_map( 'intval', $terms ), 'tribe_events_cat' );
		}
	}
	$label = (string) get_post_meta( $from, '_tcc_register_label', true );
	if ( '' !== $label ) {
		update_post_meta( $post_id, '_tcc_register_label', $label );
	}
	$url = (string) get_post_meta( $from, '_tcc_register_url', true );
	if ( '' !== $url ) {
		update_post_meta( $post_id, '_tcc_register_url', $url );
	}
}

/* ---------------------------------------------------------------------------
 * Replacing an event that was made by hand on the website
 * ------------------------------------------------------------------------- */

/** A name with capitals, "&"/"and" and punctuation taken out, so "Community Dinner & Prayer" equals "Community Dinner and Prayer". */
function tcc_pco_plain_name( $name ) {
	$name = strtolower( html_entity_decode( (string) $name, ENT_QUOTES ) );
	$name = str_replace( '&', ' and ', $name );
	return trim( (string) preg_replace( '/[^a-z0-9]+/', ' ', $name ) );
}

/**
 * Upcoming events that were made by hand on the website (not by this plugin), listed once each.
 * A repeating hand-made event is one item with many dates. Returns post id => array( title, count, next, days ).
 */
function tcc_pco_handmade_upcoming() {
	static $list = null;
	if ( null !== $list ) {
		return $list;
	}
	global $wpdb;
	$list  = array();
	$now   = current_time( 'mysql' );
	$table = $wpdb->prefix . 'tec_occurrences';
	$rows  = array();
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		// The Events Calendar keeps every date of every event in this table.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, start_date FROM {$table} WHERE start_date >= %s ORDER BY start_date ASC LIMIT 3000", $now ), ARRAY_A );
	} else {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value AS start_date FROM {$wpdb->postmeta} WHERE meta_key = '_EventStartDate' AND meta_value >= %s ORDER BY meta_value ASC LIMIT 3000", $now ), ARRAY_A );
	}
	// Load every one of these events and their fields in two lookups, instead of two lookups per event
	// in the loop below (since 0.14.1; it matters on the Waiting for approval tab as events grow).
	$ids = array_values( array_unique( array_map( 'intval', wp_list_pluck( (array) $rows, 'post_id' ) ) ) );
	if ( $ids && function_exists( '_prime_post_caches' ) ) {
		_prime_post_caches( $ids, false, true );
	}
	foreach ( (array) $rows as $row ) {
		$id = (int) $row['post_id'];
		if ( ! isset( $list[ $id ] ) ) {
			$post = get_post( $id );
			if ( ! $post || 'tribe_events' !== $post->post_type || ! in_array( $post->post_status, array( 'publish', 'future', 'private' ), true ) || '' !== (string) get_post_meta( $id, '_tcc_pco_event_id', true ) ) {
				$list[ $id ] = false;
				continue;
			}
			$list[ $id ] = array( 'title' => (string) $post->post_title, 'count' => 0, 'next' => (string) $row['start_date'], 'days' => array() );
		}
		if ( $list[ $id ] ) {
			$list[ $id ]['count']++;
			$list[ $id ]['days'][ substr( (string) $row['start_date'], 0, 10 ) ] = true;
		}
	}
	$list = array_filter( $list );
	return $list;
}

/**
 * Hand-made website events with the same name as a Planning Center event.
 * 'same_day' is true when one of its dates falls on a day the Planning Center event also has: then it is
 * almost certainly the same event. A same-named event on a different day may be a different occasion.
 */
function tcc_pco_handmade_matches( $ev ) {
	$name = tcc_pco_plain_name( isset( $ev['name'] ) ? $ev['name'] : '' );
	if ( '' === $name ) {
		return array();
	}
	$days = array();
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		$dt = tcc_pco_local( $inst['starts'] );
		if ( $dt ) {
			$days[ $dt->format( 'Y-m-d' ) ] = true;
		}
	}
	$out = array();
	foreach ( tcc_pco_handmade_upcoming() as $id => $row ) {
		if ( tcc_pco_plain_name( $row['title'] ) === $name ) {
			$row['same_day'] = (bool) array_intersect_key( $row['days'], $days );
			unset( $row['days'] );
			$out[ $id ] = $row;
		}
	}
	return $out;
}

/** Do two pieces of text say (nearly) the same thing? Used so a description is not printed twice. */
function tcc_pco_same_text( $a, $b ) {
	$plain = function ( $text ) {
		$text = strtolower( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES ) );
		return trim( (string) preg_replace( '/[^a-z0-9]+/', ' ', $text ) );
	};
	$a = $plain( $a );
	$b = $plain( $b );
	if ( '' === $a || '' === $b ) {
		return false;
	}
	if ( false !== strpos( $a, $b ) || false !== strpos( $b, $a ) ) {
		return true;
	}
	$percent = 0;
	similar_text( substr( $a, 0, 1500 ), substr( $b, 0, 1500 ), $percent );
	return $percent > 70;
}

/** What to carry over from a hand-made event to the Planning Center event that replaces it. */
function tcc_pco_carry_from( $post_id ) {
	$terms = taxonomy_exists( 'tribe_events_cat' ) ? wp_get_object_terms( $post_id, 'tribe_events_cat', array( 'fields' => 'ids' ) ) : array();
	return array(
		'content' => (string) get_post_field( 'post_content', $post_id, 'raw' ),
		'thumb'   => (int) get_post_thumbnail_id( $post_id ),
		'terms'   => is_wp_error( $terms ) ? array() : array_map( 'intval', (array) $terms ),
	);
}

/** Gives a new Planning Center date the graphic and categories of the hand-made event it replaces. */
function tcc_pco_carry_apply( $post_id, $carry ) {
	if ( ! empty( $carry['thumb'] ) && wp_attachment_is_image( (int) $carry['thumb'] ) ) {
		// The website already has this graphic, so keep using it instead of copying Planning Center's in.
		set_post_thumbnail( $post_id, (int) $carry['thumb'] );
		$o                  = tcc_pco_post_opts( $post_id );
		$o['lock']['image'] = 1;
		update_post_meta( $post_id, '_tcc_pco_opts', wp_slash( $o ) );
	}
	if ( ! empty( $carry['terms'] ) && taxonomy_exists( 'tribe_events_cat' ) ) {
		wp_set_object_terms( $post_id, array_map( 'intval', (array) $carry['terms'] ), 'tribe_events_cat', true );
	}
}

/* ---------------------------------------------------------------------------
 * Dashboard box: is the sync healthy?
 * ------------------------------------------------------------------------- */

function tcc_pco_dashboard() {
	if ( current_user_can( 'manage_options' ) ) {
		wp_add_dashboard_widget( 'tcc_pco_dash', 'Planning Center events', 'tcc_pco_dashboard_html' );
	}
}
add_action( 'wp_dashboard_setup', 'tcc_pco_dashboard' );

function tcc_pco_dashboard_html() {
	$s       = tcc_pco_settings();
	$last    = get_option( 'tcc_pco_last_run', array() );
	$next    = wp_next_scheduled( 'tcc_pco_sync_cron' );
	$waiting = 0;
	$synced  = 0;
	foreach ( tcc_pco_items() as $item ) {
		if ( tcc_pco_item_passed( $item ) ) {
			continue;
		}
		$status   = isset( $item['status'] ) ? $item['status'] : 'new';
		$waiting += ( 'new' === $status && empty( $item['gone'] ) ) ? 1 : 0;
		// Same rule as the "On the website" tab: an event taken off Church Center is not listed there, so not counted here.
		$synced  += ( 'approved' === $status && empty( $item['gone'] ) ) ? 1 : 0;
	}
	$conflicts = count( tcc_pco_conflicts() );
	$problems  = array();
	if ( '' === $s['app_id'] || '' === $s['secret'] ) {
		$problems[] = 'Planning Center is not connected. Add the Application ID and Secret on TCC Website > Planning Center > Settings.';
	} elseif ( empty( $last['time'] ) ) {
		$problems[] = 'Planning Center has not been checked yet.';
	} else {
		if ( empty( $last['ok'] ) ) {
			// 'held': the check worked but Planning Center's answer looked wrong, so nothing was removed (see tcc_pco_removal_check).
			$problems[] = ( ! empty( $last['held'] ) ? 'Nothing was taken off the website at the last check: ' : 'The last check failed: ' ) . ( isset( $last['message'] ) ? $last['message'] : 'no reason was given' );
		}
		if ( time() - (int) $last['time'] > 3 * HOUR_IN_SECONDS ) {
			$problems[] = 'The hourly check has not run for ' . human_time_diff( (int) $last['time'] ) . '. Press "Check Planning Center now" on the Planning Center screen; if this keeps happening, the website\'s scheduled tasks are not running.';
		}
	}
	if ( ! $next ) {
		$problems[] = 'No hourly check is scheduled. Switch Planning Center events off and on again on TCC Website > Features.';
	}
	if ( ! function_exists( 'tribe_create_event' ) ) {
		$problems[] = 'The Events Calendar plugin is not active, so events cannot be added to the website.';
	}
	if ( $problems ) {
		echo '<p><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#b32d2e;margin-right:6px"></span><strong>Needs a look</strong></p><ul style="list-style:disc;margin-left:18px">';
		foreach ( $problems as $p ) {
			echo '<li>' . esc_html( $p ) . '</li>';
		}
		echo '</ul>';
	} else {
		echo '<p><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#00a32a;margin-right:6px"></span><strong>Working</strong></p>';
	}
	if ( ! empty( $last['time'] ) ) {
		echo '<p>Last check: ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago' . ( $next ? '. Next check: in about ' . esc_html( human_time_diff( time(), max( time(), (int) $next ) ) ) : '' ) . '.</p>';
	}
	echo '<p><a href="' . esc_url( tcc_pco_url( 'waiting' ) ) . '">' . (int) $waiting . ' waiting for approval</a> &middot; <a href="' . esc_url( tcc_pco_url( 'synced' ) ) . '">' . (int) $synced . ' on the website</a> &middot; <a href="' . esc_url( tcc_pco_url( 'conflicts' ) ) . '"' . ( $conflicts ? ' style="color:#b32d2e"' : '' ) . '>' . (int) $conflicts . ' conflict' . ( 1 === $conflicts ? '' : 's' ) . '</a></p>';
}

/** If the hourly check ever goes missing (it is only set up when Planning Center events is switched on), put it back. */
function tcc_pco_ensure_schedule() {
	if ( ! wp_next_scheduled( 'tcc_pco_sync_cron' ) ) {
		wp_schedule_event( time() + 300, 'hourly', 'tcc_pco_sync_cron' );
	}
}
add_action( 'admin_init', 'tcc_pco_ensure_schedule' );
