<?php
/**
 * TCC Website, Planning Center events: the box "Planning Center and registration" on each event's edit screen.
 * Part: the box on each event's edit screen
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php,
 * only inside the admin (is_admin(), which includes admin-post.php where every button goes).
 * Until 0.14.4 the four screen files (admin.php, admin-tabs.php, admin-buttons.php, admin-event-box.php) were one
 * file. They were cut into four, with the code unchanged, so that an AI asked to return a whole file has less to return.
 *
 * In this file: the box itself (tcc_pco_meta_box_html): whether the event is kept up to date, what shows on its
 * page, which details keep the website's version, its rooms, its description and its Register button; and saving
 * it when Update is pressed (tcc_pco_meta_box_save), including copying the choices to the event's other dates.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Wrapped so that nothing is set up twice: if a saved edit of this file (TCC Website > Features) fails part-way,
// the original is loaded after it, and this test makes the original step aside. Keep the name it tests.
if ( ! function_exists( 'tcc_pco_meta_box_html' ) ) {

	/* ---------------------------------------------------------------------------
	 * A box on the event edit screen
	 * ------------------------------------------------------------------------- */

	function tcc_pco_meta_box() {
		add_meta_box( 'tcc_pco_box', 'Planning Center and registration', 'tcc_pco_meta_box_html', 'tribe_events', 'normal', 'high' );
	}
	add_action( 'add_meta_boxes', 'tcc_pco_meta_box' );

	/** One coloured status line for the box on the event edit screen. */
	function tcc_pco_status_line( $colour, $text ) {
		$kinds = array( '#00a32a' => 'ok', '#dba617' => 'warn', '#b32d2e' => 'bad', '#8c8f94' => 'muted' );
		return '<p style="margin:4px 0 8px"><span class="tcc-pill tcc-pill--' . ( isset( $kinds[ $colour ] ) ? $kinds[ $colour ] : 'muted' ) . '" style="font-size:13px;padding:3px 12px">' . esc_html( $text ) . '</span></p>';
	}

	function tcc_pco_meta_box_html( $post ) {
		wp_nonce_field( 'tcc_pco_box', '_tcc_pco_box_nonce' );
		tcc_pco_admin_css();
		$event_id = (string) get_post_meta( $post->ID, '_tcc_pco_event_id', true );
		$is_pco   = '' !== $event_id;
		$s        = tcc_pco_settings();
		$o        = tcc_pco_post_opts( $post->ID );
		$help     = current_user_can( 'manage_options' ) ? ' <a href="' . esc_url( tcc_pco_help_url( 'tcc-pco-one-event' ) ) . '">Help with this box</a>' : '';

		// Sync status.
		if ( $is_pco ) {
			$items  = tcc_pco_items();
			$item   = isset( $items[ $event_id ] ) ? $items[ $event_id ] : array();
			$status = isset( $item['status'] ) ? $item['status'] : '';
			$paused = (bool) get_post_meta( $post->ID, '_tcc_pco_paused', true );
			if ( tcc_pco_post_passed( $post->ID ) ) {
				echo tcc_pco_status_line( '#8c8f94', 'This date has passed.' );
				echo '<p>It is no longer updated from Planning Center. It keeps the last details it had.</p>';
			} elseif ( $paused || 'approved' !== $status ) {
				echo tcc_pco_status_line( '#dba617', 'Syncing is stopped for this event.' );
				echo '<p>Nothing here is changed by Planning Center until syncing is started again on the Planning Center screen.</p>';
			} elseif ( ! empty( $item['gone'] ) ) {
				echo tcc_pco_status_line( '#b32d2e', 'No longer published in Planning Center.' );
				echo '<p>Planning Center has stopped listing this event, so it is not being updated.</p>';
			} else {
				$last = get_option( 'tcc_pco_last_run', array() );
				echo tcc_pco_status_line( '#00a32a', 'Kept up to date from Planning Center.' );
				echo '<p>' . ( ! empty( $last['time'] ) ? 'Last checked ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago. ' : '' ) . 'Planning Center fills in the title, date, graphic, description, location, rooms and categories. Anything you add to the page itself is yours.' . $help . '</p>';
			}
			$clashes = 0;
			foreach ( tcc_pco_conflicts() as $c ) {
				$clashes += isset( $c['post_id'] ) && (int) $c['post_id'] === (int) $post->ID ? 1 : 0;
			}
			if ( $clashes ) {
				echo '<p style="color:#b32d2e">' . (int) $clashes . ' thing' . ( 1 === $clashes ? ' was' : 's were' ) . ' changed both here and in Planning Center. ' . ( current_user_can( 'manage_options' ) ? '<a href="' . esc_url( tcc_pco_url( 'conflicts' ) ) . '">Choose which to keep</a>' : 'An administrator can choose which to keep.' ) . '</p>';
			}
			echo '<p><a href="' . esc_url( tcc_pco_pc_link( $event_id ) ) . '" target="_blank" rel="noopener">Edit this event in Planning Center</a>' . ( current_user_can( 'manage_options' ) ? ' &nbsp;|&nbsp; <a href="' . esc_url( tcc_pco_url( 'synced' ) ) . '">Open the Planning Center screen</a>' : '' ) . '</p>';
			echo '<input type="hidden" name="tcc_pco_synced_form" value="1">';
		} else {
			echo '<p><span class="tcc-pill tcc-pill--muted" style="font-size:13px;padding:3px 12px">Made on the website</span></p><p>This event is not linked to Planning Center. The choices below still work for it.' . $help . '</p>';
		}

		echo '<div class="tcc-box-grid">';

		// What shows on the event page.
		echo '<div class="tcc-box-col"><h4>Show on the event page</h4>';
		foreach ( tcc_pco_show_keys() as $key => $label ) {
			if ( ! $is_pco && in_array( $key, array( 'description', 'rooms' ), true ) ) {
				continue; // These two only exist for Planning Center events.
			}
			echo '<input type="hidden" name="tcc_pco_show_all[]" value="' . esc_attr( $key ) . '">';
			echo '<label><input type="checkbox" name="tcc_pco_show[]" value="' . esc_attr( $key ) . '"' . checked( tcc_pco_shows( $post->ID, $key, $s ), true, false ) . '> ' . esc_html( $label ) . ( isset( $o['show'][ $key ] ) ? ' <span style="color:#8c8f94">(chosen here)</span>' : '' ) . '</label>';
		}
		echo '<p class="description">Untick a piece to hide it from visitors on this event.</p>';
		if ( $o['show'] ) {
			echo '<p><label><input type="checkbox" name="tcc_pco_show_reset" value="1"> Go back to the Settings tab choices</label></p>';
		}
		echo '</div>';

		if ( $is_pco ) {
			// Keep mine.
			echo '<div class="tcc-box-col"><h4>Keep the website\'s version</h4>';
			foreach ( tcc_pco_lock_keys() as $key => $label ) {
				echo '<label><input type="checkbox" name="tcc_pco_lock[]" value="' . esc_attr( $key ) . '"' . checked( ! empty( $o['lock'][ $key ] ), true, false ) . '> ' . esc_html( $label ) . '</label>';
			}
			echo '<p class="description">Tick a detail to keep your own version: Planning Center stops changing it. Untick it to hand it back.</p></div>';

			// Rooms.
			$rooms = get_post_meta( $post->ID, '_tcc_pco_rooms', true );
			echo '<div class="tcc-box-col"><h4>Rooms shown</h4>';
			if ( ! is_array( $rooms ) || ! $rooms ) {
				echo '<p><em>No rooms are booked for this date in Planning Center.</em></p>';
			} else {
				$custom = ! empty( $s['event_rooms'][ $event_id ] );
				foreach ( $rooms as $rid => $name ) {
					$label = tcc_pco_room_label( $s, (string) $rid, $name );
					echo '<input type="hidden" name="tcc_pco_rooms_all[]" value="' . esc_attr( $rid ) . '">';
					echo '<label><input type="checkbox" name="tcc_pco_rooms_show[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
				}
				echo '<p class="description">' . ( $custom ? 'These were chosen for this event.' : 'These follow the Rooms tab until you change a tick here.' ) . ' A change applies to every date of this event.</p>';
				if ( $custom ) {
					echo '<p><label><input type="checkbox" name="tcc_pco_rooms_reset" value="1"> Go back to the Rooms tab settings</label></p>';
				}
			}
			echo '</div>';
		}
		echo '</div>';

		if ( $is_pco ) {
			// Description.
			$src  = (string) $o['desc_source'];
			$full = (string) get_post_meta( $post->ID, '_tcc_pco_desc_full', true );
			$sum  = (string) get_post_meta( $post->ID, '_tcc_pco_summary', true );
			if ( '' === $full && '' === $sum ) {
				$full = (string) get_post_meta( $post->ID, '_tcc_pco_description', true );
			}
			$opts = array(
				''            => 'The usual one (Planning Center ' . ( 'summary' === $s['desc_source'] ? 'summary' : 'description' ) . ')',
				'summary'     => 'Planning Center summary',
				'description' => 'Planning Center description',
				'mine'        => 'My own text, typed here',
			);
			echo '<div class="tcc-box-section"><h4>Description on the event page</h4><div class="tcc-field"><label for="tcc_pco_desc_source">Which text to show</label>';
			// Choosing "My own text" opens the box to type it in.
			echo '<select id="tcc_pco_desc_source" name="tcc_pco_desc_source" onchange="document.getElementById(\'tcc_pco_desc_mine\').style.display = ( \'mine\' === this.value ) ? \'block\' : \'none\';">';
			foreach ( $opts as $value => $label ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $src, $value, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select></div>';
			echo '<div class="tcc-field" id="tcc_pco_desc_mine" style="display:' . ( 'mine' === $src ? 'block' : 'none' ) . '"><label for="tcc_pco_desc_text">Your own text</label><textarea id="tcc_pco_desc_text" name="tcc_pco_desc_text" rows="4" style="max-width:none">' . esc_textarea( (string) $o['desc_text'] ) . '</textarea><span class="description">Shown in place of the Planning Center text for this event.</span></div>';
			echo '<details><summary>See what Planning Center has for this event</summary>';
			echo '<p><strong>Summary:</strong> ' . ( '' !== trim( wp_strip_all_tags( $sum ) ) ? esc_html( wp_strip_all_tags( $sum ) ) : '<em>empty</em>' ) . '</p>';
			echo '<p><strong>Description:</strong> ' . ( '' !== trim( wp_strip_all_tags( $full ) ) ? esc_html( wp_strip_all_tags( $full ) ) : '<em>empty</em>' ) . '</p></details></div>';

			// Dates kept, and whether the choices apply to the other dates.
			$own = isset( $s['event_per'][ $event_id ] ) ? (int) $s['event_per'][ $event_id ] : 0;
			echo '<div class="tcc-box-section"><h4>If this event repeats</h4>';
			echo '<div class="tcc-field"><label for="tcc_pco_event_per">Upcoming dates to keep on the website</label><input type="number" id="tcc_pco_event_per" name="tcc_pco_event_per" min="1" max="10" style="width:80px" value="' . ( $own ? (int) $own : '' ) . '" placeholder="' . (int) $s['per_event'] . '"><span class="description">Leave empty for the usual number (' . (int) $s['per_event'] . '). A change shows after the next check.</span></div>';
			echo '<label class="tcc-check" style="border-top:0;padding-top:0"><input type="checkbox" name="tcc_pco_all_dates" value="1" checked><span><strong>Use the choices in this box for the other upcoming dates too</strong>New dates always start with the choices of the date before them. The date and time are never copied.</span></label></div>';
			$reg = (string) get_post_meta( $post->ID, '_tcc_pco_registration_url', true );
			echo '<div class="tcc-box-section"><h4>Register button</h4><p>' . ( '' !== $reg ? 'Planning Center has a registration link for this event (<a href="' . esc_url( $reg ) . '" target="_blank" rel="noopener">open it</a>), so a Register button shows.' : 'Planning Center has no registration link for this event, so no button shows unless you add a link here.' ) . '</p>';
		} else {
			echo '<div class="tcc-box-section"><h4>Register button</h4><p>A Register button shows when you add a link here.</p>';
		}
		echo '<div class="tcc-two">';
		echo '<div class="tcc-field"><label for="tcc_register_url">Button link (optional)</label><input type="url" id="tcc_register_url" name="tcc_register_url" style="max-width:none" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_url', true ) ) . '" placeholder="https://"><span class="description">' . ( $is_pco ? 'Used instead of the Planning Center link.' : 'Where the button goes.' ) . '</span></div>';
		echo '<div class="tcc-field"><label for="tcc_register_label">Button text (optional)</label><input type="text" id="tcc_register_label" name="tcc_register_label" maxlength="40" style="max-width:none" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_label', true ) ) . '" placeholder="Register"><span class="description">For example "Sign up" or "Get tickets". Leave empty for "Register".</span></div>';
		echo '</div></div>';
		echo '<p class="tcc-muted" style="margin:14px 0 0;padding-top:10px;border-top:1px solid #f0f0f1">These choices are saved when you press <strong>Update</strong> for the event.</p>';
	}

	/** Saves the room ticks from the edit screen. Only becomes the event's own choice when a tick was really changed. */
	function tcc_pco_meta_box_save_rooms( $post_id, $event_id ) {
		if ( ! isset( $_POST['tcc_pco_rooms_all'] ) || ! is_array( $_POST['tcc_pco_rooms_all'] ) ) {
			return;
		}
		$s     = tcc_pco_settings();
		$title = get_the_title( $post_id );
		if ( ! is_array( $s['event_rooms'] ) ) {
			$s['event_rooms'] = array();
		}
		if ( ! empty( $_POST['tcc_pco_rooms_reset'] ) ) {
			if ( isset( $s['event_rooms'][ $event_id ] ) ) {
				unset( $s['event_rooms'][ $event_id ] );
				update_option( 'tcc_pco_settings', $s, false );
				tcc_pco_log( '"' . $title . '" follows the Rooms tab again.', $post_id );
			}
			return;
		}
		$all     = array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_all'] ) );
		$show    = isset( $_POST['tcc_pco_rooms_show'] ) && is_array( $_POST['tcc_pco_rooms_show'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_show'] ) ) : array();
		$choice  = isset( $s['event_rooms'][ $event_id ] ) && is_array( $s['event_rooms'][ $event_id ] ) ? $s['event_rooms'][ $event_id ] : array();
		$changed = false;
		foreach ( $all as $rid ) {
			$want = in_array( $rid, $show, true );
			if ( $want !== tcc_pco_room_visible( $s, $event_id, $rid ) ) {
				$changed = true;
			}
			$choice[ $rid ] = $want ? 1 : 0;
		}
		if ( $changed ) {
			$s['event_rooms'][ $event_id ] = $choice;
			update_option( 'tcc_pco_settings', $s, false );
			tcc_pco_log( 'Rooms saved for "' . $title . '": ' . count( $show ) . ' showing.', $post_id );
		}
	}

	/** Writes the choices of one event, or removes the custom field when there are none. */
	function tcc_pco_save_opts( $post_id, $o ) {
		if ( ! $o['show'] && ! $o['lock'] && '' === $o['desc_source'] && '' === trim( (string) $o['desc_text'] ) ) {
			delete_post_meta( $post_id, '_tcc_pco_opts' );
		} else {
			update_post_meta( $post_id, '_tcc_pco_opts', wp_slash( $o ) );
		}
	}

	function tcc_pco_meta_box_save( $post_id ) {
		static $busy = false; // This function changes events itself further down; do not run it again for those changes.
		if ( $busy ) {
			return;
		}
		if ( ! isset( $_POST['_tcc_pco_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_tcc_pco_box_nonce'] ) ), 'tcc_pco_box' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( isset( $_POST['post_ID'] ) && (int) $_POST['post_ID'] !== (int) $post_id ) {
			return; // Some other event is being saved as a side effect.
		}

		// Registration button.
		$url = isset( $_POST['tcc_register_url'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['tcc_register_url'] ) ) ) : '';
		if ( '' === $url ) {
			delete_post_meta( $post_id, '_tcc_register_url' );
		} else {
			update_post_meta( $post_id, '_tcc_register_url', $url );
		}
		$label = isset( $_POST['tcc_register_label'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['tcc_register_label'] ) ) ) : '';
		$label = function_exists( 'mb_substr' ) ? mb_substr( $label, 0, 40 ) : substr( $label, 0, 40 );
		if ( '' === $label ) {
			delete_post_meta( $post_id, '_tcc_register_label' );
		} else {
			update_post_meta( $post_id, '_tcc_register_label', $label );
		}

		$s        = tcc_pco_settings();
		$o        = tcc_pco_post_opts( $post_id );
		$old_lock = $o['lock'];
		$event_id = (string) get_post_meta( $post_id, '_tcc_pco_event_id', true );
		$is_pco   = '' !== $event_id && ! empty( $_POST['tcc_pco_synced_form'] );

		// What shows. A tick only becomes this event's own choice when it differs from what was showing.
		if ( isset( $_POST['tcc_pco_show_all'] ) && is_array( $_POST['tcc_pco_show_all'] ) ) {
			if ( ! empty( $_POST['tcc_pco_show_reset'] ) ) {
				$o['show'] = array();
			} else {
				$all   = array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_show_all'] ) );
				$shown = isset( $_POST['tcc_pco_show'] ) && is_array( $_POST['tcc_pco_show'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_show'] ) ) : array();
				foreach ( array_intersect( array_keys( tcc_pco_show_keys() ), $all ) as $key ) {
					$want = in_array( $key, $shown, true );
					if ( $want !== tcc_pco_shows( $post_id, $key, $s ) ) {
						$o['show'][ $key ] = $want ? 1 : 0;
					}
				}
			}
		}

		if ( $is_pco ) {
			// Keep mine.
			$locks     = isset( $_POST['tcc_pco_lock'] ) && is_array( $_POST['tcc_pco_lock'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_lock'] ) ) : array();
			$o['lock'] = array();
			foreach ( array_intersect( array_keys( tcc_pco_lock_keys() ), $locks ) as $key ) {
				$o['lock'][ $key ] = 1;
			}
			// Description.
			$src              = isset( $_POST['tcc_pco_desc_source'] ) ? sanitize_key( wp_unslash( $_POST['tcc_pco_desc_source'] ) ) : '';
			$o['desc_source'] = in_array( $src, array( 'summary', 'description', 'mine' ), true ) ? $src : '';
			$o['desc_text']   = isset( $_POST['tcc_pco_desc_text'] ) ? wp_kses_post( trim( (string) wp_unslash( $_POST['tcc_pco_desc_text'] ) ) ) : '';
		}
		tcc_pco_save_opts( $post_id, $o );
		if ( ! $is_pco ) {
			return;
		}

		// Details handed back to Planning Center: its version is put back by the sync just below.
		$unlocked = array_keys( array_diff_key( $old_lock, $o['lock'] ) );
		if ( $unlocked ) {
			update_post_meta( $post_id, '_tcc_pco_force', $unlocked );
		}

		// How many upcoming dates to keep.
		$per = isset( $_POST['tcc_pco_event_per'] ) ? absint( $_POST['tcc_pco_event_per'] ) : 0;
		$had = isset( $s['event_per'][ $event_id ] ) ? (int) $s['event_per'][ $event_id ] : 0;
		$per = $per ? max( 1, min( 10, $per ) ) : 0;
		if ( $per !== $had ) {
			if ( ! is_array( $s['event_per'] ) ) {
				$s['event_per'] = array();
			}
			if ( $per ) {
				$s['event_per'][ $event_id ] = $per;
			} else {
				unset( $s['event_per'][ $event_id ] );
			}
			update_option( 'tcc_pco_settings', $s, false );
		}

		tcc_pco_meta_box_save_rooms( $post_id, $event_id );

		$busy = true;

		// The other upcoming dates of the same event get the same choices (never the date and time).
		if ( ! empty( $_POST['tcc_pco_all_dates'] ) ) {
			foreach ( tcc_pco_posts_for( $event_id ) as $other ) {
				if ( (int) $other->ID === (int) $post_id || tcc_pco_post_passed( $other->ID ) || get_post_meta( $other->ID, '_tcc_pco_paused', true ) ) {
					continue;
				}
				$theirs = tcc_pco_post_opts( $other->ID );
				$new    = $o;
				unset( $new['lock']['dates'] );
				if ( ! empty( $theirs['lock']['dates'] ) ) {
					$new['lock']['dates'] = 1;
				}
				$handed_back = array_keys( array_diff_key( $theirs['lock'], $new['lock'] ) );
				tcc_pco_save_opts( $other->ID, $new );
				if ( $handed_back ) {
					update_post_meta( $other->ID, '_tcc_pco_force', $handed_back );
				}
				tcc_pco_inherit_apply( $other->ID, array( 'from' => (int) $post_id, 'opts' => $new ) );
				foreach ( array( '_tcc_register_url' => $url, '_tcc_register_label' => $label ) as $meta_key => $value ) {
					if ( '' === $value ) {
						delete_post_meta( $other->ID, $meta_key );
					}
				}
				if ( ! empty( $new['lock']['title'] ) ) {
					$title = (string) get_post_field( 'post_title', $post_id, 'raw' );
					if ( $title !== (string) get_post_field( 'post_title', $other->ID, 'raw' ) ) {
						wp_update_post( array( 'ID' => $other->ID, 'post_title' => wp_slash( $title ) ) );
					}
				}
			}
		}

		// Bring the event in line with the new choices straight away (this uses what was last read from
		// Planning Center; it does not contact Planning Center).
		$items = tcc_pco_items();
		if ( isset( $items[ $event_id ]['status'] ) && 'approved' === $items[ $event_id ]['status'] && empty( $items[ $event_id ]['gone'] ) && ! empty( $items[ $event_id ]['data'] ) ) {
			tcc_pco_apply_event( $items[ $event_id ]['data'] );
		}
		$busy = false;
	}
	add_action( 'save_post_tribe_events', 'tcc_pco_meta_box_save', 20 );

}
