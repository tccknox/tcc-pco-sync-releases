<?php
/**
 * TCC Website, Planning Center events: what each button on the Planning Center screen does.
 * Part: what each button on the screens does
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php,
 * only inside the admin (is_admin(), which includes admin-post.php where every button goes).
 * Until 0.14.4 the four screen files (admin.php, admin-tabs.php, admin-buttons.php, admin-event-box.php) were one
 * file. They were cut into four, with the code unchanged, so that an AI asked to return a whole file has less to return.
 *
 * In this file: tcc_pco_handle(), which every button on the Planning Center screen posts to. It checks that the
 * person may manage the website and checks the form's security code (nonce) before doing anything, does the one
 * job asked for (check now, approve, hide, stop syncing, save tags, rooms or settings, ...), keeps a plain message
 * for a minute and goes back to the screen. And tcc_pco_resolve(), the two buttons on the Conflicts tab.
 * Planning Center itself is never changed by any of them: it is only ever read.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Wrapped so that nothing is set up twice: if a saved edit of this file (TCC Website > Features) fails part-way,
// the original is loaded after it, and this test makes the original step aside. Keep the name it tests.
if ( ! function_exists( 'tcc_pco_handle' ) ) {

	/* ---------------------------------------------------------------------------
	 * Handling the buttons
	 * ------------------------------------------------------------------------- */

	function tcc_pco_handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'tcc_pco_do', '_tcc_pco_nonce' );
		$op    = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$id    = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		$items = tcc_pco_items();
		$tab   = 'waiting';
		$msg   = '';
		$name  = isset( $items[ $id ]['data']['name'] ) ? $items[ $id ]['data']['name'] : 'the event';

		if ( 'check_now' === $op || 'check_remove' === $op ) {
			// check_remove: the button shown when a check held back removals (see tcc_pco_removal_check).
			$tab    = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'waiting';
			$result = tcc_pco_run( 'check_remove' === $op );
			$after  = get_option( 'tcc_pco_last_run', array() );
			$msg    = is_wp_error( $result ) ? $result->get_error_message() : 'Checked Planning Center. ' . (int) $result . ' new event(s) waiting.';
			if ( ! is_wp_error( $result ) && empty( $after['ok'] ) ) {
				$msg .= ' But it needs a look: see the red message below.';
			}
		} elseif ( 'approve' === $op && isset( $items[ $id ] ) ) {
			$items[ $id ]['status'] = 'approved';
			tcc_pco_save_items( $items );
			foreach ( tcc_pco_posts_for( $id ) as $post ) {
				delete_post_meta( $post->ID, '_tcc_pco_paused' );
			}
			tcc_pco_log( 'Approved "' . $name . '" for the website.' );
			// Hand-made events ticked for replacing: only ones that really match this event are accepted.
			$replace  = isset( $_POST['replace'] ) && is_array( $_POST['replace'] ) ? array_map( 'absint', wp_unslash( $_POST['replace'] ) ) : array();
			$matches  = $replace ? tcc_pco_handmade_matches( $items[ $id ]['data'] ) : array();
			$replaced = 0;
			foreach ( $replace as $old_id ) {
				if ( ! isset( $matches[ $old_id ] ) || ! current_user_can( 'delete_post', $old_id ) ) {
					continue;
				}
				if ( ! isset( $GLOBALS['tcc_pco_carry'][ (string) $id ] ) ) {
					$carry = tcc_pco_carry_from( $old_id );
					// If the hand-made page says the same as the Planning Center description, do not print it twice.
					foreach ( array( 'description', 'summary' ) as $which ) {
						if ( isset( $items[ $id ]['data'][ $which ] ) && tcc_pco_same_text( $carry['content'], $items[ $id ]['data'][ $which ] ) ) {
							$carry['content'] = '';
						}
					}
					$GLOBALS['tcc_pco_carry'][ (string) $id ] = $carry;
				}
				if ( wp_trash_post( $old_id ) ) {
					$replaced++;
					tcc_pco_log( 'Moved the hand-made event "' . $matches[ $old_id ]['title'] . '" to the Trash: "' . $name . '" from Planning Center replaces it.', $old_id );
				}
			}
			if ( empty( $items[ $id ]['gone'] ) ) {
				// Waiting events are not asked for their rooms (to spare Planning Center), so ask now.
				tcc_pco_apply_event( tcc_pco_fill_rooms( $id ) );
			}
			$tab = 'synced';
			$msg = '"' . $name . '" is now on the website and will be kept up to date.' . ( $replaced ? ' ' . $replaced . ' hand-made event(s) moved to the Trash.' : '' );
		} elseif ( in_array( $op, array( 'ignore', 'restore' ), true ) && isset( $items[ $id ] ) ) {
			$items[ $id ]['status'] = 'ignore' === $op ? 'ignored' : 'new';
			tcc_pco_save_items( $items );
			$msg = 'ignore' === $op ? '"' . $name . '" is hidden.' : '"' . $name . '" is waiting for approval again.';
		} elseif ( in_array( $op, array( 'unsync_keep', 'unsync_remove' ), true ) && isset( $items[ $id ] ) ) {
			$items[ $id ]['status'] = 'unsynced';
			tcc_pco_save_items( $items );
			$tab = 'synced';
			if ( 'unsync_remove' === $op ) {
				$n   = tcc_pco_trash_future_posts( $id, array() );
				$msg = 'Stopped syncing "' . $name . '" and moved ' . $n . ' upcoming date(s) to the Trash.';
			} else {
				foreach ( tcc_pco_posts_for( $id ) as $post ) {
					update_post_meta( $post->ID, '_tcc_pco_paused', 1 );
				}
				$msg = 'Stopped syncing "' . $name . '". The website events stay as they are.';
			}
			tcc_pco_log( $msg );
		} elseif ( 'resolve' === $op ) {
			$key       = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
			$choice    = isset( $_POST['choice'] ) ? sanitize_key( wp_unslash( $_POST['choice'] ) ) : '';
			$conflicts = tcc_pco_conflicts();
			$tab       = 'conflicts';
			if ( isset( $conflicts[ $key ] ) ) {
				$msg = tcc_pco_resolve( $conflicts[ $key ], $choice );
			}
		} elseif ( 'save_settings' === $op ) {
			$s              = tcc_pco_settings();
			$old_graphics   = array( (int) $s['fallback_image'], array_filter( array_map( 'intval', (array) $s['cat_images'] ) ) );
			$s['app_id']    = isset( $_POST['app_id'] ) ? sanitize_text_field( wp_unslash( $_POST['app_id'] ) ) : '';
			$secret         = isset( $_POST['secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['secret'] ) ) ) : '';
			$s['secret']    = '' !== $secret ? $secret : $s['secret'];
			$s['per_event'] = isset( $_POST['per_event'] ) ? max( 1, min( 10, (int) $_POST['per_event'] ) ) : 2;
			unset( $s['github_token'] ); // Left over from 0.3.0; no key is used any more.
			if ( ! empty( $_POST['show_form'] ) ) {
				$show      = isset( $_POST['show'] ) && is_array( $_POST['show'] ) ? wp_unslash( $_POST['show'] ) : array();
				$s['show'] = array();
				foreach ( array_keys( tcc_pco_show_keys() ) as $key ) {
					$s['show'][ $key ] = ! empty( $show[ $key ] ) ? 1 : 0;
				}
				$s['desc_source']    = isset( $_POST['desc_source'] ) && 'summary' === $_POST['desc_source'] ? 'summary' : 'description';
				$s['fallback_image'] = isset( $_POST['fallback_image'] ) ? absint( $_POST['fallback_image'] ) : 0;
				$s['cat_images']     = array();
				foreach ( isset( $_POST['cat_images'] ) && is_array( $_POST['cat_images'] ) ? wp_unslash( $_POST['cat_images'] ) : array() as $term_id => $att ) {
					if ( absint( $att ) ) {
						$s['cat_images'][ absint( $term_id ) ] = absint( $att );
					}
				}
			}
			update_option( 'tcc_pco_settings', $s, false );
			if ( array( (int) $s['fallback_image'], array_filter( array_map( 'intval', (array) $s['cat_images'] ) ) ) != $old_graphics ) { // phpcs:ignore Universal.Operators.StrictComparisons -- comparing two small arrays by value.
				tcc_pco_refresh_cards();
			}
			$tab = 'settings';
			$msg = 'Settings saved.';
		} elseif ( 'save_tags' === $op ) {
			$s    = tcc_pco_settings();
			$ids  = isset( $_POST['tag_ids'] ) && is_array( $_POST['tag_ids'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tag_ids'] ) ) : array();
			$post = isset( $_POST['tag_map'] ) && is_array( $_POST['tag_map'] ) ? wp_unslash( $_POST['tag_map'] ) : array();
			$map  = (array) $s['tag_map'];
			foreach ( $ids as $tid ) {
				$term = isset( $post[ $tid ] ) ? (int) $post[ $tid ] : 0;
				if ( $term > 0 ) {
					$map[ $tid ] = $term;
				} else {
					unset( $map[ $tid ] );
				}
			}
			$s['tag_map']   = $map;
			$auto_post      = isset( $_POST['tag_auto'] ) && is_array( $_POST['tag_auto'] ) ? array_map( 'strval', array_keys( wp_unslash( $_POST['tag_auto'] ) ) ) : array();
			$auto           = array_diff( array_map( 'strval', (array) $s['auto_tags'] ), $ids ); // Keep tags that were not on the form.
			$s['auto_tags'] = array_values( array_unique( array_merge( $auto, array_intersect( $ids, $auto_post ) ) ) );
			$s['tags_seen'] = array_values( array_unique( array_merge( array_map( 'strval', (array) $s['tags_seen'] ), $ids ) ) );
			update_option( 'tcc_pco_settings', $s, false );
			// Bring the events that are already on the website in line straight away.
			$n = 0;
			foreach ( $items as $eid => $item ) {
				if ( isset( $item['status'] ) && 'approved' === $item['status'] && empty( $item['gone'] ) && ! empty( $item['data'] ) ) {
					foreach ( tcc_pco_posts_for( $eid ) as $post_obj ) {
						if ( ! get_post_meta( $post_obj->ID, '_tcc_pco_paused', true ) && ! tcc_pco_post_passed( $post_obj->ID ) ) {
							tcc_pco_sync_terms( $post_obj->ID, $item['data'], $s );
							$n++;
						}
					}
				}
			}
			$tab = 'tags';
			$msg = 'Tags saved. ' . count( $map ) . ' public, the rest internal. ' . $n . ' website event(s) checked.' . ( $s['auto_tags'] ? ' ' . count( $s['auto_tags'] ) . ' tag(s) approve events automatically, from the next check.' : '' );
			tcc_pco_log( 'Tags saved: ' . count( $map ) . ' public tag(s).' );
		} elseif ( 'save_cats' === $op ) {
			$tab     = 'tags';
			$renamed = 0;
			$added   = '';
			$errors  = array();
			if ( taxonomy_exists( 'tribe_events_cat' ) ) {
				$names = isset( $_POST['cat_name'] ) && is_array( $_POST['cat_name'] ) ? wp_unslash( $_POST['cat_name'] ) : array();
				// Names already in use (lower case => category id), so two categories never end up with the same name.
				$taken = array();
				$all   = get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) );
				foreach ( is_wp_error( $all ) ? array() : (array) $all as $t ) {
					$taken[ strtolower( html_entity_decode( $t->name, ENT_QUOTES ) ) ] = (int) $t->term_id;
				}
				foreach ( $names as $term_id => $name ) {
					$name = trim( sanitize_text_field( (string) $name ) );
					$term = get_term( (int) $term_id, 'tribe_events_cat' );
					if ( '' === $name || ! $term || is_wp_error( $term ) || html_entity_decode( $term->name, ENT_QUOTES ) === $name ) {
						continue;
					}
					if ( isset( $taken[ strtolower( $name ) ] ) && $taken[ strtolower( $name ) ] !== (int) $term_id ) {
						$errors[] = '"' . $name . '" is already the name of another category';
						continue;
					}
					unset( $taken[ strtolower( html_entity_decode( $term->name, ENT_QUOTES ) ) ] );
					$taken[ strtolower( $name ) ] = (int) $term_id;
					// Only the name changes. The slug stays, so page lists and links keep working.
					$done = wp_update_term( (int) $term_id, 'tribe_events_cat', array( 'name' => $name, 'slug' => $term->slug ) );
					if ( is_wp_error( $done ) ) {
						$errors[] = '"' . $name . '": ' . $done->get_error_message();
					} else {
						$renamed++;
						tcc_pco_log( 'Renamed website category "' . html_entity_decode( $term->name, ENT_QUOTES ) . '" to "' . $name . '".' );
					}
				}
				$new = isset( $_POST['cat_new'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['cat_new'] ) ) ) : '';
				if ( '' !== $new && isset( $taken[ strtolower( $new ) ] ) ) {
					$errors[] = '"' . $new . '" already exists';
				} elseif ( '' !== $new ) {
					$done = wp_insert_term( $new, 'tribe_events_cat' );
					if ( is_wp_error( $done ) ) {
						$errors[] = '"' . $new . '": ' . $done->get_error_message();
					} else {
						$added = $new;
						tcc_pco_log( 'Added website category "' . $new . '".' );
					}
				}
			}
			$msg = 'Website categories saved: ' . $renamed . ' renamed' . ( '' !== $added ? ', "' . $added . '" added' : '' ) . '.' . ( $errors ? ' Not done: ' . implode( '; ', $errors ) : '' );
		} elseif ( 'save_event_rooms' === $op && isset( $items[ $id ] ) ) {
			$s   = tcc_pco_settings();
			$tab = 'synced';
			if ( ! empty( $_POST['reset'] ) ) {
				unset( $s['event_rooms'][ $id ] );
				$msg = '"' . $name . '" follows the Rooms tab again.';
			} else {
				$all    = isset( $_POST['all_rooms'] ) && is_array( $_POST['all_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['all_rooms'] ) ) : array();
				$show   = isset( $_POST['show_rooms'] ) && is_array( $_POST['show_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['show_rooms'] ) ) : array();
				$choice = isset( $s['event_rooms'][ $id ] ) && is_array( $s['event_rooms'][ $id ] ) ? $s['event_rooms'][ $id ] : array();
				foreach ( $all as $rid ) {
					$choice[ $rid ] = in_array( $rid, $show, true ) ? 1 : 0;
				}
				if ( ! is_array( $s['event_rooms'] ) ) {
					$s['event_rooms'] = array();
				}
				$s['event_rooms'][ $id ] = $choice;
				$msg                     = 'Rooms saved for "' . $name . '": ' . count( $show ) . ' showing.';
			}
			update_option( 'tcc_pco_settings', $s, false );
			tcc_pco_log( $msg );
		} elseif ( 'save_rooms' === $op ) {
			$s      = tcc_pco_settings();
			$names  = isset( $_POST['room_names'] ) && is_array( $_POST['room_names'] ) ? wp_unslash( $_POST['room_names'] ) : array();
			$show   = isset( $_POST['room_show'] ) && is_array( $_POST['room_show'] ) ? wp_unslash( $_POST['room_show'] ) : array();
			$labels = isset( $_POST['room_label'] ) && is_array( $_POST['room_label'] ) ? wp_unslash( $_POST['room_label'] ) : array();
			$rooms  = (array) $s['rooms'];
			$shown  = 0;
			foreach ( $names as $rid => $name ) {
				$rid           = sanitize_text_field( (string) $rid );
				$rooms[ $rid ] = array(
					'name'  => sanitize_text_field( (string) $name ),
					'show'  => ! empty( $show[ $rid ] ),
					'label' => isset( $labels[ $rid ] ) ? sanitize_text_field( (string) $labels[ $rid ] ) : '',
				);
			}
			foreach ( $rooms as $row ) {
				$shown += ! empty( $row['show'] ) ? 1 : 0;
			}
			$s['rooms'] = $rooms;
			update_option( 'tcc_pco_settings', $s, false );
			$tab = 'rooms';
			$msg = 'Rooms saved. ' . $shown . ' room(s) can show on the website.';
		}
		if ( $msg ) {
			set_transient( 'tcc_pco_notice_' . get_current_user_id(), $msg, MINUTE_IN_SECONDS );
		}
		wp_safe_redirect( tcc_pco_url( $tab, $msg ? array( 'tcc_msg' => '1' ) : array() ) );
		exit;
	}
	add_action( 'admin_post_tcc_pco_do', 'tcc_pco_handle' );

	function tcc_pco_resolve( $c, $choice ) {
		$post_id = (int) $c['post_id'];
		$field   = (string) $c['field'];
		$synced  = get_post_meta( $post_id, '_tcc_pco_synced', true );
		$synced  = is_array( $synced ) ? $synced : array();
		$title   = get_post( $post_id ) ? get_the_title( $post_id ) : 'the event';
		if ( 'pco' === $choice && get_post( $post_id ) && function_exists( 'tribe_update_event' ) ) {
			if ( 'image' === $field ) {
				$att = tcc_pco_image_attachment( (string) $c['pco'], $title );
				if ( $att ) {
					set_post_thumbnail( $post_id, $att );
					$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
					$synced['image_att'] = $att;
				}
			} elseif ( 'title' === $field ) {
				tribe_update_event( $post_id, array( 'post_title' => wp_slash( wp_strip_all_tags( (string) $c['pco'] ) ) ) );
				$synced['title'] = (string) $c['pco'];
			} else {
				$start = 'start' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventStartDate', true );
				$end   = 'end' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventEndDate', true );
				tribe_update_event( $post_id, tcc_pco_date_args( $start, $end, 'yes' === get_post_meta( $post_id, '_EventAllDay', true ) ) );
				$synced[ $field ] = (string) $c['pco'];
			}
			$msg = 'Used the Planning Center ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
		} else {
			// Keep the website's version and remember what Planning Center has, so it is not asked again until Planning Center changes it again.
			if ( 'image' === $field ) {
				$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
				$synced['image_att'] = (int) get_post_thumbnail_id( $post_id );
			} else {
				$synced[ $field ] = (string) $c['pco'];
			}
			$msg = 'Kept the website ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
		}
		update_post_meta( $post_id, '_tcc_pco_synced', $synced );
		tcc_pco_clear_conflict( $post_id, $field );
		tcc_pco_log( $msg, $post_id );
		return $msg;
	}

}
