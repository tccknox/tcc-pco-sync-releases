<?php
/**
 * TCC Website, Planning Center events: the admin screens.
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** How many things wait for a person: new events and conflicts. Shown beside TCC Website in the menu. */
function tcc_pco_waiting_count() {
	$count = 0;
	foreach ( tcc_pco_items() as $item ) {
		if ( isset( $item['status'] ) && 'new' === $item['status'] && empty( $item['gone'] ) ) {
			$count++;
		}
	}
	return $count + count( tcc_pco_conflicts() );
}

/** TCC Website > Planning Center. Its page address stays page=tcc-pco-sync, so every link inside it keeps working. */
function tcc_pco_admin_menu() {
	$count = tcc_pco_waiting_count();
	$badge = $count ? ' <span class="awaiting-mod">' . (int) $count . '</span>' : '';
	add_submenu_page( 'tcc-site-features', 'TCC Website: Planning Center', 'Planning Center' . $badge, 'manage_options', 'tcc-pco-sync', 'tcc_pco_admin_page', 0 );
}
add_action( 'admin_menu', 'tcc_pco_admin_menu', 10 );

function tcc_pco_url( $tab = 'waiting', $extra = array() ) {
	return add_query_arg( array_merge( array( 'page' => 'tcc-pco-sync', 'tab' => $tab ), $extra ), admin_url( 'admin.php' ) );
}

/** The Planning Center part of TCC Website > Help. */
function tcc_pco_help_url() {
	return add_query_arg( array( 'page' => 'tcc-site-features', 'tab' => 'help' ), admin_url( 'admin.php' ) ) . '#tcc-help-pc';
}

/** A small button that posts one action. */
function tcc_pco_button( $op, $label, $fields = array(), $class = 'button', $confirm = '' ) {
	$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 6px 4px 0"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
	$html .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
	$html .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
	foreach ( $fields as $k => $v ) {
		$html .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
	}
	$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	return $html;
}

function tcc_pco_when( $ev ) {
	$out = array();
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		$dt = tcc_pco_local( $inst['starts'] );
		if ( $dt ) {
			$out[] = esc_html( $dt->format( ! empty( $inst['all_day'] ) ? 'D, M j, Y' : 'D, M j, Y \a\t g:i a' ) );
		}
	}
	return $out ? implode( '<br>', $out ) : '<em>No upcoming dates</em>';
}

/** Room names booked for any upcoming date of an event. */
function tcc_pco_event_rooms( $ev ) {
	$rooms = array();
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		if ( isset( $inst['rooms'] ) && is_array( $inst['rooms'] ) ) {
			foreach ( $inst['rooms'] as $rid => $name ) {
				$rooms[ (string) $rid ] = trim( (string) $name );
			}
		}
	}
	asort( $rooms );
	return $rooms;
}

/**
 * On the website tab: the rooms booked for one event, each with a tick for "show on this event's pages".
 * Ticks start from the Rooms tab. Once saved here, this event keeps its own choices.
 */
function tcc_pco_event_rooms_form( $event_id, $rooms ) {
	if ( ! $rooms ) {
		return '<br><span style="color:#8c8f94">Rooms: none booked in Planning Center.</span>';
	}
	$s      = tcc_pco_settings();
	$custom = ! empty( $s['event_rooms'][ $event_id ] );
	$html   = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:10px 0 4px;padding:10px 12px;background:#f6f7f7;border-radius:8px">';
	$html  .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_event_rooms"><input type="hidden" name="id" value="' . esc_attr( $event_id ) . '">';
	$html  .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
	$html  .= '<strong>Rooms shown on this event\'s page</strong> <span style="color:#50575e">(' . ( $custom ? 'chosen for this event' : 'following the Rooms tab' ) . ')</span><br>';
	foreach ( $rooms as $rid => $name ) {
		$label = tcc_pco_room_label( $s, (string) $rid, $name );
		$html .= '<input type="hidden" name="all_rooms[]" value="' . esc_attr( $rid ) . '">';
		$html .= '<label style="display:inline-block;margin:4px 14px 2px 0;white-space:nowrap"><input type="checkbox" name="show_rooms[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, (string) $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
	}
	$html .= '<br><button type="submit" class="button button-small" style="margin-top:6px">Save rooms for this event</button>';
	if ( $custom ) {
		$html .= ' <button type="submit" name="reset" value="1" class="button button-small button-link" style="margin:6px 0 0 8px">Go back to the Rooms tab settings</button>';
	}
	return $html . '</form>';
}

/** The tags of an event: public ones with their website category, internal ones greyed. */
function tcc_pco_tags_html( $ev ) {
	if ( empty( $ev['tags'] ) ) {
		return '';
	}
	$s      = tcc_pco_settings();
	$public = array();
	$inside = array();
	foreach ( (array) $ev['tags'] as $tid => $name ) {
		$term = ! empty( $s['tag_map'][ $tid ] ) ? get_term( (int) $s['tag_map'][ $tid ], 'tribe_events_cat' ) : null;
		if ( $term && ! is_wp_error( $term ) ) {
			$public[] = '<span style="background:#e5f5fa;border:1px solid #00a4cf;border-radius:3px;padding:1px 6px;margin-right:4px;white-space:nowrap">' . esc_html( trim( $name ) ) . ' &rarr; ' . esc_html( $term->name ) . '</span>';
		} else {
			$inside[] = esc_html( trim( $name ) );
		}
	}
	$html = '<br><span style="line-height:2">On the website as: ' . ( $public ? implode( '', $public ) : '<em>no category</em>' ) . '</span>';
	if ( $inside ) {
		$html .= '<br><span style="color:#8c8f94">Internal tags (not shown): ' . implode( ', ', $inside ) . '</span>';
	}
	return $html;
}

/** A first guess at the website category for a Planning Center tag. Only a suggestion until someone saves the Tags tab. */
function tcc_pco_suggest_term( $name, $group, $cats ) {
	if ( ! in_array( $group, array( 'Ministry', 'Event Type' ), true ) ) {
		return 0;
	}
	$guesses = array(
		'women'           => "Women's Event",
		'abide'           => "Women's Event",
		"men's"           => "Men's Events",
		'forge'           => 'The Forge',
		'kids'            => 'TCC Kids',
		'core class'      => 'Core Classes',
		'missions'        => 'Missions',
		'next steps'      => 'Next Steps',
		'community group' => 'Community Groups',
		'connect group'   => 'Community Groups',
	);
	$name    = strtolower( (string) $name );
	foreach ( $guesses as $needle => $cat_name ) {
		if ( false === strpos( $name, $needle ) ) {
			continue;
		}
		foreach ( (array) $cats as $cat ) {
			if ( is_object( $cat ) && 0 === strcasecmp( html_entity_decode( $cat->name, ENT_QUOTES ), $cat_name ) ) {
				return (int) $cat->term_id;
			}
		}
		return 0;
	}
	return 0;
}

/** The bar with the Save button that stays at the bottom of the window while you scroll a long form. */
function tcc_pco_savebar( $label, $note = '' ) {
	return '<div class="tcc-savebar"><button type="submit" class="button button-primary">' . esc_html( $label ) . '</button>' . ( '' !== $note ? '<span class="tcc-muted">' . esc_html( $note ) . '</span>' : '' ) . '</div>';
}

function tcc_pco_tags_form( $s, $items ) {
	$tags = tcc_pco_known_tags();
	if ( ! $tags ) {
		echo '<div class="tcc-empty">Your Planning Center tags will be listed here after the next check. Press "Check Planning Center now" at the top to fetch them.</div>';
		return;
	}
	$cats   = taxonomy_exists( 'tribe_events_cat' ) ? get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) ) : array();
	$cats   = is_wp_error( $cats ) ? array() : $cats;
	$seen   = array_map( 'strval', (array) $s['tags_seen'] );
	$auto   = array_map( 'strval', (array) $s['auto_tags'] );
	$groups = array();
	foreach ( $tags as $tid => $tag ) {
		$groups[ '' !== $tag['group'] ? $tag['group'] : 'No group' ][ (string) $tid ] = $tag['name'];
	}
	$order  = array( 'Ministry', 'Event Type', 'Department', 'Event Location', 'No group' );
	$sorted = array();
	foreach ( $order as $g ) {
		if ( isset( $groups[ $g ] ) ) {
			$sorted[ $g ] = $groups[ $g ];
			unset( $groups[ $g ] );
		}
	}
	$sorted = array_merge( $sorted, $groups );

	// Counts for the summary at the top.
	$public = 0;
	$fresh  = 0;
	foreach ( $tags as $tid => $tag ) {
		$public += ! empty( $s['tag_map'][ $tid ] ) ? 1 : 0;
		$fresh  += in_array( (string) $tid, $seen, true ) ? 0 : 1;
	}

	echo '<div class="tcc-card"><h2>Which tags show on the website</h2>';
	echo '<p>These are your Planning Center tags. For each one, choose what it means on the website:</p>';
	echo '<div class="tcc-two"><div><span class="tcc-pill tcc-pill--teal">Public</span><p class="tcc-muted" style="margin:4px 0 0">Pick a website category. Events with this tag get that category, so they show in that ministry\'s lists.</p></div>';
	echo '<div><span class="tcc-pill tcc-pill--muted">Internal</span><p class="tcc-muted" style="margin:4px 0 0">Never shown on the website. Use this for things like HVAC, staffing and equipment. New tags start here.</p></div>';
	echo '<div><span class="tcc-pill tcc-pill--ok">Approve automatically</span><p class="tcc-muted" style="margin:4px 0 0">Optional. Events with this tag go on the website at the next check, without waiting for you.</p></div></div>';
	echo '<p class="tcc-stats" style="margin-top:14px"><span class="tcc-pill tcc-pill--teal">' . (int) $public . ' public</span> <span class="tcc-pill tcc-pill--muted">' . (int) ( count( $tags ) - $public ) . ' internal</span>' . ( $fresh ? ' <span class="tcc-pill tcc-pill--warn">' . (int) $fresh . ' new</span>' : '' ) . ( $auto ? ' <span class="tcc-pill tcc-pill--ok">' . count( $auto ) . ' approve automatically</span>' : '' ) . '</p></div>';

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_tags">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	$suggested = 0;
	$grid      = 'grid-template-columns:minmax(0,1fr) minmax(200px,320px) 190px';
	foreach ( $sorted as $group => $list ) {
		asort( $list );
		echo '<div class="tcc-card"><h2>' . esc_html( $group ) . ' <span class="tcc-muted" style="font-weight:400;font-size:13px">' . count( $list ) . ' tag' . ( 1 === count( $list ) ? '' : 's' ) . '</span></h2>';
		echo '<div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Planning Center tag</span><span>On the website</span><span>Approval</span></div>';
		foreach ( $list as $tid => $name ) {
			$is_new = ! in_array( (string) $tid, $seen, true );
			$chosen = ! empty( $s['tag_map'][ $tid ] ) ? (int) $s['tag_map'][ $tid ] : 0;
			$guess  = 0;
			if ( $is_new && ! $chosen ) {
				$guess = tcc_pco_suggest_term( $name, $group, $cats );
				if ( $guess ) {
					$chosen = $guess;
					$suggested++;
				}
			}
			echo '<div class="tcc-row' . ( $chosen ? ' tcc-row--on' : '' ) . '" style="' . esc_attr( $grid ) . '"><span class="tcc-row__name">' . esc_html( trim( $name ) ) . ( $is_new ? ' <span class="tcc-pill tcc-pill--warn">new</span>' : '' ) . ( $guess ? ' <span class="tcc-pill tcc-pill--warn">suggested, not saved yet</span>' : '' ) . '</span>';
			echo '<span><input type="hidden" name="tag_ids[]" value="' . esc_attr( $tid ) . '"><select name="tag_map[' . esc_attr( $tid ) . ']" aria-label="' . esc_attr( 'Website category for ' . trim( $name ) ) . '"><option value="0">Internal (not on the website)</option>';
			foreach ( (array) $cats as $cat ) {
				if ( is_object( $cat ) ) {
					echo '<option value="' . (int) $cat->term_id . '"' . selected( $chosen, (int) $cat->term_id, false ) . '>Public: ' . esc_html( $cat->name ) . '</option>';
				}
			}
			echo '</select></span>';
			echo '<span><label><input type="checkbox" name="tag_auto[' . esc_attr( $tid ) . ']" value="1"' . checked( in_array( (string) $tid, $auto, true ), true, false ) . '> Approve automatically</label></span></div>';
		}
		echo '</div>';
	}
	echo tcc_pco_savebar( 'Save tags', $suggested ? $suggested . ' suggestion(s) are filled in but not saved. Check them, then save.' : 'Events already on the website are brought in line as soon as you save.' );
	echo '</form>';
	tcc_pco_cats_form( $cats );
}

/** Rename website event categories or add one, without leaving the plugin. */
function tcc_pco_cats_form( $cats ) {
	echo '<div class="tcc-card"><h2>Website categories</h2>';
	echo '<p>These are the categories you can pick above. Change a name to rename it everywhere on the website, or add a new one at the bottom. Renaming is safe: every event and page list that uses the category keeps working.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_cats">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	$grid = 'grid-template-columns:minmax(0,1fr) 130px';
	echo '<div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Category name</span><span>Events using it</span></div>';
	foreach ( (array) $cats as $cat ) {
		if ( ! is_object( $cat ) ) {
			continue;
		}
		$name = html_entity_decode( $cat->name, ENT_QUOTES );
		echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span><input type="text" name="cat_name[' . (int) $cat->term_id . ']" value="' . esc_attr( $name ) . '" maxlength="80" aria-label="' . esc_attr( 'Name of the category ' . $name ) . '"></span><span class="tcc-muted">' . (int) $cat->count . '</span></div>';
	}
	echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span><input type="text" name="cat_new" value="" maxlength="80" placeholder="Add a new category: type its name here" aria-label="New category name"></span><span class="tcc-pill tcc-pill--muted" style="justify-self:start">new</span></div>';
	echo '<p style="margin:14px 0 0"><button type="submit" class="button">Save website categories</button></p>';
	echo '</form>';
	echo '<p class="tcc-muted" style="margin-bottom:0">A new category is only a label until a page is set up to list it. To delete a category, use Events &rarr; Event Categories; it is left out here on purpose, because deleting one can empty a ministry page list.</p></div>';
}

function tcc_pco_rooms_form( $s, $items ) {
	$rooms = array();
	$used  = array();
	foreach ( (array) $s['rooms'] as $rid => $row ) {
		if ( ! empty( $row['name'] ) ) {
			$rooms[ (string) $rid ] = (string) $row['name'];
		}
	}
	foreach ( tcc_pco_all_rooms() as $rid => $name ) {
		$rooms[ (string) $rid ] = (string) $name;
	}
	foreach ( $items as $item ) {
		if ( empty( $item['data'] ) || ! empty( $item['gone'] ) ) {
			continue;
		}
		foreach ( tcc_pco_event_rooms( $item['data'] ) as $rid => $name ) {
			$rooms[ $rid ]  = $name;
			$used[ $rid ][] = (string) $item['data']['name'];
		}
	}
	asort( $rooms );
	if ( ! $rooms ) {
		echo '<div class="tcc-empty">Your Planning Center rooms will be listed here after the next check. Press "Check Planning Center now" at the top to fetch them.</div>';
		return;
	}
	$shown = 0;
	foreach ( $rooms as $rid => $name ) {
		$shown += ! empty( $s['rooms'][ $rid ]['show'] ) ? 1 : 0;
	}

	echo '<div class="tcc-card"><h2>Which rooms visitors can see</h2>';
	echo '<p>Every room the church has in Planning Center. Tick a room to let it show on event pages, as a small label with a pin. Give it a public name if the Planning Center name is not how you would say it to a visitor.</p>';
	echo '<p class="tcc-muted">This is the starting point for every event. To show or hide a room for one event only, use that event\'s own screen. Equipment is never listed.</p>';
	echo '<p class="tcc-stats"><span class="tcc-pill tcc-pill--teal">' . (int) $shown . ' can show</span> <span class="tcc-pill tcc-pill--muted">' . (int) ( count( $rooms ) - $shown ) . ' hidden</span></p></div>';

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_rooms">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	$grid = 'grid-template-columns:90px minmax(0,1fr) minmax(180px,300px) minmax(0,1fr)';
	echo '<div class="tcc-card"><div class="tcc-row tcc-row--head" style="' . esc_attr( $grid ) . '"><span>Show</span><span>Room in Planning Center</span><span>Public name (optional)</span><span>Booked for</span></div>';
	foreach ( $rooms as $rid => $name ) {
		$row = isset( $s['rooms'][ $rid ] ) ? (array) $s['rooms'][ $rid ] : array();
		$on  = ! empty( $row['show'] );
		echo '<div class="tcc-row' . ( $on ? ' tcc-row--on' : '' ) . '" style="' . esc_attr( $grid ) . '">';
		echo '<span><input type="hidden" name="room_names[' . esc_attr( $rid ) . ']" value="' . esc_attr( $name ) . '"><label><input type="checkbox" name="room_show[' . esc_attr( $rid ) . ']" value="1"' . checked( $on, true, false ) . '> Show</label></span>';
		echo '<span class="tcc-row__name">' . esc_html( $name ) . '</span>';
		echo '<span><input type="text" name="room_label[' . esc_attr( $rid ) . ']" value="' . esc_attr( isset( $row['label'] ) ? (string) $row['label'] : '' ) . '" placeholder="' . esc_attr( $name ) . '" aria-label="' . esc_attr( 'Public name for ' . $name ) . '"></span>';
		echo '<span class="tcc-muted">';
		foreach ( isset( $used[ $rid ] ) ? array_unique( $used[ $rid ] ) : array() as $event_name ) {
			echo '<span class="tcc-pill tcc-pill--muted" style="margin:1px 2px 1px 0">' . esc_html( $event_name ) . '</span>';
		}
		echo '</span></div>';
	}
	echo '</div>';
	echo tcc_pco_savebar( 'Save rooms', 'Event pages change as soon as you save.' );
	echo '</form>';
}

/**
 * The look of the plugin's screens: white rounded panels, small status labels, one event per panel.
 * Printed once, on the plugin's own screen and in the box on the event edit screen.
 */
function tcc_pco_admin_css() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	echo '<style>'
		. '.tcc-pco{max-width:1280px}'
		. '.tcc-top{display:flex;flex-wrap:wrap;align-items:center;gap:12px 16px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 18px;margin:14px 0 18px}'
		. '.tcc-top__text{flex:1 1 320px;margin:0;color:#50575e}'
		. '.tcc-top form{margin:0!important}'
		. '.tcc-pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;line-height:1.7;white-space:nowrap;vertical-align:middle}'
		. '.tcc-pill--ok{background:#e6f6ea;color:#0a6b25}.tcc-pill--warn{background:#fcf3d7;color:#7a5200}.tcc-pill--bad{background:#fbe9e9;color:#8a1f1f}.tcc-pill--muted{background:#f0f0f1;color:#50575e}.tcc-pill--teal{background:#e5f5fa;color:#046c8a}'
		. '.tcc-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px 18px;margin:0 0 14px}'
		. '.tcc-card>h2:first-child,.tcc-card>h3:first-child{margin-top:0}'
		. '.tcc-card h2{font-size:16px;margin:22px 0 8px}'
		. '.tcc-muted{color:#50575e}'
		. '.tcc-section-title{font-size:14px;margin:24px 0 10px}'
		. '.tcc-empty{background:#fff;border:1px dashed #c3c4c7;border-radius:8px;padding:22px 18px;color:#50575e;margin:0 0 14px}'
		. '.tcc-event{display:grid;grid-template-columns:150px minmax(0,1fr) 200px 240px;gap:18px;align-items:start}'
		. '.tcc-event__img img{width:150px;height:auto;border-radius:6px;display:block}'
		. '.tcc-noimg{width:150px;aspect-ratio:16/9;background:#f0f0f1;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#8c8f94;font-size:12px}'
		. '.tcc-event__title{font-size:15px;font-weight:600;margin:0 0 4px;line-height:1.35}'
		. '.tcc-event__text{margin:0 0 8px;color:#3c434a}'
		. '.tcc-event__meta{margin:4px 0 0;color:#50575e;line-height:1.9}'
		. '.tcc-label{display:block;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#787c82;margin:0 0 4px}'
		. '.tcc-event__actions>form{display:block!important;margin:0 0 8px!important}'
		. '.tcc-event__actions>form>.button{width:100%;text-align:center;min-height:36px}'
		. '.tcc-event__actions .button-link-delete{border-color:transparent;background:transparent}'
		. '@media(max-width:1180px){.tcc-event{grid-template-columns:120px minmax(0,1fr)}.tcc-event__img img,.tcc-noimg{width:120px}.tcc-event__dates,.tcc-event__actions{grid-column:2}}'
		. '@media(max-width:600px){.tcc-event{grid-template-columns:1fr}.tcc-event__dates,.tcc-event__actions{grid-column:1}}'
		. '.tcc-pco table.widefat{border-radius:8px;overflow:hidden;border-color:#dcdcde}'
		. '.tcc-pco .form-table th{padding-left:0}'
		. '.tcc-help h2{font-size:16px;margin:0 0 8px}.tcc-help li{margin-bottom:6px}.tcc-help ol,.tcc-help ul{margin-left:20px}.tcc-help ul{list-style:disc}'
		. '.tcc-help table{border-collapse:collapse;width:100%}.tcc-help td,.tcc-help th{padding:8px 12px 8px 0;text-align:left;vertical-align:top;border-top:1px solid #f0f0f1}.tcc-help th{white-space:nowrap;width:190px}'
		. '.tcc-jump{display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center}.tcc-jump a{display:inline-block;background:#f0f6fc;border-radius:999px;padding:4px 12px;text-decoration:none}.tcc-jump a:hover,.tcc-jump a:focus{background:#dcebf9}'
		. '.tcc-card[id]{scroll-margin-top:46px}'
		. '@media(max-width:600px){.tcc-help table,.tcc-help tbody,.tcc-help tr,.tcc-help th,.tcc-help td{display:block;width:auto;white-space:normal}.tcc-help th{padding-bottom:0}.tcc-help td{border-top:0;padding-top:2px}}'
		. '.tcc-savebar{position:sticky;bottom:0;z-index:5;display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 18px;margin:0 0 14px;box-shadow:0 -3px 10px rgba(0,0,0,.06)}'
		. '.tcc-savebar .button-primary{min-height:38px;padding:0 20px}'
		. '.tcc-row{display:grid;gap:8px 16px;align-items:center;padding:9px 0;border-top:1px solid #f0f0f1}'
		. '.tcc-row--head{border-top:0;padding:0 0 6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#787c82}'
		. '.tcc-row--on .tcc-row__name{font-weight:600}'
		. '.tcc-row select,.tcc-row input[type=text]{width:100%;max-width:none}'
		. '@media(max-width:860px){.tcc-row{grid-template-columns:1fr!important}.tcc-row--head{display:none}}'
		. '.tcc-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px 28px}'
		. '.tcc-field{margin:0 0 12px}'
		. '.tcc-field>label,.tcc-field__label{display:block;font-weight:600;margin:0 0 5px}'
		. '.tcc-field input[type=text],.tcc-field input[type=url],.tcc-field input[type=password],.tcc-field select,.tcc-field textarea{width:100%;max-width:520px}'
		. '.tcc-field .description{display:block;margin-top:5px;color:#50575e}'
		. '.tcc-check{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-top:1px solid #f0f0f1}'
		. '.tcc-check:first-of-type{border-top:0}'
		. '.tcc-check input{margin-top:3px;flex:0 0 auto}'
		. '.tcc-check strong{display:block}'
		. '.tcc-check span{color:#50575e}'
		. '.tcc-pco details,#tcc_pco_box details{margin:8px 0 0}'
		. '.tcc-pco summary,#tcc_pco_box summary{cursor:pointer;color:#2271b1;padding:4px 0}'
		. '.tcc-box-grid{display:flex;flex-wrap:wrap;gap:14px;margin:12px 0}'
		. '.tcc-box-col{flex:1 1 230px;min-width:0;background:#f6f7f7;border-radius:8px;padding:12px 14px}'
		. '.tcc-box-col h4{margin:0 0 6px;font-size:13px}'
		. '.tcc-box-col label{display:block;margin:5px 0}'
		. '.tcc-box-section{border-top:1px solid #f0f0f1;margin-top:14px;padding-top:12px}'
		. '.tcc-box-section h4{margin:0 0 6px;font-size:13px}'
		. '</style>';
}

function tcc_pco_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$tab         = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'waiting';
	$items       = tcc_pco_items();
	$conflicts   = tcc_pco_conflicts();
	$groups      = array( 'new' => array(), 'approved' => array(), 'ignored' => array(), 'unsynced' => array() );
	$passed      = 0;
	$unpublished = 0;
	foreach ( $items as $id => $item ) {
		$status = isset( $item['status'] ) ? $item['status'] : 'new';
		if ( tcc_pco_item_passed( $item ) ) {
			// Over and done: not listed any more. Its website pages keep the last details they had.
			$passed += in_array( $status, array( 'approved', 'unsynced' ), true ) ? 1 : 0;
			continue;
		}
		if ( ! empty( $item['gone'] ) ) {
			// Taken off Church Center in Planning Center: not listed here either. Its upcoming dates were
			// removed from the website when that was noticed. Publish it again and it comes back as it was.
			$unpublished += 'approved' === $status ? 1 : 0;
			continue;
		}
		if ( isset( $groups[ $status ] ) && ! empty( $item['data'] ) ) {
			$groups[ $status ][ $id ] = $item;
		}
	}
	$s        = tcc_pco_settings();
	$new_tags = count( array_diff( array_keys( tcc_pco_known_tags() ), array_map( 'strval', (array) $s['tags_seen'] ) ) );
	$tabs     = array(
		'waiting'   => 'Waiting for approval (' . count( $groups['new'] ) . ')',
		'synced'    => 'On the website (' . count( $groups['approved'] ) . ')',
		'conflicts' => 'Conflicts (' . count( $conflicts ) . ')',
		'changes'   => 'Recent changes',
		'tags'      => 'Tags' . ( $new_tags ? ' (' . $new_tags . ' new)' : '' ),
		'rooms'     => 'Rooms',
		'settings'  => 'Settings',
	);
	if ( ! isset( $tabs[ $tab ] ) ) {
		$tab = 'waiting';
	}
	$last = get_option( 'tcc_pco_last_run', array() );

	tcc_pco_admin_css();
	echo '<div class="wrap tcc-pco"><h1>Planning Center</h1>';
	if ( isset( $_GET['tcc_msg'] ) ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['tcc_msg'] ) ) ) . '</p></div>';
	}
	if ( ! function_exists( 'tribe_create_event' ) ) {
		echo '<div class="notice notice-error"><p>The Events Calendar plugin is not active, so events cannot be added to the website.</p></div>';
	}

	// The strip at the top: what this is, the last check, and the button to check now.
	echo '<div class="tcc-top"><p class="tcc-top__text">Events published to Church Center in Planning Center show up here. Nothing goes on the website until you approve it, and Planning Center is never changed. <a href="' . esc_url( tcc_pco_help_url() ) . '">How this works</a></p>';
	if ( '' === $s['app_id'] || '' === $s['secret'] ) {
		echo '<span class="tcc-pill tcc-pill--bad">Not connected</span>';
	} elseif ( empty( $last['time'] ) ) {
		echo '<span class="tcc-pill tcc-pill--muted">Not checked yet</span>';
	} elseif ( empty( $last['ok'] ) ) {
		echo '<span class="tcc-pill tcc-pill--bad" title="' . esc_attr( isset( $last['message'] ) ? $last['message'] : '' ) . '">Last check failed ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago</span>';
	} else {
		echo '<span class="tcc-pill tcc-pill--ok" title="' . esc_attr( isset( $last['message'] ) ? $last['message'] : '' ) . '">Checked ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago</span>';
	}
	echo tcc_pco_button( 'check_now', 'Check Planning Center now', array( 'tab' => $tab ), 'button button-primary' ) . '</div>';
	if ( ! empty( $last['time'] ) && empty( $last['ok'] ) && ! empty( $last['message'] ) ) {
		echo '<div class="notice notice-error inline"><p>The last check did not work: ' . esc_html( $last['message'] ) . '</p></div>';
	}

	echo '<h2 class="nav-tab-wrapper">';
	foreach ( $tabs as $key => $label ) {
		echo '<a class="nav-tab' . ( $tab === $key ? ' nav-tab-active' : '' ) . '" href="' . esc_url( tcc_pco_url( $key ) ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</h2><div style="margin-top:16px">';

	if ( 'waiting' === $tab ) {
		if ( '' === $s['app_id'] || '' === $s['secret'] ) {
			echo '<div class="tcc-card"><strong>Planning Center is not connected yet.</strong> Add the Application ID and Secret on the <a href="' . esc_url( tcc_pco_url( 'settings' ) ) . '">Settings</a> tab.</div>';
		}
		tcc_pco_table( $groups['new'], 'waiting', 'Nothing is waiting. When an event is published to Church Center in Planning Center, it appears here within the hour.' );
		if ( $groups['ignored'] ) {
			echo '<h3 class="tcc-section-title">Hidden (you chose not to put these on the website)</h3>';
			tcc_pco_table( $groups['ignored'], 'ignored', '' );
		}
	} elseif ( 'synced' === $tab ) {
		tcc_pco_table( $groups['approved'], 'synced', 'No events are on the website from Planning Center yet. Approve one on the Waiting for approval tab.' );
		if ( $groups['unsynced'] ) {
			echo '<h3 class="tcc-section-title">Stopped (no longer kept up to date)</h3>';
			tcc_pco_table( $groups['unsynced'], 'unsynced', '' );
		}
		if ( $unpublished ) {
			echo '<p class="tcc-muted">' . (int) $unpublished . ' approved event' . ( 1 === $unpublished ? ' is' : 's are' ) . ' no longer published to Church Center in Planning Center, so ' . ( 1 === $unpublished ? 'it is' : 'they are' ) . ' not listed and ' . ( 1 === $unpublished ? 'its' : 'their' ) . ' upcoming dates were taken off the website. Publish ' . ( 1 === $unpublished ? 'it' : 'them' ) . ' again and ' . ( 1 === $unpublished ? 'it comes' : 'they come' ) . ' back.</p>';
		}
		if ( $passed ) {
			echo '<p class="tcc-muted">' . (int) $passed . ' event' . ( 1 === $passed ? ' has' : 's have' ) . ' passed and ' . ( 1 === $passed ? 'is' : 'are' ) . ' no longer listed here. Their pages stay on the website with the last details they had.</p>';
		}
	} elseif ( 'conflicts' === $tab ) {
		tcc_pco_conflicts_table( $conflicts );
	} elseif ( 'changes' === $tab ) {
		$log = get_option( 'tcc_pco_log', array() );
		if ( ! $log ) {
			echo '<div class="tcc-empty">Nothing has happened yet. Everything the plugin does to the website is written down here.</div>';
		} else {
			echo '<p class="tcc-muted">Everything the plugin has done to the website, newest first. The last 150 are kept.</p>';
			echo '<table class="widefat striped"><thead><tr><th style="width:180px">When</th><th>What happened</th><th style="width:120px"></th></tr></thead><tbody>';
			foreach ( (array) $log as $row ) {
				echo '<tr><td>' . esc_html( wp_date( 'M j, Y g:i a', (int) $row['time'] ) ) . '</td><td>' . esc_html( $row['message'] ) . '</td><td>';
				if ( ! empty( $row['post_id'] ) && get_post( (int) $row['post_id'] ) && 'trash' !== get_post_status( (int) $row['post_id'] ) ) {
					echo '<a href="' . esc_url( (string) get_edit_post_link( (int) $row['post_id'] ) ) . '">Open event</a>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}
	} elseif ( 'tags' === $tab ) {
		tcc_pco_tags_form( $s, $items );
	} elseif ( 'rooms' === $tab ) {
		tcc_pco_rooms_form( $s, $items );
	} else {
		tcc_pco_settings_form( $s, $items );
	}
	echo '</div></div>';
}

/** A list of events, one white panel each: graphic, what it is, its next dates, and the buttons. */
function tcc_pco_table( $rows, $mode, $empty ) {
	if ( ! $rows ) {
		if ( $empty ) {
			echo '<div class="tcc-empty">' . esc_html( $empty ) . '</div>';
		}
		return;
	}
	$sets = tcc_pco_settings();
	foreach ( $rows as $id => $item ) {
		$ev = $item['data'];
		echo '<div class="tcc-card tcc-event"><div class="tcc-event__img">';
		if ( ! empty( $ev['image_url'] ) ) {
			echo '<img src="' . esc_url( $ev['image_url'] ) . '" alt="">';
		} else {
			echo '<div class="tcc-noimg">No graphic</div>';
		}
		echo '</div><div class="tcc-event__main"><p class="tcc-event__title">' . esc_html( $ev['name'] ) . '</p>';

		// Show the text visitors will get: the description or the summary, as chosen on the Settings tab.
		$text = 'summary' === $sets['desc_source'] ? ( '' !== $ev['summary'] ? $ev['summary'] : $ev['description'] ) : ( '' !== $ev['description'] ? $ev['description'] : $ev['summary'] );
		$text = wp_strip_all_tags( $text );
		if ( '' !== $text ) {
			echo '<p class="tcc-event__text">' . esc_html( wp_html_excerpt( $text, 220, '...' ) ) . '</p>';
		}
		$bits   = array();
		$bits[] = ! empty( $ev['registration_url'] ) ? '<span class="tcc-pill tcc-pill--teal">Registration link</span>' : '<span class="tcc-pill tcc-pill--muted">No registration link</span>';
		$bits[] = ! empty( $ev['image_url'] ) ? '' : '<span class="tcc-pill tcc-pill--muted">Uses the default graphic</span>';
		echo '<p class="tcc-event__meta">' . implode( ' ', array_filter( $bits ) ) . '</p>';
		$rooms = tcc_pco_event_rooms( $ev );
		if ( $rooms && 'synced' !== $mode ) {
			echo '<p class="tcc-event__meta">Rooms: ' . esc_html( implode( ', ', $rooms ) ) . '</p>';
		}
		echo '<p class="tcc-event__meta" style="margin-top:0">' . preg_replace( '#^<br>#', '', tcc_pco_tags_html( $ev ) ) . '</p>';
		if ( 'synced' === $mode ) {
			echo tcc_pco_event_rooms_form( $id, $rooms );
		}
		$links = array();
		if ( 'synced' === $mode || 'unsynced' === $mode ) {
			foreach ( tcc_pco_posts_for( $id ) as $post ) {
				if ( tcc_pco_post_passed( $post->ID ) ) {
					continue; // Dates that are over are left alone and not listed.
				}
				$links[] = '<a href="' . esc_url( (string) get_edit_post_link( $post->ID ) ) . '">' . esc_html( mysql2date( 'M j', (string) get_post_meta( $post->ID, '_EventStartDate', true ) ) ) . '</a>';
			}
		}
		echo '<p class="tcc-event__meta">' . ( $links ? 'Edit on the website: ' . implode( ', ', $links ) . ' &nbsp;|&nbsp; ' : '' ) . '<a href="' . esc_url( tcc_pco_pc_link( $id ) ) . '" target="_blank" rel="noopener">Edit in Planning Center</a></p>';

		echo '</div><div class="tcc-event__dates"><span class="tcc-label">Next dates</span>' . tcc_pco_when( $ev ) . '</div><div class="tcc-event__actions">';
		$f = array( 'id' => $id );
		if ( 'waiting' === $mode ) {
			echo tcc_pco_approve_form( $id, $ev );
			echo tcc_pco_button( 'ignore', 'Hide', $f );
		} elseif ( 'ignored' === $mode ) {
			echo tcc_pco_button( 'restore', 'Move back to waiting', $f );
		} elseif ( 'synced' === $mode ) {
			echo tcc_pco_button( 'unsync_keep', 'Stop syncing, keep on website', $f );
			echo tcc_pco_button( 'unsync_remove', 'Stop syncing and remove', $f, 'button button-link-delete', 'Move the upcoming website dates of this event to the Trash?' );
		} else {
			echo tcc_pco_button( 'approve', 'Start syncing again', $f );
			echo tcc_pco_button( 'ignore', 'Hide', $f ); // Moves it to the Hidden list on the Waiting for approval tab.
		}
		echo '</div></div>';
	}
}

/**
 * The Approve button. When the website already has a hand-made event with the same name, it is listed
 * with a tick: ticked ones go to the Trash on approval, and their graphic and page content carry over.
 */
function tcc_pco_approve_form( $id, $ev ) {
	$matches = tcc_pco_handmade_matches( $ev );
	if ( ! $matches ) {
		return tcc_pco_button( 'approve', 'Approve and add to website', array( 'id' => $id ), 'button button-primary' );
	}
	$ask   = 'Move the ticked hand-made events to the Trash and put the Planning Center event in their place?';
	$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0 0 8px;padding:12px;background:#fcf9e8;border:1px solid #f0c33c;border-radius:8px" onsubmit="return !this.querySelector(\'input[type=checkbox]:checked\') || confirm(\'' . esc_js( $ask ) . '\')">';
	$html .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="approve"><input type="hidden" name="id" value="' . esc_attr( $id ) . '">';
	$html .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
	$html .= '<strong>Already on the website (made by hand):</strong>';
	foreach ( $matches as $post_id => $row ) {
		$when  = mysql2date( 'M j, Y', $row['next'] );
		$what  = $row['count'] > 1 ? 'repeating, ' . (int) $row['count'] . ' upcoming dates, next ' . $when : $when;
		$html .= '<label style="display:block;margin:6px 0"><input type="checkbox" name="replace[]" value="' . (int) $post_id . '"' . checked( $row['same_day'], true, false ) . '> Replace "' . esc_html( $row['title'] ) . '" (' . esc_html( $what ) . ')' . ( $row['same_day'] ? '' : ' <span style="color:#996800">different day: may be a different occasion</span>' ) . ' <a href="' . esc_url( (string) get_edit_post_link( $post_id ) ) . '" target="_blank" rel="noopener">open</a></label>';
	}
	$html .= '<p class="description" style="margin:6px 0 8px">A ticked event is moved to the Trash when you approve, so visitors do not see the event twice. Its graphic, page content and categories are carried over to the Planning Center event. You can restore it from Events &rarr; Trash. A repeating hand-made event is a single item, so its past dates go to the Trash with it.</p>';
	$html .= '<button type="submit" class="button button-primary">Approve and add to website</button></form>';
	return $html;
}

function tcc_pco_conflicts_table( $conflicts ) {
	if ( ! $conflicts ) {
		echo '<div class="tcc-empty">No conflicts. A conflict appears when something was changed on the website and was also changed in Planning Center, so the sync cannot tell which one you want.</div>';
		return;
	}
	echo '<p>These were changed in both places. Nothing has been overwritten. Choose which version to keep.</p>';
	echo '<table class="widefat striped"><thead><tr><th>Event</th><th style="width:90px">What</th><th>On the website now</th><th>In Planning Center</th><th style="width:300px">Choose</th></tr></thead><tbody>';
	foreach ( $conflicts as $key => $c ) {
		$post = get_post( (int) $c['post_id'] );
		echo '<tr><td>' . ( $post ? '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( get_the_title( $post ) ) . '</a>' : '<em>Event no longer exists</em>' ) . '</td>';
		echo '<td>' . esc_html( tcc_pco_field_label( $c['field'] ) ) . '</td>';
		if ( 'image' === $c['field'] ) {
			echo '<td>' . ( $post && has_post_thumbnail( $post ) ? get_the_post_thumbnail( $post, array( 120, 68 ) ) : esc_html( $c['website'] ) ) . '</td>';
			echo '<td><img src="' . esc_url( $c['pco'] ) . '" alt="" style="width:120px;height:auto"></td>';
		} else {
			echo '<td>' . esc_html( $c['website'] ) . '</td><td>' . esc_html( $c['pco'] ) . '</td>';
		}
		echo '<td>' . tcc_pco_button( 'resolve', 'Use Planning Center', array( 'key' => $key, 'choice' => 'pco' ), 'button button-primary' );
		echo tcc_pco_button( 'resolve', 'Keep website', array( 'key' => $key, 'choice' => 'site' ) ) . '</td></tr>';
	}
	echo '</tbody></table>';
}

/** One "Choose graphic" control: a small preview, a button that opens the Media Library, and a Remove button. */
function tcc_pco_image_picker( $name, $att_id ) {
	$url = $att_id ? wp_get_attachment_image_url( $att_id, 'medium' ) : '';
	if ( ! $url ) {
		$att_id = 0;
	}
	return '<span class="tcc-pco-picker" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><input type="hidden" name="' . esc_attr( $name ) . '" value="' . (int) $att_id . '"><img src="' . esc_url( (string) $url ) . '" alt="" style="width:120px;height:auto;border-radius:4px;' . ( $url ? '' : 'display:none' ) . '"><button type="button" class="button tcc-pco-pick">Choose graphic</button><button type="button" class="button button-link-delete tcc-pco-unpick"' . ( $url ? '' : ' style="display:none"' ) . '>Remove</button></span>';
}

function tcc_pco_admin_assets() {
	if ( isset( $_GET['page'] ) && 'tcc-pco-sync' === $_GET['page'] ) {
		wp_enqueue_media();
	}
}
add_action( 'admin_enqueue_scripts', 'tcc_pco_admin_assets' );

/** One line under each "what shows" tick, saying what it is. */
function tcc_pco_show_hints() {
	return array(
		'description' => 'The text from Planning Center (or typed on the event), above anything you add to the page.',
		'register'    => 'Only appears when the event has a registration link.',
		'location'    => 'The place name, the address, the Get directions link and the map.',
		'rooms'       => 'Only rooms that are ticked on the Rooms tab.',
		'end_time'    => 'Untick to show only when the event starts.',
	);
}

function tcc_pco_settings_form( $s, $items ) {
	$connected = '' !== $s['app_id'] && '' !== $s['secret'];
	$last      = get_option( 'tcc_pco_last_run', array() );
	$hints     = tcc_pco_show_hints();

	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_settings"><input type="hidden" name="show_form" value="1">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );

	// Connection.
	echo '<div class="tcc-card"><h2>Connection to Planning Center ';
	if ( ! $connected ) {
		echo '<span class="tcc-pill tcc-pill--bad">Not connected</span>';
	} elseif ( ! empty( $last['time'] ) && empty( $last['ok'] ) ) {
		echo '<span class="tcc-pill tcc-pill--bad">Not working</span>';
	} else {
		echo '<span class="tcc-pill tcc-pill--ok">Connected</span>';
	}
	echo '</h2><p>The website signs in to Planning Center with a Personal Access Token. The website only ever reads Calendar with it and never changes anything. But the token itself can do whatever the Planning Center person who made it can do, in every part of Planning Center (People, Giving, Services and the rest), so anyone who got hold of the Secret could too. Make it from a Planning Center login that can only see Calendar; the steps are below.</p>';
	echo '<div class="tcc-two"><div class="tcc-field"><label for="tcc_app_id">Application ID</label><input type="text" id="tcc_app_id" name="app_id" autocomplete="off" value="' . esc_attr( $s['app_id'] ) . '"></div>';
	echo '<div class="tcc-field"><label for="tcc_secret">Secret</label><input type="password" id="tcc_secret" name="secret" autocomplete="new-password" value="" placeholder="' . ( '' !== $s['secret'] ? 'Saved. Leave empty to keep it.' : '' ) . '"><span class="description">The saved secret is never shown again. Type a new one only to replace it.</span></div></div>';
	echo '<details><summary>How to get these two values</summary><ol><li>Best: in Planning Center People, add a person just for the website (for example "TCC Website", with an email address the church controls). Give that person <strong>Viewer</strong> access to Calendar and <strong>no access</strong> to People, Giving, Services, Check-Ins, Groups, Registrations or Publishing. Sign in to Planning Center as that person. (If that is not possible, sign in as a Planning Center administrator, but know that the token then has all of that administrator\'s access.)</li><li>Go to <code>api.planningcenteronline.com/oauth/applications</code>.</li><li>Under Personal Access Tokens, create a new one (name it "Website").</li><li>Copy the Application ID and the Secret into the two boxes above and press Save settings.</li><li>If a token made by an administrator was used before, delete that old token on the same Planning Center page.</li></ol></details></div>';

	// What shows.
	echo '<div class="tcc-card"><h2>What shows on event pages</h2><p>The starting point for every event. You can change any of these for one event on its own screen.</p>';
	foreach ( tcc_pco_show_keys() as $key => $label ) {
		echo '<label class="tcc-check"><input type="checkbox" name="show[' . esc_attr( $key ) . ']" value="1"' . checked( ! isset( $s['show'][ $key ] ) || ! empty( $s['show'][ $key ] ), true, false ) . '><span><strong>' . esc_html( $label ) . '</strong>' . esc_html( isset( $hints[ $key ] ) ? $hints[ $key ] : '' ) . '</span></label>';
	}
	echo '</div>';

	// Description and repeating events.
	echo '<div class="tcc-card"><h2>Descriptions and repeating events</h2><div class="tcc-two">';
	echo '<div class="tcc-field"><label for="tcc_desc_source">Which Planning Center text to use as the description</label><select id="tcc_desc_source" name="desc_source"><option value="description"' . selected( $s['desc_source'], 'description', false ) . '>Description (the long text)</option><option value="summary"' . selected( $s['desc_source'], 'summary', false ) . '>Summary (the short text)</option></select><span class="description">If the one you choose is empty, the other is used. An event can also have its own text typed on the website.</span></div>';
	echo '<div class="tcc-field"><label for="tcc_per">Upcoming dates to keep for a repeating event</label><input type="number" id="tcc_per" name="per_event" min="1" max="10" value="' . (int) $s['per_event'] . '" class="small-text" style="width:80px"><span class="description">For example 2 shows this week\'s and next week\'s. One event can have its own number, set on that event.</span></div>';
	echo '</div></div>';

	// Graphics.
	echo '<div class="tcc-card"><h2>Graphics</h2><p>An approved event uses its Planning Center graphic. An event with no graphic of its own (from Planning Center or made by hand) is shown with the default below. Nothing is saved onto the event: give it its own graphic later and that one shows instead.</p>';
	echo '<div class="tcc-field"><span class="tcc-field__label">Default graphic</span>' . tcc_pco_image_picker( 'fallback_image', (int) $s['fallback_image'] ) . '</div>';
	$cats = taxonomy_exists( 'tribe_events_cat' ) ? get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) ) : array();
	$cats = is_wp_error( $cats ) ? array() : (array) $cats;
	if ( $cats ) {
		$set = count( array_filter( (array) $s['cat_images'] ) );
		echo '<details' . ( $set ? ' open' : '' ) . '><summary>A different default for one category (optional' . ( $set ? ', ' . (int) $set . ' set' : '' ) . ')</summary><p class="tcc-muted">An event in one of these categories uses that category\'s graphic before the default above.</p>';
		$grid = 'grid-template-columns:minmax(0,220px) minmax(0,1fr)';
		foreach ( $cats as $cat ) {
			if ( is_object( $cat ) ) {
				echo '<div class="tcc-row" style="' . esc_attr( $grid ) . '"><span class="tcc-row__name">' . esc_html( $cat->name ) . '</span><span>' . tcc_pco_image_picker( 'cat_images[' . (int) $cat->term_id . ']', isset( $s['cat_images'][ (int) $cat->term_id ] ) ? (int) $s['cat_images'][ (int) $cat->term_id ] : 0 ) . '</span></div>';
			}
		}
		echo '</details>';
	}
	echo '</div>';
	// The "Choose graphic" buttons open the normal Media Library window.
	echo '<script>jQuery(function($){$(document).on("click",".tcc-pco-pick",function(e){e.preventDefault();var box=$(this).closest(".tcc-pco-picker");var frame=wp.media({title:"Choose a graphic",button:{text:"Use this graphic"},library:{type:"image"},multiple:false});frame.on("select",function(){var a=frame.state().get("selection").first().toJSON();var url=(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url);box.find("input").val(a.id);box.find("img").attr("src",url).show();box.find(".tcc-pco-unpick").show();});frame.open();});$(document).on("click",".tcc-pco-unpick",function(e){e.preventDefault();var box=$(this).closest(".tcc-pco-picker");box.find("input").val("0");box.find("img").hide();$(this).hide();});});</script>';

	echo tcc_pco_savebar( 'Save settings', 'Nothing on this tab changes until you save.' );
	echo '</form>';

	echo '<p class="tcc-muted">Looking for the short codes for the page builder, or how any of this works? See <a href="' . esc_url( tcc_pco_help_url() ) . '">Help</a>.</p>';
}

/* ---------------------------------------------------------------------------
 * Handling the buttons
 * ------------------------------------------------------------------------- */

function tcc_pco_handle() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'tcc_pco_do', '_tcc_pco_nonce' );
	$op    = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
	$id    = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
	$items = tcc_pco_items();
	$tab   = 'waiting';
	$msg   = '';
	$name  = isset( $items[ $id ]['data']['name'] ) ? $items[ $id ]['data']['name'] : 'the event';

	if ( 'check_now' === $op ) {
		$tab    = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'waiting';
		$result = tcc_pco_run();
		$msg    = is_wp_error( $result ) ? $result->get_error_message() : 'Checked Planning Center. ' . (int) $result . ' new event(s) waiting.';
	} elseif ( 'approve' === $op && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'approved';
		tcc_pco_save_items( $items );
		foreach ( tcc_pco_posts_for( $id ) as $post ) {
			delete_post_meta( $post->ID, '_tcc_pco_paused' );
		}
		tcc_pco_log( 'Approved "' . $name . '" for the website.' );
		// Hand-made events ticked for replacing: only ones that really match this event are accepted.
		$replace  = isset( $_POST['replace'] ) && is_array( $_POST['replace'] ) ? array_map( 'absint', wp_unslash( $_POST['replace'] ) ) : array();
		$matches  = $replace ? tcc_pco_handmade_matches( $items[ $id ]['data'] ) : array();
		$replaced = 0;
		foreach ( $replace as $old_id ) {
			if ( ! isset( $matches[ $old_id ] ) || ! current_user_can( 'delete_post', $old_id ) ) {
				continue;
			}
			if ( ! isset( $GLOBALS['tcc_pco_carry'][ (string) $id ] ) ) {
				$carry = tcc_pco_carry_from( $old_id );
				// If the hand-made page says the same as the Planning Center description, do not print it twice.
				foreach ( array( 'description', 'summary' ) as $which ) {
					if ( isset( $items[ $id ]['data'][ $which ] ) && tcc_pco_same_text( $carry['content'], $items[ $id ]['data'][ $which ] ) ) {
						$carry['content'] = '';
					}
				}
				$GLOBALS['tcc_pco_carry'][ (string) $id ] = $carry;
			}
			if ( wp_trash_post( $old_id ) ) {
				$replaced++;
				tcc_pco_log( 'Moved the hand-made event "' . $matches[ $old_id ]['title'] . '" to the Trash: "' . $name . '" from Planning Center replaces it.', $old_id );
			}
		}
		if ( empty( $items[ $id ]['gone'] ) ) {
			tcc_pco_apply_event( $items[ $id ]['data'] );
		}
		$tab = 'synced';
		$msg = '"' . $name . '" is now on the website and will be kept up to date.' . ( $replaced ? ' ' . $replaced . ' hand-made event(s) moved to the Trash.' : '' );
	} elseif ( in_array( $op, array( 'ignore', 'restore' ), true ) && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'ignore' === $op ? 'ignored' : 'new';
		tcc_pco_save_items( $items );
		$msg = 'ignore' === $op ? '"' . $name . '" is hidden.' : '"' . $name . '" is waiting for approval again.';
	} elseif ( in_array( $op, array( 'unsync_keep', 'unsync_remove' ), true ) && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'unsynced';
		tcc_pco_save_items( $items );
		$tab = 'synced';
		if ( 'unsync_remove' === $op ) {
			$n   = tcc_pco_trash_future_posts( $id, array() );
			$msg = 'Stopped syncing "' . $name . '" and moved ' . $n . ' upcoming date(s) to the Trash.';
		} else {
			foreach ( tcc_pco_posts_for( $id ) as $post ) {
				update_post_meta( $post->ID, '_tcc_pco_paused', 1 );
			}
			$msg = 'Stopped syncing "' . $name . '". The website events stay as they are.';
		}
		tcc_pco_log( $msg );
	} elseif ( 'resolve' === $op ) {
		$key       = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$choice    = isset( $_POST['choice'] ) ? sanitize_key( wp_unslash( $_POST['choice'] ) ) : '';
		$conflicts = tcc_pco_conflicts();
		$tab       = 'conflicts';
		if ( isset( $conflicts[ $key ] ) ) {
			$msg = tcc_pco_resolve( $conflicts[ $key ], $choice );
		}
	} elseif ( 'save_settings' === $op ) {
		$s              = tcc_pco_settings();
		$old_graphics   = array( (int) $s['fallback_image'], array_filter( array_map( 'intval', (array) $s['cat_images'] ) ) );
		$s['app_id']    = isset( $_POST['app_id'] ) ? sanitize_text_field( wp_unslash( $_POST['app_id'] ) ) : '';
		$secret         = isset( $_POST['secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['secret'] ) ) ) : '';
		$s['secret']    = '' !== $secret ? $secret : $s['secret'];
		$s['per_event'] = isset( $_POST['per_event'] ) ? max( 1, min( 10, (int) $_POST['per_event'] ) ) : 2;
		unset( $s['github_token'] ); // Left over from 0.3.0; no key is used any more.
		if ( ! empty( $_POST['show_form'] ) ) {
			$show      = isset( $_POST['show'] ) && is_array( $_POST['show'] ) ? wp_unslash( $_POST['show'] ) : array();
			$s['show'] = array();
			foreach ( array_keys( tcc_pco_show_keys() ) as $key ) {
				$s['show'][ $key ] = ! empty( $show[ $key ] ) ? 1 : 0;
			}
			$s['desc_source']    = isset( $_POST['desc_source'] ) && 'summary' === $_POST['desc_source'] ? 'summary' : 'description';
			$s['fallback_image'] = isset( $_POST['fallback_image'] ) ? absint( $_POST['fallback_image'] ) : 0;
			$s['cat_images']     = array();
			foreach ( isset( $_POST['cat_images'] ) && is_array( $_POST['cat_images'] ) ? wp_unslash( $_POST['cat_images'] ) : array() as $term_id => $att ) {
				if ( absint( $att ) ) {
					$s['cat_images'][ absint( $term_id ) ] = absint( $att );
				}
			}
		}
		update_option( 'tcc_pco_settings', $s, false );
		if ( array( (int) $s['fallback_image'], array_filter( array_map( 'intval', (array) $s['cat_images'] ) ) ) != $old_graphics ) { // phpcs:ignore Universal.Operators.StrictComparisons -- comparing two small arrays by value.
			tcc_pco_refresh_cards();
		}
		$tab = 'settings';
		$msg = 'Settings saved.';
	} elseif ( 'save_tags' === $op ) {
		$s    = tcc_pco_settings();
		$ids  = isset( $_POST['tag_ids'] ) && is_array( $_POST['tag_ids'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tag_ids'] ) ) : array();
		$post = isset( $_POST['tag_map'] ) && is_array( $_POST['tag_map'] ) ? wp_unslash( $_POST['tag_map'] ) : array();
		$map  = (array) $s['tag_map'];
		foreach ( $ids as $tid ) {
			$term = isset( $post[ $tid ] ) ? (int) $post[ $tid ] : 0;
			if ( $term > 0 ) {
				$map[ $tid ] = $term;
			} else {
				unset( $map[ $tid ] );
			}
		}
		$s['tag_map']   = $map;
		$auto_post      = isset( $_POST['tag_auto'] ) && is_array( $_POST['tag_auto'] ) ? array_map( 'strval', array_keys( wp_unslash( $_POST['tag_auto'] ) ) ) : array();
		$auto           = array_diff( array_map( 'strval', (array) $s['auto_tags'] ), $ids ); // Keep tags that were not on the form.
		$s['auto_tags'] = array_values( array_unique( array_merge( $auto, array_intersect( $ids, $auto_post ) ) ) );
		$s['tags_seen'] = array_values( array_unique( array_merge( array_map( 'strval', (array) $s['tags_seen'] ), $ids ) ) );
		update_option( 'tcc_pco_settings', $s, false );
		// Bring the events that are already on the website in line straight away.
		$n = 0;
		foreach ( $items as $eid => $item ) {
			if ( isset( $item['status'] ) && 'approved' === $item['status'] && empty( $item['gone'] ) && ! empty( $item['data'] ) ) {
				foreach ( tcc_pco_posts_for( $eid ) as $post_obj ) {
					if ( ! get_post_meta( $post_obj->ID, '_tcc_pco_paused', true ) && ! tcc_pco_post_passed( $post_obj->ID ) ) {
						tcc_pco_sync_terms( $post_obj->ID, $item['data'], $s );
						$n++;
					}
				}
			}
		}
		$tab = 'tags';
		$msg = 'Tags saved. ' . count( $map ) . ' public, the rest internal. ' . $n . ' website event(s) checked.' . ( $s['auto_tags'] ? ' ' . count( $s['auto_tags'] ) . ' tag(s) approve events automatically, from the next check.' : '' );
		tcc_pco_log( 'Tags saved: ' . count( $map ) . ' public tag(s).' );
	} elseif ( 'save_cats' === $op ) {
		$tab     = 'tags';
		$renamed = 0;
		$added   = '';
		$errors  = array();
		if ( taxonomy_exists( 'tribe_events_cat' ) ) {
			$names = isset( $_POST['cat_name'] ) && is_array( $_POST['cat_name'] ) ? wp_unslash( $_POST['cat_name'] ) : array();
			// Names already in use (lower case => category id), so two categories never end up with the same name.
			$taken = array();
			$all   = get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) );
			foreach ( is_wp_error( $all ) ? array() : (array) $all as $t ) {
				$taken[ strtolower( html_entity_decode( $t->name, ENT_QUOTES ) ) ] = (int) $t->term_id;
			}
			foreach ( $names as $term_id => $name ) {
				$name = trim( sanitize_text_field( (string) $name ) );
				$term = get_term( (int) $term_id, 'tribe_events_cat' );
				if ( '' === $name || ! $term || is_wp_error( $term ) || html_entity_decode( $term->name, ENT_QUOTES ) === $name ) {
					continue;
				}
				if ( isset( $taken[ strtolower( $name ) ] ) && $taken[ strtolower( $name ) ] !== (int) $term_id ) {
					$errors[] = '"' . $name . '" is already the name of another category';
					continue;
				}
				unset( $taken[ strtolower( html_entity_decode( $term->name, ENT_QUOTES ) ) ] );
				$taken[ strtolower( $name ) ] = (int) $term_id;
				// Only the name changes. The slug stays, so page lists and links keep working.
				$done = wp_update_term( (int) $term_id, 'tribe_events_cat', array( 'name' => $name, 'slug' => $term->slug ) );
				if ( is_wp_error( $done ) ) {
					$errors[] = '"' . $name . '": ' . $done->get_error_message();
				} else {
					$renamed++;
					tcc_pco_log( 'Renamed website category "' . html_entity_decode( $term->name, ENT_QUOTES ) . '" to "' . $name . '".' );
				}
			}
			$new = isset( $_POST['cat_new'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['cat_new'] ) ) ) : '';
			if ( '' !== $new && isset( $taken[ strtolower( $new ) ] ) ) {
				$errors[] = '"' . $new . '" already exists';
			} elseif ( '' !== $new ) {
				$done = wp_insert_term( $new, 'tribe_events_cat' );
				if ( is_wp_error( $done ) ) {
					$errors[] = '"' . $new . '": ' . $done->get_error_message();
				} else {
					$added = $new;
					tcc_pco_log( 'Added website category "' . $new . '".' );
				}
			}
		}
		$msg = 'Website categories saved: ' . $renamed . ' renamed' . ( '' !== $added ? ', "' . $added . '" added' : '' ) . '.' . ( $errors ? ' Not done: ' . implode( '; ', $errors ) : '' );
	} elseif ( 'save_event_rooms' === $op && isset( $items[ $id ] ) ) {
		$s   = tcc_pco_settings();
		$tab = 'synced';
		if ( ! empty( $_POST['reset'] ) ) {
			unset( $s['event_rooms'][ $id ] );
			$msg = '"' . $name . '" follows the Rooms tab again.';
		} else {
			$all    = isset( $_POST['all_rooms'] ) && is_array( $_POST['all_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['all_rooms'] ) ) : array();
			$show   = isset( $_POST['show_rooms'] ) && is_array( $_POST['show_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['show_rooms'] ) ) : array();
			$choice = isset( $s['event_rooms'][ $id ] ) && is_array( $s['event_rooms'][ $id ] ) ? $s['event_rooms'][ $id ] : array();
			foreach ( $all as $rid ) {
				$choice[ $rid ] = in_array( $rid, $show, true ) ? 1 : 0;
			}
			if ( ! is_array( $s['event_rooms'] ) ) {
				$s['event_rooms'] = array();
			}
			$s['event_rooms'][ $id ] = $choice;
			$msg                     = 'Rooms saved for "' . $name . '": ' . count( $show ) . ' showing.';
		}
		update_option( 'tcc_pco_settings', $s, false );
		tcc_pco_log( $msg );
	} elseif ( 'save_rooms' === $op ) {
		$s      = tcc_pco_settings();
		$names  = isset( $_POST['room_names'] ) && is_array( $_POST['room_names'] ) ? wp_unslash( $_POST['room_names'] ) : array();
		$show   = isset( $_POST['room_show'] ) && is_array( $_POST['room_show'] ) ? wp_unslash( $_POST['room_show'] ) : array();
		$labels = isset( $_POST['room_label'] ) && is_array( $_POST['room_label'] ) ? wp_unslash( $_POST['room_label'] ) : array();
		$rooms  = (array) $s['rooms'];
		$shown  = 0;
		foreach ( $names as $rid => $name ) {
			$rid           = sanitize_text_field( (string) $rid );
			$rooms[ $rid ] = array(
				'name'  => sanitize_text_field( (string) $name ),
				'show'  => ! empty( $show[ $rid ] ),
				'label' => isset( $labels[ $rid ] ) ? sanitize_text_field( (string) $labels[ $rid ] ) : '',
			);
		}
		foreach ( $rooms as $row ) {
			$shown += ! empty( $row['show'] ) ? 1 : 0;
		}
		$s['rooms'] = $rooms;
		update_option( 'tcc_pco_settings', $s, false );
		$tab = 'rooms';
		$msg = 'Rooms saved. ' . $shown . ' room(s) can show on the website.';
	}
	wp_safe_redirect( tcc_pco_url( $tab, $msg ? array( 'tcc_msg' => rawurlencode( $msg ) ) : array() ) );
	exit;
}
add_action( 'admin_post_tcc_pco_do', 'tcc_pco_handle' );

function tcc_pco_resolve( $c, $choice ) {
	$post_id = (int) $c['post_id'];
	$field   = (string) $c['field'];
	$synced  = get_post_meta( $post_id, '_tcc_pco_synced', true );
	$synced  = is_array( $synced ) ? $synced : array();
	$title   = get_post( $post_id ) ? get_the_title( $post_id ) : 'the event';
	if ( 'pco' === $choice && get_post( $post_id ) && function_exists( 'tribe_update_event' ) ) {
		if ( 'image' === $field ) {
			$att = tcc_pco_image_attachment( (string) $c['pco'], $title );
			if ( $att ) {
				set_post_thumbnail( $post_id, $att );
				$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
				$synced['image_att'] = $att;
			}
		} elseif ( 'title' === $field ) {
			tribe_update_event( $post_id, array( 'post_title' => wp_slash( wp_strip_all_tags( (string) $c['pco'] ) ) ) );
			$synced['title'] = (string) $c['pco'];
		} else {
			$start = 'start' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventStartDate', true );
			$end   = 'end' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventEndDate', true );
			tribe_update_event( $post_id, tcc_pco_date_args( $start, $end, 'yes' === get_post_meta( $post_id, '_EventAllDay', true ) ) );
			$synced[ $field ] = (string) $c['pco'];
		}
		$msg = 'Used the Planning Center ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
	} else {
		// Keep the website's version and remember what Planning Center has, so it is not asked again until Planning Center changes it again.
		if ( 'image' === $field ) {
			$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
			$synced['image_att'] = (int) get_post_thumbnail_id( $post_id );
		} else {
			$synced[ $field ] = (string) $c['pco'];
		}
		$msg = 'Kept the website ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
	}
	update_post_meta( $post_id, '_tcc_pco_synced', $synced );
	tcc_pco_clear_conflict( $post_id, $field );
	tcc_pco_log( $msg, $post_id );
	return $msg;
}

/* ---------------------------------------------------------------------------
 * A box on the event edit screen
 * ------------------------------------------------------------------------- */

function tcc_pco_meta_box() {
	add_meta_box( 'tcc_pco_box', 'Planning Center and registration', 'tcc_pco_meta_box_html', 'tribe_events', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'tcc_pco_meta_box' );

/** One coloured status line for the box on the event edit screen. */
function tcc_pco_status_line( $colour, $text ) {
	$kinds = array( '#00a32a' => 'ok', '#dba617' => 'warn', '#b32d2e' => 'bad', '#8c8f94' => 'muted' );
	return '<p style="margin:4px 0 8px"><span class="tcc-pill tcc-pill--' . ( isset( $kinds[ $colour ] ) ? $kinds[ $colour ] : 'muted' ) . '" style="font-size:13px;padding:3px 12px">' . esc_html( $text ) . '</span></p>';
}

function tcc_pco_meta_box_html( $post ) {
	wp_nonce_field( 'tcc_pco_box', '_tcc_pco_box_nonce' );
	tcc_pco_admin_css();
	$event_id = (string) get_post_meta( $post->ID, '_tcc_pco_event_id', true );
	$is_pco   = '' !== $event_id;
	$s        = tcc_pco_settings();
	$o        = tcc_pco_post_opts( $post->ID );
	$help     = current_user_can( 'manage_options' ) ? ' <a href="' . esc_url( tcc_pco_help_url() ) . '">Help</a>' : '';

	// Sync status.
	if ( $is_pco ) {
		$items  = tcc_pco_items();
		$item   = isset( $items[ $event_id ] ) ? $items[ $event_id ] : array();
		$status = isset( $item['status'] ) ? $item['status'] : '';
		$paused = (bool) get_post_meta( $post->ID, '_tcc_pco_paused', true );
		if ( tcc_pco_post_passed( $post->ID ) ) {
			echo tcc_pco_status_line( '#8c8f94', 'This date has passed.' );
			echo '<p>It is no longer updated from Planning Center. It keeps the last details it had.</p>';
		} elseif ( $paused || 'approved' !== $status ) {
			echo tcc_pco_status_line( '#dba617', 'Syncing is stopped for this event.' );
			echo '<p>Nothing here is changed by Planning Center until syncing is started again on the Planning Center screen.</p>';
		} elseif ( ! empty( $item['gone'] ) ) {
			echo tcc_pco_status_line( '#b32d2e', 'No longer published in Planning Center.' );
			echo '<p>Planning Center has stopped listing this event, so it is not being updated.</p>';
		} else {
			$last = get_option( 'tcc_pco_last_run', array() );
			echo tcc_pco_status_line( '#00a32a', 'Kept up to date from Planning Center.' );
			echo '<p>' . ( ! empty( $last['time'] ) ? 'Last checked ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago. ' : '' ) . 'Planning Center fills in the title, date, graphic, description, location, rooms and categories. Anything you add to the page itself is yours.' . $help . '</p>';
		}
		$clashes = 0;
		foreach ( tcc_pco_conflicts() as $c ) {
			$clashes += isset( $c['post_id'] ) && (int) $c['post_id'] === (int) $post->ID ? 1 : 0;
		}
		if ( $clashes ) {
			echo '<p style="color:#b32d2e">' . (int) $clashes . ' thing' . ( 1 === $clashes ? ' was' : 's were' ) . ' changed both here and in Planning Center. ' . ( current_user_can( 'manage_options' ) ? '<a href="' . esc_url( tcc_pco_url( 'conflicts' ) ) . '">Choose which to keep</a>' : 'An administrator can choose which to keep.' ) . '</p>';
		}
		echo '<p><a href="' . esc_url( tcc_pco_pc_link( $event_id ) ) . '" target="_blank" rel="noopener">Edit this event in Planning Center</a>' . ( current_user_can( 'manage_options' ) ? ' &nbsp;|&nbsp; <a href="' . esc_url( tcc_pco_url( 'synced' ) ) . '">Open the Planning Center screen</a>' : '' ) . '</p>';
		echo '<input type="hidden" name="tcc_pco_synced_form" value="1">';
	} else {
		echo '<p><span class="tcc-pill tcc-pill--muted" style="font-size:13px;padding:3px 12px">Made on the website</span></p><p>This event is not linked to Planning Center. The choices below still work for it.' . $help . '</p>';
	}

	echo '<div class="tcc-box-grid">';

	// What shows on the event page.
	echo '<div class="tcc-box-col"><h4>Show on the event page</h4>';
	foreach ( tcc_pco_show_keys() as $key => $label ) {
		if ( ! $is_pco && in_array( $key, array( 'description', 'rooms' ), true ) ) {
			continue; // These two only exist for Planning Center events.
		}
		echo '<input type="hidden" name="tcc_pco_show_all[]" value="' . esc_attr( $key ) . '">';
		echo '<label><input type="checkbox" name="tcc_pco_show[]" value="' . esc_attr( $key ) . '"' . checked( tcc_pco_shows( $post->ID, $key, $s ), true, false ) . '> ' . esc_html( $label ) . ( isset( $o['show'][ $key ] ) ? ' <span style="color:#8c8f94">(chosen here)</span>' : '' ) . '</label>';
	}
	echo '<p class="description">Untick a piece to hide it from visitors on this event.</p>';
	if ( $o['show'] ) {
		echo '<p><label><input type="checkbox" name="tcc_pco_show_reset" value="1"> Go back to the Settings tab choices</label></p>';
	}
	echo '</div>';

	if ( $is_pco ) {
		// Keep mine.
		echo '<div class="tcc-box-col"><h4>Keep the website\'s version</h4>';
		foreach ( tcc_pco_lock_keys() as $key => $label ) {
			echo '<label><input type="checkbox" name="tcc_pco_lock[]" value="' . esc_attr( $key ) . '"' . checked( ! empty( $o['lock'][ $key ] ), true, false ) . '> ' . esc_html( $label ) . '</label>';
		}
		echo '<p class="description">Tick a detail to keep your own version: Planning Center stops changing it. Untick it to hand it back.</p></div>';

		// Rooms.
		$rooms = get_post_meta( $post->ID, '_tcc_pco_rooms', true );
		echo '<div class="tcc-box-col"><h4>Rooms shown</h4>';
		if ( ! is_array( $rooms ) || ! $rooms ) {
			echo '<p><em>No rooms are booked for this date in Planning Center.</em></p>';
		} else {
			$custom = ! empty( $s['event_rooms'][ $event_id ] );
			foreach ( $rooms as $rid => $name ) {
				$label = tcc_pco_room_label( $s, (string) $rid, $name );
				echo '<input type="hidden" name="tcc_pco_rooms_all[]" value="' . esc_attr( $rid ) . '">';
				echo '<label><input type="checkbox" name="tcc_pco_rooms_show[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
			}
			echo '<p class="description">' . ( $custom ? 'These were chosen for this event.' : 'These follow the Rooms tab until you change a tick here.' ) . ' A change applies to every date of this event.</p>';
			if ( $custom ) {
				echo '<p><label><input type="checkbox" name="tcc_pco_rooms_reset" value="1"> Go back to the Rooms tab settings</label></p>';
			}
		}
		echo '</div>';
	}
	echo '</div>';

	if ( $is_pco ) {
		// Description.
		$src  = (string) $o['desc_source'];
		$full = (string) get_post_meta( $post->ID, '_tcc_pco_desc_full', true );
		$sum  = (string) get_post_meta( $post->ID, '_tcc_pco_summary', true );
		if ( '' === $full && '' === $sum ) {
			$full = (string) get_post_meta( $post->ID, '_tcc_pco_description', true );
		}
		$opts = array(
			''            => 'The usual one (Planning Center ' . ( 'summary' === $s['desc_source'] ? 'summary' : 'description' ) . ')',
			'summary'     => 'Planning Center summary',
			'description' => 'Planning Center description',
			'mine'        => 'My own text, typed here',
		);
		echo '<div class="tcc-box-section"><h4>Description on the event page</h4><div class="tcc-field"><label for="tcc_pco_desc_source">Which text to show</label>';
		// Choosing "My own text" opens the box to type it in.
		echo '<select id="tcc_pco_desc_source" name="tcc_pco_desc_source" onchange="document.getElementById(\'tcc_pco_desc_mine\').style.display = ( \'mine\' === this.value ) ? \'block\' : \'none\';">';
		foreach ( $opts as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $src, $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></div>';
		echo '<div class="tcc-field" id="tcc_pco_desc_mine" style="display:' . ( 'mine' === $src ? 'block' : 'none' ) . '"><label for="tcc_pco_desc_text">Your own text</label><textarea id="tcc_pco_desc_text" name="tcc_pco_desc_text" rows="4" style="max-width:none">' . esc_textarea( (string) $o['desc_text'] ) . '</textarea><span class="description">Shown in place of the Planning Center text for this event.</span></div>';
		echo '<details><summary>See what Planning Center has for this event</summary>';
		echo '<p><strong>Summary:</strong> ' . ( '' !== trim( wp_strip_all_tags( $sum ) ) ? esc_html( wp_strip_all_tags( $sum ) ) : '<em>empty</em>' ) . '</p>';
		echo '<p><strong>Description:</strong> ' . ( '' !== trim( wp_strip_all_tags( $full ) ) ? esc_html( wp_strip_all_tags( $full ) ) : '<em>empty</em>' ) . '</p></details></div>';

		// Dates kept, and whether the choices apply to the other dates.
		$own = isset( $s['event_per'][ $event_id ] ) ? (int) $s['event_per'][ $event_id ] : 0;
		echo '<div class="tcc-box-section"><h4>If this event repeats</h4>';
		echo '<div class="tcc-field"><label for="tcc_pco_event_per">Upcoming dates to keep on the website</label><input type="number" id="tcc_pco_event_per" name="tcc_pco_event_per" min="1" max="10" style="width:80px" value="' . ( $own ? (int) $own : '' ) . '" placeholder="' . (int) $s['per_event'] . '"><span class="description">Leave empty for the usual number (' . (int) $s['per_event'] . '). A change shows after the next check.</span></div>';
		echo '<label class="tcc-check" style="border-top:0;padding-top:0"><input type="checkbox" name="tcc_pco_all_dates" value="1" checked><span><strong>Use the choices in this box for the other upcoming dates too</strong>New dates always start with the choices of the date before them. The date and time are never copied.</span></label></div>';
		$reg = (string) get_post_meta( $post->ID, '_tcc_pco_registration_url', true );
		echo '<div class="tcc-box-section"><h4>Register button</h4><p>' . ( '' !== $reg ? 'Planning Center has a registration link for this event (<a href="' . esc_url( $reg ) . '" target="_blank" rel="noopener">open it</a>), so a Register button shows.' : 'Planning Center has no registration link for this event, so no button shows unless you add a link here.' ) . '</p>';
	} else {
		echo '<div class="tcc-box-section"><h4>Register button</h4><p>A Register button shows when you add a link here.</p>';
	}
	echo '<div class="tcc-two">';
	echo '<div class="tcc-field"><label for="tcc_register_url">Button link (optional)</label><input type="url" id="tcc_register_url" name="tcc_register_url" style="max-width:none" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_url', true ) ) . '" placeholder="https://"><span class="description">' . ( $is_pco ? 'Used instead of the Planning Center link.' : 'Where the button goes.' ) . '</span></div>';
	echo '<div class="tcc-field"><label for="tcc_register_label">Button text (optional)</label><input type="text" id="tcc_register_label" name="tcc_register_label" maxlength="40" style="max-width:none" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_label', true ) ) . '" placeholder="Register"><span class="description">For example "Sign up" or "Get tickets". Leave empty for "Register".</span></div>';
	echo '</div></div>';
	echo '<p class="tcc-muted" style="margin:14px 0 0;padding-top:10px;border-top:1px solid #f0f0f1">These choices are saved when you press <strong>Update</strong> for the event.</p>';
}

/** Saves the room ticks from the edit screen. Only becomes the event's own choice when a tick was really changed. */
function tcc_pco_meta_box_save_rooms( $post_id, $event_id ) {
	if ( ! isset( $_POST['tcc_pco_rooms_all'] ) || ! is_array( $_POST['tcc_pco_rooms_all'] ) ) {
		return;
	}
	$s     = tcc_pco_settings();
	$title = get_the_title( $post_id );
	if ( ! is_array( $s['event_rooms'] ) ) {
		$s['event_rooms'] = array();
	}
	if ( ! empty( $_POST['tcc_pco_rooms_reset'] ) ) {
		if ( isset( $s['event_rooms'][ $event_id ] ) ) {
			unset( $s['event_rooms'][ $event_id ] );
			update_option( 'tcc_pco_settings', $s, false );
			tcc_pco_log( '"' . $title . '" follows the Rooms tab again.', $post_id );
		}
		return;
	}
	$all     = array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_all'] ) );
	$show    = isset( $_POST['tcc_pco_rooms_show'] ) && is_array( $_POST['tcc_pco_rooms_show'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_show'] ) ) : array();
	$choice  = isset( $s['event_rooms'][ $event_id ] ) && is_array( $s['event_rooms'][ $event_id ] ) ? $s['event_rooms'][ $event_id ] : array();
	$changed = false;
	foreach ( $all as $rid ) {
		$want = in_array( $rid, $show, true );
		if ( $want !== tcc_pco_room_visible( $s, $event_id, $rid ) ) {
			$changed = true;
		}
		$choice[ $rid ] = $want ? 1 : 0;
	}
	if ( $changed ) {
		$s['event_rooms'][ $event_id ] = $choice;
		update_option( 'tcc_pco_settings', $s, false );
		tcc_pco_log( 'Rooms saved for "' . $title . '": ' . count( $show ) . ' showing.', $post_id );
	}
}

/** Writes the choices of one event, or removes the custom field when there are none. */
function tcc_pco_save_opts( $post_id, $o ) {
	if ( ! $o['show'] && ! $o['lock'] && '' === $o['desc_source'] && '' === trim( (string) $o['desc_text'] ) ) {
		delete_post_meta( $post_id, '_tcc_pco_opts' );
	} else {
		update_post_meta( $post_id, '_tcc_pco_opts', wp_slash( $o ) );
	}
}

function tcc_pco_meta_box_save( $post_id ) {
	static $busy = false; // This function changes events itself further down; do not run it again for those changes.
	if ( $busy ) {
		return;
	}
	if ( ! isset( $_POST['_tcc_pco_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_tcc_pco_box_nonce'] ) ), 'tcc_pco_box' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['post_ID'] ) && (int) $_POST['post_ID'] !== (int) $post_id ) {
		return; // Some other event is being saved as a side effect.
	}

	// Registration button.
	$url = isset( $_POST['tcc_register_url'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['tcc_register_url'] ) ) ) : '';
	if ( '' === $url ) {
		delete_post_meta( $post_id, '_tcc_register_url' );
	} else {
		update_post_meta( $post_id, '_tcc_register_url', $url );
	}
	$label = isset( $_POST['tcc_register_label'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['tcc_register_label'] ) ) ) : '';
	$label = function_exists( 'mb_substr' ) ? mb_substr( $label, 0, 40 ) : substr( $label, 0, 40 );
	if ( '' === $label ) {
		delete_post_meta( $post_id, '_tcc_register_label' );
	} else {
		update_post_meta( $post_id, '_tcc_register_label', $label );
	}

	$s        = tcc_pco_settings();
	$o        = tcc_pco_post_opts( $post_id );
	$old_lock = $o['lock'];
	$event_id = (string) get_post_meta( $post_id, '_tcc_pco_event_id', true );
	$is_pco   = '' !== $event_id && ! empty( $_POST['tcc_pco_synced_form'] );

	// What shows. A tick only becomes this event's own choice when it differs from what was showing.
	if ( isset( $_POST['tcc_pco_show_all'] ) && is_array( $_POST['tcc_pco_show_all'] ) ) {
		if ( ! empty( $_POST['tcc_pco_show_reset'] ) ) {
			$o['show'] = array();
		} else {
			$all   = array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_show_all'] ) );
			$shown = isset( $_POST['tcc_pco_show'] ) && is_array( $_POST['tcc_pco_show'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_show'] ) ) : array();
			foreach ( array_intersect( array_keys( tcc_pco_show_keys() ), $all ) as $key ) {
				$want = in_array( $key, $shown, true );
				if ( $want !== tcc_pco_shows( $post_id, $key, $s ) ) {
					$o['show'][ $key ] = $want ? 1 : 0;
				}
			}
		}
	}

	if ( $is_pco ) {
		// Keep mine.
		$locks     = isset( $_POST['tcc_pco_lock'] ) && is_array( $_POST['tcc_pco_lock'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['tcc_pco_lock'] ) ) : array();
		$o['lock'] = array();
		foreach ( array_intersect( array_keys( tcc_pco_lock_keys() ), $locks ) as $key ) {
			$o['lock'][ $key ] = 1;
		}
		// Description.
		$src              = isset( $_POST['tcc_pco_desc_source'] ) ? sanitize_key( wp_unslash( $_POST['tcc_pco_desc_source'] ) ) : '';
		$o['desc_source'] = in_array( $src, array( 'summary', 'description', 'mine' ), true ) ? $src : '';
		$o['desc_text']   = isset( $_POST['tcc_pco_desc_text'] ) ? wp_kses_post( trim( (string) wp_unslash( $_POST['tcc_pco_desc_text'] ) ) ) : '';
	}
	tcc_pco_save_opts( $post_id, $o );
	if ( ! $is_pco ) {
		return;
	}

	// Details handed back to Planning Center: its version is put back by the sync just below.
	$unlocked = array_keys( array_diff_key( $old_lock, $o['lock'] ) );
	if ( $unlocked ) {
		update_post_meta( $post_id, '_tcc_pco_force', $unlocked );
	}

	// How many upcoming dates to keep.
	$per = isset( $_POST['tcc_pco_event_per'] ) ? absint( $_POST['tcc_pco_event_per'] ) : 0;
	$had = isset( $s['event_per'][ $event_id ] ) ? (int) $s['event_per'][ $event_id ] : 0;
	$per = $per ? max( 1, min( 10, $per ) ) : 0;
	if ( $per !== $had ) {
		if ( ! is_array( $s['event_per'] ) ) {
			$s['event_per'] = array();
		}
		if ( $per ) {
			$s['event_per'][ $event_id ] = $per;
		} else {
			unset( $s['event_per'][ $event_id ] );
		}
		update_option( 'tcc_pco_settings', $s, false );
	}

	tcc_pco_meta_box_save_rooms( $post_id, $event_id );

	$busy = true;

	// The other upcoming dates of the same event get the same choices (never the date and time).
	if ( ! empty( $_POST['tcc_pco_all_dates'] ) ) {
		foreach ( tcc_pco_posts_for( $event_id ) as $other ) {
			if ( (int) $other->ID === (int) $post_id || tcc_pco_post_passed( $other->ID ) || get_post_meta( $other->ID, '_tcc_pco_paused', true ) ) {
				continue;
			}
			$theirs = tcc_pco_post_opts( $other->ID );
			$new    = $o;
			unset( $new['lock']['dates'] );
			if ( ! empty( $theirs['lock']['dates'] ) ) {
				$new['lock']['dates'] = 1;
			}
			$handed_back = array_keys( array_diff_key( $theirs['lock'], $new['lock'] ) );
			tcc_pco_save_opts( $other->ID, $new );
			if ( $handed_back ) {
				update_post_meta( $other->ID, '_tcc_pco_force', $handed_back );
			}
			tcc_pco_inherit_apply( $other->ID, array( 'from' => (int) $post_id, 'opts' => $new ) );
			foreach ( array( '_tcc_register_url' => $url, '_tcc_register_label' => $label ) as $meta_key => $value ) {
				if ( '' === $value ) {
					delete_post_meta( $other->ID, $meta_key );
				}
			}
			if ( ! empty( $new['lock']['title'] ) ) {
				$title = (string) get_post_field( 'post_title', $post_id, 'raw' );
				if ( $title !== (string) get_post_field( 'post_title', $other->ID, 'raw' ) ) {
					wp_update_post( array( 'ID' => $other->ID, 'post_title' => wp_slash( $title ) ) );
				}
			}
		}
	}

	// Bring the event in line with the new choices straight away (this uses what was last read from
	// Planning Center; it does not contact Planning Center).
	$items = tcc_pco_items();
	if ( isset( $items[ $event_id ]['status'] ) && 'approved' === $items[ $event_id ]['status'] && empty( $items[ $event_id ]['gone'] ) && ! empty( $items[ $event_id ]['data'] ) ) {
		tcc_pco_apply_event( $items[ $event_id ]['data'] );
	}
	$busy = false;
}
add_action( 'save_post_tribe_events', 'tcc_pco_meta_box_save', 20 );
