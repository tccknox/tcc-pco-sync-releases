<?php
/**
 * TCC Website, Planning Center events: the screens (the menu, the page and its event lists).
 * Part: the screens: menu, page and event lists
 * Part of the TCC Website plugin since 0.12.0 (before 0.12.0 it was a separate plugin). Loaded by features/planning-center.php,
 * only inside the admin (is_admin(), which includes admin-post.php where every button goes).
 * Until 0.14.4 the four screen files (admin.php, admin-tabs.php, admin-buttons.php, admin-event-box.php) were one
 * file. They were cut into four, with the code unchanged, so that an AI asked to return a whole file has less to return.
 *
 * In this file: the TCC Website > Planning Center menu item and its count; the page itself with its tabs
 * (tcc_pco_admin_page); the Waiting for approval and On the website lists (tcc_pco_table) with the Approve form;
 * the Conflicts table; small pieces the other screen files use (tcc_pco_url, tcc_pco_help_url, tcc_pco_button,
 * tcc_pco_when, tcc_pco_event_rooms); and the look of these screens (tcc_pco_admin_css).
 * The other tabs are in admin-tabs.php, what the buttons do is in admin-buttons.php, and the box on an
 * event's edit screen is in admin-event-box.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Wrapped so that nothing is set up twice: if a saved edit of this file (TCC Website > Features) fails part-way,
// the original is loaded after it, and this test makes the original step aside. Keep the name it tests.
if ( ! function_exists( 'tcc_pco_admin_page' ) ) {

	/** How many things wait for a person: new events and conflicts. Shown beside TCC Website in the menu. */
	function tcc_pco_waiting_count() {
		$count = 0;
		foreach ( tcc_pco_items() as $item ) {
			if ( isset( $item['status'] ) && 'new' === $item['status'] && empty( $item['gone'] ) ) {
				$count++;
			}
		}
		return $count + count( tcc_pco_conflicts() );
	}

	/** TCC Website > Planning Center. Its page address stays page=tcc-pco-sync, so every link inside it keeps working. */
	function tcc_pco_admin_menu() {
		$count = tcc_pco_waiting_count();
		$badge = $count ? ' <span class="awaiting-mod">' . (int) $count . '</span>' : '';
		add_submenu_page( 'tcc-site-features', 'TCC Website: Planning Center', 'Planning Center' . $badge, 'manage_options', 'tcc-pco-sync', 'tcc_pco_admin_page', 0 );
	}
	add_action( 'admin_menu', 'tcc_pco_admin_menu', 10 );

	function tcc_pco_url( $tab = 'waiting', $extra = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'tcc-pco-sync', 'tab' => $tab ), $extra ), admin_url( 'admin.php' ) );
	}

	/** Where the Planning Center help is: the Planning Center group on TCC Website > Features. $spot is a part of it. */
	function tcc_pco_help_url( $spot = 'tcc-area-planning-center' ) {
		return add_query_arg( array( 'page' => 'tcc-site-features', 'tab' => 'features' ), admin_url( 'admin.php' ) ) . '#' . $spot;
	}

	/** A small button that posts one action. */
	function tcc_pco_button( $op, $label, $fields = array(), $class = 'button', $confirm = '' ) {
		$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 6px 4px 0"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
		$html .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
		$html .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
		foreach ( $fields as $k => $v ) {
			$html .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
		return $html;
	}

	function tcc_pco_when( $ev ) {
		$out = array();
		foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
			$dt = tcc_pco_local( $inst['starts'] );
			if ( $dt ) {
				$out[] = esc_html( $dt->format( ! empty( $inst['all_day'] ) ? 'D, M j, Y' : 'D, M j, Y \a\t g:i a' ) );
			}
		}
		return $out ? implode( '<br>', $out ) : '<em>No upcoming dates</em>';
	}

	/** Room names booked for any upcoming date of an event. */
	function tcc_pco_event_rooms( $ev ) {
		$rooms = array();
		foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
			if ( isset( $inst['rooms'] ) && is_array( $inst['rooms'] ) ) {
				foreach ( $inst['rooms'] as $rid => $name ) {
					$rooms[ (string) $rid ] = trim( (string) $name );
				}
			}
		}
		asort( $rooms );
		return $rooms;
	}

	/**
	 * On the website tab: the rooms booked for one event, each with a tick for "show on this event's pages".
	 * Ticks start from the Rooms tab. Once saved here, this event keeps its own choices.
	 */
	function tcc_pco_event_rooms_form( $event_id, $rooms ) {
		if ( ! $rooms ) {
			return '<br><span style="color:#8c8f94">Rooms: none booked in Planning Center.</span>';
		}
		$s      = tcc_pco_settings();
		$custom = ! empty( $s['event_rooms'][ $event_id ] );
		$html   = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:10px 0 4px;padding:10px 12px;background:#f6f7f7;border-radius:8px">';
		$html  .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_event_rooms"><input type="hidden" name="id" value="' . esc_attr( $event_id ) . '">';
		$html  .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
		$html  .= '<strong>Rooms shown on this event\'s page</strong> <span style="color:#50575e">(' . ( $custom ? 'chosen for this event' : 'following the Rooms tab' ) . ')</span><br>';
		foreach ( $rooms as $rid => $name ) {
			$label = tcc_pco_room_label( $s, (string) $rid, $name );
			$html .= '<input type="hidden" name="all_rooms[]" value="' . esc_attr( $rid ) . '">';
			$html .= '<label style="display:inline-block;margin:4px 14px 2px 0;white-space:nowrap"><input type="checkbox" name="show_rooms[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, (string) $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
		}
		$html .= '<br><button type="submit" class="button button-small" style="margin-top:6px">Save rooms for this event</button>';
		if ( $custom ) {
			$html .= ' <button type="submit" name="reset" value="1" class="button button-small button-link" style="margin:6px 0 0 8px">Go back to the Rooms tab settings</button>';
		}
		return $html . '</form>';
	}

	/** The tags of an event: public ones with their website category, internal ones greyed. */
	function tcc_pco_tags_html( $ev ) {
		if ( empty( $ev['tags'] ) ) {
			return '';
		}
		$s      = tcc_pco_settings();
		$public = array();
		$inside = array();
		foreach ( (array) $ev['tags'] as $tid => $name ) {
			$term = ! empty( $s['tag_map'][ $tid ] ) ? get_term( (int) $s['tag_map'][ $tid ], 'tribe_events_cat' ) : null;
			if ( $term && ! is_wp_error( $term ) ) {
				$public[] = '<span style="background:#e5f5fa;border:1px solid #00a4cf;border-radius:3px;padding:1px 6px;margin-right:4px;white-space:nowrap">' . esc_html( trim( $name ) ) . ' &rarr; ' . esc_html( $term->name ) . '</span>';
			} else {
				$inside[] = esc_html( trim( $name ) );
			}
		}
		$html = '<br><span style="line-height:2">On the website as: ' . ( $public ? implode( '', $public ) : '<em>no category</em>' ) . '</span>';
		if ( $inside ) {
			$html .= '<br><span style="color:#8c8f94">Internal tags (not shown): ' . implode( ', ', $inside ) . '</span>';
		}
		return $html;
	}

	/**
	 * The look of the plugin's screens: white rounded panels, small status labels, one event per panel.
	 * Printed once, on the plugin's own screen and in the box on the event edit screen.
	 */
	function tcc_pco_admin_css() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		echo '<style>'
			. '.tcc-pco{max-width:1280px}'
			. '.tcc-pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:600;line-height:1.7;white-space:nowrap;vertical-align:middle}'
			. '.tcc-pill--ok{background:#e6f6ea;color:#0a6b25}.tcc-pill--warn{background:#fcf3d7;color:#7a5200}.tcc-pill--bad{background:#fbe9e9;color:#8a1f1f}.tcc-pill--muted{background:#f0f0f1;color:#50575e}.tcc-pill--teal{background:#e5f5fa;color:#046c8a}'
			. '.tcc-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px 18px;margin:0 0 14px}'
			. '.tcc-card>h2:first-child,.tcc-card>h3:first-child{margin-top:0}'
			. '.tcc-card h2{font-size:16px;margin:22px 0 8px}'
			. '.tcc-muted{color:#50575e}'
			. '.tcc-section-title{font-size:14px;margin:24px 0 10px}'
			. '.tcc-empty{background:#fff;border:1px dashed #c3c4c7;border-radius:8px;padding:22px 18px;color:#50575e;margin:0 0 14px}'
			. '.tcc-event{display:grid;grid-template-columns:150px minmax(0,1fr) 200px 240px;gap:18px;align-items:start}'
			. '.tcc-event__img img{width:150px;height:auto;border-radius:6px;display:block}'
			. '.tcc-noimg{width:150px;aspect-ratio:16/9;background:#f0f0f1;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#8c8f94;font-size:12px}'
			. '.tcc-event__title{font-size:15px;font-weight:600;margin:0 0 4px;line-height:1.35}'
			. '.tcc-event__text{margin:0 0 8px;color:#3c434a}'
			. '.tcc-event__meta{margin:4px 0 0;color:#50575e;line-height:1.9}'
			. '.tcc-label{display:block;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#787c82;margin:0 0 4px}'
			. '.tcc-event__actions>form{display:block!important;margin:0 0 8px!important}'
			. '.tcc-event__actions>form>.button{width:100%;text-align:center;min-height:36px}'
			. '.tcc-event__actions .button-link-delete{border-color:transparent;background:transparent}'
			. '@media(max-width:1180px){.tcc-event{grid-template-columns:120px minmax(0,1fr)}.tcc-event__img img,.tcc-noimg{width:120px}.tcc-event__dates,.tcc-event__actions{grid-column:2}}'
			. '@media(max-width:600px){.tcc-event{grid-template-columns:1fr}.tcc-event__dates,.tcc-event__actions{grid-column:1}}'
			. '.tcc-pco table.widefat{border-radius:8px;overflow:hidden;border-color:#dcdcde}'
			. '.tcc-pco .form-table th{padding-left:0}'
			. '.tcc-card[id]{scroll-margin-top:46px}'
			. '.tcc-savebar{position:sticky;bottom:0;z-index:5;display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 18px;margin:0 0 14px;box-shadow:0 -3px 10px rgba(0,0,0,.06)}'
			. '.tcc-savebar .button-primary{min-height:38px;padding:0 20px}'
			. '.tcc-row{display:grid;gap:8px 16px;align-items:center;padding:9px 0;border-top:1px solid #f0f0f1}'
			. '.tcc-row--head{border-top:0;padding:0 0 6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#787c82}'
			. '.tcc-row--on .tcc-row__name{font-weight:600}'
			. '.tcc-row select,.tcc-row input[type=text]{width:100%;max-width:none}'
			. '@media(max-width:860px){.tcc-row{grid-template-columns:1fr!important}.tcc-row--head{display:none}}'
			. '.tcc-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px 28px}'
			. '.tcc-field{margin:0 0 12px}'
			. '.tcc-field>label,.tcc-field__label{display:block;font-weight:600;margin:0 0 5px}'
			. '.tcc-field input[type=text],.tcc-field input[type=url],.tcc-field input[type=password],.tcc-field select,.tcc-field textarea{width:100%;max-width:520px}'
			. '.tcc-field .description{display:block;margin-top:5px;color:#50575e}'
			. '.tcc-check{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-top:1px solid #f0f0f1}'
			. '.tcc-check:first-of-type{border-top:0}'
			. '.tcc-check input{margin-top:3px;flex:0 0 auto}'
			. '.tcc-check strong{display:block}'
			. '.tcc-check span{color:#50575e}'
			. '.tcc-pco details,#tcc_pco_box details{margin:8px 0 0}'
			. '.tcc-pco summary,#tcc_pco_box summary{cursor:pointer;color:#2271b1;padding:4px 0}'
			. '.tcc-box-grid{display:flex;flex-wrap:wrap;gap:14px;margin:12px 0}'
			. '.tcc-box-col{flex:1 1 230px;min-width:0;background:#f6f7f7;border-radius:8px;padding:12px 14px}'
			. '.tcc-box-col h4{margin:0 0 6px;font-size:13px}'
			. '.tcc-box-col label{display:block;margin:5px 0}'
			. '.tcc-box-section{border-top:1px solid #f0f0f1;margin-top:14px;padding-top:12px}'
			. '.tcc-box-section h4{margin:0 0 6px;font-size:13px}'
			. '</style>';
	}

	function tcc_pco_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab         = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'waiting';
		$items       = tcc_pco_items();
		$conflicts   = tcc_pco_conflicts();
		$groups      = array( 'new' => array(), 'approved' => array(), 'ignored' => array(), 'unsynced' => array() );
		$passed      = 0;
		$unpublished = 0;
		foreach ( $items as $id => $item ) {
			$status = isset( $item['status'] ) ? $item['status'] : 'new';
			if ( tcc_pco_item_passed( $item ) ) {
				// Over and done: not listed any more. Its website pages keep the last details they had.
				$passed += in_array( $status, array( 'approved', 'unsynced' ), true ) ? 1 : 0;
				continue;
			}
			if ( ! empty( $item['gone'] ) ) {
				// Taken off Church Center in Planning Center: not listed here either. Its upcoming dates were
				// removed from the website when that was noticed. Publish it again and it comes back as it was.
				$unpublished += 'approved' === $status ? 1 : 0;
				continue;
			}
			if ( isset( $groups[ $status ] ) && ! empty( $item['data'] ) ) {
				$groups[ $status ][ $id ] = $item;
			}
		}
		$s        = tcc_pco_settings();
		$new_tags = count( array_diff( array_keys( tcc_pco_known_tags() ), array_map( 'strval', (array) $s['tags_seen'] ) ) );
		$tabs     = array(
			'waiting'   => 'Waiting for approval (' . count( $groups['new'] ) . ')',
			'synced'    => 'On the website (' . count( $groups['approved'] ) . ')',
			'conflicts' => 'Conflicts (' . count( $conflicts ) . ')',
			'changes'   => 'Recent changes',
			'tags'      => 'Tags' . ( $new_tags ? ' (' . $new_tags . ' new)' : '' ),
			'rooms'     => 'Rooms',
			'settings'  => 'Settings',
		);
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'waiting';
		}
		$last = get_option( 'tcc_pco_last_run', array() );

		tcc_pco_admin_css();
		if ( '' === $s['app_id'] || '' === $s['secret'] ) {
			$status = tcc_site_pill( 'bad', 'Not connected' );
		} elseif ( empty( $last['time'] ) ) {
			$status = tcc_site_pill( 'muted', 'Not checked yet' );
		} elseif ( empty( $last['ok'] ) ) {
			$status = tcc_site_pill( 'bad', ( ! empty( $last['held'] ) ? 'Needs a look: checked ' : 'Last check failed ' ) . human_time_diff( (int) $last['time'] ) . ' ago', isset( $last['message'] ) ? $last['message'] : '' );
		} else {
			$status = tcc_site_pill( 'ok', 'Checked ' . human_time_diff( (int) $last['time'] ) . ' ago', isset( $last['message'] ) ? $last['message'] : '' );
		}
		$status  .= tcc_pco_button( 'check_now', 'Check Planning Center now', array( 'tab' => $tab ), 'button button-primary' );
		$sentence = 'Events published to Church Center in Planning Center show up here. Nothing goes on the website until you approve it, and Planning Center is never changed. <a href="' . esc_url( tcc_pco_help_url() ) . '">How this works</a>';
		$nav      = array();
		foreach ( $tabs as $key => $label ) {
			$nav[ $key ] = array( 'label' => $label, 'url' => tcc_pco_url( $key ) );
		}
		echo '<div class="wrap tcc-site tcc-pco">';
		tcc_site_screen_header( 'Planning Center', $sentence, $status, $nav, $tab );
		// What the last button did. The words are kept on the website for a minute (see tcc_pco_handle), never
		// taken from the page address, so a link sent by someone else cannot show a made-up message here.
		if ( isset( $_GET['tcc_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only says whether to look for the message.
			$notice = get_transient( 'tcc_pco_notice_' . get_current_user_id() );
			if ( is_string( $notice ) && '' !== $notice ) {
				delete_transient( 'tcc_pco_notice_' . get_current_user_id() );
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
			}
		}
		if ( ! function_exists( 'tribe_create_event' ) ) {
			echo '<div class="notice notice-error"><p>The Events Calendar plugin is not active, so events cannot be added to the website.</p></div>';
		}

		if ( ! empty( $last['time'] ) && empty( $last['ok'] ) && ! empty( $last['message'] ) ) {
			if ( ! empty( $last['held'] ) ) {
				// The guard in tcc_pco_ingest() held back removals. Only a person can say whether Planning Center was right.
				echo '<div class="notice notice-error inline"><p><strong>Nothing was taken off the website.</strong> ' . esc_html( $last['message'] ) . '</p><p>'
					. tcc_pco_button( 'check_remove', 'They were taken off: remove them', array( 'tab' => $tab ), 'button', 'Check Planning Center again and move the upcoming website dates of every event it no longer lists to the Trash?' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* inside.
					. '</p></div>';
			} else {
				echo '<div class="notice notice-error inline"><p>The last check did not work: ' . esc_html( $last['message'] ) . '</p></div>';
			}
		}

		if ( function_exists( 'tcc_site_pco_tab_help' ) ) {
			echo tcc_site_fold( 'How this tab works', tcc_site_pco_tab_help( $tab ), 'tcc-tabhelp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed help wording.
		}
		echo '<div>';

		if ( 'waiting' === $tab ) {
			if ( '' === $s['app_id'] || '' === $s['secret'] ) {
				echo '<div class="tcc-card"><strong>Planning Center is not connected yet.</strong> Add the Application ID and Secret on the <a href="' . esc_url( tcc_pco_url( 'settings' ) ) . '">Settings</a> tab.</div>';
			}
			tcc_pco_table( $groups['new'], 'waiting', 'Nothing is waiting. When an event is published to Church Center in Planning Center, it appears here within the hour.' );
			if ( $groups['ignored'] ) {
				echo '<h3 class="tcc-section-title">Hidden (you chose not to put these on the website)</h3>';
				tcc_pco_table( $groups['ignored'], 'ignored', '' );
			}
		} elseif ( 'synced' === $tab ) {
			tcc_pco_table( $groups['approved'], 'synced', 'No events are on the website from Planning Center yet. Approve one on the Waiting for approval tab.' );
			if ( $groups['unsynced'] ) {
				echo '<h3 class="tcc-section-title">Stopped (no longer kept up to date)</h3>';
				tcc_pco_table( $groups['unsynced'], 'unsynced', '' );
			}
			if ( $unpublished ) {
				echo '<p class="tcc-muted">' . (int) $unpublished . ' approved event' . ( 1 === $unpublished ? ' is' : 's are' ) . ' no longer published to Church Center in Planning Center, so ' . ( 1 === $unpublished ? 'it is' : 'they are' ) . ' not listed and ' . ( 1 === $unpublished ? 'its' : 'their' ) . ' upcoming dates were taken off the website. Publish ' . ( 1 === $unpublished ? 'it' : 'them' ) . ' again and ' . ( 1 === $unpublished ? 'it comes' : 'they come' ) . ' back.</p>';
			}
			if ( $passed ) {
				echo '<p class="tcc-muted">' . (int) $passed . ' event' . ( 1 === $passed ? ' has' : 's have' ) . ' passed and ' . ( 1 === $passed ? 'is' : 'are' ) . ' no longer listed here. Their pages stay on the website with the last details they had.</p>';
			}
		} elseif ( 'conflicts' === $tab ) {
			tcc_pco_conflicts_table( $conflicts );
		} elseif ( 'changes' === $tab ) {
			$log = get_option( 'tcc_pco_log', array() );
			if ( ! $log ) {
				echo '<div class="tcc-empty">Nothing has happened yet. Everything the plugin does to the website is written down here.</div>';
			} else {
				echo '<p class="tcc-muted">Everything the plugin has done to the website, newest first. The last 150 are kept.</p>';
				echo '<table class="widefat striped"><thead><tr><th style="width:180px">When</th><th>What happened</th><th style="width:120px"></th></tr></thead><tbody>';
				foreach ( (array) $log as $row ) {
					echo '<tr><td>' . esc_html( wp_date( 'M j, Y g:i a', (int) $row['time'] ) ) . '</td><td>' . esc_html( $row['message'] ) . '</td><td>';
					if ( ! empty( $row['post_id'] ) && get_post( (int) $row['post_id'] ) && 'trash' !== get_post_status( (int) $row['post_id'] ) ) {
						echo '<a href="' . esc_url( (string) get_edit_post_link( (int) $row['post_id'] ) ) . '">Open event</a>';
					}
					echo '</td></tr>';
				}
				echo '</tbody></table>';
			}
		} elseif ( 'tags' === $tab ) {
			tcc_pco_tags_form( $s, $items );
		} elseif ( 'rooms' === $tab ) {
			tcc_pco_rooms_form( $s, $items );
		} else {
			tcc_pco_settings_form( $s, $items );
		}
		echo '</div></div>';
	}

	/** A list of events, one white panel each: graphic, what it is, its next dates, and the buttons. */
	function tcc_pco_table( $rows, $mode, $empty ) {
		if ( ! $rows ) {
			if ( $empty ) {
				echo '<div class="tcc-empty">' . esc_html( $empty ) . '</div>';
			}
			return;
		}
		$sets = tcc_pco_settings();
		foreach ( $rows as $id => $item ) {
			$ev = $item['data'];
			echo '<div class="tcc-card tcc-event"><div class="tcc-event__img">';
			if ( ! empty( $ev['image_url'] ) ) {
				echo '<img src="' . esc_url( $ev['image_url'] ) . '" alt="">';
			} else {
				echo '<div class="tcc-noimg">No graphic</div>';
			}
			echo '</div><div class="tcc-event__main"><p class="tcc-event__title">' . esc_html( $ev['name'] ) . '</p>';

			// Show the text visitors will get: the description or the summary, as chosen on the Settings tab.
			$text = 'summary' === $sets['desc_source'] ? ( '' !== $ev['summary'] ? $ev['summary'] : $ev['description'] ) : ( '' !== $ev['description'] ? $ev['description'] : $ev['summary'] );
			$text = wp_strip_all_tags( $text );
			if ( '' !== $text ) {
				echo '<p class="tcc-event__text">' . esc_html( wp_html_excerpt( $text, 220, '...' ) ) . '</p>';
			}
			$bits   = array();
			$bits[] = ! empty( $ev['registration_url'] ) ? '<span class="tcc-pill tcc-pill--teal">Registration link</span>' : '<span class="tcc-pill tcc-pill--muted">No registration link</span>';
			$bits[] = ! empty( $ev['image_url'] ) ? '' : '<span class="tcc-pill tcc-pill--muted">Uses the default graphic</span>';
			echo '<p class="tcc-event__meta">' . implode( ' ', array_filter( $bits ) ) . '</p>';
			$rooms = tcc_pco_event_rooms( $ev );
			if ( $rooms && 'synced' !== $mode ) {
				echo '<p class="tcc-event__meta">Rooms: ' . esc_html( implode( ', ', $rooms ) ) . '</p>';
			}
			echo '<p class="tcc-event__meta" style="margin-top:0">' . preg_replace( '#^<br>#', '', tcc_pco_tags_html( $ev ) ) . '</p>';
			if ( 'synced' === $mode ) {
				echo tcc_pco_event_rooms_form( $id, $rooms );
			}
			$links = array();
			if ( 'synced' === $mode || 'unsynced' === $mode ) {
				foreach ( tcc_pco_posts_for( $id ) as $post ) {
					if ( tcc_pco_post_passed( $post->ID ) ) {
						continue; // Dates that are over are left alone and not listed.
					}
					$links[] = '<a href="' . esc_url( (string) get_edit_post_link( $post->ID ) ) . '">' . esc_html( mysql2date( 'M j', (string) get_post_meta( $post->ID, '_EventStartDate', true ) ) ) . '</a>';
				}
			}
			echo '<p class="tcc-event__meta">' . ( $links ? 'Edit on the website: ' . implode( ', ', $links ) . ' &nbsp;|&nbsp; ' : '' ) . '<a href="' . esc_url( tcc_pco_pc_link( $id ) ) . '" target="_blank" rel="noopener">Edit in Planning Center</a></p>';

			echo '</div><div class="tcc-event__dates"><span class="tcc-label">Next dates</span>' . tcc_pco_when( $ev ) . '</div><div class="tcc-event__actions">';
			$f = array( 'id' => $id );
			if ( 'waiting' === $mode ) {
				echo tcc_pco_approve_form( $id, $ev );
				echo tcc_pco_button( 'ignore', 'Hide', $f );
			} elseif ( 'ignored' === $mode ) {
				echo tcc_pco_button( 'restore', 'Move back to waiting', $f );
			} elseif ( 'synced' === $mode ) {
				echo tcc_pco_button( 'unsync_keep', 'Stop syncing, keep on website', $f );
				echo tcc_pco_button( 'unsync_remove', 'Stop syncing and remove', $f, 'button button-link-delete', 'Move the upcoming website dates of this event to the Trash?' );
			} else {
				echo tcc_pco_button( 'approve', 'Start syncing again', $f );
				echo tcc_pco_button( 'ignore', 'Hide', $f ); // Moves it to the Hidden list on the Waiting for approval tab.
			}
			echo '</div></div>';
		}
	}

	/**
	 * The Approve button. When the website already has a hand-made event with the same name, it is listed
	 * with a tick: ticked ones go to the Trash on approval, and their graphic and page content carry over.
	 */
	function tcc_pco_approve_form( $id, $ev ) {
		$matches = tcc_pco_handmade_matches( $ev );
		if ( ! $matches ) {
			return tcc_pco_button( 'approve', 'Approve and add to website', array( 'id' => $id ), 'button button-primary' );
		}
		$ask   = 'Move the ticked hand-made events to the Trash and put the Planning Center event in their place?';
		$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0 0 8px;padding:12px;background:#fcf9e8;border:1px solid #f0c33c;border-radius:8px" onsubmit="return !this.querySelector(\'input[type=checkbox]:checked\') || confirm(\'' . esc_js( $ask ) . '\')">';
		$html .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="approve"><input type="hidden" name="id" value="' . esc_attr( $id ) . '">';
		$html .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
		$html .= '<strong>Already on the website (made by hand):</strong>';
		foreach ( $matches as $post_id => $row ) {
			$when  = mysql2date( 'M j, Y', $row['next'] );
			$what  = $row['count'] > 1 ? 'repeating, ' . (int) $row['count'] . ' upcoming dates, next ' . $when : $when;
			$html .= '<label style="display:block;margin:6px 0"><input type="checkbox" name="replace[]" value="' . (int) $post_id . '"' . checked( $row['same_day'], true, false ) . '> Replace "' . esc_html( $row['title'] ) . '" (' . esc_html( $what ) . ')' . ( $row['same_day'] ? '' : ' <span style="color:#996800">different day: may be a different occasion</span>' ) . ' <a href="' . esc_url( (string) get_edit_post_link( $post_id ) ) . '" target="_blank" rel="noopener">open</a></label>';
		}
		$html .= '<p class="description" style="margin:6px 0 8px">A ticked event is moved to the Trash when you approve, so visitors do not see the event twice. Its graphic, page content and categories are carried over to the Planning Center event. You can restore it from Events &rarr; Trash. A repeating hand-made event is a single item, so its past dates go to the Trash with it.</p>';
		$html .= '<button type="submit" class="button button-primary">Approve and add to website</button></form>';
		return $html;
	}

	function tcc_pco_conflicts_table( $conflicts ) {
		if ( ! $conflicts ) {
			echo '<div class="tcc-empty">No conflicts. A conflict appears when something was changed on the website and was also changed in Planning Center, so the sync cannot tell which one you want.</div>';
			return;
		}
		echo '<p>These were changed in both places. Nothing has been overwritten. Choose which version to keep.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Event</th><th style="width:90px">What</th><th>On the website now</th><th>In Planning Center</th><th style="width:300px">Choose</th></tr></thead><tbody>';
		foreach ( $conflicts as $key => $c ) {
			$post = get_post( (int) $c['post_id'] );
			echo '<tr><td>' . ( $post ? '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( get_the_title( $post ) ) . '</a>' : '<em>Event no longer exists</em>' ) . '</td>';
			echo '<td>' . esc_html( tcc_pco_field_label( $c['field'] ) ) . '</td>';
			if ( 'image' === $c['field'] ) {
				echo '<td>' . ( $post && has_post_thumbnail( $post ) ? get_the_post_thumbnail( $post, array( 120, 68 ) ) : esc_html( $c['website'] ) ) . '</td>';
				echo '<td><img src="' . esc_url( $c['pco'] ) . '" alt="" style="width:120px;height:auto"></td>';
			} else {
				echo '<td>' . esc_html( $c['website'] ) . '</td><td>' . esc_html( $c['pco'] ) . '</td>';
			}
			echo '<td>' . tcc_pco_button( 'resolve', 'Use Planning Center', array( 'key' => $key, 'choice' => 'pco' ), 'button button-primary' );
			echo tcc_pco_button( 'resolve', 'Keep website', array( 'key' => $key, 'choice' => 'site' ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	function tcc_pco_admin_assets() {
		if ( isset( $_GET['page'] ) && 'tcc-pco-sync' === $_GET['page'] ) {
			wp_enqueue_media();
		}
	}
	add_action( 'admin_enqueue_scripts', 'tcc_pco_admin_assets' );

}
