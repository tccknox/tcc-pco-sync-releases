<?php
/**
 * TCC Planning Center Sync: updates from GitHub.
 *
 * How it works:
 *  - New versions are published to a public repository that holds nothing but the built plugin:
 *    TCC_PCO_RELEASES. It has two files: tcc-pco-sync.zip and latest.json (version, download link,
 *    checksum, notes). They are written automatically when a version is tagged in the church's
 *    private website repository (see .github/workflows/release-pco-sync.yml there).
 *  - When WordPress looks for plugin updates, this file reads latest.json. If its version is higher
 *    than the installed one, the normal "Update available" notice shows on the Plugins screen.
 *    Nothing installs by itself: a person presses "Update now".
 *  - No key or password is needed or stored on the website. The download is checked against the
 *    checksum in latest.json before it is installed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_PCO_RELEASES', 'tccknox/tcc-pco-sync-releases' );
define( 'TCC_PCO_RELEASES_RAW', 'https://raw.githubusercontent.com/' . TCC_PCO_RELEASES . '/' );

/**
 * Is this download link Planning Center Sync's own published zip? Exactly: the releases address,
 * one version name (never "..", so it cannot step out of the repository) and tcc-pco-sync.zip.
 * The same repository also holds TCC Website Features in its own folder, which is not ours.
 */
function tcc_pco_update_is_ours( $url ) {
	$shape = '#^' . preg_quote( TCC_PCO_RELEASES_RAW, '#' ) . '[A-Za-z0-9_][A-Za-z0-9._-]*/tcc-pco-sync\.zip$#';
	return is_string( $url ) && 1 === preg_match( $shape, $url ) && false === strpos( $url, '..' );
}

function tcc_pco_update_basename() {
	return plugin_basename( __DIR__ . '/tcc-pco-sync.php' );
}

function tcc_pco_update_note( $ok, $message ) {
	update_option( 'tcc_pco_update_status', array( 'time' => time(), 'ok' => (bool) $ok, 'message' => (string) $message ), false );
}

/**
 * The newest published version, or null. Asked at most every six hours unless $fresh is true.
 * Returns array( 'version', 'asset_url', 'sha256', 'page', 'notes', 'date' ).
 */
function tcc_pco_update_latest( $fresh = false ) {
	if ( ! $fresh ) {
		$cached = get_transient( 'tcc_pco_update_latest' );
		if ( is_array( $cached ) ) {
			return ! empty( $cached['version'] ) ? $cached : null;
		}
	}
	$response = wp_remote_get(
		TCC_PCO_RELEASES_RAW . 'main/latest.json',
		array( 'timeout' => 15, 'headers' => array( 'User-Agent' => 'TCC Website Sync' ) )
	);
	if ( is_wp_error( $response ) ) {
		tcc_pco_update_note( false, 'GitHub could not be reached: ' . $response->get_error_message() );
		set_transient( 'tcc_pco_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		tcc_pco_update_note( false, 'The list of versions could not be read (error ' . $code . ').' );
		set_transient( 'tcc_pco_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$data     = json_decode( wp_remote_retrieve_body( $response ), true );
	$version  = is_array( $data ) && isset( $data['version'] ) ? (string) $data['version'] : '';
	$download = is_array( $data ) && isset( $data['download'] ) ? (string) $data['download'] : '';
	$sha      = is_array( $data ) && isset( $data['sha256'] ) ? strtolower( (string) $data['sha256'] ) : '';
	// Only accept a proper version number, a download from the releases repository itself, and a real checksum.
	if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $version ) || ! tcc_pco_update_is_ours( $download ) || ! preg_match( '/^[0-9a-f]{64}$/', $sha ) ) {
		tcc_pco_update_note( true, 'No published version was found yet.' );
		set_transient( 'tcc_pco_update_latest', array(), HOUR_IN_SECONDS );
		return null;
	}
	$best  = array(
		'version'   => $version,
		'asset_url' => $download,
		'sha256'    => $sha,
		'page'      => 'https://github.com/' . TCC_PCO_RELEASES,
		'notes'     => isset( $data['notes'] ) ? (string) $data['notes'] : '',
		'date'      => isset( $data['date'] ) ? (string) $data['date'] : '',
	);
	$newer = version_compare( $version, TCC_PCO_VERSION, '>' );
	tcc_pco_update_note( true, $newer ? 'Version ' . $version . ' is available. Update it on the Plugins screen.' : 'This is the newest version (' . TCC_PCO_VERSION . ').' );
	set_transient( 'tcc_pco_update_latest', $best, 6 * HOUR_IN_SECONDS );
	return $best;
}

/** Tells WordPress about a newer version, so the Plugins screen shows the normal update notice. */
function tcc_pco_update_inject( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}
	$latest   = tcc_pco_update_latest();
	$basename = tcc_pco_update_basename();
	if ( ! $latest ) {
		return $transient;
	}
	$item = (object) array(
		'id'          => 'github.com/' . TCC_PCO_RELEASES,
		'slug'        => 'tcc-pco-sync',
		'plugin'      => $basename,
		'new_version' => $latest['version'],
		'url'         => $latest['page'],
		'package'     => $latest['asset_url'],
	);
	if ( version_compare( $latest['version'], TCC_PCO_VERSION, '>' ) ) {
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $basename ] = $item;
	} else {
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		$transient->no_update[ $basename ] = $item;
	}
	return $transient;
}
add_filter( 'pre_set_site_transient_update_plugins', 'tcc_pco_update_inject' );

/** The "View details" window on the Plugins screen. */
function tcc_pco_update_details( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'tcc-pco-sync' !== $args->slug ) {
		return $result;
	}
	$latest = tcc_pco_update_latest();
	if ( ! $latest ) {
		return $result;
	}
	return (object) array(
		'name'          => 'TCC Planning Center Sync',
		'slug'          => 'tcc-pco-sync',
		'version'       => $latest['version'],
		'author'        => 'Trinity Community Church',
		'homepage'      => $latest['page'],
		'last_updated'  => $latest['date'],
		'download_link' => $latest['asset_url'],
		'sections'      => array(
			'changelog' => '' !== trim( $latest['notes'] ) ? wpautop( esc_html( $latest['notes'] ) ) : '<p>No notes were written for this version.</p>',
		),
	);
}
add_filter( 'plugins_api', 'tcc_pco_update_details', 10, 3 );

/**
 * Downloads the new version and checks it against the checksum in latest.json before WordPress installs it.
 */
function tcc_pco_update_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
	if ( false !== $reply || ! tcc_pco_update_is_ours( $package ) ) {
		return $reply;
	}
	$latest = tcc_pco_update_latest();
	if ( ! $latest || $latest['asset_url'] !== $package ) {
		$latest = tcc_pco_update_latest( true );
	}
	if ( ! $latest || $latest['asset_url'] !== $package ) {
		return new WP_Error( 'tcc_pco_download', 'The new version could not be confirmed. Press "Check for a new version now" on the Planning Center > Settings tab and try again.' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$tmp = download_url( $package, 120 );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	if ( ! hash_equals( $latest['sha256'], strtolower( (string) hash_file( 'sha256', $tmp ) ) ) ) {
		@unlink( $tmp );
		return new WP_Error( 'tcc_pco_checksum', 'The downloaded file did not match its checksum, so it was not installed.' );
	}
	return $tmp;
}
add_filter( 'upgrader_pre_download', 'tcc_pco_update_download', 10, 4 );

/** Looks again right now (the "Check for a new version" button). Returns the message to show. */
function tcc_pco_update_check_now() {
	delete_transient( 'tcc_pco_update_latest' );
	tcc_pco_update_latest( true );
	delete_site_transient( 'update_plugins' );
	if ( function_exists( 'wp_update_plugins' ) ) {
		wp_update_plugins();
	}
	$status = get_option( 'tcc_pco_update_status', array() );
	return isset( $status['message'] ) ? (string) $status['message'] : 'Checked.';
}

/** After this plugin is updated, forget the old "a new version is available" note so the Settings tab is not out of date. */
function tcc_pco_update_done( $upgrader, $extra ) {
	if ( isset( $extra['type'], $extra['plugins'] ) && 'plugin' === $extra['type'] && in_array( tcc_pco_update_basename(), (array) $extra['plugins'], true ) ) {
		delete_transient( 'tcc_pco_update_latest' );
		delete_option( 'tcc_pco_update_status' );
	}
}
add_action( 'upgrader_process_complete', 'tcc_pco_update_done', 10, 2 );
