<?php
/**
 * Plugin Name: TCC Planning Center Sync
 * Description: Brings events that are published to Church Center in Planning Center Calendar onto the website, after someone approves them. One-way (Planning Center to website). Nothing is ever written back to Planning Center.
 * Version: 0.3.1
 * Author: Trinity Community Church
 *
 * How it works, in short:
 *  1. Every hour (or when you press "Check now") it asks Planning Center for upcoming events that are published to Church Center.
 *  2. New events wait on the "Waiting for approval" tab. Nothing appears on the website until someone approves it.
 *  3. Approved events become normal website events. Planning Center owns the title, dates, graphic,
 *     description, registration link, location and rooms. The page body and extra buttons belong to the website.
 *     Categories: a Planning Center tag that is matched to a website category on the Tags tab is "public" and
 *     keeps that category in step; every other tag is internal and never shows on the website.
 *  4. If someone changed a Planning Center-owned field on the website AND it also changed in Planning Center,
 *     nothing is overwritten: it is listed on the "Conflicts" tab for a person to decide.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_PCO_VERSION', '0.3.1' );
define( 'TCC_PCO_API', 'https://api.planningcenteronline.com/calendar/v2' );

require_once __DIR__ . '/admin.php';
require_once __DIR__ . '/updater.php';

/* ---------------------------------------------------------------------------
 * Settings, stored items, log and conflicts
 * ------------------------------------------------------------------------- */

function tcc_pco_settings() {
	$defaults = array(
		'app_id'    => '',
		'secret'    => '',
		'per_event' => 2,
		'tag_map'   => array(), // Planning Center tag id => website category id. A tag that is not here is internal.
		'tags_seen' => array(), // Tag ids someone has already looked at on the Tags tab.
		'rooms'     => array(), // Planning Center room id => array( 'show' => bool, 'label' => public name ).
	);
	$saved = get_option( 'tcc_pco_settings', array() );
	return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
}

function tcc_pco_items() {
	$items = get_option( 'tcc_pco_items', array() );
	return is_array( $items ) ? $items : array();
}

function tcc_pco_save_items( $items ) {
	update_option( 'tcc_pco_items', $items, false );
}

function tcc_pco_log( $message, $post_id = 0 ) {
	$log = get_option( 'tcc_pco_log', array() );
	if ( ! is_array( $log ) ) {
		$log = array();
	}
	array_unshift(
		$log,
		array(
			'time'    => time(),
			'message' => (string) $message,
			'post_id' => (int) $post_id,
		)
	);
	update_option( 'tcc_pco_log', array_slice( $log, 0, 150 ), false );
}

function tcc_pco_conflicts() {
	$c = get_option( 'tcc_pco_conflicts', array() );
	return is_array( $c ) ? $c : array();
}

function tcc_pco_field_label( $field ) {
	$labels = array(
		'title' => 'Title',
		'start' => 'Start',
		'end'   => 'End',
		'image' => 'Graphic',
	);
	return isset( $labels[ $field ] ) ? $labels[ $field ] : $field;
}

/* ---------------------------------------------------------------------------
 * Talking to Planning Center (read only)
 * ------------------------------------------------------------------------- */

function tcc_pco_get( $path, $query = array() ) {
	$s = tcc_pco_settings();
	if ( '' === $s['app_id'] || '' === $s['secret'] ) {
		return new WP_Error( 'tcc_pco_no_key', 'Planning Center is not connected yet. Add the Application ID and Secret on the Settings tab.' );
	}
	$url      = TCC_PCO_API . $path . ( $query ? '?' . http_build_query( $query ) : '' );
	$response = wp_remote_get(
		$url,
		array(
			'timeout' => 20,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $s['app_id'] . ':' . $s['secret'] ),
				'User-Agent'    => 'TCC Website Sync',
			),
		)
	);
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		return new WP_Error( 'tcc_pco_http', 'Planning Center answered with error ' . $code . ( 401 === $code ? ' (the Application ID or Secret is not accepted)' : '' ) . '.' );
	}
	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	return is_array( $body ) ? $body : new WP_Error( 'tcc_pco_json', 'Planning Center sent something that could not be read.' );
}

/**
 * Every Planning Center tag with the group it sits in (Ministry, Department, ...). Saved for the Tags tab.
 */
function tcc_pco_known_tags() {
	$tags = get_option( 'tcc_pco_tags', array() );
	return is_array( $tags ) ? $tags : array();
}

function tcc_pco_refresh_tags() {
	$body = tcc_pco_get( '/tags', array( 'include' => 'tag_group', 'per_page' => 100 ) );
	if ( is_wp_error( $body ) ) {
		return; // Keep the list we already have.
	}
	$groups = array();
	foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
		if ( isset( $inc['type'], $inc['id'] ) && 'TagGroup' === $inc['type'] ) {
			$groups[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? (string) $inc['attributes']['name'] : '';
		}
	}
	$tags = array();
	foreach ( isset( $body['data'] ) ? (array) $body['data'] : array() as $row ) {
		if ( empty( $row['id'] ) ) {
			continue;
		}
		$gid                        = isset( $row['relationships']['tag_group']['data']['id'] ) ? (string) $row['relationships']['tag_group']['data']['id'] : '';
		$tags[ (string) $row['id'] ] = array(
			'name'  => isset( $row['attributes']['name'] ) ? trim( (string) $row['attributes']['name'] ) : '',
			'group' => isset( $groups[ $gid ] ) ? $groups[ $gid ] : '',
		);
	}
	if ( $tags ) {
		update_option( 'tcc_pco_tags', $tags, false );
	}
}

/**
 * Every room the church has in Planning Center (room id => name), whether or not an event uses it. Saved for the Rooms tab.
 */
function tcc_pco_all_rooms() {
	$rooms = get_option( 'tcc_pco_rooms_all', array() );
	return is_array( $rooms ) ? $rooms : array();
}

function tcc_pco_refresh_rooms() {
	$rooms = array();
	for ( $page = 0; $page < 10; $page++ ) {
		$body = tcc_pco_get( '/resources', array( 'per_page' => 100, 'offset' => $page * 100, 'order' => 'name' ) );
		if ( is_wp_error( $body ) ) {
			return; // Keep the list we already have.
		}
		$rows = isset( $body['data'] ) ? (array) $body['data'] : array();
		foreach ( $rows as $row ) {
			if ( ! empty( $row['id'] ) && isset( $row['attributes']['kind'] ) && 'Room' === $row['attributes']['kind'] ) {
				$rooms[ (string) $row['id'] ] = isset( $row['attributes']['name'] ) ? trim( (string) $row['attributes']['name'] ) : '';
			}
		}
		if ( count( $rows ) < 100 ) {
			break;
		}
	}
	if ( $rooms ) {
		asort( $rooms );
		update_option( 'tcc_pco_rooms_all', $rooms, false );
	}
}

/**
 * The rooms booked for one date of an event, as room id => name. Equipment is left out.
 * Returns null when Planning Center could not be asked, so the rooms already saved are kept.
 */
function tcc_pco_fetch_rooms( $instance_id ) {
	$body = tcc_pco_get(
		'/event_instances/' . rawurlencode( (string) $instance_id ) . '/resource_bookings',
		array( 'include' => 'resource', 'per_page' => 100 )
	);
	if ( is_wp_error( $body ) ) {
		return null;
	}
	$rooms = array();
	foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
		if ( isset( $inc['type'], $inc['id'] ) && 'Resource' === $inc['type'] && isset( $inc['attributes']['kind'] ) && 'Room' === $inc['attributes']['kind'] ) {
			$rooms[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? trim( (string) $inc['attributes']['name'] ) : '';
		}
	}
	asort( $rooms );
	return $rooms;
}

/**
 * Returns a plain list of upcoming events that are published to Church Center, each with its next dates.
 */
function tcc_pco_fetch_events() {
	$s    = tcc_pco_settings();
	tcc_pco_refresh_tags();
	tcc_pco_refresh_rooms();
	$body = tcc_pco_get(
		'/events',
		array(
			'filter'                          => 'future',
			'where[visible_in_church_center]' => 'true',
			'include'                         => 'tags',
			'per_page'                        => 100,
		)
	);
	if ( is_wp_error( $body ) ) {
		return $body;
	}
	$tag_names = array();
	foreach ( isset( $body['included'] ) ? (array) $body['included'] : array() as $inc ) {
		if ( isset( $inc['type'], $inc['id'] ) && 'Tag' === $inc['type'] ) {
			$tag_names[ (string) $inc['id'] ] = isset( $inc['attributes']['name'] ) ? (string) $inc['attributes']['name'] : '';
		}
	}
	$events = array();
	foreach ( isset( $body['data'] ) ? (array) $body['data'] : array() as $row ) {
		if ( empty( $row['id'] ) ) {
			continue;
		}
		$a    = isset( $row['attributes'] ) ? (array) $row['attributes'] : array();
		$tags = array();
		if ( isset( $row['relationships']['tags']['data'] ) ) {
			foreach ( (array) $row['relationships']['tags']['data'] as $t ) {
				$tid = isset( $t['id'] ) ? (string) $t['id'] : '';
				if ( '' !== $tid ) {
					$tags[ $tid ] = isset( $tag_names[ $tid ] ) ? $tag_names[ $tid ] : $tid;
				}
			}
		}
		$inst = tcc_pco_get(
			'/events/' . rawurlencode( (string) $row['id'] ) . '/event_instances',
			array(
				'filter'   => 'future',
				'order'    => 'starts_at',
				'per_page' => max( 1, min( 10, (int) $s['per_event'] ) ),
			)
		);
		if ( is_wp_error( $inst ) ) {
			return $inst;
		}
		$instances = array();
		foreach ( isset( $inst['data'] ) ? (array) $inst['data'] : array() as $i ) {
			$ia = isset( $i['attributes'] ) ? (array) $i['attributes'] : array();
			if ( empty( $i['id'] ) || empty( $ia['starts_at'] ) ) {
				continue;
			}
			$starts = ! empty( $ia['published_starts_at'] ) ? (string) $ia['published_starts_at'] : (string) $ia['starts_at'];
			$ends   = ! empty( $ia['published_ends_at'] ) ? (string) $ia['published_ends_at'] : ( ! empty( $ia['ends_at'] ) ? (string) $ia['ends_at'] : $starts );
			$instances[] = array(
				'id'       => (string) $i['id'],
				// Planning Center's "published" times are the public ones. starts_at / ends_at also cover
				// setup, teardown and room pre-cooling, which visitors should not see.
				'starts'   => $starts,
				'ends'     => $ends,
				'all_day'  => ! empty( $ia['all_day_event'] ),
				'location' => isset( $ia['location'] ) ? (string) $ia['location'] : '',
				'rooms'    => tcc_pco_fetch_rooms( (string) $i['id'] ),
			);
		}
		$events[] = array(
			'id'               => (string) $row['id'],
			'name'             => isset( $a['name'] ) ? (string) $a['name'] : '',
			'summary'          => isset( $a['summary'] ) ? (string) $a['summary'] : '',
			'description'      => isset( $a['description'] ) ? (string) $a['description'] : '',
			'image_url'        => isset( $a['image_url'] ) ? (string) $a['image_url'] : '',
			'registration_url' => isset( $a['registration_url'] ) ? (string) $a['registration_url'] : '',
			'tags'             => $tags,
			'instances'        => $instances,
		);
	}
	return $events;
}

/* ---------------------------------------------------------------------------
 * The sync itself
 * ------------------------------------------------------------------------- */

/**
 * Takes the list from Planning Center, updates the waiting list, and updates approved events on the website.
 */
function tcc_pco_ingest( $events ) {
	$items = tcc_pco_items();
	$seen  = array();
	$new   = 0;
	foreach ( (array) $events as $ev ) {
		if ( empty( $ev['id'] ) ) {
			continue;
		}
		$id          = (string) $ev['id'];
		$seen[ $id ] = true;
		if ( ! isset( $items[ $id ] ) ) {
			$items[ $id ] = array(
				'status'     => 'new',
				'first_seen' => time(),
			);
			$new++;
		}
		$items[ $id ]['data']      = $ev;
		$items[ $id ]['last_seen'] = time();
		$items[ $id ]['gone']      = false;
	}
	foreach ( $items as $id => $item ) {
		if ( isset( $seen[ $id ] ) || ! empty( $item['gone'] ) ) {
			continue;
		}
		// No longer upcoming or no longer published to Church Center.
		$items[ $id ]['gone'] = true;
		if ( isset( $item['status'] ) && 'approved' === $item['status'] ) {
			$removed = tcc_pco_trash_future_posts( $id, array() );
			if ( $removed ) {
				tcc_pco_log( 'Removed ' . $removed . ' upcoming date(s) of "' . ( isset( $item['data']['name'] ) ? $item['data']['name'] : $id ) . '" from the website: it is no longer published in Planning Center.' );
			}
		}
	}
	tcc_pco_save_items( $items );
	foreach ( $items as $id => $item ) {
		if ( isset( $item['status'] ) && 'approved' === $item['status'] && empty( $item['gone'] ) && ! empty( $item['data'] ) ) {
			tcc_pco_apply_event( $item['data'] );
		}
	}
	return $new;
}

function tcc_pco_run() {
	if ( get_transient( 'tcc_pco_running' ) ) {
		return new WP_Error( 'tcc_pco_busy', 'A check is already running. Try again in a minute.' );
	}
	set_transient( 'tcc_pco_running', 1, 5 * MINUTE_IN_SECONDS );
	$events = tcc_pco_fetch_events();
	if ( is_wp_error( $events ) ) {
		delete_transient( 'tcc_pco_running' );
		update_option( 'tcc_pco_last_run', array( 'time' => time(), 'ok' => false, 'message' => $events->get_error_message() ), false );
		return $events;
	}
	$new = tcc_pco_ingest( $events );
	delete_transient( 'tcc_pco_running' );
	update_option( 'tcc_pco_last_run', array( 'time' => time(), 'ok' => true, 'message' => count( $events ) . ' published event(s) found, ' . $new . ' new.' ), false );
	return $new;
}
add_action( 'tcc_pco_sync_cron', 'tcc_pco_run' );

function tcc_pco_local( $iso ) {
	try {
		$dt = new DateTime( $iso );
		$dt->setTimezone( wp_timezone() );
		return $dt;
	} catch ( Exception $e ) {
		return null;
	}
}

function tcc_pco_date_args( $start, $end, $all_day ) {
	$s = date_create( $start, wp_timezone() );
	$e = date_create( $end, wp_timezone() );
	if ( ! $s || ! $e ) {
		return array();
	}
	return array(
		'EventAllDay'        => (bool) $all_day,
		'EventStartDate'     => $s->format( 'Y-m-d' ),
		'EventStartHour'     => $s->format( 'h' ),
		'EventStartMinute'   => $s->format( 'i' ),
		'EventStartMeridian' => $s->format( 'a' ),
		'EventEndDate'       => $e->format( 'Y-m-d' ),
		'EventEndHour'       => $e->format( 'h' ),
		'EventEndMinute'     => $e->format( 'i' ),
		'EventEndMeridian'   => $e->format( 'a' ),
		'EventTimezone'      => wp_timezone_string(),
	);
}

function tcc_pco_posts_for( $event_id, $instance_id = '' ) {
	$meta = array(
		array(
			'key'   => '_tcc_pco_event_id',
			'value' => (string) $event_id,
		),
	);
	if ( '' !== $instance_id ) {
		$meta[] = array(
			'key'   => '_tcc_pco_instance_id',
			'value' => (string) $instance_id,
		);
	}
	return get_posts(
		array(
			'post_type'        => 'tribe_events',
			'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page'   => 50,
			'meta_query'       => $meta,
			'suppress_filters' => true,
			'orderby'          => 'ID',
			'order'            => 'ASC',
		)
	);
}

/**
 * Moves upcoming website dates of a Planning Center event to the Trash, except the instance ids in $keep.
 */
function tcc_pco_trash_future_posts( $event_id, $keep, $before = '' ) {
	$count = 0;
	$now   = current_time( 'Y-m-d H:i:s' );
	foreach ( tcc_pco_posts_for( $event_id ) as $post ) {
		$inst  = (string) get_post_meta( $post->ID, '_tcc_pco_instance_id', true );
		$start = (string) get_post_meta( $post->ID, '_EventStartDate', true );
		if ( in_array( $inst, $keep, true ) || $start <= $now ) {
			continue;
		}
		if ( '' !== $before && $start >= $before ) {
			continue;
		}
		if ( get_post_meta( $post->ID, '_tcc_pco_paused', true ) ) {
			continue;
		}
		wp_trash_post( $post->ID );
		$count++;
	}
	return $count;
}

function tcc_pco_image_key( $url ) {
	if ( '' === $url ) {
		return '';
	}
	$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
	parse_str( $query, $q );
	return isset( $q['key'] ) ? (string) $q['key'] : md5( (string) strtok( $url, '?' ) );
}

/**
 * Copies a Planning Center graphic into the Media Library once and returns the attachment id (0 if it could not).
 */
function tcc_pco_image_attachment( $url, $title ) {
	$key = tcc_pco_image_key( $url );
	if ( '' === $key ) {
		return 0;
	}
	$found = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_tcc_pco_image_key',
			'meta_value'     => $key,
		)
	);
	if ( $found ) {
		return (int) $found[0];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = download_url( $url, 30 );
	if ( is_wp_error( $tmp ) ) {
		return 0;
	}
	$mime = wp_get_image_mime( $tmp );
	$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif' );
	if ( ! $mime || ! isset( $ext[ $mime ] ) ) {
		@unlink( $tmp );
		return 0;
	}
	$file = array(
		'name'     => sanitize_title( $title ? $title : 'event' ) . '-planning-center.' . $ext[ $mime ],
		'tmp_name' => $tmp,
	);
	$id   = media_handle_sideload( $file, 0, $title );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp );
		return 0;
	}
	update_post_meta( $id, '_tcc_pco_image_key', $key );
	return (int) $id;
}

function tcc_pco_add_conflict( $post_id, $field, $website, $pco ) {
	$c = tcc_pco_conflicts();
	$c[ $post_id . ':' . $field ] = array(
		'post_id' => (int) $post_id,
		'field'   => $field,
		'website' => (string) $website,
		'pco'     => (string) $pco,
		'time'    => time(),
	);
	update_option( 'tcc_pco_conflicts', $c, false );
}

function tcc_pco_clear_conflict( $post_id, $field ) {
	$c = tcc_pco_conflicts();
	if ( isset( $c[ $post_id . ':' . $field ] ) ) {
		unset( $c[ $post_id . ':' . $field ] );
		update_option( 'tcc_pco_conflicts', $c, false );
	}
}

/**
 * Keeps the website categories that come from public Planning Center tags in step.
 * Categories someone added by hand on the website are never removed.
 */
function tcc_pco_sync_terms( $post_id, $ev, $s ) {
	if ( ! taxonomy_exists( 'tribe_events_cat' ) ) {
		return;
	}
	$want = array();
	foreach ( isset( $ev['tags'] ) ? (array) $ev['tags'] : array() as $tag_id => $tag_name ) {
		if ( ! empty( $s['tag_map'][ $tag_id ] ) && term_exists( (int) $s['tag_map'][ $tag_id ], 'tribe_events_cat' ) ) {
			$want[] = (int) $s['tag_map'][ $tag_id ];
		}
	}
	$want    = array_values( array_unique( $want ) );
	$last    = get_post_meta( $post_id, '_tcc_pco_terms', true );
	$last    = is_array( $last ) ? array_map( 'intval', $last ) : array();
	$current = wp_get_object_terms( $post_id, 'tribe_events_cat', array( 'fields' => 'ids' ) );
	$current = is_wp_error( $current ) ? array() : array_map( 'intval', $current );
	$new     = array_values( array_unique( array_merge( array_diff( $current, array_diff( $last, $want ) ), $want ) ) );
	sort( $new );
	sort( $current );
	if ( $new !== $current ) {
		wp_set_object_terms( $post_id, $new, 'tribe_events_cat' );
	}
	update_post_meta( $post_id, '_tcc_pco_terms', $want );
}

/**
 * Finds the website venue for a Planning Center location such as "Trinity Community Church - 6706 Central Ave Pike, ...".
 * An existing venue with the same name is reused; otherwise a new venue is made. Returns 0 when there is no location.
 */
function tcc_pco_venue_for( $location ) {
	static $cache = array();
	$location = trim( (string) $location );
	if ( '' === $location || ! post_type_exists( 'tribe_venue' ) ) {
		return 0;
	}
	if ( isset( $cache[ $location ] ) ) {
		return $cache[ $location ];
	}
	$parts   = preg_split( '/\s+-\s+/', $location, 2 );
	$name    = trim( (string) $parts[0] );
	$address = isset( $parts[1] ) ? trim( (string) $parts[1] ) : '';
	$venue   = 0;
	$found   = get_posts(
		array(
			'post_type'        => 'tribe_venue',
			'post_status'      => 'publish',
			'title'            => $name,
			'posts_per_page'   => 1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'fields'           => 'ids',
			'suppress_filters' => true,
		)
	);
	if ( $found ) {
		$venue = (int) $found[0];
	} elseif ( function_exists( 'tribe_create_venue' ) ) {
		$made = tribe_create_venue( array( 'Venue' => $name, 'Address' => $address ) );
		if ( $made && ! is_wp_error( $made ) ) {
			$venue = (int) $made;
			tcc_pco_log( 'Made a new location "' . $name . '" from Planning Center.' );
		}
	}
	$cache[ $location ] = $venue;
	return $venue;
}

/**
 * Creates or updates the website dates of one approved Planning Center event.
 */
function tcc_pco_apply_event( $ev ) {
	if ( ! function_exists( 'tribe_create_event' ) || ! function_exists( 'tribe_update_event' ) ) {
		return;
	}
	$s          = tcc_pco_settings();
	$keep       = array();
	$last_start = '';
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		$start = tcc_pco_local( $inst['starts'] );
		$end   = tcc_pco_local( $inst['ends'] );
		if ( ! $start || ! $end ) {
			continue;
		}
		$keep[]     = (string) $inst['id'];
		$want       = array(
			'title' => (string) $ev['name'],
			'start' => $start->format( 'Y-m-d H:i:s' ),
			'end'   => $end->format( 'Y-m-d H:i:s' ),
		);
		$last_start = $want['start'];
		$all_day    = ! empty( $inst['all_day'] );
		$posts      = tcc_pco_posts_for( $ev['id'], $inst['id'] );
		$post_id    = $posts ? (int) $posts[0]->ID : 0;

		if ( ! $post_id ) {
			$post_id = tribe_create_event(
				array_merge(
					array(
						'post_title'  => $want['title'],
						'post_status' => 'publish',
					),
					tcc_pco_date_args( $want['start'], $want['end'], $all_day )
				)
			);
			if ( ! $post_id || is_wp_error( $post_id ) ) {
				tcc_pco_log( 'Could not create "' . $want['title'] . '" on the website.' );
				continue;
			}
			$post_id = (int) $post_id;
			update_post_meta( $post_id, '_tcc_pco_event_id', (string) $ev['id'] );
			update_post_meta( $post_id, '_tcc_pco_instance_id', (string) $inst['id'] );
			$synced = $want;
			tcc_pco_log( 'Added "' . $want['title'] . '" (' . $start->format( 'M j, Y g:i a' ) . ') to the website.', $post_id );
		} else {
			if ( get_post_meta( $post_id, '_tcc_pco_paused', true ) ) {
				continue;
			}
			$synced  = get_post_meta( $post_id, '_tcc_pco_synced', true );
			$synced  = is_array( $synced ) ? $synced : array();
			$current = array(
				'title' => (string) get_post_field( 'post_title', $post_id, 'raw' ),
				'start' => (string) get_post_meta( $post_id, '_EventStartDate', true ),
				'end'   => (string) get_post_meta( $post_id, '_EventEndDate', true ),
			);
			$apply   = array();
			foreach ( $want as $field => $value ) {
				$last = isset( $synced[ $field ] ) ? (string) $synced[ $field ] : $current[ $field ];
				if ( $value === $last ) {
					continue; // Planning Center has not changed this.
				}
				if ( $current[ $field ] === $last || $current[ $field ] === $value ) {
					$apply[ $field ]  = $value;
					$synced[ $field ] = $value;
					tcc_pco_clear_conflict( $post_id, $field );
				} else {
					tcc_pco_add_conflict( $post_id, $field, $current[ $field ], $value );
				}
			}
			if ( $apply ) {
				$args = array();
				if ( isset( $apply['title'] ) ) {
					$args['post_title'] = $apply['title'];
				}
				if ( isset( $apply['start'] ) || isset( $apply['end'] ) ) {
					$args = array_merge(
						$args,
						tcc_pco_date_args(
							isset( $apply['start'] ) ? $apply['start'] : $current['start'],
							isset( $apply['end'] ) ? $apply['end'] : $current['end'],
							$all_day
						)
					);
				}
				tribe_update_event( $post_id, $args );
				$labels = array_map( 'tcc_pco_field_label', array_keys( $apply ) );
				tcc_pco_log( 'Updated ' . strtolower( implode( ', ', $labels ) ) . ' of "' . $want['title'] . '" from Planning Center.', $post_id );
			}
		}

		// The description and registration link live in their own fields, so the page body stays the website's.
		$desc = (string) ( '' !== $ev['description'] ? $ev['description'] : $ev['summary'] );
		$desc = wp_kses_post( (string) preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', '', $desc ) );
		if ( (string) get_post_meta( $post_id, '_tcc_pco_description', true ) !== $desc ) {
			update_post_meta( $post_id, '_tcc_pco_description', wp_slash( $desc ) );
		}
		update_post_meta( $post_id, '_tcc_pco_registration_url', esc_url_raw( (string) $ev['registration_url'] ) );
		update_post_meta( $post_id, '_tcc_pco_location', sanitize_text_field( (string) $inst['location'] ) );

		// Location: set the website venue unless someone picked a different one on the website.
		$venue = tcc_pco_venue_for( (string) $inst['location'] );
		if ( $venue ) {
			$now_venue  = (int) get_post_meta( $post_id, '_EventVenueID', true );
			$last_venue = isset( $synced['venue'] ) ? (int) $synced['venue'] : 0;
			if ( $now_venue !== $venue && ( 0 === $now_venue || $now_venue === $last_venue ) ) {
				update_post_meta( $post_id, '_EventVenueID', $venue );
				$now_venue = $venue;
			}
			if ( $now_venue === $venue ) {
				$synced['venue'] = $venue;
			}
		}

		// Rooms (null means Planning Center could not be asked this time: keep what is saved).
		if ( isset( $inst['rooms'] ) && is_array( $inst['rooms'] ) ) {
			update_post_meta( $post_id, '_tcc_pco_rooms', $inst['rooms'] );
		}

		// Categories from public tags.
		tcc_pco_sync_terms( $post_id, $ev, $s );

		// Graphic.
		$key = tcc_pco_image_key( (string) $ev['image_url'] );
		if ( '' !== $key && ( ! isset( $synced['image'] ) || $synced['image'] !== $key ) ) {
			$thumb    = (int) get_post_thumbnail_id( $post_id );
			$last_att = isset( $synced['image_att'] ) ? (int) $synced['image_att'] : 0;
			if ( 0 === $thumb || $thumb === $last_att ) {
				$att = tcc_pco_image_attachment( (string) $ev['image_url'], (string) $ev['name'] );
				if ( $att ) {
					set_post_thumbnail( $post_id, $att );
					$synced['image']     = $key;
					$synced['image_att'] = $att;
					tcc_pco_clear_conflict( $post_id, 'image' );
				}
			} else {
				tcc_pco_add_conflict( $post_id, 'image', 'A different graphic was chosen on the website', (string) $ev['image_url'] );
			}
		}
		update_post_meta( $post_id, '_tcc_pco_synced', $synced );
	}
	// A date that was on the website but is no longer among the next dates in Planning Center was cancelled or moved there.
	$per     = max( 1, min( 10, (int) $s['per_event'] ) );
	$removed = tcc_pco_trash_future_posts( $ev['id'], $keep, count( $keep ) >= $per ? $last_start : '' );
	if ( $removed ) {
		tcc_pco_log( 'Removed ' . $removed . ' date(s) of "' . $ev['name'] . '" that are no longer in Planning Center.' );
	}
}

/* ---------------------------------------------------------------------------
 * Front end: description, registration button, and keeping recurring dates grouped in the event lists
 * ------------------------------------------------------------------------- */

function tcc_pco_description_shortcode() {
	$id = get_the_ID();
	if ( ! $id ) {
		return '';
	}
	$desc = (string) get_post_meta( $id, '_tcc_pco_description', true );
	return '' === trim( $desc ) ? '' : '<div class="tcc-pco-description" style="margin-bottom:20px">' . wpautop( wp_kses_post( $desc ) ) . '</div>';
}
add_shortcode( 'tcc_pco_description', 'tcc_pco_description_shortcode' );

function tcc_pco_register_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'label' => 'Register' ), $atts, 'tcc_event_register' );
	$id   = get_the_ID();
	if ( ! $id ) {
		return '';
	}
	$url = (string) get_post_meta( $id, '_tcc_register_url', true ); // Website's own link wins if someone typed one.
	if ( '' === $url ) {
		$url = (string) get_post_meta( $id, '_tcc_pco_registration_url', true );
	}
	if ( '' === $url ) {
		return '';
	}
	return '<span class="tcc-event-register-wrap" style="display:block;margin-top:24px"><a class="et_pb_button tcc-event-register" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $atts['label'] ) . '</a></span>';
}
add_shortcode( 'tcc_event_register', 'tcc_pco_register_shortcode' );

/**
 * [tcc_event_rooms label="Rooms"] lists the rooms of the event that are ticked "show on website" on the Rooms tab.
 * Prints nothing when the event has no such room.
 */
function tcc_pco_rooms_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'label' => 'Rooms' ), $atts, 'tcc_event_rooms' );
	$id   = get_the_ID();
	if ( ! $id ) {
		return '';
	}
	$rooms = get_post_meta( $id, '_tcc_pco_rooms', true );
	if ( ! is_array( $rooms ) || ! $rooms ) {
		return '';
	}
	$s     = tcc_pco_settings();
	$names = array();
	foreach ( $rooms as $room_id => $name ) {
		if ( empty( $s['rooms'][ $room_id ]['show'] ) ) {
			continue;
		}
		$label   = isset( $s['rooms'][ $room_id ]['label'] ) ? trim( (string) $s['rooms'][ $room_id ]['label'] ) : '';
		$names[] = '' !== $label ? $label : trim( (string) $name );
	}
	$names = array_values( array_unique( array_filter( $names ) ) );
	if ( ! $names ) {
		return '';
	}
	$label = trim( (string) $atts['label'] );
	return '<span class="tcc-event-rooms" style="display:block;margin-top:8px">' . ( '' !== $label ? '<strong>' . esc_html( $label ) . ':</strong> ' : '' ) . esc_html( implode( ', ', $names ) ) . '</span>';
}
add_shortcode( 'tcc_event_rooms', 'tcc_pco_rooms_shortcode' );

function tcc_pco_series_key( $key, $post_id ) {
	$event_id = (string) get_post_meta( $post_id, '_tcc_pco_event_id', true );
	return '' !== $event_id ? 'pco-' . $event_id : $key;
}
add_filter( 'tcc_upcoming_series_key', 'tcc_pco_series_key', 10, 2 );

/* ---------------------------------------------------------------------------
 * Switching on and off
 * ------------------------------------------------------------------------- */

function tcc_pco_activate() {
	if ( ! wp_next_scheduled( 'tcc_pco_sync_cron' ) ) {
		wp_schedule_event( time() + 300, 'hourly', 'tcc_pco_sync_cron' );
	}
}
register_activation_hook( __FILE__, 'tcc_pco_activate' );

function tcc_pco_deactivate() {
	wp_clear_scheduled_hook( 'tcc_pco_sync_cron' );
}
register_deactivation_hook( __FILE__, 'tcc_pco_deactivate' );
