<?php
/**
 * Plugin Name: TCC Planning Center Sync
 * Description: Brings events that are published to Church Center in Planning Center Calendar onto the website, after someone approves them. One-way (Planning Center to website). Nothing is ever written back to Planning Center.
 * Version: 0.10.0
 * Author: Trinity Community Church
 *
 * How it works, in short:
 *  1. Every hour (or when you press "Check now") it asks Planning Center for upcoming events that are published to Church Center.
 *  2. New events wait on the "Waiting for approval" tab. Nothing appears on the website until someone approves it.
 *  3. Approved events become normal website events. Planning Center owns the title, dates, graphic,
 *     description, registration link, location and rooms. The page body and extra buttons belong to the website.
 *     Categories: a Planning Center tag that is matched to a website category on the Tags tab is "public" and
 *     keeps that category in step; every other tag is internal and never shows on the website.
 *  4. If someone changed a Planning Center-owned field on the website AND it also changed in Planning Center,
 *     nothing is overwritten: it is listed on the "Conflicts" tab for a person to decide.
 *
 * Where the code is:
 *   sync.php      the sync itself (talking to Planning Center, making and updating events, the short codes)
 *   options.php   choices for one event, the default graphic, the Dashboard box
 *   admin.php     the admin screens and the box on each event's edit screen
 *   help.php      the Help tab
 *   updater.php   updates from GitHub
 *   code-edits.php, ai-prompts.php   the Code tab and the briefings for an AI assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TCC_PCO_VERSION', '0.10.0' );
define( 'TCC_PCO_API', 'https://api.planningcenteronline.com/calendar/v2' );

/**
 * The Code tab (code-edits.php): lets an administrator change this plugin's code from the admin without
 * touching the original, and put the original back with one button. It is loaded first, because it
 * decides whether each file below runs as it came with the plugin or as a saved edit of it.
 */
require_once __DIR__ . '/code-edits.php';
tcc_code_register(
	'tcc-pco-sync',
	array(
		'name'    => 'TCC Planning Center Sync',
		'menu'    => 'Planning Center',
		'dir'     => __DIR__,
		'version' => TCC_PCO_VERSION,
		'page'    => 'tcc-pco-sync',
		'files'   => 'tcc_pco_code_files',
		'extra'   => 'tcc_pco_code_extra',
		'ai'      => 'tcc_pco_ai_notes', // In ai-prompts.php, which is only loaded in the admin.
	)
);

/** The files that can be edited on the Code tab. */
function tcc_pco_code_files() {
	return array(
		'sync.php'    => array(
			'label' => 'The sync itself',
			'what'  => 'Asks Planning Center for events, decides what is new or changed, and makes and updates the website\'s events. Also the Register button, the rooms and the description on event pages.',
			'group' => 'How the plugin works',
		),
		'options.php' => array(
			'label' => 'Choices for one event',
			'what'  => 'The "what shows" and "keep the website\'s version" choices, the description choice, the default graphic for events without one, and the box on the WordPress Dashboard.',
			'group' => 'How the plugin works',
		),
		'admin.php'   => array(
			'label' => 'The admin screens',
			'what'  => 'The Planning Center screen and its tabs (Waiting for approval, On the website, Conflicts, Tags, Rooms, Settings), every button on them, and the box on each event\'s edit screen.',
			'group' => 'The plugin\'s own screens',
		),
		'help.php'    => array(
			'label' => 'The Help tab',
			'what'  => 'The words on Planning Center > Help. Change them here when the plugin changes, so the help stays true.',
			'group' => 'The plugin\'s own screens',
		),
	);
}

/** Files an AI assistant is shown so it understands the whole plugin, but which cannot be edited on the Code tab. */
function tcc_pco_code_extra() {
	return array(
		'tcc-pco-sync.php' => 'The main file: loads the others and switches the hourly check on and off',
		'ai-prompts.php'   => 'The wording of the AI prompts',
	);
}

// Each of these runs the saved edit of the file if there is a healthy one, otherwise the original.
tcc_code_require( 'tcc-pco-sync', 'options.php' );
tcc_code_require( 'tcc-pco-sync', 'admin.php' );
tcc_code_require( 'tcc-pco-sync', 'help.php' );
require_once __DIR__ . '/updater.php';
tcc_code_require( 'tcc-pco-sync', 'sync.php' );
if ( is_admin() ) {
	require_once __DIR__ . '/ai-prompts.php';
}

/* ---------------------------------------------------------------------------
 * Switching on and off
 * ------------------------------------------------------------------------- */

function tcc_pco_activate() {
	if ( ! wp_next_scheduled( 'tcc_pco_sync_cron' ) ) {
		wp_schedule_event( time() + 300, 'hourly', 'tcc_pco_sync_cron' );
	}
}
register_activation_hook( __FILE__, 'tcc_pco_activate' );

function tcc_pco_deactivate() {
	wp_clear_scheduled_hook( 'tcc_pco_sync_cron' );
}
register_deactivation_hook( __FILE__, 'tcc_pco_deactivate' );
