<?php
/**
 * TCC Planning Center Sync: the admin screens.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_pco_admin_menu() {
	$count = 0;
	foreach ( tcc_pco_items() as $item ) {
		if ( isset( $item['status'] ) && 'new' === $item['status'] && empty( $item['gone'] ) ) {
			$count++;
		}
	}
	$count += count( tcc_pco_conflicts() );
	$bubble = $count ? ' <span class="awaiting-mod">' . (int) $count . '</span>' : '';
	add_menu_page( 'Planning Center Sync', 'Planning Center' . $bubble, 'manage_options', 'tcc-pco-sync', 'tcc_pco_admin_page', 'dashicons-update', 7 );
}
add_action( 'admin_menu', 'tcc_pco_admin_menu' );

function tcc_pco_url( $tab = 'waiting', $extra = array() ) {
	return add_query_arg( array_merge( array( 'page' => 'tcc-pco-sync', 'tab' => $tab ), $extra ), admin_url( 'admin.php' ) );
}

/** A small button that posts one action. */
function tcc_pco_button( $op, $label, $fields = array(), $class = 'button', $confirm = '' ) {
	$html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 6px 4px 0"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '>';
	$html .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
	$html .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
	foreach ( $fields as $k => $v ) {
		$html .= '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
	}
	$html .= '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	return $html;
}

function tcc_pco_when( $ev ) {
	$out = array();
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		$dt = tcc_pco_local( $inst['starts'] );
		if ( $dt ) {
			$out[] = esc_html( $dt->format( ! empty( $inst['all_day'] ) ? 'D, M j, Y' : 'D, M j, Y \a\t g:i a' ) );
		}
	}
	return $out ? implode( '<br>', $out ) : '<em>No upcoming dates</em>';
}

/** Room names booked for any upcoming date of an event. */
function tcc_pco_event_rooms( $ev ) {
	$rooms = array();
	foreach ( isset( $ev['instances'] ) ? (array) $ev['instances'] : array() as $inst ) {
		if ( isset( $inst['rooms'] ) && is_array( $inst['rooms'] ) ) {
			foreach ( $inst['rooms'] as $rid => $name ) {
				$rooms[ (string) $rid ] = trim( (string) $name );
			}
		}
	}
	asort( $rooms );
	return $rooms;
}

/**
 * On the website tab: the rooms booked for one event, each with a tick for "show on this event's pages".
 * Ticks start from the Rooms tab. Once saved here, this event keeps its own choices.
 */
function tcc_pco_event_rooms_form( $event_id, $rooms ) {
	if ( ! $rooms ) {
		return '<br><span style="color:#8c8f94">Rooms: none booked in Planning Center.</span>';
	}
	$s      = tcc_pco_settings();
	$custom = ! empty( $s['event_rooms'][ $event_id ] );
	$html   = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:8px 0 0;padding:8px 10px;background:#f6f7f7;border-radius:4px">';
	$html  .= '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_event_rooms"><input type="hidden" name="id" value="' . esc_attr( $event_id ) . '">';
	$html  .= wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce', true, false );
	$html  .= '<strong>Rooms shown on this event\'s page</strong> <span style="color:#50575e">(' . ( $custom ? 'chosen for this event' : 'following the Rooms tab' ) . ')</span><br>';
	foreach ( $rooms as $rid => $name ) {
		$label = tcc_pco_room_label( $s, (string) $rid, $name );
		$html .= '<input type="hidden" name="all_rooms[]" value="' . esc_attr( $rid ) . '">';
		$html .= '<label style="display:inline-block;margin:4px 14px 2px 0;white-space:nowrap"><input type="checkbox" name="show_rooms[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, (string) $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
	}
	$html .= '<br><button type="submit" class="button button-small" style="margin-top:6px">Save rooms for this event</button>';
	if ( $custom ) {
		$html .= ' <button type="submit" name="reset" value="1" class="button button-small button-link" style="margin:6px 0 0 8px">Go back to the Rooms tab settings</button>';
	}
	return $html . '</form>';
}

/** The tags of an event: public ones with their website category, internal ones greyed. */
function tcc_pco_tags_html( $ev ) {
	if ( empty( $ev['tags'] ) ) {
		return '';
	}
	$s      = tcc_pco_settings();
	$public = array();
	$inside = array();
	foreach ( (array) $ev['tags'] as $tid => $name ) {
		$term = ! empty( $s['tag_map'][ $tid ] ) ? get_term( (int) $s['tag_map'][ $tid ], 'tribe_events_cat' ) : null;
		if ( $term && ! is_wp_error( $term ) ) {
			$public[] = '<span style="background:#e5f5fa;border:1px solid #00a4cf;border-radius:3px;padding:1px 6px;margin-right:4px;white-space:nowrap">' . esc_html( trim( $name ) ) . ' &rarr; ' . esc_html( $term->name ) . '</span>';
		} else {
			$inside[] = esc_html( trim( $name ) );
		}
	}
	$html = '<br><span style="line-height:2">On the website as: ' . ( $public ? implode( '', $public ) : '<em>no category</em>' ) . '</span>';
	if ( $inside ) {
		$html .= '<br><span style="color:#8c8f94">Internal tags (not shown): ' . implode( ', ', $inside ) . '</span>';
	}
	return $html;
}

/** A first guess at the website category for a Planning Center tag. Only a suggestion until someone saves the Tags tab. */
function tcc_pco_suggest_term( $name, $group, $cats ) {
	if ( ! in_array( $group, array( 'Ministry', 'Event Type' ), true ) ) {
		return 0;
	}
	$guesses = array(
		'women'           => "Women's Event",
		'abide'           => "Women's Event",
		"men's"           => "Men's Events",
		'forge'           => 'The Forge',
		'kids'            => 'TCC Kids',
		'core class'      => 'Core Classes',
		'missions'        => 'Missions',
		'next steps'      => 'Next Steps',
		'community group' => 'Community Groups',
		'connect group'   => 'Community Groups',
	);
	$name    = strtolower( (string) $name );
	foreach ( $guesses as $needle => $cat_name ) {
		if ( false === strpos( $name, $needle ) ) {
			continue;
		}
		foreach ( (array) $cats as $cat ) {
			if ( is_object( $cat ) && 0 === strcasecmp( html_entity_decode( $cat->name, ENT_QUOTES ), $cat_name ) ) {
				return (int) $cat->term_id;
			}
		}
		return 0;
	}
	return 0;
}

function tcc_pco_tags_form( $s, $items ) {
	$tags = tcc_pco_known_tags();
	if ( ! $tags ) {
		echo '<p><em>Tags will be listed here after the next check of Planning Center.</em></p>';
		return;
	}
	$cats   = taxonomy_exists( 'tribe_events_cat' ) ? get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) ) : array();
	$cats   = is_wp_error( $cats ) ? array() : $cats;
	$seen   = array_map( 'strval', (array) $s['tags_seen'] );
	$groups = array();
	foreach ( $tags as $tid => $tag ) {
		$groups[ '' !== $tag['group'] ? $tag['group'] : 'No group' ][ (string) $tid ] = $tag['name'];
	}
	$order  = array( 'Ministry', 'Event Type', 'Department', 'Event Location', 'No group' );
	$sorted = array();
	foreach ( $order as $g ) {
		if ( isset( $groups[ $g ] ) ) {
			$sorted[ $g ] = $groups[ $g ];
			unset( $groups[ $g ] );
		}
	}
	$sorted = array_merge( $sorted, $groups );

	echo '<p>These are your Planning Center tags, in their Planning Center groups. Give a tag a website category to make it <strong>public</strong>: events with that tag get that category and show in that ministry\'s lists. Leave a tag on <strong>Internal</strong> and it never shows on the website. A tag added in Planning Center later starts as Internal and is marked <em>new</em> here.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_tags">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	$suggested = 0;
	foreach ( $sorted as $group => $list ) {
		asort( $list );
		echo '<h3 style="margin-bottom:6px">' . esc_html( $group ) . '</h3>';
		echo '<table class="widefat striped" style="max-width:760px"><thead><tr><th>Planning Center tag</th><th style="width:330px">On the website</th></tr></thead><tbody>';
		foreach ( $list as $tid => $name ) {
			$is_new = ! in_array( (string) $tid, $seen, true );
			$chosen = ! empty( $s['tag_map'][ $tid ] ) ? (int) $s['tag_map'][ $tid ] : 0;
			$guess  = 0;
			if ( $is_new && ! $chosen ) {
				$guess = tcc_pco_suggest_term( $name, $group, $cats );
				if ( $guess ) {
					$chosen = $guess;
					$suggested++;
				}
			}
			echo '<tr><td>' . esc_html( $name ) . ( $is_new ? ' <span style="background:#f0c33c;border-radius:3px;padding:0 6px;font-size:11px">new</span>' : '' ) . '</td>';
			echo '<td><input type="hidden" name="tag_ids[]" value="' . esc_attr( $tid ) . '"><select name="tag_map[' . esc_attr( $tid ) . ']"><option value="0">Internal (not on the website)</option>';
			foreach ( (array) $cats as $cat ) {
				if ( is_object( $cat ) ) {
					echo '<option value="' . (int) $cat->term_id . '"' . selected( $chosen, (int) $cat->term_id, false ) . '>Public: ' . esc_html( $cat->name ) . '</option>';
				}
			}
			echo '</select>' . ( $guess ? ' <em style="color:#996800">suggested, not saved yet</em>' : '' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}
	if ( $suggested ) {
		echo '<p><strong>' . (int) $suggested . ' suggestion(s) are filled in but not saved.</strong> Check them, change any that are wrong, then save.</p>';
	}
	submit_button( 'Save tags' );
	echo '</form>';
	tcc_pco_cats_form( $cats );
}

/** Rename website event categories or add one, without leaving the plugin. */
function tcc_pco_cats_form( $cats ) {
	echo '<hr style="margin:28px 0 18px"><h2>Website categories</h2>';
	echo '<p>These are the event categories on the website, the ones you can pick above. Change a name here to rename it everywhere on the website, or add a new one at the bottom. Renaming keeps every event and every page list that uses the category. A new category is only a label until a page is set up to list it.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_cats">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	echo '<table class="widefat striped" style="max-width:760px"><thead><tr><th>Category name</th><th style="width:160px">Events using it</th></tr></thead><tbody>';
	foreach ( (array) $cats as $cat ) {
		if ( ! is_object( $cat ) ) {
			continue;
		}
		$name = html_entity_decode( $cat->name, ENT_QUOTES );
		echo '<tr><td><input type="text" name="cat_name[' . (int) $cat->term_id . ']" value="' . esc_attr( $name ) . '" class="regular-text" style="width:100%" maxlength="80"></td><td>' . (int) $cat->count . '</td></tr>';
	}
	echo '<tr><td><input type="text" name="cat_new" value="" class="regular-text" style="width:100%" maxlength="80" placeholder="Add a new category: type its name here"></td><td><em>new</em></td></tr>';
	echo '</tbody></table>';
	submit_button( 'Save website categories', 'secondary' );
	echo '</form>';
	echo '<p class="description">To delete a category, use Events &rarr; Event Categories. It is left out here on purpose, because deleting one can empty a ministry page list.</p>';
}

function tcc_pco_rooms_form( $s, $items ) {
	$rooms = array();
	$used  = array();
	foreach ( (array) $s['rooms'] as $rid => $row ) {
		if ( ! empty( $row['name'] ) ) {
			$rooms[ (string) $rid ] = (string) $row['name'];
		}
	}
	foreach ( tcc_pco_all_rooms() as $rid => $name ) {
		$rooms[ (string) $rid ] = (string) $name;
	}
	foreach ( $items as $item ) {
		if ( empty( $item['data'] ) || ! empty( $item['gone'] ) ) {
			continue;
		}
		foreach ( tcc_pco_event_rooms( $item['data'] ) as $rid => $name ) {
			$rooms[ $rid ]  = $name;
			$used[ $rid ][] = (string) $item['data']['name'];
		}
	}
	asort( $rooms );
	echo '<p>Every room the church has in Planning Center. "Used by" shows which of the events on this page\'s lists have it booked. Tick a room to let it show on event pages, and give it a public name if the Planning Center name is not how you would say it to a visitor. This is the starting point for every event; to show or hide a room for one event only, use that event\'s row on the On the website tab. Equipment is not listed.</p>';
	if ( ! $rooms ) {
		echo '<p><em>Rooms will be listed here after the next check of Planning Center.</em></p>';
		return;
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_rooms">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th style="width:130px">Show on website</th><th>Room in Planning Center</th><th style="width:280px">Public name (optional)</th><th>Used by</th></tr></thead><tbody>';
	foreach ( $rooms as $rid => $name ) {
		$row = isset( $s['rooms'][ $rid ] ) ? (array) $s['rooms'][ $rid ] : array();
		echo '<tr><td><input type="hidden" name="room_names[' . esc_attr( $rid ) . ']" value="' . esc_attr( $name ) . '"><label><input type="checkbox" name="room_show[' . esc_attr( $rid ) . ']" value="1"' . checked( ! empty( $row['show'] ), true, false ) . '> Show</label></td>';
		echo '<td>' . esc_html( $name ) . '</td>';
		echo '<td><input type="text" name="room_label[' . esc_attr( $rid ) . ']" class="regular-text" style="width:100%" value="' . esc_attr( isset( $row['label'] ) ? (string) $row['label'] : '' ) . '" placeholder="' . esc_attr( $name ) . '"></td>';
		echo '<td>' . esc_html( isset( $used[ $rid ] ) ? implode( ', ', array_unique( $used[ $rid ] ) ) : '' ) . '</td></tr>';
	}
	echo '</tbody></table>';
	submit_button( 'Save rooms' );
	echo '</form>';
	echo '<p>For the page builder: <code>[tcc_event_rooms]</code> shows the rooms of the event as rounded labels, and nothing when there are none.</p>';
}

function tcc_pco_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$tab       = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'waiting';
	$items     = tcc_pco_items();
	$conflicts = tcc_pco_conflicts();
	$groups    = array( 'new' => array(), 'approved' => array(), 'ignored' => array(), 'unsynced' => array() );
	$passed    = 0;
	foreach ( $items as $id => $item ) {
		$status = isset( $item['status'] ) ? $item['status'] : 'new';
		if ( tcc_pco_item_passed( $item ) ) {
			// Over and done: not listed any more. Its website pages keep the last details they had.
			$passed += in_array( $status, array( 'approved', 'unsynced' ), true ) ? 1 : 0;
			continue;
		}
		if ( 'new' === $status && ! empty( $item['gone'] ) ) {
			continue;
		}
		if ( isset( $groups[ $status ] ) && ! empty( $item['data'] ) ) {
			$groups[ $status ][ $id ] = $item;
		}
	}
	$s        = tcc_pco_settings();
	$new_tags = count( array_diff( array_keys( tcc_pco_known_tags() ), array_map( 'strval', (array) $s['tags_seen'] ) ) );
	$tabs     = array(
		'waiting'   => 'Waiting for approval (' . count( $groups['new'] ) . ')',
		'synced'    => 'On the website (' . count( $groups['approved'] ) . ')',
		'conflicts' => 'Conflicts (' . count( $conflicts ) . ')',
		'changes'   => 'Recent changes',
		'tags'      => 'Tags' . ( $new_tags ? ' (' . $new_tags . ' new)' : '' ),
		'rooms'     => 'Rooms',
		'settings'  => 'Settings',
	);
	$last = get_option( 'tcc_pco_last_run', array() );

	echo '<div class="wrap"><h1>Planning Center Sync</h1>';
	if ( isset( $_GET['tcc_msg'] ) ) {
		echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['tcc_msg'] ) ) ) . '</p></div>';
	}
	if ( ! function_exists( 'tribe_create_event' ) ) {
		echo '<div class="notice notice-error"><p>The Events Calendar plugin is not active, so events cannot be added to the website.</p></div>';
	}
	echo '<p>Events published to Church Center in Planning Center Calendar show up here. Nothing goes on the website until you approve it. Planning Center is never changed by this page.</p>';
	echo '<p>' . tcc_pco_button( 'check_now', 'Check Planning Center now', array( 'tab' => $tab ), 'button button-primary' );
	if ( ! empty( $last['time'] ) ) {
		echo ' <span style="color:' . ( ! empty( $last['ok'] ) ? '#50575e' : '#b32d2e' ) . '">Last check ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago: ' . esc_html( isset( $last['message'] ) ? $last['message'] : '' ) . '</span>';
	} else {
		echo ' <span style="color:#50575e">Not checked yet.</span>';
	}
	echo '</p><h2 class="nav-tab-wrapper">';
	foreach ( $tabs as $key => $label ) {
		echo '<a class="nav-tab' . ( $tab === $key ? ' nav-tab-active' : '' ) . '" href="' . esc_url( tcc_pco_url( $key ) ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</h2><div style="margin-top:16px">';

	if ( 'waiting' === $tab ) {
		if ( '' === $s['app_id'] || '' === $s['secret'] ) {
			echo '<p><strong>Planning Center is not connected yet.</strong> Add the Application ID and Secret on the <a href="' . esc_url( tcc_pco_url( 'settings' ) ) . '">Settings</a> tab.</p>';
		}
		tcc_pco_table( $groups['new'], 'waiting', 'Nothing is waiting. New events published to Church Center will appear here.' );
		if ( $groups['ignored'] ) {
			echo '<h3>Hidden (you chose not to put these on the website)</h3>';
			tcc_pco_table( $groups['ignored'], 'ignored', '' );
		}
	} elseif ( 'synced' === $tab ) {
		tcc_pco_table( $groups['approved'], 'synced', 'No events are being synced yet. Approve one on the Waiting for approval tab.' );
		if ( $groups['unsynced'] ) {
			echo '<h3>Stopped (no longer kept up to date)</h3>';
			tcc_pco_table( $groups['unsynced'], 'unsynced', '' );
		}
		if ( $passed ) {
			echo '<p style="color:#50575e">' . (int) $passed . ' event' . ( 1 === $passed ? ' has' : 's have' ) . ' passed and ' . ( 1 === $passed ? 'is' : 'are' ) . ' no longer listed here. Their pages stay on the website with the last details they had.</p>';
		}
	} elseif ( 'conflicts' === $tab ) {
		tcc_pco_conflicts_table( $conflicts );
	} elseif ( 'changes' === $tab ) {
		$log = get_option( 'tcc_pco_log', array() );
		if ( ! $log ) {
			echo '<p>No changes yet.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th style="width:180px">When</th><th>What happened</th><th style="width:120px"></th></tr></thead><tbody>';
			foreach ( (array) $log as $row ) {
				echo '<tr><td>' . esc_html( wp_date( 'M j, Y g:i a', (int) $row['time'] ) ) . '</td><td>' . esc_html( $row['message'] ) . '</td><td>';
				if ( ! empty( $row['post_id'] ) && get_post( (int) $row['post_id'] ) ) {
					echo '<a href="' . esc_url( get_edit_post_link( (int) $row['post_id'] ) ) . '">Open event</a>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}
	} elseif ( 'tags' === $tab ) {
		tcc_pco_tags_form( $s, $items );
	} elseif ( 'rooms' === $tab ) {
		tcc_pco_rooms_form( $s, $items );
	} else {
		tcc_pco_settings_form( $s, $items );
	}
	echo '</div></div>';
}

function tcc_pco_table( $rows, $mode, $empty ) {
	if ( ! $rows ) {
		if ( $empty ) {
			echo '<p>' . esc_html( $empty ) . '</p>';
		}
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th style="width:130px">Graphic</th><th>Event</th><th style="width:230px">Next dates</th><th style="width:330px">Actions</th></tr></thead><tbody>';
	foreach ( $rows as $id => $item ) {
		$ev = $item['data'];
		echo '<tr><td>';
		if ( ! empty( $ev['image_url'] ) ) {
			echo '<img src="' . esc_url( $ev['image_url'] ) . '" alt="" style="width:120px;height:auto;border-radius:4px">';
		} else {
			echo '<em>No graphic</em>';
		}
		echo '</td><td><strong>' . esc_html( $ev['name'] ) . '</strong>';
		if ( ! empty( $item['gone'] ) ) {
			echo ' <span style="color:#b32d2e">(no longer published in Planning Center)</span>';
		}
		$text = wp_strip_all_tags( '' !== $ev['summary'] ? $ev['summary'] : $ev['description'] );
		if ( '' !== $text ) {
			echo '<br>' . esc_html( wp_html_excerpt( $text, 220, '...' ) );
		}
		$bits = array();
		$bits[] = ! empty( $ev['registration_url'] ) ? 'Has a registration link' : 'No registration link';
		$rooms  = tcc_pco_event_rooms( $ev );
		if ( $rooms && 'synced' !== $mode ) {
			$bits[] = 'Rooms: ' . esc_html( implode( ', ', $rooms ) );
		}
		echo '<br><span style="color:#50575e">' . implode( ' &middot; ', $bits ) . '</span>';
		echo tcc_pco_tags_html( $ev );
		if ( 'synced' === $mode ) {
			echo tcc_pco_event_rooms_form( $id, $rooms );
		}
		if ( 'synced' === $mode || 'unsynced' === $mode ) {
			$links = array();
			foreach ( tcc_pco_posts_for( $id ) as $post ) {
				if ( tcc_pco_post_passed( $post->ID ) ) {
					continue; // Dates that are over are left alone and not listed.
				}
				$links[] = '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( mysql2date( 'M j', (string) get_post_meta( $post->ID, '_EventStartDate', true ) ) ) . '</a>';
			}
			if ( $links ) {
				echo '<br>Website events: ' . implode( ', ', $links );
			}
		}
		echo '</td><td>' . tcc_pco_when( $ev ) . '</td><td>';
		$f = array( 'id' => $id );
		if ( 'waiting' === $mode ) {
			echo tcc_pco_button( 'approve', 'Approve and add to website', $f, 'button button-primary' );
			echo tcc_pco_button( 'ignore', 'Hide', $f );
		} elseif ( 'ignored' === $mode ) {
			echo tcc_pco_button( 'restore', 'Move back to waiting', $f );
		} elseif ( 'synced' === $mode ) {
			echo tcc_pco_button( 'unsync_keep', 'Stop syncing, keep on website', $f );
			echo tcc_pco_button( 'unsync_remove', 'Stop syncing and remove', $f, 'button button-link-delete', 'Move the upcoming website dates of this event to the Trash?' );
		} else {
			echo tcc_pco_button( 'approve', 'Start syncing again', $f );
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

function tcc_pco_conflicts_table( $conflicts ) {
	if ( ! $conflicts ) {
		echo '<p>No conflicts. A conflict appears when something was changed on the website and was also changed in Planning Center, so the sync cannot tell which one you want.</p>';
		return;
	}
	echo '<p>These were changed in both places. Nothing has been overwritten. Choose which version to keep.</p>';
	echo '<table class="widefat striped"><thead><tr><th>Event</th><th style="width:90px">What</th><th>On the website now</th><th>In Planning Center</th><th style="width:300px">Choose</th></tr></thead><tbody>';
	foreach ( $conflicts as $key => $c ) {
		$post = get_post( (int) $c['post_id'] );
		echo '<tr><td>' . ( $post ? '<a href="' . esc_url( get_edit_post_link( $post->ID ) ) . '">' . esc_html( get_the_title( $post ) ) . '</a>' : '<em>Event no longer exists</em>' ) . '</td>';
		echo '<td>' . esc_html( tcc_pco_field_label( $c['field'] ) ) . '</td>';
		if ( 'image' === $c['field'] ) {
			echo '<td>' . ( $post && has_post_thumbnail( $post ) ? get_the_post_thumbnail( $post, array( 120, 68 ) ) : esc_html( $c['website'] ) ) . '</td>';
			echo '<td><img src="' . esc_url( $c['pco'] ) . '" alt="" style="width:120px;height:auto"></td>';
		} else {
			echo '<td>' . esc_html( $c['website'] ) . '</td><td>' . esc_html( $c['pco'] ) . '</td>';
		}
		echo '<td>' . tcc_pco_button( 'resolve', 'Use Planning Center', array( 'key' => $key, 'choice' => 'pco' ), 'button button-primary' );
		echo tcc_pco_button( 'resolve', 'Keep website', array( 'key' => $key, 'choice' => 'site' ) ) . '</td></tr>';
	}
	echo '</tbody></table>';
}

function tcc_pco_settings_form( $s, $items ) {
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="tcc_pco_do"><input type="hidden" name="op" value="save_settings">';
	wp_nonce_field( 'tcc_pco_do', '_tcc_pco_nonce' );
	echo '<h2>Connection</h2><p>Create a Personal Access Token at <code>api.planningcenteronline.com/oauth/applications</code> (signed in as a Planning Center admin), then paste its two values here. It is only used to read Calendar.</p>';
	echo '<table class="form-table"><tr><th><label for="tcc_app_id">Application ID</label></th><td><input type="text" id="tcc_app_id" name="app_id" class="regular-text" autocomplete="off" value="' . esc_attr( $s['app_id'] ) . '"></td></tr>';
	echo '<tr><th><label for="tcc_secret">Secret</label></th><td><input type="password" id="tcc_secret" name="secret" class="regular-text" autocomplete="new-password" value="" placeholder="' . ( '' !== $s['secret'] ? 'Saved. Leave empty to keep it.' : '' ) . '"></td></tr>';
	echo '<tr><th><label for="tcc_per">Dates per repeating event</label></th><td><input type="number" id="tcc_per" name="per_event" min="1" max="10" value="' . (int) $s['per_event'] . '" class="small-text"> <span class="description">How many upcoming dates of a repeating event to keep on the website.</span></td></tr></table>';
	echo '<h2>Plugin updates</h2><p>New versions of this plugin are published at <code>github.com/' . esc_html( TCC_PCO_RELEASES ) . '</code> and show up on the Plugins screen like any other update. No key or password is needed.</p>';
	echo '<table class="form-table">';
	$up = get_option( 'tcc_pco_update_status', array() );
	echo '<tr><th>Installed version</th><td>' . esc_html( TCC_PCO_VERSION );
	if ( ! empty( $up['time'] ) ) {
		echo ' &nbsp; <span style="color:' . ( ! empty( $up['ok'] ) ? '#50575e' : '#b32d2e' ) . '">Last looked ' . esc_html( human_time_diff( (int) $up['time'] ) ) . ' ago: ' . esc_html( isset( $up['message'] ) ? $up['message'] : '' ) . '</span>';
	}
	echo '</td></tr></table>';
	submit_button( 'Save settings' );
	echo '</form>';
	echo '<p>' . tcc_pco_button( 'check_update', 'Check for a new version now' ) . '</p>';
	echo '<h2>For the page builder</h2><p><code>[tcc_pco_description]</code> shows the description from Planning Center on an event page. <code>[tcc_event_register label="Register"]</code> shows a button when the event has a registration link. <code>[tcc_event_rooms label="Rooms"]</code> lists the rooms ticked on the Rooms tab. Categories are set on the <a href="' . esc_url( tcc_pco_url( 'tags' ) ) . '">Tags</a> tab.</p>';
}

/* ---------------------------------------------------------------------------
 * Handling the buttons
 * ------------------------------------------------------------------------- */

function tcc_pco_handle() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'tcc_pco_do', '_tcc_pco_nonce' );
	$op    = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
	$id    = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
	$items = tcc_pco_items();
	$tab   = 'waiting';
	$msg   = '';
	$name  = isset( $items[ $id ]['data']['name'] ) ? $items[ $id ]['data']['name'] : 'the event';

	if ( 'check_now' === $op ) {
		$tab    = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'waiting';
		$result = tcc_pco_run();
		$msg    = is_wp_error( $result ) ? $result->get_error_message() : 'Checked Planning Center. ' . (int) $result . ' new event(s) waiting.';
	} elseif ( 'approve' === $op && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'approved';
		tcc_pco_save_items( $items );
		foreach ( tcc_pco_posts_for( $id ) as $post ) {
			delete_post_meta( $post->ID, '_tcc_pco_paused' );
		}
		tcc_pco_log( 'Approved "' . $name . '" for the website.' );
		if ( empty( $items[ $id ]['gone'] ) ) {
			tcc_pco_apply_event( $items[ $id ]['data'] );
		}
		$tab = 'synced';
		$msg = '"' . $name . '" is now on the website and will be kept up to date.';
	} elseif ( in_array( $op, array( 'ignore', 'restore' ), true ) && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'ignore' === $op ? 'ignored' : 'new';
		tcc_pco_save_items( $items );
		$msg = 'ignore' === $op ? '"' . $name . '" is hidden.' : '"' . $name . '" is waiting for approval again.';
	} elseif ( in_array( $op, array( 'unsync_keep', 'unsync_remove' ), true ) && isset( $items[ $id ] ) ) {
		$items[ $id ]['status'] = 'unsynced';
		tcc_pco_save_items( $items );
		$tab = 'synced';
		if ( 'unsync_remove' === $op ) {
			$n   = tcc_pco_trash_future_posts( $id, array() );
			$msg = 'Stopped syncing "' . $name . '" and moved ' . $n . ' upcoming date(s) to the Trash.';
		} else {
			foreach ( tcc_pco_posts_for( $id ) as $post ) {
				update_post_meta( $post->ID, '_tcc_pco_paused', 1 );
			}
			$msg = 'Stopped syncing "' . $name . '". The website events stay as they are.';
		}
		tcc_pco_log( $msg );
	} elseif ( 'resolve' === $op ) {
		$key       = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$choice    = isset( $_POST['choice'] ) ? sanitize_key( wp_unslash( $_POST['choice'] ) ) : '';
		$conflicts = tcc_pco_conflicts();
		$tab       = 'conflicts';
		if ( isset( $conflicts[ $key ] ) ) {
			$msg = tcc_pco_resolve( $conflicts[ $key ], $choice );
		}
	} elseif ( 'save_settings' === $op ) {
		$s              = tcc_pco_settings();
		$s['app_id']    = isset( $_POST['app_id'] ) ? sanitize_text_field( wp_unslash( $_POST['app_id'] ) ) : '';
		$secret         = isset( $_POST['secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['secret'] ) ) ) : '';
		$s['secret']    = '' !== $secret ? $secret : $s['secret'];
		$s['per_event'] = isset( $_POST['per_event'] ) ? max( 1, min( 10, (int) $_POST['per_event'] ) ) : 2;
		unset( $s['github_token'] ); // Left over from 0.3.0; no key is used any more.
		update_option( 'tcc_pco_settings', $s, false );
		$tab = 'settings';
		$msg = 'Settings saved.';
	} elseif ( 'check_update' === $op ) {
		$tab = 'settings';
		$msg = tcc_pco_update_check_now();
	} elseif ( 'save_tags' === $op ) {
		$s    = tcc_pco_settings();
		$ids  = isset( $_POST['tag_ids'] ) && is_array( $_POST['tag_ids'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tag_ids'] ) ) : array();
		$post = isset( $_POST['tag_map'] ) && is_array( $_POST['tag_map'] ) ? wp_unslash( $_POST['tag_map'] ) : array();
		$map  = (array) $s['tag_map'];
		foreach ( $ids as $tid ) {
			$term = isset( $post[ $tid ] ) ? (int) $post[ $tid ] : 0;
			if ( $term > 0 ) {
				$map[ $tid ] = $term;
			} else {
				unset( $map[ $tid ] );
			}
		}
		$s['tag_map']   = $map;
		$s['tags_seen'] = array_values( array_unique( array_merge( array_map( 'strval', (array) $s['tags_seen'] ), $ids ) ) );
		update_option( 'tcc_pco_settings', $s, false );
		// Bring the events that are already on the website in line straight away.
		$n = 0;
		foreach ( $items as $eid => $item ) {
			if ( isset( $item['status'] ) && 'approved' === $item['status'] && empty( $item['gone'] ) && ! empty( $item['data'] ) ) {
				foreach ( tcc_pco_posts_for( $eid ) as $post_obj ) {
					if ( ! get_post_meta( $post_obj->ID, '_tcc_pco_paused', true ) && ! tcc_pco_post_passed( $post_obj->ID ) ) {
						tcc_pco_sync_terms( $post_obj->ID, $item['data'], $s );
						$n++;
					}
				}
			}
		}
		$tab = 'tags';
		$msg = 'Tags saved. ' . count( $map ) . ' public, the rest internal. ' . $n . ' website event(s) checked.';
		tcc_pco_log( 'Tags saved: ' . count( $map ) . ' public tag(s).' );
	} elseif ( 'save_cats' === $op ) {
		$tab     = 'tags';
		$renamed = 0;
		$added   = '';
		$errors  = array();
		if ( taxonomy_exists( 'tribe_events_cat' ) ) {
			$names = isset( $_POST['cat_name'] ) && is_array( $_POST['cat_name'] ) ? wp_unslash( $_POST['cat_name'] ) : array();
			// Names already in use (lower case => category id), so two categories never end up with the same name.
			$taken = array();
			$all   = get_terms( array( 'taxonomy' => 'tribe_events_cat', 'hide_empty' => false ) );
			foreach ( is_wp_error( $all ) ? array() : (array) $all as $t ) {
				$taken[ strtolower( html_entity_decode( $t->name, ENT_QUOTES ) ) ] = (int) $t->term_id;
			}
			foreach ( $names as $term_id => $name ) {
				$name = trim( sanitize_text_field( (string) $name ) );
				$term = get_term( (int) $term_id, 'tribe_events_cat' );
				if ( '' === $name || ! $term || is_wp_error( $term ) || html_entity_decode( $term->name, ENT_QUOTES ) === $name ) {
					continue;
				}
				if ( isset( $taken[ strtolower( $name ) ] ) && $taken[ strtolower( $name ) ] !== (int) $term_id ) {
					$errors[] = '"' . $name . '" is already the name of another category';
					continue;
				}
				unset( $taken[ strtolower( html_entity_decode( $term->name, ENT_QUOTES ) ) ] );
				$taken[ strtolower( $name ) ] = (int) $term_id;
				// Only the name changes. The slug stays, so page lists and links keep working.
				$done = wp_update_term( (int) $term_id, 'tribe_events_cat', array( 'name' => $name, 'slug' => $term->slug ) );
				if ( is_wp_error( $done ) ) {
					$errors[] = '"' . $name . '": ' . $done->get_error_message();
				} else {
					$renamed++;
					tcc_pco_log( 'Renamed website category "' . html_entity_decode( $term->name, ENT_QUOTES ) . '" to "' . $name . '".' );
				}
			}
			$new = isset( $_POST['cat_new'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['cat_new'] ) ) ) : '';
			if ( '' !== $new && isset( $taken[ strtolower( $new ) ] ) ) {
				$errors[] = '"' . $new . '" already exists';
			} elseif ( '' !== $new ) {
				$done = wp_insert_term( $new, 'tribe_events_cat' );
				if ( is_wp_error( $done ) ) {
					$errors[] = '"' . $new . '": ' . $done->get_error_message();
				} else {
					$added = $new;
					tcc_pco_log( 'Added website category "' . $new . '".' );
				}
			}
		}
		$msg = 'Website categories saved: ' . $renamed . ' renamed' . ( '' !== $added ? ', "' . $added . '" added' : '' ) . '.' . ( $errors ? ' Not done: ' . implode( '; ', $errors ) : '' );
	} elseif ( 'save_event_rooms' === $op && isset( $items[ $id ] ) ) {
		$s   = tcc_pco_settings();
		$tab = 'synced';
		if ( ! empty( $_POST['reset'] ) ) {
			unset( $s['event_rooms'][ $id ] );
			$msg = '"' . $name . '" follows the Rooms tab again.';
		} else {
			$all    = isset( $_POST['all_rooms'] ) && is_array( $_POST['all_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['all_rooms'] ) ) : array();
			$show   = isset( $_POST['show_rooms'] ) && is_array( $_POST['show_rooms'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['show_rooms'] ) ) : array();
			$choice = isset( $s['event_rooms'][ $id ] ) && is_array( $s['event_rooms'][ $id ] ) ? $s['event_rooms'][ $id ] : array();
			foreach ( $all as $rid ) {
				$choice[ $rid ] = in_array( $rid, $show, true ) ? 1 : 0;
			}
			if ( ! is_array( $s['event_rooms'] ) ) {
				$s['event_rooms'] = array();
			}
			$s['event_rooms'][ $id ] = $choice;
			$msg                     = 'Rooms saved for "' . $name . '": ' . count( $show ) . ' showing.';
		}
		update_option( 'tcc_pco_settings', $s, false );
		tcc_pco_log( $msg );
	} elseif ( 'save_rooms' === $op ) {
		$s      = tcc_pco_settings();
		$names  = isset( $_POST['room_names'] ) && is_array( $_POST['room_names'] ) ? wp_unslash( $_POST['room_names'] ) : array();
		$show   = isset( $_POST['room_show'] ) && is_array( $_POST['room_show'] ) ? wp_unslash( $_POST['room_show'] ) : array();
		$labels = isset( $_POST['room_label'] ) && is_array( $_POST['room_label'] ) ? wp_unslash( $_POST['room_label'] ) : array();
		$rooms  = (array) $s['rooms'];
		$shown  = 0;
		foreach ( $names as $rid => $name ) {
			$rid           = sanitize_text_field( (string) $rid );
			$rooms[ $rid ] = array(
				'name'  => sanitize_text_field( (string) $name ),
				'show'  => ! empty( $show[ $rid ] ),
				'label' => isset( $labels[ $rid ] ) ? sanitize_text_field( (string) $labels[ $rid ] ) : '',
			);
		}
		foreach ( $rooms as $row ) {
			$shown += ! empty( $row['show'] ) ? 1 : 0;
		}
		$s['rooms'] = $rooms;
		update_option( 'tcc_pco_settings', $s, false );
		$tab = 'rooms';
		$msg = 'Rooms saved. ' . $shown . ' room(s) can show on the website.';
	}
	wp_safe_redirect( tcc_pco_url( $tab, $msg ? array( 'tcc_msg' => rawurlencode( $msg ) ) : array() ) );
	exit;
}
add_action( 'admin_post_tcc_pco_do', 'tcc_pco_handle' );

function tcc_pco_resolve( $c, $choice ) {
	$post_id = (int) $c['post_id'];
	$field   = (string) $c['field'];
	$synced  = get_post_meta( $post_id, '_tcc_pco_synced', true );
	$synced  = is_array( $synced ) ? $synced : array();
	$title   = get_post( $post_id ) ? get_the_title( $post_id ) : 'the event';
	if ( 'pco' === $choice && get_post( $post_id ) && function_exists( 'tribe_update_event' ) ) {
		if ( 'image' === $field ) {
			$att = tcc_pco_image_attachment( (string) $c['pco'], $title );
			if ( $att ) {
				set_post_thumbnail( $post_id, $att );
				$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
				$synced['image_att'] = $att;
			}
		} elseif ( 'title' === $field ) {
			tribe_update_event( $post_id, array( 'post_title' => (string) $c['pco'] ) );
			$synced['title'] = (string) $c['pco'];
		} else {
			$start = 'start' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventStartDate', true );
			$end   = 'end' === $field ? (string) $c['pco'] : (string) get_post_meta( $post_id, '_EventEndDate', true );
			tribe_update_event( $post_id, tcc_pco_date_args( $start, $end, 'yes' === get_post_meta( $post_id, '_EventAllDay', true ) ) );
			$synced[ $field ] = (string) $c['pco'];
		}
		$msg = 'Used the Planning Center ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
	} else {
		// Keep the website's version and remember what Planning Center has, so it is not asked again until Planning Center changes it again.
		if ( 'image' === $field ) {
			$synced['image']     = tcc_pco_image_key( (string) $c['pco'] );
			$synced['image_att'] = (int) get_post_thumbnail_id( $post_id );
		} else {
			$synced[ $field ] = (string) $c['pco'];
		}
		$msg = 'Kept the website ' . strtolower( tcc_pco_field_label( $field ) ) . ' for "' . $title . '".';
	}
	update_post_meta( $post_id, '_tcc_pco_synced', $synced );
	tcc_pco_clear_conflict( $post_id, $field );
	tcc_pco_log( $msg, $post_id );
	return $msg;
}

/* ---------------------------------------------------------------------------
 * A box on the event edit screen
 * ------------------------------------------------------------------------- */

function tcc_pco_meta_box() {
	add_meta_box( 'tcc_pco_box', 'Planning Center and registration', 'tcc_pco_meta_box_html', 'tribe_events', 'side', 'default' );
}
add_action( 'add_meta_boxes', 'tcc_pco_meta_box' );

/** One coloured status line for the box on the event edit screen. */
function tcc_pco_status_line( $colour, $text ) {
	return '<p style="margin:0 0 8px"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' . esc_attr( $colour ) . ';margin-right:6px"></span><strong>' . esc_html( $text ) . '</strong></p>';
}

function tcc_pco_meta_box_html( $post ) {
	wp_nonce_field( 'tcc_pco_box', '_tcc_pco_box_nonce' );
	$event_id = (string) get_post_meta( $post->ID, '_tcc_pco_event_id', true );
	if ( '' !== $event_id ) {
		$items  = tcc_pco_items();
		$item   = isset( $items[ $event_id ] ) ? $items[ $event_id ] : array();
		$status = isset( $item['status'] ) ? $item['status'] : '';
		$paused = (bool) get_post_meta( $post->ID, '_tcc_pco_paused', true );

		// Sync status.
		if ( tcc_pco_post_passed( $post->ID ) ) {
			echo tcc_pco_status_line( '#8c8f94', 'This date has passed.' );
			echo '<p>It is no longer updated from Planning Center. It keeps the last details it had.</p>';
		} elseif ( $paused || 'approved' !== $status ) {
			echo tcc_pco_status_line( '#dba617', 'Syncing is stopped for this event.' );
			echo '<p>Nothing here is changed by Planning Center until syncing is started again on the Planning Center screen.</p>';
		} elseif ( ! empty( $item['gone'] ) ) {
			echo tcc_pco_status_line( '#b32d2e', 'No longer published in Planning Center.' );
			echo '<p>Planning Center has stopped listing this event, so it is not being updated.</p>';
		} else {
			$last = get_option( 'tcc_pco_last_run', array() );
			echo tcc_pco_status_line( '#00a32a', 'Kept up to date from Planning Center.' );
			echo '<p>' . ( ! empty( $last['time'] ) ? 'Last checked ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago. ' : '' ) . 'The title, dates, graphic, description, registration link, location, rooms and public-tag categories come from Planning Center. The page content is yours.</p>';
		}
		$clashes = 0;
		foreach ( tcc_pco_conflicts() as $c ) {
			$clashes += isset( $c['post_id'] ) && (int) $c['post_id'] === (int) $post->ID ? 1 : 0;
		}
		if ( $clashes ) {
			echo '<p style="color:#b32d2e">' . (int) $clashes . ' thing' . ( 1 === $clashes ? ' was' : 's were' ) . ' changed both here and in Planning Center. ' . ( current_user_can( 'manage_options' ) ? '<a href="' . esc_url( tcc_pco_url( 'conflicts' ) ) . '">Choose which to keep</a>' : 'An administrator can choose which to keep.' ) . '</p>';
		}
		if ( current_user_can( 'manage_options' ) ) {
			echo '<p><a href="' . esc_url( tcc_pco_url( 'synced' ) ) . '">Open the Planning Center screen</a></p>';
		}

		// Rooms shown on the event page.
		$rooms = get_post_meta( $post->ID, '_tcc_pco_rooms', true );
		echo '<hr><p style="margin-bottom:4px"><strong>Rooms shown on the event page</strong></p>';
		if ( ! is_array( $rooms ) || ! $rooms ) {
			echo '<p><em>No rooms are booked for this date in Planning Center.</em></p>';
		} else {
			$s      = tcc_pco_settings();
			$custom = ! empty( $s['event_rooms'][ $event_id ] );
			foreach ( $rooms as $rid => $name ) {
				$label = tcc_pco_room_label( $s, (string) $rid, $name );
				echo '<input type="hidden" name="tcc_pco_rooms_all[]" value="' . esc_attr( $rid ) . '">';
				echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="tcc_pco_rooms_show[]" value="' . esc_attr( $rid ) . '"' . checked( tcc_pco_room_visible( $s, $event_id, (string) $rid ), true, false ) . '> ' . esc_html( $label ) . ( $label !== trim( (string) $name ) ? ' <span style="color:#8c8f94">(' . esc_html( trim( (string) $name ) ) . ')</span>' : '' ) . '</label>';
			}
			echo '<p class="description">Ticked rooms show to visitors. ' . ( $custom ? 'These were chosen for this event.' : 'These follow the Rooms tab until you change a tick here.' ) . ' A change applies to every date of this event and is saved when you update the event.</p>';
			if ( $custom ) {
				echo '<p><label><input type="checkbox" name="tcc_pco_rooms_reset" value="1"> Go back to the Rooms tab settings</label></p>';
			}
		}

		$desc = (string) get_post_meta( $post->ID, '_tcc_pco_description', true );
		echo '<hr><p><label>Description from Planning Center (read only)</label><textarea readonly rows="5" style="width:100%">' . esc_textarea( wp_strip_all_tags( $desc ) ) . '</textarea></p>';
		$reg = (string) get_post_meta( $post->ID, '_tcc_pco_registration_url', true );
		echo '<p>Planning Center registration link: ' . ( '' !== $reg ? '<a href="' . esc_url( $reg ) . '" target="_blank" rel="noopener">open</a>' : '<em>none</em>' ) . '</p>';
	} else {
		echo '<p>This event was made on the website. It is not linked to Planning Center.</p>';
	}
	echo '<p><label for="tcc_register_url">Registration button link (optional)</label><input type="url" id="tcc_register_url" name="tcc_register_url" style="width:100%" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_url', true ) ) . '" placeholder="https://"><span class="description">If filled in, the Register button uses this instead of the Planning Center link.</span></p>';
	echo '<p><label for="tcc_register_label">Registration button text (optional)</label><input type="text" id="tcc_register_label" name="tcc_register_label" maxlength="40" style="width:100%" value="' . esc_attr( (string) get_post_meta( $post->ID, '_tcc_register_label', true ) ) . '" placeholder="Register"><span class="description">For this event only, for example "Sign up" or "Get tickets". Leave empty for the usual text. Keep it short.</span></p>';
}

function tcc_pco_meta_box_save( $post_id ) {
	if ( ! isset( $_POST['_tcc_pco_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_tcc_pco_box_nonce'] ) ), 'tcc_pco_box' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$url = isset( $_POST['tcc_register_url'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['tcc_register_url'] ) ) ) : '';
	if ( '' === $url ) {
		delete_post_meta( $post_id, '_tcc_register_url' );
	} else {
		update_post_meta( $post_id, '_tcc_register_url', $url );
	}
	$label = isset( $_POST['tcc_register_label'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['tcc_register_label'] ) ) ) : '';
	if ( '' === $label ) {
		delete_post_meta( $post_id, '_tcc_register_label' );
	} else {
		update_post_meta( $post_id, '_tcc_register_label', function_exists( 'mb_substr' ) ? mb_substr( $label, 0, 40 ) : substr( $label, 0, 40 ) );
	}

	// Room ticks. Only saved as this event's own choice when a tick was really changed,
	// so simply updating an event does not stop it following the Rooms tab.
	$event_id = (string) get_post_meta( $post_id, '_tcc_pco_event_id', true );
	if ( '' === $event_id || ! isset( $_POST['tcc_pco_rooms_all'] ) || ! is_array( $_POST['tcc_pco_rooms_all'] ) ) {
		return;
	}
	$s     = tcc_pco_settings();
	$title = get_the_title( $post_id );
	if ( ! is_array( $s['event_rooms'] ) ) {
		$s['event_rooms'] = array();
	}
	if ( ! empty( $_POST['tcc_pco_rooms_reset'] ) ) {
		if ( isset( $s['event_rooms'][ $event_id ] ) ) {
			unset( $s['event_rooms'][ $event_id ] );
			update_option( 'tcc_pco_settings', $s, false );
			tcc_pco_log( '"' . $title . '" follows the Rooms tab again.', $post_id );
		}
		return;
	}
	$all     = array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_all'] ) );
	$show    = isset( $_POST['tcc_pco_rooms_show'] ) && is_array( $_POST['tcc_pco_rooms_show'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['tcc_pco_rooms_show'] ) ) : array();
	$choice  = isset( $s['event_rooms'][ $event_id ] ) && is_array( $s['event_rooms'][ $event_id ] ) ? $s['event_rooms'][ $event_id ] : array();
	$changed = false;
	foreach ( $all as $rid ) {
		$want = in_array( $rid, $show, true );
		if ( $want !== tcc_pco_room_visible( $s, $event_id, $rid ) ) {
			$changed = true;
		}
		$choice[ $rid ] = $want ? 1 : 0;
	}
	if ( $changed ) {
		$s['event_rooms'][ $event_id ] = $choice;
		update_option( 'tcc_pco_settings', $s, false );
		tcc_pco_log( 'Rooms saved for "' . $title . '": ' . count( $show ) . ' showing.', $post_id );
	}
}
add_action( 'save_post_tribe_events', 'tcc_pco_meta_box_save' );
