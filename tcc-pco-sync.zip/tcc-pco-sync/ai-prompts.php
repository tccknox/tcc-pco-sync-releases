<?php
/**
 * TCC Planning Center Sync: the briefings for an AI assistant ("AI prompts").
 *
 * Someone who has to change this plugin may not have access to the church's GitHub repository
 * or its notes. These briefings stand in for that: they tell an AI assistant how the plugin is
 * put together, what it stores and what each file is for, so the assistant can help straight away.
 *
 * They are shown, with a Copy button, on Planning Center > Settings (one on each file's code page,
 * and one for the whole plugin at the bottom) and on Planning Center > Help. code-edits.php puts the pieces together: the briefing
 * about the website (the same for both plugins), then the plugin part below, then the part for one file.
 *
 * Keep these true. When the plugin changes, change the matching lines here in the same version,
 * exactly as with the Help tab. Write for an AI that has never seen this website: short, exact,
 * no guessing. Never put a key, a token or a person's details in here.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The briefing for the whole plugin, and one per file that can be edited. Used by code-edits.php. */
function tcc_pco_ai_notes() {
	$s         = tcc_pco_settings();
	$connected = '' !== $s['app_id'] && '' !== $s['secret'];

	$plugin = array(
		'What it is: it copies events from Planning Center Calendar onto the website, so nobody types them in twice. It is ONE-WAY. It only ever reads Planning Center (HTTP GET requests to ' . TCC_PCO_API . '); it must never write anything back. Any change that would send data to Planning Center is out of bounds.',
		'',
		'The life of an event:',
		'1. About once an hour (the WordPress scheduled task tcc_pco_sync_cron), or when someone presses "Check Planning Center now", the plugin asks Planning Center for upcoming events that are marked visible in Church Center.',
		'2. A new event waits on the "Waiting for approval" tab. Nothing appears on the website until a person approves it (unless it carries a tag that is set to approve automatically).',
		'3. An approved event becomes an ordinary event of The Events Calendar plugin (post type tribe_events), one website event per upcoming date, a few dates ahead for a repeating event.',
		'4. From then on Planning Center owns the title, date and time, graphic, description, registration link, location, rooms and (through tags) categories. The page content and anything added by hand belong to the website and are never touched.',
		'5. If a Planning Center-owned detail was changed on the website AND changed in Planning Center, nothing is overwritten: it is listed on the "Conflicts" tab for a person to choose.',
		'6. When an event\'s last date is over it drops off the plugin\'s lists; its page stays as it was. If it is taken off Church Center, its upcoming dates go to the Events Trash.',
		'',
		'How it is put together:',
		'- tcc-pco-sync.php is the main file. It only sets the version, loads the other files, and switches the hourly check on and off when the plugin is activated or deactivated.',
		'- sync.php is the sync itself: settings, the stored lists, the calls to Planning Center, what is new or changed, making and updating events, graphics, places, categories, and the short codes [tcc_pco_description], [tcc_event_register] and [tcc_event_rooms].',
		'- options.php holds the choices made for one event ("what shows", "keep the website\'s version", which description), the default graphic for events without one, and the box on the WordPress Dashboard.',
		'- admin.php draws the screen "Planning Center" with its tabs (Waiting for approval, On the website, Conflicts, Recent changes, Tags, Rooms, Settings, Help; the plugin\'s code is shown at the bottom of Settings), handles every button, and draws the box "Planning Center and registration" on each event\'s edit screen.',
		'- help.php is the Help tab. updater.php brings new versions from the public GitHub repository tccknox/tcc-pco-sync-releases; a person still presses "Update now". code-edits.php draws the code pages and saves edits. ai-prompts.php is the wording of this briefing.',
		'',
		'What it stores (all in the WordPress database; nothing is stored anywhere else):',
		'- Option tcc_pco_settings: the connection (app_id and secret: SECRET, never print, log or show them), how many dates to keep per event, tag_map (Planning Center tag id => website category id; a tag not listed is internal and never shows), auto_tags, rooms and event_rooms (which rooms may be shown, and their public names), show (which pieces of an event page show), desc_source, fallback_image and cat_images (default graphics).',
		'- Option tcc_pco_items: every Planning Center event the plugin has seen, keyed by its Planning Center id, with its status (new, approved, ignored, unsynced), its last known details and dates.',
		'- Options tcc_pco_log (the diary on "Recent changes", last 150 lines), tcc_pco_conflicts, tcc_pco_tags, tcc_pco_rooms_all, tcc_pco_last_run.',
		'- Custom fields on each website event: _tcc_pco_event_id and _tcc_pco_instance_id (which Planning Center event and date it is), _tcc_pco_synced (what was last written, used to tell whether someone changed it on the website), _tcc_pco_opts (the choices made for this event), _tcc_pco_paused, _tcc_pco_summary, _tcc_pco_description, _tcc_pco_registration_url, _tcc_pco_rooms, _tcc_pco_location, _tcc_pco_image_key.',
		'',
		'What it is connected to:',
		'- Planning Center: signed in with a Personal Access Token (Application ID and Secret) typed on the Settings tab. It is ' . ( $connected ? 'connected' : 'NOT connected' ) . ' on this website right now.',
		'- The Events Calendar plugin: approved events are saved through it. It is ' . ( function_exists( 'tribe_create_event' ) ? 'active' : 'NOT active' ) . ' here.',
		'- WordPress scheduled tasks (WP-Cron) for the hourly check. On the staging copy WP-Cron is driven by a cron job at the host every 30 minutes.',
		'- The church\'s other plugin, TCC Website Features: its event feeds use this plugin to treat the dates of one repeating event as one event (the filter tcc_upcoming_series_key), and its event page banner follows this plugin\'s "what shows" choices (the function tcc_pco_shows). Do not rename those.',
		'- The event page layout in Divi > Theme Builder, "Individual event page - BANNER (new)", which holds this plugin\'s three short codes.',
		'- The Media Library: each Planning Center graphic is copied in once, with "planning-center" in its file name.',
		'',
		'Rules that matter most here:',
		'- Never write to Planning Center. Never print, log or return the Application ID or Secret.',
		'- Be gentle with Planning Center and the server: no call to Planning Center while a visitor loads a page; calls happen only in the hourly check or when an administrator presses a button.',
		'- Never overwrite something a person changed on the website without the conflict step. Never delete an event outright; removed events go to the Trash.',
		'- Anything the plugin does to the website is written to the diary with tcc_pco_log(), in plain English.',
		'- A change to how a volunteer uses the plugin needs the matching change on the Help tab (help.php).',
	);

	$files = array(
		'sync.php'    => implode(
			"\n",
			array(
				'What it is: the sync itself. Read the plugin description above first; this file is where almost all of it happens.',
				'Main parts, in the order they appear: tcc_pco_settings() and the stored lists; tcc_pco_log(); tcc_pco_get() (the one function that calls Planning Center, read-only, with the token); refreshing tags and rooms; tcc_pco_fetch_events() (asks for future events visible in Church Center, 100 at a time, following pages); tcc_pco_ingest() (works out what is new, changed or gone, and approves automatically by tag); tcc_pco_run() (the whole check, guarded so two cannot run at once); dates and time zones (tcc_pco_local, tcc_pco_date_args); finding and trashing the website events of a Planning Center event; copying a graphic into the Media Library once; conflicts; categories from tags (tcc_pco_sync_terms); the venue (tcc_pco_venue_for); tcc_pco_apply_event() (makes and updates the website events of one approved event, and is the heart of the file); and the three short codes.',
				'Take special care with: tcc_pco_apply_event() (a mistake here changes or duplicates real events), dates and time zones (Planning Center gives UTC; the website shows local time), and the "did someone change this on the website" check that feeds the Conflicts tab (it compares against the custom field _tcc_pco_synced).',
				'Other files call functions from this one (tcc_pco_settings, tcc_pco_items, tcc_pco_run, tcc_pco_apply_event, tcc_pco_log and more). Do not rename a function or change what it returns without changing every caller; ask to see options.php and admin.php first.',
				'How to check a change, on the staging copy only: press "Check Planning Center now" and read the label at the top of the screen (it must not say the check failed); look at "Recent changes" for what was done; open an event that came from Planning Center and compare its title, date, time, graphic, place and rooms with Planning Center; open /events/ and the home page. A repeating event should show its next few dates, not duplicates.',
			)
		),
		'options.php' => implode(
			"\n",
			array(
				'What it is: the choices made for one event and the pieces that act on them. The choices are saved on each website event as one custom field, _tcc_pco_opts.',
				'Main parts: the list of pieces of an event page that can be hidden (tcc_pco_show_keys: description, Register button, location, rooms, end time) and of details a person can keep their own version of (tcc_pco_lock_keys: title, date and time, graphic, location, categories); tcc_pco_shows() and tcc_pco_locked(), which the rest of the plugin and TCC Website Features ask; which description an event page prints; hiding the short codes of a piece that is switched off (the pre_do_shortcode_tag filter) and a body class and a few lines of CSS for the same; the default graphic for events with none, shown without being saved onto the event (the post_thumbnail_id filter), and clearing Divi\'s style cache and the page caches when a graphic setting changes; carrying choices from one date of an event to the next; spotting a hand-made website event with the same name as a Planning Center one; the box on the WordPress Dashboard; and making sure the hourly check is scheduled.',
				'Take special care with: tcc_pco_shows() is called by the other plugin (TCC Website Features, the event page banner), so keep its name and what it returns. The default graphic must never be saved onto the event itself.',
				'How to check a change, on the staging copy only: open an event that came from Planning Center (Events > the event) and use the box "Planning Center and registration": untick a piece under "Show on the event page", save, and look at the event\'s page; put it back. Check an event with no graphic shows the default one on its page and on its card on /events/. Check the Dashboard box still says whether the sync is healthy.',
			)
		),
		'admin.php'   => implode(
			"\n",
			array(
				'What it is: everything an administrator sees and presses. The screen "Planning Center" (tcc_pco_admin_page) with its tabs; the panels for events (tcc_pco_table), tags, rooms and settings; tcc_pco_handle(), which every button posts to (it checks the person may manage the website and checks a nonce before doing anything, then redirects back with a plain message); resolving a conflict; and the box on each event\'s edit screen (tcc_pco_meta_box_html and tcc_pco_meta_box_save).',
				'House style for these screens: white rounded panels (class tcc-card), small status labels (class tcc-pill with --ok, --warn, --bad, --muted), one idea per panel, plain labels on buttons, a visible status, and usable on a narrow screen. All the CSS is in tcc_pco_admin_css(). Wording is for volunteers: plain English, no jargon.',
				'Take special care with: every action must keep its permission check and nonce check; everything printed must be escaped; the Secret must only ever be shown as an empty password box, never printed back; destructive buttons ask for confirmation and say what will happen.',
				'How to check a change, on the staging copy only: open Planning Center and click through every tab; press the button you changed and read the message that comes back; look at the screen at a narrow width (about 375 pixels) as well as a wide one; open an event\'s edit screen and check the box "Planning Center and registration" still saves.',
			)
		),
		'help.php'    => implode(
			"\n",
			array(
				'What it is: the Help tab (Planning Center > Help), one function, tcc_pco_help_tab( $s ), that prints panels of plain-English help.',
				'Who reads it: church volunteers, not programmers. Keep every sentence short and plain. Say where to click. The only technical panel is the last one, "For whoever builds the pages".',
				'How it is arranged: what the plugin does; how an event gets on the website; where to find things; what comes from Planning Center and what is the website\'s; "How do I..."; what it is connected to (with live status labels); changing the code and asking an AI; and what to do if something looks wrong.',
				'Rules: keep the function name and its argument; everything printed must be escaped or be fixed text written in this file; keep the CSS classes (tcc-card, tcc-help, tcc-pill).',
				'Pages to check after any change: Planning Center > Help at a wide screen and at phone width.',
			)
		),
	);

	return array(
		'plugin' => implode( "\n", $plugin ),
		'files'  => $files,
	);
}
