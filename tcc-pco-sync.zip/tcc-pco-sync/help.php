<?php
/**
 * TCC Planning Center Sync: the Help tab.
 *
 * Written for volunteers. It says what the plugin does, what it is connected to, where to find
 * things, and what to do when something looks wrong. Keep it in plain English and keep it true:
 * when a feature changes, change the matching lines here in the same version.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcc_pco_help_tab( $s ) {
	$tab  = function ( $key, $label ) {
		return '<a href="' . esc_url( tcc_pco_url( $key ) ) . '">' . esc_html( $label ) . '</a>';
	};
	$last = get_option( 'tcc_pco_last_run', array() );
	$next = wp_next_scheduled( 'tcc_pco_sync_cron' );

	echo '<div class="tcc-help">';

	echo '<div class="tcc-card"><h2>What this does</h2>';
	echo '<p>It copies events from <strong>Planning Center Calendar</strong> onto the website, so nobody has to type them in twice.</p><ul>';
	echo '<li>It only brings in events that are <strong>published to Church Center</strong> in Planning Center.</li>';
	echo '<li>Nothing appears on the website until someone <strong>approves</strong> it here.</li>';
	echo '<li>After that, the website copy is <strong>kept up to date</strong>: change the time in Planning Center and the website follows, usually within the hour.</li>';
	echo '<li>It only <strong>reads</strong> Planning Center. It can never change anything there.</li>';
	echo '</ul></div>';

	echo '<div class="tcc-card"><h2>How an event gets on the website</h2><ol>';
	echo '<li>In Planning Center Calendar, the event is set to show in Church Center.</li>';
	echo '<li>Within the hour it appears here under ' . $tab( 'waiting', 'Waiting for approval' ) . '. (Press <em>Check Planning Center now</em> if you do not want to wait.)</li>';
	echo '<li>You press <strong>Approve and add to website</strong>. If the website already has the same event made by hand, the page tells you and offers to replace it.</li>';
	echo '<li>The event is now on the website and listed under ' . $tab( 'synced', 'On the website' ) . '. A repeating event shows its next few dates.</li>';
	echo '<li>When its last date is over, it drops off these lists by itself. Its page stays as it was.</li>';
	echo '</ol></div>';

	echo '<div class="tcc-card"><h2>Where to find things</h2><table>';
	echo '<tr><th>' . $tab( 'waiting', 'Waiting for approval' ) . '</th><td>New events from Planning Center. Approve them, or hide the ones that should not be on the website.</td></tr>';
	echo '<tr><th>' . $tab( 'synced', 'On the website' ) . '</th><td>Events you approved. Stop syncing one here, choose its rooms, or jump to its edit screen.</td></tr>';
	echo '<tr><th>' . $tab( 'conflicts', 'Conflicts' ) . '</th><td>Only used when the same detail was changed on the website <em>and</em> in Planning Center. You pick which one to keep. Nothing is overwritten until you choose.</td></tr>';
	echo '<tr><th>' . $tab( 'changes', 'Recent changes' ) . '</th><td>A diary of everything the plugin did. Look here first when you wonder "why did that change?".</td></tr>';
	echo '<tr><th>' . $tab( 'tags', 'Tags' ) . '</th><td>Which Planning Center tags become website categories (and so which ministry pages an event shows on). Also where a tag can be set to approve events automatically.</td></tr>';
	echo '<tr><th>' . $tab( 'rooms', 'Rooms' ) . '</th><td>Which rooms may be shown to visitors, and the public name for each.</td></tr>';
	echo '<tr><th>' . $tab( 'settings', 'Settings' ) . '</th><td>The connection to Planning Center, what shows on event pages, the default graphic, and plugin updates.</td></tr>';
	echo '<tr><th>Events &rarr; an event</th><td>Each event\'s edit screen has a box called <strong>Planning Center and registration</strong>. That is where you change things for one event only.</td></tr>';
	echo '<tr><th>Dashboard</th><td>A small box called <strong>Planning Center Sync</strong> says whether everything is working.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>What comes from Planning Center, and what is yours</h2>';
	echo '<p><strong>From Planning Center:</strong> title, date and time, graphic, description, registration link, location, rooms, and categories (from tags marked public).</p>';
	echo '<p><strong>Yours on the website:</strong> anything you add to the page itself (text, pictures, buttons), the Register button\'s wording, and every choice in the event\'s <em>Planning Center and registration</em> box.</p>';
	echo '<p>If you want to keep your own version of a detail, tick it under <strong>Keep the website\'s version</strong> on that event. Planning Center then leaves it alone.</p>';
	echo '<p class="tcc-muted">A change that should apply everywhere (Church Center, the website, room bookings) has to be made in Planning Center. Each event has an <em>Edit in Planning Center</em> link.</p></div>';

	echo '<div class="tcc-card"><h2>How do I...</h2><table>';
	echo '<tr><th>Hide a room for one event</th><td>Open the event (Events &rarr; the event) and untick the room under <em>Rooms shown</em>. To hide a room everywhere, use the ' . $tab( 'rooms', 'Rooms' ) . ' tab.</td></tr>';
	echo '<tr><th>Hide the location, end time or description</th><td>On the event, untick it under <em>Show on the event page</em>. To change it for every event, use ' . $tab( 'settings', 'Settings' ) . '.</td></tr>';
	echo '<tr><th>Use my own title or graphic</th><td>Change it on the event as usual, then tick <em>Title</em> or <em>Graphic</em> under <em>Keep the website\'s version</em>.</td></tr>';
	echo '<tr><th>Write my own description</th><td>On the event, under <em>Description on the event page</em> choose <em>My own text, typed here</em> and type it in the box that opens.</td></tr>';
	echo '<tr><th>Change the Register button</th><td>On the event, under <em>Register button</em>, fill in <em>Button text</em> (and <em>Button link</em>, if it should go somewhere other than Planning Center).</td></tr>';
	echo '<tr><th>Add text, pictures or buttons</th><td>Just add them to the event\'s page like any other page. The sync never touches the page content.</td></tr>';
	echo '<tr><th>Take an event off the website</th><td>On ' . $tab( 'synced', 'On the website' ) . ' press <em>Stop syncing and remove</em>. Or take it off Church Center in Planning Center and it leaves the website at the next check.</td></tr>';
	echo '<tr><th>Show more dates of a repeating event</th><td>On the event, under <em>If this event repeats</em>, set <em>Upcoming dates to keep on the website</em>. The number for all events is on ' . $tab( 'settings', 'Settings' ) . '.</td></tr>';
	echo '<tr><th>Give events without a graphic a picture</th><td>Set the <em>Default graphic</em> on ' . $tab( 'settings', 'Settings' ) . '. It is shown for any event that has none. A change shows on the event cards straight away.</td></tr>';
	echo '<tr><th>Fix a wrong start time</th><td>Fix it in Planning Center. If the website shows an earlier time than the real start, a setup or pre-cool time is marked visible on that event in Planning Center.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>What it is connected to</h2><table>';
	echo '<tr><th>Planning Center</th><td>' . ( '' !== $s['app_id'] && '' !== $s['secret'] ? '<span class="tcc-pill tcc-pill--ok">Connected</span>' : '<span class="tcc-pill tcc-pill--bad">Not connected</span>' ) . ' The website signs in with a <em>Personal Access Token</em> (an Application ID and a Secret), saved on ' . $tab( 'settings', 'Settings' ) . '. A Planning Center administrator makes one at <code>api.planningcenteronline.com/oauth/applications</code>. If it is ever deleted there, the checks fail until a new one is pasted in.</td></tr>';
	echo '<tr><th>The Events Calendar</th><td>' . ( function_exists( 'tribe_create_event' ) ? '<span class="tcc-pill tcc-pill--ok">Active</span>' : '<span class="tcc-pill tcc-pill--bad">Not active</span>' ) . ' The website\'s events plugin. Approved events are saved there as ordinary events, under <strong>Events</strong> in the left menu.</td></tr>';
	echo '<tr><th>The hourly check</th><td>' . ( ! empty( $last['time'] ) ? 'Last ran ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago' : 'Has not run yet' ) . ( $next ? ', next in about ' . esc_html( human_time_diff( time(), max( time(), (int) $next ) ) ) : '' ) . '. The website asks Planning Center for changes about once an hour, using the website\'s scheduled tasks.</td></tr>';
	echo '<tr><th>Updates</th><td>Version ' . esc_html( TCC_PCO_VERSION ) . '. New versions come from <code>github.com/' . esc_html( TCC_PCO_RELEASES ) . '</code> and show on the <strong>Plugins</strong> screen like any other update. No password is stored for this.</td></tr>';
	echo '<tr><th>Media Library</th><td>Each Planning Center graphic is copied in once, with "planning-center" in its file name, and shared by every date of the event.</td></tr>';
	echo '</table></div>';

	echo '<div class="tcc-card"><h2>If something looks wrong</h2><ol>';
	echo '<li><strong>Look at the top of this screen.</strong> A red label means the last check failed; the message under it says why.</li>';
	echo '<li><strong>An event is missing.</strong> Is it set to show in Church Center in Planning Center? Is it sitting under ' . $tab( 'waiting', 'Waiting for approval' ) . ', or in the Hidden list at the bottom of that tab?</li>';
	echo '<li><strong>A change did not come through.</strong> Press <em>Check Planning Center now</em>. If it still does not, look at ' . $tab( 'conflicts', 'Conflicts' ) . ', and check whether that detail is ticked under <em>Keep the website\'s version</em> on the event.</li>';
	echo '<li><strong>Something changed and you do not know why.</strong> ' . $tab( 'changes', 'Recent changes' ) . ' lists what the plugin did and when.</li>';
	echo '<li><strong>An event was removed by mistake.</strong> Removed events go to <strong>Events &rarr; Trash</strong> and can be restored from there.</li>';
	echo '<li><strong>The checks have stopped.</strong> The Dashboard box says so. Pressing <em>Check Planning Center now</em> always works; if the hourly check stays stopped, the website\'s scheduled tasks need looking at by whoever manages the hosting.</li>';
	echo '</ol></div>';

	echo '<div class="tcc-card"><h2>For whoever builds the pages</h2>';
	echo '<p>These short codes can be placed in the event page layout. Each prints nothing when it has nothing to show.</p><table>';
	echo '<tr><th><code>[tcc_pco_description]</code></th><td>The event\'s description (Planning Center\'s, or the text typed on the event).</td></tr>';
	echo '<tr><th><code>[tcc_event_register]</code></th><td>The Register button. Optional: <code>label="Register"</code>.</td></tr>';
	echo '<tr><th><code>[tcc_event_rooms]</code></th><td>The rooms, as small rounded labels.</td></tr>';
	echo '</table><p class="tcc-muted">The technical notes are in the church\'s website repository on GitHub, under <code>plugins/tcc-pco-sync</code> and <code>docs</code>.</p></div>';

	echo '</div>';
}
